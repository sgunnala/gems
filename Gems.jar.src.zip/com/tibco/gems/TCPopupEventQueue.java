package com.tibco.gems;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JFileChooser;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.MenuSelectionManager;
import javax.swing.SwingUtilities;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.text.JTextComponent;

public class TCPopupEventQueue
  extends EventQueue
{
  public JPopupMenu popup;
  public BasicAction cut;
  public BasicAction copy;
  public BasicAction paste;
  public BasicAction selectAll;
  public BasicAction hexbytes;
  public BasicAction asciibytes;
  public BasicAction textAct;
  public BasicAction xmlAct;
  public BasicAction save2csv;
  public BasicAction servprop;
  public BasicAction clear;
  public BasicAction showtotal;
  public BasicAction servtrace;
  public BasicAction purge;
  static File m_currentdir = null;
  
  public void createTextPopupMenu(JTextComponent paramJTextComponent)
  {
    this.cut = new CutAction("Cut", null);
    this.copy = new CopyAction("Copy", null);
    this.paste = new PasteAction("Paste", null);
    this.selectAll = new SelectAllAction("Select All", null);
    this.cut.setTextComponent(paramJTextComponent);
    this.copy.setTextComponent(paramJTextComponent);
    this.paste.setTextComponent(paramJTextComponent);
    this.selectAll.setTextComponent(paramJTextComponent);
    this.popup = new JPopupMenu();
    this.popup.add(this.cut);
    this.popup.add(this.copy);
    this.popup.add(this.paste);
    this.popup.addSeparator();
    this.popup.add(this.selectAll);
    if ((paramJTextComponent instanceof GemsMessageText)) {
      if (((GemsMessageText)paramJTextComponent).getMode() == 1)
      {
        this.popup.addSeparator();
        this.asciibytes = new AsciiBytesAction("View as Text", null);
        this.asciibytes.setTextComponent(paramJTextComponent);
        this.popup.add(this.asciibytes);
      }
      else if (((GemsMessageText)paramJTextComponent).getMode() == 2)
      {
        this.popup.addSeparator();
        this.hexbytes = new HexBytesAction("View as Hex", null);
        this.hexbytes.setTextComponent(paramJTextComponent);
        this.popup.add(this.hexbytes);
      }
      else if (((GemsMessageText)paramJTextComponent).getMode() == 4)
      {
        this.popup.addSeparator();
        this.textAct = new TextAction("View as Text", null);
        this.textAct.setTextComponent(paramJTextComponent);
        this.popup.add(this.textAct);
      }
      else if (((GemsMessageText)paramJTextComponent).getMode() == 3)
      {
        this.popup.addSeparator();
        this.xmlAct = new XmlAction("View as XML", null);
        this.xmlAct.setTextComponent(paramJTextComponent);
        this.popup.add(this.xmlAct);
      }
    }
  }
  
  public void createTablePopupMenu(JTable paramJTable, Object paramObject, int paramInt1, int paramInt2)
  {
    this.copy = new TableCopyAction("Copy Cell", null);
    this.servprop = new TableServerPropertyAction("Set Server Property...", null);
    this.servtrace = new TableServerTraceAction("Set Server Trace...", null);
    this.save2csv = new TableSave2CSVAction("Save Table To CSV File...", null);
    this.purge = null;
    this.copy.setTableComponent(paramJTable, paramObject);
    this.save2csv.setTableComponent(paramJTable, paramObject);
    this.servprop.setTableComponent(paramJTable, paramObject);
    this.popup = new JPopupMenu();
    this.popup.add(this.copy);
    this.popup.addSeparator();
    this.popup.add(this.save2csv);
    if (this.purge != null)
    {
      this.popup.addSeparator();
      this.popup.add(this.purge);
    }
    TableSorter localTableSorter = null;
    if ((paramJTable.getModel() instanceof TableSorter)) {
      localTableSorter = (TableSorter)paramJTable.getModel();
    }
    if ((localTableSorter != null) && (!Gems.getGems().getViewOnlyMode()) && ((localTableSorter.getTableModel() instanceof GemsServerInfoTableModel)))
    {
      this.popup.addSeparator();
      this.popup.add(this.servprop);
      this.popup.add(this.servtrace);
    }
    else if ((paramJTable.getModel() instanceof GemsServerMonitorTableModel))
    {
      this.showtotal = new ShowTotalAction("Show/Hide Totals", null);
      this.showtotal.setTableComponent(paramJTable, paramObject);
      this.popup.addSeparator();
      this.popup.add(this.showtotal);
    }
  }
  
  public void createEventTablePopupMenu(JTable paramJTable, Object paramObject)
  {
    this.copy = new TableCopyAction("Copy Cell", null);
    this.clear = new TableClearEventsAction("Clear Events", null);
    this.copy.setTableComponent(paramJTable, paramObject);
    this.clear.setTableComponent(paramJTable, paramObject);
    this.popup = new JPopupMenu();
    this.popup.add(this.copy);
    this.popup.addSeparator();
    this.popup.add(this.clear);
  }
  
  public void createCheckTablePopupMenu(JTable paramJTable, Object paramObject)
  {
    this.copy = new TableCopyAction("Copy Cell", null);
    this.selectAll = new TableSelectAllAction("Select All", null);
    this.copy.setTableComponent(paramJTable, paramObject);
    this.selectAll.setTableComponent(paramJTable, paramObject);
    this.popup = new JPopupMenu();
    this.popup.add(this.copy);
    this.popup.addSeparator();
    this.popup.add(this.selectAll);
  }
  
  public void showPopup(Component paramComponent, MouseEvent paramMouseEvent)
  {
    this.popup.validate();
    this.popup.show(paramComponent, paramMouseEvent.getX(), paramMouseEvent.getY());
  }
  
  protected void dispatchEvent(AWTEvent paramAWTEvent)
  {
    super.dispatchEvent(paramAWTEvent);
    if (!(paramAWTEvent instanceof MouseEvent)) {
      return;
    }
    MouseEvent localMouseEvent = (MouseEvent)paramAWTEvent;
    if (!localMouseEvent.isPopupTrigger()) {
      return;
    }
    Component localComponent = SwingUtilities.getDeepestComponentAt((Component)localMouseEvent.getSource(), localMouseEvent.getX(), localMouseEvent.getY());
    if (localComponent == null) {
      return;
    }
    Point localPoint1 = localMouseEvent.getPoint();
    Point localPoint2 = localMouseEvent.getComponent().getLocation();
    Point localPoint3 = localComponent.getLocationOnScreen();
    localPoint3.translate((int)-localPoint2.getX(), (int)-localPoint2.getY());
    localPoint1.translate((int)-localPoint3.getX(), (int)-localPoint3.getY());
    int i = 0;
    Object localObject = null;
    int j = 0;
    int k = 0;
    if ((localComponent instanceof JTable))
    {
      i = 1;
      k = ((JTable)localComponent).columnAtPoint(localPoint1);
      j = ((JTable)localComponent).rowAtPoint(localPoint1);
      localObject = ((JTable)localComponent).getModel().getValueAt(j, k);
      if (localObject != null) {}
    }
    else if (!(localComponent instanceof JTextComponent))
    {
      return;
    }
    if (MenuSelectionManager.defaultManager().getSelectedPath().length > 0) {
      return;
    }
    if (i != 0)
    {
      TableSorter localTableSorter = null;
      if ((((JTable)localComponent).getModel() instanceof TableSorter)) {
        localTableSorter = (TableSorter)((JTable)localComponent).getModel();
      }
      if ((localTableSorter != null) && ((localTableSorter.getTableModel() instanceof GemsDestTableModel)))
      {
        createCheckTablePopupMenu((JTable)localComponent, localObject);
      }
      else
      {
        PopupHandler localPopupHandler;
        if ((((JTable)localComponent).getModel() instanceof GetPopupHandler))
        {
          localPopupHandler = ((GetPopupHandler)((JTable)localComponent).getModel()).getPopupHandler();
          this.popup = localPopupHandler.createPopup(localPoint1);
        }
        else if ((localTableSorter != null) && ((localTableSorter.getTableModel() instanceof GetPopupHandler)))
        {
          localPopupHandler = ((GetPopupHandler)localTableSorter.getTableModel()).getPopupHandler();
          this.popup = localPopupHandler.createPopup(localPoint1);
        }
        else
        {
          createTablePopupMenu((JTable)localComponent, localObject, j, k);
        }
      }
    }
    else
    {
      ((JTextComponent)localComponent).grabFocus();
      createTextPopupMenu((JTextComponent)localComponent);
    }
    showPopup((Component)localMouseEvent.getSource(), localMouseEvent);
  }
  
  public class TableClearEventsAction
    extends TCPopupEventQueue.BasicAction
  {
    int row;
    
    public TableClearEventsAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      TableSorter localTableSorter = (TableSorter)this.tabcomp.getModel();
      Gems.getGems().clearCurrentEventsDisplay();
    }
  }
  
  public class TablePurgeQueueAction
    extends TCPopupEventQueue.BasicAction
  {
    int row;
    
    public TablePurgeQueueAction(String paramString, Icon paramIcon, int paramInt)
    {
      super(paramString, paramIcon);
      this.row = paramInt;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      TableSorter localTableSorter = (TableSorter)this.tabcomp.getModel();
      System.err.println(localTableSorter.getTableModel().getValueAt(this.row, 0));
    }
  }
  
  public class TableSelectAllAction
    extends TCPopupEventQueue.BasicAction
  {
    public TableSelectAllAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl A"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      TableSorter localTableSorter = (TableSorter)this.tabcomp.getModel();
      Object localObject;
      if ((localTableSorter.getTableModel() instanceof GemsDestTableModel))
      {
        localObject = (GemsDestTableModel)localTableSorter.getTableModel();
        ((GemsDestTableModel)localObject).selectAllRows();
      }
      else if ((localTableSorter.getTableModel() instanceof GemsMessageTableModel))
      {
        localObject = (GemsMessageTableModel)localTableSorter.getTableModel();
        ((GemsMessageTableModel)localObject).selectAllRows();
      }
    }
  }
  
  public class TableSave2CSVAction
    extends TCPopupEventQueue.BasicAction
  {
    public TableSave2CSVAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        TableModel localTableModel = this.tabcomp.getModel();
        JFileChooser localJFileChooser = new JFileChooser(TCPopupEventQueue.m_currentdir);
        localJFileChooser.setApproveButtonText("Save");
        localJFileChooser.setDialogTitle("Save Table To CSV File");
        int i = localJFileChooser.showOpenDialog(this.tabcomp);
        TCPopupEventQueue.m_currentdir = localJFileChooser.getCurrentDirectory();
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          localFile.createNewFile();
          FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
          PrintWriter localPrintWriter = new PrintWriter(localFileOutputStream);
          int j = localTableModel.getColumnCount();
          int k = localTableModel.getRowCount();
          StringBuffer localStringBuffer = new StringBuffer();
          Object localObject;
          for (int m = 0; m < j; m++)
          {
            localObject = this.tabcomp.getColumnModel().getColumn(m);
            localStringBuffer.append(((TableColumn)localObject).getHeaderValue());
            if (m + 1 < j) {
              localStringBuffer.append(Gems.getGems().getCSVFileDelimiter());
            }
          }
          if ((localStringBuffer.charAt(0) == 'I') && (localStringBuffer.charAt(1) == 'D')) {
            localPrintWriter.print('\'');
          }
          localPrintWriter.println(localStringBuffer.toString());
          for (m = 0; m < k; m++)
          {
            localObject = new StringBuffer();
            for (int n = 0; n < j; n++)
            {
              ((StringBuffer)localObject).append(localTableModel.getValueAt(m, n));
              if (n + 1 < j) {
                ((StringBuffer)localObject).append(Gems.getGems().getCSVFileDelimiter());
              }
            }
            localPrintWriter.println(((StringBuffer)localObject).toString());
          }
          localPrintWriter.close();
        }
      }
      catch (IOException localIOException)
      {
        System.err.println("JavaIOException: " + localIOException.getMessage());
        return;
      }
    }
    
    public boolean isEnabled()
    {
      return this.tabcomp != null;
    }
  }
  
  public class TableCopyAction
    extends TCPopupEventQueue.BasicAction
  {
    public TableCopyAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      StringSelection localStringSelection = new StringSelection(this.v.toString());
      Toolkit.getDefaultToolkit().getSystemClipboard().setContents(localStringSelection, localStringSelection);
    }
    
    public boolean isEnabled()
    {
      return this.tabcomp != null;
    }
  }
  
  public class ShowTotalAction
    extends TCPopupEventQueue.BasicAction
  {
    public ShowTotalAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Gems.getGems().setShowTotals(!Gems.getGems().getShowTotals());
    }
    
    public boolean isEnabled()
    {
      return this.tabcomp != null;
    }
  }
  
  public class TableServerTraceAction
    extends TCPopupEventQueue.BasicAction
  {
    public TableServerTraceAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Gems.getGems().getTreeModel().setServerTrace();
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class TableServerPropertyAction
    extends TCPopupEventQueue.BasicAction
  {
    public TableServerPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Gems.getGems().getTreeModel().serverPanelDoubleClick((String)this.v);
    }
    
    public boolean isEnabled()
    {
      return this.v != null;
    }
  }
  
  public class SelectAllAction
    extends TCPopupEventQueue.BasicAction
  {
    public SelectAllAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl A"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.selectAll();
    }
    
    public boolean isEnabled()
    {
      return (this.txtcomp != null) && (this.txtcomp.isEnabled()) && (this.txtcomp.getText().length() > 0) && ((this.txtcomp.getSelectedText() == null) || (this.txtcomp.getSelectedText().length() < this.txtcomp.getText().length()));
    }
  }
  
  public class PasteAction
    extends TCPopupEventQueue.BasicAction
  {
    public PasteAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl V"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.paste();
    }
    
    public boolean isEnabled()
    {
      Transferable localTransferable = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
      return (this.txtcomp != null) && (this.txtcomp.isEnabled()) && (this.txtcomp.isEditable()) && (localTransferable.isDataFlavorSupported(DataFlavor.stringFlavor));
    }
  }
  
  public class CopyAction
    extends TCPopupEventQueue.BasicAction
  {
    public CopyAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl C"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.copy();
    }
    
    public boolean isEnabled()
    {
      return (this.txtcomp != null) && (this.txtcomp.getSelectedText() != null);
    }
  }
  
  public class CutAction
    extends TCPopupEventQueue.BasicAction
  {
    public CutAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl X"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.cut();
    }
    
    public boolean isEnabled()
    {
      return (this.txtcomp != null) && (this.txtcomp.isEditable()) && (this.txtcomp.getSelectedText() != null);
    }
  }
  
  public abstract class BasicAction
    extends AbstractAction
  {
    JTextComponent txtcomp;
    JTable tabcomp;
    Object v;
    
    public BasicAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
      putValue("ShortDescription", paramString);
    }
    
    public void setTextComponent(JTextComponent paramJTextComponent)
    {
      this.txtcomp = paramJTextComponent;
    }
    
    public void setTableComponent(JTable paramJTable, Object paramObject)
    {
      this.tabcomp = paramJTable;
      this.v = paramObject;
    }
    
    public abstract void actionPerformed(ActionEvent paramActionEvent);
  }
  
  public class AsciiBytesAction
    extends TCPopupEventQueue.BasicAction
  {
    public AsciiBytesAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (this.txtcomp != null) {
        ((GemsMessageText)this.txtcomp).setMode(2);
      }
    }
    
    public boolean isEnabled()
    {
      return this.txtcomp != null;
    }
  }
  
  public class HexBytesAction
    extends TCPopupEventQueue.BasicAction
  {
    public HexBytesAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      ((GemsMessageText)this.txtcomp).setMode(1);
    }
    
    public boolean isEnabled()
    {
      return this.txtcomp != null;
    }
  }
  
  public class XmlAction
    extends TCPopupEventQueue.BasicAction
  {
    public XmlAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      ((GemsMessageText)this.txtcomp).setMode(4);
    }
    
    public boolean isEnabled()
    {
      return this.txtcomp != null;
    }
  }
  
  public class TextAction
    extends TCPopupEventQueue.BasicAction
  {
    public TextAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      ((GemsMessageText)this.txtcomp).setMode(3);
    }
    
    public boolean isEnabled()
    {
      return this.txtcomp != null;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\TCPopupEventQueue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */