package com.tibco.gems;

import com.tibco.tibjms.Tibjms;
import com.tibco.tibjms.TibjmsTopicConnectionFactory;
import com.tibco.tibjms.admin.TibjmsAdmin;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;
import javax.swing.Timer;
import javax.swing.table.JTableHeader;
import javax.swing.text.DefaultEditorKit.CopyAction;
import javax.swing.text.DefaultEditorKit.CutAction;
import javax.swing.text.DefaultEditorKit.PasteAction;

public class GemsTopicSubscriber
  extends JFrame
{
  JFrame m_frame;
  JPanel m_panel;
  boolean m_running = false;
  int m_msgs = 0;
  int m_maxMsgs = 10;
  Message m_msg = null;
  TibjmsAdmin m_admin = null;
  TopicSession m_session = null;
  GemsConnectionNode m_cn;
  TopicConnection m_connection = null;
  TopicSubscriber m_subscriber = null;
  Timer m_timer = new Timer(Gems.getGems().getMsgReadDelay(), new RefreshTimerAction());
  protected JTextField m_conn;
  protected JTextField m_topic;
  protected JButton m_destwiz;
  protected JTextField m_msgsRead;
  protected JTextField m_msgsDisplay;
  protected JTextField m_selector;
  protected JButton m_startButton;
  protected JButton m_stopButton;
  protected JCheckBox m_noLimit;
  JTable m_table;
  protected GemsMessageTableModel m_tableModel;
  protected boolean m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
  protected JMenuItem m_optMenuItem;
  protected JMenuItem m_dumpMenuItem;
  TableSorter m_sorter;
  protected boolean m_isMonitorTopic = false;
  protected boolean m_isMonitorQueue = false;
  protected boolean m_isMonitor = false;
  
  public GemsTopicSubscriber(GemsConnectionNode paramGemsConnectionNode, String paramString1, String paramString2)
  {
    super(Gems.getGems().getTitlePrefix() + paramString2);
    setLocation(400, 175);
    setDefaultCloseOperation(2);
    this.m_frame = this;
    this.m_cn = paramGemsConnectionNode;
    if (paramString1 == null) {
      paramString1 = new String();
    }
    if (paramString1.startsWith("$sys.monitor.Q")) {
      this.m_isMonitorQueue = true;
    } else if (paramString1.startsWith("$sys.monitor.T")) {
      this.m_isMonitorTopic = true;
    } else if (paramString1.startsWith("$sys.monitor")) {
      this.m_isMonitor = true;
    }
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    JLabel localJLabel2 = new JLabel("Topic Name:", 11);
    this.m_topic = new JTextField(paramString1, 20);
    if (this.m_isMonitor) {
      this.m_topic.setEnabled(false);
    }
    localJLabel2.setLabelFor(this.m_topic);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_topic);
    this.m_destwiz = new JButton("...");
    this.m_destwiz.setPreferredSize(new Dimension(18, 16));
    this.m_destwiz.addActionListener(new DestinationWizardAction());
    if (this.m_isMonitor) {
      this.m_destwiz.setEnabled(false);
    }
    localJPanel3.add(this.m_destwiz);
    localJPanel2.add(localJPanel3);
    JLabel localJLabel3 = new JLabel("Selector:", 11);
    this.m_selector = new JTextField("", 20);
    localJLabel3.setLabelFor(this.m_selector);
    localJPanel2.add(localJLabel3);
    localJPanel2.add(this.m_selector);
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    JLabel localJLabel4 = new JLabel("Msgs to Read:", 11);
    this.m_msgsRead = new JTextField("10", 20);
    this.m_msgsRead.setMinimumSize(new Dimension(40, 24));
    localJLabel4.setLabelFor(this.m_msgsRead);
    localJPanel2.add(localJLabel4);
    localJPanel4.add(this.m_msgsRead);
    this.m_noLimit = new JCheckBox("No Limit", false);
    localJPanel4.add(this.m_noLimit);
    localJPanel2.add(localJPanel4);
    this.m_tableModel = new GemsMessageTableModel(false, false);
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setSelectionMode(0);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(650, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel5 = new JPanel(true);
    localJPanel5.setLayout(new BoxLayout(localJPanel5, 0));
    Component localComponent = Box.createRigidArea(new Dimension(250, 10));
    localJPanel5.add(localComponent);
    this.m_startButton = new JButton("Start");
    this.m_startButton.addActionListener(new StartPressed());
    this.m_stopButton = new JButton("Stop");
    this.m_stopButton.addActionListener(new StopPressed());
    this.m_stopButton.setEnabled(false);
    localJPanel5.add(this.m_startButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel5.add(localComponent);
    localJPanel5.add(this.m_stopButton);
    localJPanel1.add(localJPanel5, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 4, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    pack();
    show();
  }
  
  public void start()
  {
    this.m_running = true;
    this.m_msgs = 0;
    this.m_topic.setEnabled(false);
    this.m_msgsRead.setEnabled(false);
    this.m_startButton.setEnabled(false);
    this.m_stopButton.setEnabled(true);
    this.m_noLimit.setEnabled(false);
    this.m_selector.setEnabled(false);
    this.m_destwiz.setEnabled(false);
    this.m_optMenuItem.setEnabled(false);
    this.m_dumpMenuItem.setEnabled(false);
    try
    {
      this.m_maxMsgs = Integer.parseInt(this.m_msgsRead.getText());
    }
    catch (Exception localException)
    {
      this.m_maxMsgs = 10;
    }
    if (this.m_topic.getText().startsWith("$sys.monitor.")) {
      this.m_tableModel.buildMonitorColumnHeaders(!this.m_isMonitor);
    } else {
      this.m_tableModel.buildColumnHeaders();
    }
    try
    {
      TibjmsTopicConnectionFactory localTibjmsTopicConnectionFactory = new TibjmsTopicConnectionFactory(this.m_cn.m_url, null, this.m_cn.m_sslParams);
      this.m_connection = localTibjmsTopicConnectionFactory.createTopicConnection(this.m_cn.m_user, this.m_cn.m_password);
      this.m_session = this.m_connection.createTopicSession(false, 1);
      Topic localTopic = this.m_session.createTopic(this.m_topic.getText());
      if ((this.m_selector != null) && (this.m_selector.getText().length() > 0)) {
        this.m_subscriber = this.m_session.createSubscriber(localTopic, this.m_selector.getText(), false);
      } else {
        this.m_subscriber = this.m_session.createSubscriber(localTopic);
      }
      this.m_connection.start();
      this.m_timer.start();
    }
    catch (JMSException localJMSException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localJMSException.getMessage(), "Error", 1);
      stop();
    }
  }
  
  public void stop()
  {
    this.m_timer.stop();
    this.m_running = false;
    try
    {
      if (this.m_subscriber != null)
      {
        this.m_subscriber.close();
        this.m_subscriber = null;
      }
      if (this.m_session != null)
      {
        this.m_session.close();
        this.m_session = null;
      }
      if (this.m_connection != null)
      {
        this.m_connection.close();
        this.m_connection = null;
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("Exception: " + localJMSException.getMessage());
    }
    if (!this.m_isMonitor) {
      this.m_topic.setEnabled(true);
    }
    this.m_msgsRead.setEnabled(true);
    this.m_startButton.setEnabled(true);
    this.m_stopButton.setEnabled(false);
    this.m_noLimit.setEnabled(true);
    this.m_selector.setEnabled(true);
    if (!this.m_isMonitor) {
      this.m_destwiz.setEnabled(true);
    }
    this.m_optMenuItem.setEnabled(true);
    this.m_dumpMenuItem.setEnabled(true);
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          GemsTopicSubscriber.this.showMessageFrame();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    this.m_dumpMenuItem = new JMenuItem("Save Messages To File...");
    this.m_dumpMenuItem.addActionListener(new DumpToFile());
    localJMenu.add(this.m_dumpMenuItem);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsTopicSubscriber.this.dispose();
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CutAction());
    localJMenuItem.setText("Cut");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CopyAction());
    localJMenuItem.setText("Copy");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(67, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.PasteAction());
    localJMenuItem.setText("Paste");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(86, 2));
    localJMenu.add(localJMenuItem);
    localJMenu.addSeparator();
    this.m_optMenuItem = localJMenu.add(new JMenuItem("Options..."));
    this.m_optMenuItem.addActionListener(new EditOptionsAction());
    localJMenuBar.add(localJMenu);
    localJMenu = new JMenu("Message");
    localJMenu.setMnemonic(77);
    localJMenuBar.add(localJMenu);
    if ((this.m_isMonitorQueue) || (this.m_isMonitorTopic) || (this.m_isMonitor)) {
      localJMenuItem = localJMenu.add(new JMenuItem("View Monitor Message..."));
    } else {
      localJMenuItem = localJMenu.add(new JMenuItem("View Message..."));
    }
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsTopicSubscriber.this.showMessageFrame();
      }
    });
    if ((this.m_isMonitorQueue) || (this.m_isMonitorTopic))
    {
      localJMenuItem = localJMenu.add(new JMenuItem("View Original Message..."));
      localJMenuItem.addActionListener(new ActionListener()
      {
        public void actionPerformed(ActionEvent paramAnonymousActionEvent)
        {
          GemsTopicSubscriber.this.showOrigMessageFrame();
        }
      });
    }
    return localJMenuBar;
  }
  
  public void showMessageFrame()
  {
    Message localMessage = this.m_tableModel.getSelectedMessage();
    if (localMessage != null)
    {
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, null, true, null, this.m_topic.getText().startsWith("$sys.monitor."));
      localGemsMessageFrame.populate(localMessage);
    }
    else
    {
      JOptionPane.showMessageDialog(this.m_frame, "Select a Message to view!", "View Message", 1);
    }
  }
  
  public void showOrigMessageFrame()
  {
    Message localMessage1 = this.m_tableModel.getSelectedMessage();
    if ((localMessage1 != null) && ((localMessage1 instanceof MapMessage)))
    {
      try
      {
        MapMessage localMapMessage = (MapMessage)localMessage1;
        if (localMapMessage.itemExists("message_bytes"))
        {
          Message localMessage2 = Tibjms.createFromBytes(localMapMessage.getBytes("message_bytes"));
          GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, null, false, null, false);
          localGemsMessageFrame.populate(localMessage2);
          return;
        }
      }
      catch (Exception localException) {}
      JOptionPane.showMessageDialog(null, "There is no original message associated with this monitor message", "Error", 1);
    }
    else
    {
      JOptionPane.showMessageDialog(this.m_frame, "Select a Message to view!", "View Message", 1);
    }
  }
  
  public void dispose()
  {
    stop();
    super.dispose();
  }
  
  class DumpToFile
    implements ActionListener
  {
    DumpToFile() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        JFileChooser localJFileChooser = new JFileChooser();
        localJFileChooser.setApproveButtonText("Save");
        localJFileChooser.setDialogTitle("Save Messages To File (appends)");
        int i = localJFileChooser.showOpenDialog(GemsTopicSubscriber.this.m_frame);
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          GemsTopicSubscriber.this.m_tableModel.dumpMsgsToFile(localFile);
        }
      }
      catch (IOException localIOException)
      {
        JOptionPane.showMessageDialog(GemsTopicSubscriber.this.m_frame, localIOException.getMessage(), "Error", 1);
        return;
      }
    }
  }
  
  class DestinationWizardAction
    implements ActionListener
  {
    DestinationWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsTopicSubscriber.this.m_frame, GemsTopicSubscriber.this.m_cn, GemsTopicSubscriber.this.m_isMonitorQueue ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null) {
        if (GemsTopicSubscriber.this.m_isMonitorQueue) {
          GemsTopicSubscriber.this.m_topic.setText("$sys.monitor.Q.*." + localGemsDestinationPicker.m_retDest.m_destName);
        } else if (GemsTopicSubscriber.this.m_isMonitorTopic) {
          GemsTopicSubscriber.this.m_topic.setText("$sys.monitor.T.*." + localGemsDestinationPicker.m_retDest.m_destName);
        } else {
          GemsTopicSubscriber.this.m_topic.setText(localGemsDestinationPicker.m_retDest.m_destName);
        }
      }
    }
  }
  
  class EditOptionsAction
    implements ActionListener
  {
    EditOptionsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      new GemsBrowserOptionsDialog(GemsTopicSubscriber.this.m_frame, "Edit Options");
      GemsTopicSubscriber.this.m_timer.setDelay(Gems.getGems().getMsgReadDelay());
      GemsTopicSubscriber.this.m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
    }
  }
  
  class StopPressed
    implements ActionListener
  {
    StopPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTopicSubscriber.this.stop();
    }
  }
  
  class StartPressed
    implements ActionListener
  {
    StartPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTopicSubscriber.this.start();
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsTopicSubscriber.this.m_running) {
        try
        {
          Message localMessage = GemsTopicSubscriber.this.m_subscriber.receiveNoWait();
          if (localMessage != null)
          {
            if (GemsTopicSubscriber.this.m_topic.getText().startsWith("$sys.monitor.")) {
              GemsTopicSubscriber.this.m_tableModel.addMonitorMessage(localMessage, GemsTopicSubscriber.this.m_viewoldestFirst, !GemsTopicSubscriber.this.m_isMonitor);
            } else {
              GemsTopicSubscriber.this.m_tableModel.addMessage(localMessage, GemsTopicSubscriber.this.m_viewoldestFirst);
            }
            if (!GemsTopicSubscriber.this.m_noLimit.isSelected()) {
              if (++GemsTopicSubscriber.this.m_msgs >= GemsTopicSubscriber.this.m_maxMsgs) {
                GemsTopicSubscriber.this.stop();
              }
            }
          }
        }
        catch (JMSException localJMSException)
        {
          System.err.println("Exception: " + localJMSException.getMessage());
          GemsTopicSubscriber.this.stop();
        }
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsTopicSubscriber.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */