package com.tibco.gems;

import com.tibco.tibjms.admin.ServerInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.PrintStream;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.Timer;
import javax.swing.table.JTableHeader;

public class GemsDestDisplay
  extends JFrame
{
  JFrame m_frame;
  JPanel m_panel;
  GemsConnectionNode m_cn;
  protected String m_type;
  protected JTextField m_conn;
  protected JTextField m_pattern;
  protected JButton m_closeButton;
  protected JButton m_lookup;
  protected boolean m_isQueue;
  protected boolean m_isFirstUpdate = false;
  protected JCheckBoxMenuItem m_autoRefresh = null;
  JTable m_table;
  protected GemsDetailsTableModel m_tableModel;
  TableSorter m_sorter;
  protected Timer m_timer = null;
  
  public GemsDestDisplay(GemsConnectionNode paramGemsConnectionNode, String paramString)
  {
    super(Gems.getGems().getTitlePrefix() + paramString + "s Display");
    setLocation(300, 155);
    setDefaultCloseOperation(2);
    this.m_frame = this;
    this.m_cn = paramGemsConnectionNode;
    this.m_type = paramString;
    if (paramString.equals("Queue")) {
      this.m_isQueue = true;
    } else {
      this.m_isQueue = false;
    }
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    localJPanel3.setMinimumSize(new Dimension(600, 24));
    JLabel localJLabel2 = new JLabel(paramString + " Pattern:", 11);
    this.m_pattern = new JTextField(this.m_isQueue ? Gems.getGems().getQueueNamePattern() : Gems.getGems().getTopicNamePattern(), 32);
    this.m_pattern.addKeyListener(new SubmitListener());
    localJLabel2.setLabelFor(this.m_pattern);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_pattern);
    this.m_lookup = new JButton("Lookup");
    this.m_lookup.addActionListener(new LookupAction());
    localJPanel3.add(this.m_lookup);
    localJPanel2.add(localJPanel3);
    this.m_tableModel = new GemsDetailsTableModel();
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_tableModel.setPopupHandler(new PopupDestDisplayHandler(this.m_table, this.m_tableModel, this.m_cn, this));
    this.m_tableModel.setTable(this.m_table);
    this.m_table.setSelectionMode(0);
    if (!Gems.getGems().getViewOnlyMode()) {
      addMouseListenerToTable(this.m_table);
    }
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(835, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    Component localComponent = Box.createRigidArea(new Dimension(350, 10));
    localJPanel4.add(localComponent);
    this.m_closeButton = new JButton("Close");
    this.m_closeButton.addActionListener(new ClosePressed());
    localJPanel4.add(this.m_closeButton);
    localJPanel1.add(localJPanel4, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 2, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    pack();
    show();
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          GemsDestDisplay.this.editDestProperties();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsDestDisplay.this.dispose();
      }
    });
    if (!Gems.getGems().getViewOnlyMode())
    {
      localJMenu = new JMenu("Edit");
      localJMenu.setMnemonic(69);
      localJMenuBar.add(localJMenu);
      localJMenuItem = new JMenuItem(this.m_type + " Properties...");
      localJMenuItem.addActionListener(new EditPropAction());
      localJMenu.add(localJMenuItem);
    }
    localJMenu = new JMenu("View");
    localJMenu.setMnemonic(86);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("Temporaries"));
    localJMenuItem.addActionListener(new ViewTempsAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Refresh"));
    localJMenuItem.addActionListener(new RefreshAction());
    this.m_autoRefresh = new JCheckBoxMenuItem("Auto Refresh");
    if (Gems.getGems().getDisplayRefresh() > 0)
    {
      localJMenuItem = localJMenu.add(this.m_autoRefresh);
      this.m_autoRefresh.setState(true);
    }
    else
    {
      this.m_autoRefresh.setState(false);
    }
    return localJMenuBar;
  }
  
  public void editDestProperties()
  {
    String str = this.m_tableModel.getSelectedCol1();
    GemsDestPropEditor localGemsDestPropEditor = new GemsDestPropEditor(this.m_frame, this.m_cn, this.m_type, str);
  }
  
  public void lookupDestinations()
  {
    if (this.m_timer != null) {
      this.m_timer.stop();
    }
    this.m_tableModel.setRowCount(0);
    this.m_tableModel.setColumnCount(0);
    ServerInfo localServerInfo = this.m_cn.getJmsServerInfo(false);
    if (localServerInfo != null)
    {
      int i;
      if (this.m_isQueue)
      {
        if ((localServerInfo.getQueueCount() > Gems.getGems().getMaxQueues()) && (this.m_pattern.getText().equals(">")))
        {
          i = JOptionPane.showConfirmDialog(this, "There are " + localServerInfo.getQueueCount() + " queues, set a pattern to filter the number of queues. \nAre you sure you want to continue?", "Lookup Queues", 0);
          if (i != 0) {
            return;
          }
          this.m_autoRefresh.setState(false);
        }
        else
        {
          this.m_autoRefresh.setState(true);
        }
      }
      else if ((localServerInfo.getTopicCount() > Gems.getGems().getMaxTopics()) && (this.m_pattern.getText().equals(">")))
      {
        i = JOptionPane.showConfirmDialog(this, "There are " + localServerInfo.getTopicCount() + " topics, set a pattern to filter the number of queues. \nAre you sure you want to continue?", "Lookup Topics", 0);
        if (i != 0) {
          return;
        }
        this.m_autoRefresh.setState(false);
      }
      else
      {
        this.m_autoRefresh.setState(true);
      }
      this.m_isFirstUpdate = true;
      if (Gems.getGems().getDisplayRefresh() == 0) {
        this.m_autoRefresh.setState(false);
      }
      if (this.m_timer == null)
      {
        this.m_timer = new Timer(Gems.getGems().getDisplayRefresh() * 1000 + 1000, new RefreshTimerAction());
        this.m_timer.setInitialDelay(50);
        this.m_timer.start();
      }
      else
      {
        this.m_timer.restart();
      }
    }
  }
  
  public void getDestinations()
  {
    if (this.m_pattern.getText().length() == 0)
    {
      this.m_tableModel.populateErrorInfo("No " + this.m_type + " name pattern configured");
      return;
    }
    if (!this.m_cn.isConnected())
    {
      this.m_tableModel.populateErrorInfo("Not connected to EMS server");
      return;
    }
    try
    {
      int i = 3;
      if (this.m_pattern.getText().startsWith("$TMP$.")) {
        i = 4;
      }
      if (this.m_isQueue) {
        try
        {
          this.m_tableModel.populateQueuesInfo(this.m_cn.getJmsAdmin().getQueues(this.m_pattern.getText(), i));
        }
        catch (Throwable localThrowable1)
        {
          this.m_tableModel.populateQueuesInfo(this.m_cn.getJmsAdmin().getQueues(this.m_pattern.getText()));
        }
      } else {
        try
        {
          this.m_tableModel.populateTopicsInfo(this.m_cn.getJmsAdmin().getTopics(this.m_pattern.getText(), i));
        }
        catch (Throwable localThrowable2)
        {
          this.m_tableModel.populateTopicsInfo(this.m_cn.getJmsAdmin().getTopics(this.m_pattern.getText()));
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      this.m_autoRefresh.setState(false);
      return;
    }
  }
  
  public void dispose()
  {
    super.dispose();
  }
  
  class ViewTempsAction
    implements ActionListener
  {
    ViewTempsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestDisplay.this.m_pattern.setText("$TMP$.>");
      GemsDestDisplay.this.lookupDestinations();
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if ((GemsDestDisplay.this.m_isFirstUpdate) || (GemsDestDisplay.this.m_autoRefresh.getState())) {
        GemsDestDisplay.this.getDestinations();
      }
      GemsDestDisplay.this.m_isFirstUpdate = false;
    }
  }
  
  class RefreshAction
    implements ActionListener
  {
    RefreshAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsDestDisplay.this.m_timer != null)
      {
        GemsDestDisplay.this.m_isFirstUpdate = true;
        GemsDestDisplay.this.m_timer.restart();
      }
    }
  }
  
  class LookupAction
    implements ActionListener
  {
    LookupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestDisplay.this.lookupDestinations();
    }
  }
  
  class EditPropAction
    implements ActionListener
  {
    EditPropAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestDisplay.this.editDestProperties();
    }
  }
  
  public class SubmitListener
    implements KeyListener
  {
    public SubmitListener() {}
    
    public void keyPressed(KeyEvent paramKeyEvent)
    {
      if (paramKeyEvent.getKeyCode() == 10) {
        GemsDestDisplay.this.lookupDestinations();
      }
    }
    
    public void keyReleased(KeyEvent paramKeyEvent) {}
    
    public void keyTyped(KeyEvent paramKeyEvent) {}
  }
  
  class ClosePressed
    implements ActionListener
  {
    ClosePressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestDisplay.this.dispose();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDestDisplay.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */