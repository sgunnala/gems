package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class DateTimePicker
  extends JDialog
  implements ItemListener, MouseListener, FocusListener, KeyListener, ActionListener
{
  private static final String[] MONTHS = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
  private static final String[] DAYS = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
  private static final Color WEEK_DAYS_FOREGROUND = Color.black;
  private static final Color DAYS_FOREGROUND = Color.blue;
  private static final Color SELECTED_DAY_FOREGROUND = Color.white;
  private static final Color SELECTED_DAY_BACKGROUND = Color.blue;
  private static final Border EMPTY_BORDER = BorderFactory.createEmptyBorder(1, 1, 1, 1);
  private static final Border FOCUSED_BORDER = BorderFactory.createLineBorder(Color.yellow, 1);
  private static final int FIRST_YEAR = 1900;
  private static final int LAST_YEAR = 2100;
  private GregorianCalendar calendar;
  private JLabel[][] days;
  private FocusablePanel daysGrid;
  private JComboBox month;
  private JComboBox year;
  private JComboBox hour;
  private JComboBox minute;
  private JComboBox second;
  private JButton previousMonth;
  private JButton nextMonth;
  private JButton ok;
  private JButton cancel;
  private int offset;
  private int lastDay;
  private JLabel day;
  private boolean okClicked;
  
  private void construct()
  {
    this.calendar = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
    this.month = new JComboBox(MONTHS);
    this.month.addItemListener(this);
    this.year = new JComboBox();
    for (int i = 1900; i <= 2100; i++) {
      this.year.addItem(Integer.toString(i));
    }
    this.year.addItemListener(this);
    this.previousMonth = new JButton("<<");
    this.previousMonth.addActionListener(this);
    this.nextMonth = new JButton(">>");
    this.nextMonth.addActionListener(this);
    this.days = new JLabel[7][7];
    for (i = 0; i < 7; i++)
    {
      this.days[0][i] = new JLabel(DAYS[i], 4);
      this.days[0][i].setForeground(WEEK_DAYS_FOREGROUND);
    }
    for (i = 1; i < 7; i++) {
      for (j = 0; j < 7; j++)
      {
        this.days[i][j] = new JLabel(" ", 4);
        this.days[i][j].setForeground(DAYS_FOREGROUND);
        this.days[i][j].setBackground(SELECTED_DAY_BACKGROUND);
        this.days[i][j].setBorder(EMPTY_BORDER);
        this.days[i][j].addMouseListener(this);
      }
    }
    String[] arrayOfString1 = new String[24];
    for (int j = 0; j < 24; j++) {
      if (j < 10) {
        arrayOfString1[j] = ("0" + j);
      } else {
        arrayOfString1[j] = Integer.toString(j);
      }
    }
    String[] arrayOfString2 = new String[60];
    for (int k = 0; k < 60; k++) {
      if (k < 10) {
        arrayOfString2[k] = ("0" + k);
      } else {
        arrayOfString2[k] = Integer.toString(k);
      }
    }
    this.hour = new JComboBox(arrayOfString1);
    this.hour.addItemListener(this);
    this.minute = new JComboBox(arrayOfString2);
    this.minute.addItemListener(this);
    this.second = new JComboBox(arrayOfString2);
    this.second.addItemListener(this);
    this.ok = new JButton("Ok");
    this.ok.addActionListener(this);
    this.cancel = new JButton("Cancel");
    this.cancel.addActionListener(this);
    JPanel localJPanel1 = new JPanel();
    localJPanel1.add(this.previousMonth);
    localJPanel1.add(this.month);
    localJPanel1.add(this.year);
    localJPanel1.add(this.nextMonth);
    this.daysGrid = new FocusablePanel(new GridLayout(7, 7, 5, 0));
    this.daysGrid.addFocusListener(this);
    this.daysGrid.addKeyListener(this);
    for (int m = 0; m < 7; m++) {
      for (int n = 0; n < 7; n++) {
        this.daysGrid.add(this.days[m][n]);
      }
    }
    this.daysGrid.setBackground(Color.white);
    this.daysGrid.setBorder(BorderFactory.createLoweredBevelBorder());
    JPanel localJPanel2 = new JPanel();
    localJPanel2.add(this.daysGrid);
    GridLayout localGridLayout = new GridLayout(2, 3);
    localGridLayout.setHgap(10);
    JPanel localJPanel3 = new JPanel(localGridLayout);
    JLabel localJLabel1 = new JLabel("Hour");
    localJLabel1.setHorizontalAlignment(0);
    JLabel localJLabel2 = new JLabel("Minute");
    localJLabel2.setHorizontalAlignment(0);
    JLabel localJLabel3 = new JLabel("Second");
    localJLabel3.setHorizontalAlignment(0);
    localJPanel3.add(localJLabel1);
    localJPanel3.add(localJLabel2);
    localJPanel3.add(localJLabel3);
    localJPanel3.add(this.hour);
    localJPanel3.add(this.minute);
    localJPanel3.add(this.second);
    JPanel localJPanel4 = new JPanel();
    localJPanel4.add(this.ok);
    localJPanel4.add(this.cancel);
    JPanel localJPanel5 = new JPanel(new BorderLayout());
    localJPanel5.add(localJPanel3, "North");
    localJPanel5.add(localJPanel4, "South");
    Container localContainer = getContentPane();
    localContainer.setLayout(new BorderLayout());
    localContainer.add(localJPanel1, "North");
    localContainer.add(localJPanel2, "Center");
    localContainer.add(localJPanel5, "South");
    pack();
    setResizable(false);
  }
  
  private int getSelectedDay()
  {
    if (this.day == null) {
      return -1;
    }
    try
    {
      return Integer.parseInt(this.day.getText());
    }
    catch (NumberFormatException localNumberFormatException) {}
    return -1;
  }
  
  private int getSelectedHour()
  {
    if (this.hour == null) {
      return -1;
    }
    try
    {
      return Integer.parseInt(this.hour.getSelectedItem().toString());
    }
    catch (NumberFormatException localNumberFormatException) {}
    return -1;
  }
  
  private int getSelectedMinute()
  {
    if (this.minute == null) {
      return -1;
    }
    try
    {
      return Integer.parseInt(this.minute.getSelectedItem().toString());
    }
    catch (NumberFormatException localNumberFormatException) {}
    return -1;
  }
  
  private int getSelectedSecond()
  {
    if (this.second == null) {
      return -1;
    }
    try
    {
      return Integer.parseInt(this.second.getSelectedItem().toString());
    }
    catch (NumberFormatException localNumberFormatException) {}
    return -1;
  }
  
  private void setSelected(JLabel paramJLabel)
  {
    if (this.day != null)
    {
      this.day.setForeground(DAYS_FOREGROUND);
      this.day.setOpaque(false);
      this.day.setBorder(EMPTY_BORDER);
    }
    this.day = paramJLabel;
    this.day.setForeground(SELECTED_DAY_FOREGROUND);
    this.day.setOpaque(true);
    if (this.daysGrid.hasFocus()) {
      this.day.setBorder(FOCUSED_BORDER);
    }
  }
  
  private void setSelected(int paramInt)
  {
    setSelected(this.days[((paramInt + this.offset - 1) / 7 + 1)][((paramInt + this.offset - 1) % 7)]);
  }
  
  private void update()
  {
    int i = getSelectedDay();
    for (int j = 0; j < 7; j++)
    {
      this.days[1][j].setText(" ");
      this.days[5][j].setText(" ");
      this.days[6][j].setText(" ");
    }
    this.calendar.set(5, 1);
    this.calendar.set(2, this.month.getSelectedIndex() + 0);
    this.calendar.set(1, this.year.getSelectedIndex() + 1900);
    this.offset = (this.calendar.get(7) - 1);
    this.lastDay = this.calendar.getActualMaximum(5);
    for (j = 0; j < this.lastDay; j++) {
      this.days[((j + this.offset) / 7 + 1)][((j + this.offset) % 7)].setText(String.valueOf(j + 1));
    }
    if (i != -1)
    {
      if (i > this.lastDay) {
        i = this.lastDay;
      }
      setSelected(i);
    }
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (paramActionEvent.getSource() == this.ok)
    {
      this.okClicked = true;
      setVisible(false);
    }
    else
    {
      int i;
      int j;
      if (paramActionEvent.getSource() == this.previousMonth)
      {
        if (this.month.getSelectedIndex() == 0)
        {
          i = 11;
          j = this.year.getSelectedIndex() - 1;
          this.month.setSelectedIndex(i);
          this.year.setSelectedIndex(j);
        }
        else
        {
          i = this.month.getSelectedIndex() - 1;
          this.month.setSelectedIndex(i);
        }
        update();
      }
      else if (paramActionEvent.getSource() == this.nextMonth)
      {
        if (this.month.getSelectedIndex() == 11)
        {
          i = 0;
          j = this.year.getSelectedIndex() + 1;
          this.month.setSelectedIndex(i);
          this.year.setSelectedIndex(j);
        }
        else
        {
          i = this.month.getSelectedIndex() + 1;
          this.month.setSelectedIndex(i);
        }
        update();
      }
      else if (paramActionEvent.getSource() == this.cancel)
      {
        setVisible(false);
      }
    }
  }
  
  public void focusGained(FocusEvent paramFocusEvent)
  {
    setSelected(this.day);
  }
  
  public void focusLost(FocusEvent paramFocusEvent)
  {
    setSelected(this.day);
  }
  
  public void itemStateChanged(ItemEvent paramItemEvent)
  {
    update();
  }
  
  public void keyPressed(KeyEvent paramKeyEvent)
  {
    int i = getSelectedDay();
    switch (paramKeyEvent.getKeyCode())
    {
    case 37: 
      if (i > 1) {
        setSelected(i - 1);
      }
      break;
    case 39: 
      if (i < this.lastDay) {
        setSelected(i + 1);
      }
      break;
    case 38: 
      if (i > 7) {
        setSelected(i - 7);
      }
      break;
    case 40: 
      if (i <= this.lastDay - 7) {
        setSelected(i + 7);
      }
      break;
    }
  }
  
  public void mouseClicked(MouseEvent paramMouseEvent)
  {
    JLabel localJLabel = (JLabel)paramMouseEvent.getSource();
    if (!localJLabel.getText().equals(" ")) {
      setSelected(localJLabel);
    }
    this.daysGrid.requestFocus();
  }
  
  public void keyReleased(KeyEvent paramKeyEvent) {}
  
  public void keyTyped(KeyEvent paramKeyEvent) {}
  
  public void mouseEntered(MouseEvent paramMouseEvent) {}
  
  public void mouseExited(MouseEvent paramMouseEvent) {}
  
  public void mousePressed(MouseEvent paramMouseEvent) {}
  
  public void mouseReleased(MouseEvent paramMouseEvent) {}
  
  public DateTimePicker(Dialog paramDialog, String paramString)
  {
    super(paramDialog, paramString, true);
    construct();
  }
  
  public DateTimePicker(Dialog paramDialog)
  {
    super(paramDialog, true);
    construct();
  }
  
  public DateTimePicker(Frame paramFrame, String paramString)
  {
    super(paramFrame, paramString, true);
    construct();
  }
  
  public DateTimePicker(Frame paramFrame)
  {
    super(paramFrame, true);
    construct();
  }
  
  public Date select(Date paramDate)
  {
    this.calendar.setTime(paramDate);
    this.calendar.setTimeZone(TimeZone.getDefault());
    int i = this.calendar.get(5);
    int j = this.calendar.get(2);
    int k = this.calendar.get(1);
    int m = this.calendar.get(11);
    int n = this.calendar.get(12);
    int i1 = this.calendar.get(13);
    this.year.setSelectedIndex(k - 1900);
    this.month.setSelectedIndex(j - 0);
    this.hour.setSelectedIndex(m);
    this.minute.setSelectedIndex(n);
    this.second.setSelectedIndex(i1);
    setSelected(i);
    this.okClicked = false;
    setVisible(true);
    if (!this.okClicked) {
      return null;
    }
    this.calendar.set(5, getSelectedDay());
    this.calendar.set(2, this.month.getSelectedIndex() + 0);
    this.calendar.set(1, this.year.getSelectedIndex() + 1900);
    this.calendar.set(11, getSelectedHour());
    this.calendar.set(12, getSelectedMinute());
    this.calendar.set(13, getSelectedSecond());
    return this.calendar.getTime();
  }
  
  public Date select()
  {
    return select(new Date());
  }
  
  private static class FocusablePanel
    extends JPanel
  {
    public FocusablePanel(LayoutManager paramLayoutManager)
    {
      super();
    }
    
    public boolean isFocusTraversable()
    {
      return true;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\DateTimePicker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */