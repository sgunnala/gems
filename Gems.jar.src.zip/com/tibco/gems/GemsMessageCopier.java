package com.tibco.gems;

import com.tibco.tibjms.Tibjms;
import com.tibco.tibjms.TibjmsQueueConnectionFactory;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.Session;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.Timer;

public class GemsMessageCopier
  extends JDialog
{
  JFrame m_frame;
  JPanel m_panel;
  boolean m_running = false;
  Session m_session = null;
  GemsConnectionNode m_cn;
  QueueConnection m_connection = null;
  Timer m_timer = new Timer(100, new RefreshTimerAction());
  protected JComboBox m_conn;
  protected JComboBox m_type;
  protected JTextField m_dest;
  protected JTextArea m_results;
  protected JButton m_startButton;
  protected JButton m_stopButton;
  protected JButton m_lookup;
  protected Hashtable m_connTable;
  protected Vector m_msgs;
  int m_msgsNum = 0;
  Destination m_jmsdest = null;
  MessageProducer m_msgProducer = null;
  
  public GemsMessageCopier(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, Vector paramVector)
  {
    super(paramJFrame, "Copy Selected Messages To:", true);
    setLocationRelativeTo(paramJFrame);
    setDefaultCloseOperation(2);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_msgs = paramVector;
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    this.m_connTable = GemsConnectionNode.getConnections();
    JLabel localJLabel1 = new JLabel("EMS Server:", 11);
    this.m_conn = new JComboBox();
    Enumeration localEnumeration = this.m_connTable.keys();
    ArrayList localArrayList = new ArrayList();
    while (localEnumeration.hasMoreElements())
    {
      localObject = (String)localEnumeration.nextElement();
      localArrayList.add(localObject);
      Collections.sort(localArrayList);
      this.m_conn.insertItemAt(localObject, localArrayList.indexOf(localObject));
      if (((String)localObject).startsWith(paramGemsConnectionNode.getName())) {
        this.m_conn.setSelectedItem(localObject);
      }
    }
    if (this.m_conn.getSelectedItem() == null) {
      this.m_conn.setSelectedIndex(0);
    }
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    Object localObject = new JLabel("Destination Type:", 11);
    this.m_type = new JComboBox();
    this.m_type.addItem("Queue");
    this.m_type.addItem("Topic");
    this.m_type.setMaximumSize(new Dimension(0, 24));
    ((JLabel)localObject).setLabelFor(this.m_type);
    localJPanel2.add((Component)localObject);
    localJPanel2.add(this.m_type);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    localJPanel3.setMinimumSize(new Dimension(300, 24));
    JLabel localJLabel2 = new JLabel("Destination Name:", 11);
    this.m_dest = new JTextField("", 32);
    localJLabel2.setLabelFor(this.m_dest);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_dest);
    this.m_lookup = new JButton("LookUp...");
    this.m_lookup.addActionListener(new LookupAction());
    localJPanel3.add(this.m_lookup);
    localJPanel2.add(localJPanel3);
    this.m_results = new JTextArea("");
    this.m_results.setEditable(false);
    JScrollPane localJScrollPane = new JScrollPane(this.m_results);
    localJScrollPane.setPreferredSize(new Dimension(430, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    Component localComponent = Box.createRigidArea(new Dimension(175, 10));
    localJPanel4.add(localComponent);
    this.m_startButton = new JButton("Start");
    this.m_startButton.addActionListener(new StartPressed());
    this.m_stopButton = new JButton("Stop");
    this.m_stopButton.setEnabled(false);
    this.m_stopButton.addActionListener(new StopPressed());
    localJPanel4.add(this.m_startButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel4.add(localComponent);
    localJPanel4.add(this.m_stopButton);
    localJPanel1.add(localJPanel4, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 3, 2, 5, 5, 5, 5);
    pack();
    show();
  }
  
  public void start()
  {
    if (this.m_dest.getText().length() == 0)
    {
      JOptionPane.showMessageDialog(this, "Enter a destination to copy to", "Error", 1);
      return;
    }
    this.m_running = true;
    this.m_conn.setEnabled(false);
    this.m_type.setEnabled(false);
    this.m_startButton.setEnabled(false);
    this.m_stopButton.setEnabled(true);
    this.m_dest.setEnabled(false);
    this.m_results.setText("");
    try
    {
      GemsConnectionNode localGemsConnectionNode = (GemsConnectionNode)this.m_connTable.get(this.m_conn.getSelectedItem());
      this.m_results.append("Connecting to: " + this.m_conn.getSelectedItem() + "\n");
      TibjmsQueueConnectionFactory localTibjmsQueueConnectionFactory = new TibjmsQueueConnectionFactory(localGemsConnectionNode.m_url, null, localGemsConnectionNode.m_sslParams);
      this.m_connection = localTibjmsQueueConnectionFactory.createQueueConnection(localGemsConnectionNode.m_user, localGemsConnectionNode.m_password);
      this.m_results.append("Creating transacted session\n");
      this.m_session = this.m_connection.createSession(true, 1);
      if (this.m_type.getSelectedItem().equals("Queue"))
      {
        this.m_results.append("Creating producer to queue: " + this.m_dest.getText() + "\n");
        this.m_jmsdest = this.m_session.createQueue(this.m_dest.getText());
      }
      else
      {
        this.m_results.append("Creating producer to topic: " + this.m_dest.getText() + "\n");
        this.m_jmsdest = this.m_session.createTopic(this.m_dest.getText());
      }
      this.m_msgProducer = this.m_session.createProducer(null);
      this.m_connection.start();
      this.m_msgsNum = this.m_msgs.size();
      this.m_timer.start();
    }
    catch (Exception localException)
    {
      this.m_results.append("Exception: " + localException.getMessage() + "\n");
      stop();
    }
  }
  
  public void stop()
  {
    this.m_timer.stop();
    this.m_running = false;
    try
    {
      if (this.m_session != null)
      {
        this.m_session.close();
        this.m_session = null;
      }
      if (this.m_connection != null)
      {
        this.m_connection.close();
        this.m_connection = null;
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("Exception: " + localJMSException.getMessage());
    }
    this.m_dest.setEnabled(true);
    this.m_startButton.setEnabled(true);
    this.m_stopButton.setEnabled(false);
    this.m_conn.setEnabled(true);
    this.m_type.setEnabled(true);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsMessageCopier.this.dispose();
      }
    });
    return localJMenuBar;
  }
  
  public void dispose()
  {
    stop();
    super.dispose();
  }
  
  class LookupAction
    implements ActionListener
  {
    LookupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = (GemsConnectionNode)GemsMessageCopier.this.m_connTable.get(GemsMessageCopier.this.m_conn.getSelectedItem());
      if (localGemsConnectionNode == null) {
        return;
      }
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsMessageCopier.this.m_frame, localGemsConnectionNode, GemsMessageCopier.this.m_type.getSelectedItem().equals("Queue") ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null) {
        GemsMessageCopier.this.m_dest.setText(localGemsDestinationPicker.m_retDest.m_destName);
      }
    }
  }
  
  class StopPressed
    implements ActionListener
  {
    StopPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageCopier.this.stop();
    }
  }
  
  class StartPressed
    implements ActionListener
  {
    StartPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageCopier.this.start();
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsMessageCopier.this.m_running) {
        try
        {
          if (GemsMessageCopier.this.m_msgsNum <= 0)
          {
            GemsMessageCopier.this.m_results.append("Commiting messages \n");
            GemsMessageCopier.this.m_session.commit();
            GemsMessageCopier.this.m_results.append("Done\n");
            GemsMessageCopier.this.stop();
          }
          else
          {
            Message localMessage1 = (Message)GemsMessageCopier.this.m_msgs.elementAt(--GemsMessageCopier.this.m_msgsNum);
            GemsMessageCopier.this.m_results.append("Copying message: " + localMessage1.getJMSMessageID() + "\n");
            Message localMessage2 = Tibjms.createFromBytes(Tibjms.getAsBytes(localMessage1));
            if (localMessage1 != null)
            {
              GemsMessageCopier.this.m_msgProducer.send(GemsMessageCopier.this.m_jmsdest, localMessage2, localMessage1.getJMSDeliveryMode(), localMessage1.getJMSPriority(), localMessage1.getJMSExpiration());
              GemsMessageCopier.this.m_results.append("Message sent as: " + localMessage2.getJMSMessageID() + "\n");
            }
          }
        }
        catch (JMSException localJMSException1)
        {
          GemsMessageCopier.this.m_results.append("Exception: " + localJMSException1.getMessage() + "\n");
          GemsMessageCopier.this.m_results.append("Rolling back");
          try
          {
            GemsMessageCopier.this.m_session.rollback();
          }
          catch (JMSException localJMSException2)
          {
            GemsMessageCopier.this.m_results.append("Exception: " + localJMSException2.getMessage() + "\n");
          }
          GemsMessageCopier.this.stop();
        }
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsMessageCopier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */