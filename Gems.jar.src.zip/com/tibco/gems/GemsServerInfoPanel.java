package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class GemsServerInfoPanel
  extends JPanel
{
  protected GemsServerInfoTableModel m_tableModel;
  JTable m_table;
  TableSorter m_sorter;
  
  public GemsServerInfoPanel()
  {
    super(true);
    setLayout(new BorderLayout());
    this.m_tableModel = new GemsServerInfoTableModel();
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_tableModel.setTable(this.m_table);
    if (!Gems.getGems().getViewOnlyMode()) {
      addMouseListenerToTable(this.m_table);
    }
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    add(localJScrollPane, "Center");
  }
  
  GemsServerInfoTableModel getModel()
  {
    return this.m_tableModel;
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          Gems.getGems().getTreeModel().serverPanelDoubleClick(GemsServerInfoPanel.this.m_tableModel.getSelectedCol1());
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsServerInfoPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */