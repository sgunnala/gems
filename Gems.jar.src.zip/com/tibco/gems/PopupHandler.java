package com.tibco.gems;

import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.text.JTextComponent;

public class PopupHandler
{
  public JPopupMenu createPopup(Point paramPoint)
  {
    JPopupMenu localJPopupMenu = new JPopupMenu();
    return localJPopupMenu;
  }
  
  public class SelectAllAction
    extends PopupHandler.TextAction
  {
    public SelectAllAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl A"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.selectAll();
    }
    
    public boolean isEnabled()
    {
      return (this.txtcomp != null) && (this.txtcomp.isEnabled()) && (this.txtcomp.getText().length() > 0) && ((this.txtcomp.getSelectedText() == null) || (this.txtcomp.getSelectedText().length() < this.txtcomp.getText().length()));
    }
  }
  
  public class PasteAction
    extends PopupHandler.TextAction
  {
    public PasteAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl V"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.paste();
    }
    
    public boolean isEnabled()
    {
      Transferable localTransferable = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
      return (this.txtcomp != null) && (this.txtcomp.isEnabled()) && (this.txtcomp.isEditable()) && (localTransferable.isDataFlavorSupported(DataFlavor.stringFlavor));
    }
  }
  
  public class CopyAction
    extends PopupHandler.TextAction
  {
    public CopyAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl C"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.copy();
    }
    
    public boolean isEnabled()
    {
      return (this.txtcomp != null) && (this.txtcomp.getSelectedText() != null);
    }
  }
  
  public class CutAction
    extends PopupHandler.TextAction
  {
    public CutAction(String paramString, Icon paramIcon)
    {
      super(paramString, paramIcon);
      putValue("AcceleratorKey", KeyStroke.getKeyStroke("ctrl X"));
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      this.txtcomp.cut();
    }
    
    public boolean isEnabled()
    {
      return (this.txtcomp != null) && (this.txtcomp.isEditable()) && (this.txtcomp.getSelectedText() != null);
    }
  }
  
  public abstract class TextAction
    extends AbstractAction
  {
    JTextComponent txtcomp;
    
    public TextAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
      putValue("ShortDescription", paramString);
    }
    
    public void setTextComponent(JTextComponent paramJTextComponent)
    {
      this.txtcomp = paramJTextComponent;
    }
    
    public abstract void actionPerformed(ActionEvent paramActionEvent);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\PopupHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */