package com.tibco.gems;

import java.awt.Component;
import java.awt.Container;
import java.io.PrintStream;
import javax.swing.Spring;
import javax.swing.SpringLayout;
import javax.swing.SpringLayout.Constraints;

public class SpringUtilities
{
  public static void printSizes(Component paramComponent)
  {
    System.out.println("minimumSize = " + paramComponent.getMinimumSize());
    System.out.println("preferredSize = " + paramComponent.getPreferredSize());
    System.out.println("maximumSize = " + paramComponent.getMaximumSize());
  }
  
  public static void makeGrid(Container paramContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    SpringLayout localSpringLayout;
    try
    {
      localSpringLayout = (SpringLayout)paramContainer.getLayout();
    }
    catch (ClassCastException localClassCastException)
    {
      System.err.println("The first argument to makeGrid must use SpringLayout.");
      return;
    }
    Spring localSpring1 = Spring.constant(paramInt5);
    Spring localSpring2 = Spring.constant(paramInt6);
    Spring localSpring3 = Spring.constant(paramInt3);
    Spring localSpring4 = Spring.constant(paramInt4);
    int i = paramInt1 * paramInt2;
    Spring localSpring5 = localSpringLayout.getConstraints(paramContainer.getComponent(0)).getWidth();
    Spring localSpring6 = localSpringLayout.getConstraints(paramContainer.getComponent(0)).getWidth();
    for (int j = 1; j < i; j++)
    {
      localObject2 = localSpringLayout.getConstraints(paramContainer.getComponent(j));
      localSpring5 = Spring.max(localSpring5, ((SpringLayout.Constraints)localObject2).getWidth());
      localSpring6 = Spring.max(localSpring6, ((SpringLayout.Constraints)localObject2).getHeight());
    }
    for (j = 0; j < i; j++)
    {
      localObject2 = localSpringLayout.getConstraints(paramContainer.getComponent(j));
      ((SpringLayout.Constraints)localObject2).setWidth(localSpring5);
      ((SpringLayout.Constraints)localObject2).setHeight(localSpring6);
    }
    Object localObject1 = null;
    Object localObject2 = null;
    for (int k = 0; k < i; k++)
    {
      SpringLayout.Constraints localConstraints2 = localSpringLayout.getConstraints(paramContainer.getComponent(k));
      if (k % paramInt2 == 0)
      {
        localObject2 = localObject1;
        localConstraints2.setX(localSpring3);
      }
      else
      {
        localConstraints2.setX(Spring.sum(((SpringLayout.Constraints)localObject1).getConstraint("East"), localSpring1));
      }
      if (k / paramInt2 == 0) {
        localConstraints2.setY(localSpring4);
      } else {
        localConstraints2.setY(Spring.sum(((SpringLayout.Constraints)localObject2).getConstraint("South"), localSpring2));
      }
      localObject1 = localConstraints2;
    }
    SpringLayout.Constraints localConstraints1 = localSpringLayout.getConstraints(paramContainer);
    localConstraints1.setConstraint("South", Spring.sum(Spring.constant(paramInt6), ((SpringLayout.Constraints)localObject1).getConstraint("South")));
    localConstraints1.setConstraint("East", Spring.sum(Spring.constant(paramInt5), ((SpringLayout.Constraints)localObject1).getConstraint("East")));
  }
  
  private static SpringLayout.Constraints getConstraintsForCell(int paramInt1, int paramInt2, Container paramContainer, int paramInt3)
  {
    SpringLayout localSpringLayout = (SpringLayout)paramContainer.getLayout();
    Component localComponent = paramContainer.getComponent(paramInt1 * paramInt3 + paramInt2);
    return localSpringLayout.getConstraints(localComponent);
  }
  
  public static void makeCompactGrid(Container paramContainer, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6)
  {
    SpringLayout localSpringLayout;
    try
    {
      localSpringLayout = (SpringLayout)paramContainer.getLayout();
    }
    catch (ClassCastException localClassCastException)
    {
      System.err.println("The first argument to makeCompactGrid must use SpringLayout.");
      return;
    }
    Spring localSpring1 = Spring.constant(paramInt3);
    for (int i = 0; i < paramInt2; i++)
    {
      Spring localSpring3 = Spring.constant(0);
      for (int k = 0; k < paramInt1; k++) {
        localSpring3 = Spring.max(localSpring3, getConstraintsForCell(k, i, paramContainer, paramInt2).getWidth());
      }
      for (k = 0; k < paramInt1; k++)
      {
        SpringLayout.Constraints localConstraints2 = getConstraintsForCell(k, i, paramContainer, paramInt2);
        localConstraints2.setX(localSpring1);
        localConstraints2.setWidth(localSpring3);
      }
      localSpring1 = Spring.sum(localSpring1, Spring.sum(localSpring3, Spring.constant(paramInt5)));
    }
    Spring localSpring2 = Spring.constant(paramInt4);
    for (int j = 0; j < paramInt1; j++)
    {
      Spring localSpring4 = Spring.constant(0);
      for (int m = 0; m < paramInt2; m++) {
        localSpring4 = Spring.max(localSpring4, getConstraintsForCell(j, m, paramContainer, paramInt2).getHeight());
      }
      for (m = 0; m < paramInt2; m++)
      {
        SpringLayout.Constraints localConstraints3 = getConstraintsForCell(j, m, paramContainer, paramInt2);
        localConstraints3.setY(localSpring2);
        localConstraints3.setHeight(localSpring4);
      }
      localSpring2 = Spring.sum(localSpring2, Spring.sum(localSpring4, Spring.constant(paramInt6)));
    }
    SpringLayout.Constraints localConstraints1 = localSpringLayout.getConstraints(paramContainer);
    localConstraints1.setConstraint("South", localSpring2);
    localConstraints1.setConstraint("East", localSpring1);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\SpringUtilities.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */