package com.tibco.gems;

import com.tibco.tibjms.TibjmsConnectionFactory;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Hashtable;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TemporaryQueue;
import javax.jms.TemporaryTopic;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;
import javax.swing.Timer;
import javax.swing.table.JTableHeader;
import javax.swing.text.DefaultEditorKit.CopyAction;
import javax.swing.text.DefaultEditorKit.CutAction;
import javax.swing.text.DefaultEditorKit.PasteAction;

public class GemsReqReplyTester
  extends JFrame
{
  GemsReqReplyTester m_frame;
  JPanel m_panel;
  boolean m_running = false;
  int m_msgCount = 0;
  int m_msgSeq = 0;
  int m_maxMsgs = 10;
  Session m_session = null;
  Session m_replysession = null;
  GemsConnectionNode m_cn;
  Connection m_connection = null;
  MessageProducer m_producer = null;
  MessageConsumer m_consumer = null;
  Destination m_requestDestination = null;
  Destination m_replyDestination = null;
  String m_destination = null;
  Timer m_timer = null;
  Timer m_stoptimer = null;
  SyncThread m_thread = null;
  protected JTextField m_conn;
  protected JTextField m_reqDest;
  protected JTextField m_msgsSend;
  protected JTextField m_delay;
  protected JComboBox m_mode;
  protected JComboBox m_msgType;
  protected JButton m_destwiz;
  protected JButton m_msgwiz;
  protected JButton m_startButton;
  protected JButton m_stopButton;
  protected JCheckBox m_noDelay;
  protected GemsMessageFrame m_textMsgFrame;
  protected GemsMessageFrame m_mapMsgFrame;
  JTable m_table;
  protected GemsMessageTableModel m_tableModel;
  protected boolean m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
  protected long m_RRTimeout = Gems.getGems().getRequestReplyTimeout() * 1000;
  protected JMenuItem m_optMenuItem;
  protected JMenuItem m_dumpMenuItem;
  TableSorter m_sorter;
  boolean m_isQueue = true;
  Mutex m_mutex = new Mutex();
  public Hashtable m_pending = new Hashtable();
  
  public GemsReqReplyTester(GemsConnectionNode paramGemsConnectionNode, String paramString1, boolean paramBoolean, String paramString2)
  {
    super(Gems.getGems().getTitlePrefix() + paramString2);
    setLocation(400, 175);
    setDefaultCloseOperation(2);
    this.m_frame = this;
    this.m_cn = paramGemsConnectionNode;
    this.m_isQueue = paramBoolean;
    this.m_destination = paramString1;
    String str;
    if (paramBoolean) {
      str = "Queue";
    } else {
      str = "Topic";
    }
    this.m_mapMsgFrame = new GemsMessageFrame(this.m_cn, true, paramString1, this.m_isQueue, this.m_frame, false, true, true);
    this.m_textMsgFrame = new GemsMessageFrame(this.m_cn, true, paramString1, this.m_isQueue, this.m_frame, false, false, true);
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    JLabel localJLabel2 = new JLabel("Request " + str + " Name:", 11);
    this.m_reqDest = new JTextField(paramString1, 20);
    localJLabel2.setLabelFor(this.m_reqDest);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_reqDest);
    this.m_destwiz = new JButton("...");
    this.m_destwiz.setPreferredSize(new Dimension(18, 16));
    this.m_destwiz.addActionListener(new DestinationWizardAction());
    localJPanel3.add(this.m_destwiz);
    localJPanel2.add(localJPanel3);
    JLabel localJLabel3 = new JLabel("Mode:", 11);
    this.m_mode = new JComboBox();
    for (Object localObject3 : MODE_TYPE.values()) {
      this.m_mode.addItem(localObject3);
    }
    localJLabel3.setLabelFor(this.m_mode);
    localJPanel2.add(localJLabel3);
    localJPanel2.add(this.m_mode);
    ??? = new JPanel(true);
    ((JPanel)???).setLayout(new BoxLayout((Container)???, 0));
    JLabel localJLabel4 = new JLabel("Request Message:", 11);
    this.m_msgType = new JComboBox();
    for (localObject4 : MSG_TYPE.values()) {
      this.m_msgType.addItem(localObject4);
    }
    localJLabel4.setLabelFor(this.m_msgType);
    localJPanel2.add(localJLabel4);
    this.m_msgwiz = new JButton("...");
    this.m_msgwiz.setPreferredSize(new Dimension(18, 16));
    this.m_msgwiz.addActionListener(new MessageWizardAction());
    ((JPanel)???).add(this.m_msgType);
    ((JPanel)???).add(this.m_msgwiz);
    localJPanel2.add((Component)???);
    ??? = new JLabel("Requests to Send:", 11);
    this.m_msgsSend = new JTextField("10", 20);
    this.m_msgsSend.setMinimumSize(new Dimension(40, 24));
    ((JLabel)???).setLabelFor(this.m_msgsSend);
    localJPanel2.add((Component)???);
    localJPanel2.add(this.m_msgsSend);
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    JLabel localJLabel5 = new JLabel("Delay Between Sends(ms):", 11);
    this.m_delay = new JTextField("200", 20);
    this.m_delay.setMinimumSize(new Dimension(40, 24));
    localJPanel4.setPreferredSize(new Dimension(100, 24));
    localJLabel5.setLabelFor(this.m_delay);
    localJPanel2.add(localJLabel5);
    localJPanel4.add(this.m_delay);
    this.m_noDelay = new JCheckBox("None", false);
    localJPanel4.add(this.m_noDelay);
    localJPanel2.add(localJPanel4);
    this.m_tableModel = new GemsMessageTableModel(false, false);
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setSelectionMode(0);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    Object localObject4 = new JScrollPane(this.m_table);
    ((JScrollPane)localObject4).setPreferredSize(new Dimension(480, 300));
    localJPanel1.add((Component)localObject4, "Center");
    JPanel localJPanel5 = new JPanel(true);
    localJPanel5.setLayout(new BoxLayout(localJPanel5, 0));
    Component localComponent = Box.createRigidArea(new Dimension(280, 10));
    localJPanel5.add(localComponent);
    this.m_startButton = new JButton("Start");
    this.m_startButton.addActionListener(new StartPressed());
    this.m_stopButton = new JButton("Stop");
    this.m_stopButton.addActionListener(new StopPressed());
    this.m_stopButton.setEnabled(false);
    localJPanel5.add(this.m_startButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel5.add(localComponent);
    localJPanel5.add(this.m_stopButton);
    localJPanel1.add(localJPanel5, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 3, 4, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    pack();
    show();
  }
  
  public void start()
  {
    this.m_running = true;
    this.m_msgCount = 0;
    this.m_reqDest.setEnabled(false);
    this.m_msgsSend.setEnabled(false);
    this.m_startButton.setEnabled(false);
    this.m_stopButton.setEnabled(true);
    this.m_noDelay.setEnabled(false);
    this.m_delay.setEnabled(false);
    this.m_mode.setEnabled(false);
    this.m_msgType.setEnabled(false);
    this.m_destwiz.setEnabled(false);
    this.m_msgwiz.setEnabled(false);
    this.m_optMenuItem.setEnabled(false);
    this.m_dumpMenuItem.setEnabled(false);
    int i = 0;
    try
    {
      this.m_maxMsgs = Integer.parseInt(this.m_msgsSend.getText());
      i = Integer.parseInt(this.m_delay.getText());
    }
    catch (Exception localException1)
    {
      this.m_maxMsgs = 10;
      i = 200;
    }
    if (this.m_noDelay.isSelected()) {
      i = 0;
    }
    this.m_tableModel.buildRequestReplyColumnHeaders();
    if ((this.m_reqDest.getText() == null) || (this.m_reqDest.getText().length() == 0))
    {
      stop();
      return;
    }
    try
    {
      TibjmsConnectionFactory localTibjmsConnectionFactory = new TibjmsConnectionFactory(this.m_cn.m_url, null, this.m_cn.m_sslParams);
      this.m_connection = localTibjmsConnectionFactory.createConnection(this.m_cn.m_user, this.m_cn.m_password);
      this.m_session = this.m_connection.createSession(false, 22);
      if (this.m_isQueue)
      {
        this.m_requestDestination = this.m_session.createQueue(this.m_reqDest.getText());
        if (this.m_mode.getSelectedItem() == MODE_TYPE.Asynchronous) {
          this.m_replyDestination = this.m_session.createTemporaryQueue();
        }
      }
      else
      {
        this.m_requestDestination = this.m_session.createTopic(this.m_reqDest.getText());
        if (this.m_mode.getSelectedItem() == MODE_TYPE.Asynchronous) {
          this.m_replyDestination = this.m_session.createTemporaryTopic();
        }
      }
      if (this.m_mode.getSelectedItem() == MODE_TYPE.Asynchronous)
      {
        this.m_consumer = this.m_session.createConsumer(this.m_replyDestination);
        this.m_consumer.setMessageListener(new OnAsyncReplyMessage());
      }
      this.m_producer = this.m_session.createProducer(null);
      this.m_connection.start();
      if (this.m_mode.getSelectedItem() == MODE_TYPE.Asynchronous)
      {
        if (this.m_timer == null) {
          this.m_timer = new Timer(i, new RefreshTimerAction());
        } else {
          this.m_timer.setDelay(i);
        }
        this.m_timer.setInitialDelay(200);
        this.m_timer.start();
      }
      else
      {
        this.m_thread = new SyncThread(i);
        this.m_thread.start();
      }
    }
    catch (Exception localException2)
    {
      JOptionPane.showMessageDialog(this.m_frame, localException2.getMessage(), "Error", 1);
      stop();
    }
  }
  
  public void stop()
  {
    if (!this.m_running) {
      return;
    }
    try
    {
      this.m_thread = null;
      if (this.m_timer != null) {
        this.m_timer.stop();
      }
      this.m_running = false;
      if (this.m_consumer != null)
      {
        this.m_consumer.close();
        this.m_consumer = null;
      }
      if (this.m_replyDestination != null)
      {
        if (this.m_isQueue) {
          ((TemporaryQueue)this.m_replyDestination).delete();
        } else {
          ((TemporaryTopic)this.m_replyDestination).delete();
        }
        this.m_replyDestination = null;
      }
      if (this.m_producer != null)
      {
        this.m_producer.close();
        this.m_producer = null;
      }
      if (this.m_session != null)
      {
        this.m_session.close();
        this.m_session = null;
      }
      if (this.m_connection != null)
      {
        this.m_connection.close();
        this.m_connection = null;
      }
      this.m_reqDest.setEnabled(true);
      this.m_msgsSend.setEnabled(true);
      this.m_startButton.setEnabled(true);
      this.m_stopButton.setEnabled(false);
      this.m_noDelay.setEnabled(true);
      this.m_delay.setEnabled(true);
      this.m_mode.setEnabled(true);
      this.m_destwiz.setEnabled(true);
      this.m_msgwiz.setEnabled(true);
      this.m_msgType.setEnabled(true);
      this.m_optMenuItem.setEnabled(true);
      this.m_dumpMenuItem.setEnabled(true);
      this.m_mutex.acquire();
      this.m_pending.clear();
      this.m_mutex.release();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
  }
  
  public void updateByTimer(Message paramMessage1, Message paramMessage2)
  {
    Timer localTimer = new Timer(0, new UpdateTimerAction(paramMessage1, paramMessage2));
    localTimer.setRepeats(false);
    localTimer.start();
  }
  
  public void stopByTimer()
  {
    if (this.m_stoptimer == null) {
      this.m_stoptimer = new Timer(0, new StopTimerAction());
    }
    this.m_stoptimer.setRepeats(false);
    this.m_stoptimer.start();
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          GemsReqReplyTester.this.showReplyMessageFrame();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    this.m_dumpMenuItem = new JMenuItem("Save Messages To File...");
    this.m_dumpMenuItem.addActionListener(new DumpToFile());
    localJMenu.add(this.m_dumpMenuItem);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsReqReplyTester.this.dispose();
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CutAction());
    localJMenuItem.setText("Cut");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CopyAction());
    localJMenuItem.setText("Copy");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(67, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.PasteAction());
    localJMenuItem.setText("Paste");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(86, 2));
    localJMenu.add(localJMenuItem);
    localJMenu.addSeparator();
    this.m_optMenuItem = localJMenu.add(new JMenuItem("Options..."));
    this.m_optMenuItem.addActionListener(new EditOptionsAction());
    localJMenuBar.add(localJMenu);
    localJMenu = new JMenu("View");
    localJMenu.setMnemonic(86);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("View Selected Request Message..."));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsReqReplyTester.this.showRequestMessageFrame();
      }
    });
    localJMenuItem = localJMenu.add(new JMenuItem("View Selected Reply Message..."));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsReqReplyTester.this.showReplyMessageFrame();
      }
    });
    return localJMenuBar;
  }
  
  public void showReplyMessageFrame()
  {
    Message localMessage = this.m_tableModel.getSelectedReplyMessage();
    if (localMessage != null)
    {
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, null, true, null, false);
      localGemsMessageFrame.populate(localMessage);
    }
    else
    {
      JOptionPane.showMessageDialog(this.m_frame, "There is no reply Message to view!", "View Reply Message", 1);
    }
  }
  
  public void showRequestMessageFrame()
  {
    Message localMessage = this.m_tableModel.getSelectedMessage();
    if (localMessage != null)
    {
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, null, true, null, false);
      localGemsMessageFrame.populate(localMessage);
    }
    else
    {
      JOptionPane.showMessageDialog(this.m_frame, "Select a Message to view!", "View Request Message", 1);
    }
  }
  
  public void dispose()
  {
    stop();
    super.dispose();
  }
  
  class DumpToFile
    implements ActionListener
  {
    DumpToFile() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        JFileChooser localJFileChooser = new JFileChooser();
        localJFileChooser.setApproveButtonText("Save");
        localJFileChooser.setDialogTitle("Save Messages To File (appends)");
        int i = localJFileChooser.showOpenDialog(GemsReqReplyTester.this.m_frame);
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          GemsReqReplyTester.this.m_tableModel.dumpMsgsToFile(localFile);
        }
      }
      catch (IOException localIOException)
      {
        JOptionPane.showMessageDialog(GemsReqReplyTester.this.m_frame, localIOException.getMessage(), "Error", 1);
        return;
      }
    }
  }
  
  class OnAsyncReplyMessage
    implements MessageListener
  {
    OnAsyncReplyMessage() {}
    
    public void onMessage(Message paramMessage)
    {
      try
      {
        if (paramMessage == null) {
          return;
        }
        String str = paramMessage.getJMSCorrelationID();
        if ((str == null) || (str.length() == 0))
        {
          System.err.println("GemsReqReplyTester.onAsyncReplyMessage: JMSCorrelationID not returned by receiver, try using Synch mode");
          return;
        }
        GemsReqReplyTester.this.m_mutex.acquire();
        Message localMessage = (Message)GemsReqReplyTester.this.m_pending.remove(str);
        GemsReqReplyTester.this.m_mutex.release();
        if (localMessage == null)
        {
          System.err.println("GemsReqReplyTester.onAsyncReplyMessage: No pending message for CID: " + str);
          return;
        }
        GemsReqReplyTester.this.m_tableModel.updateRequestMessage(localMessage, paramMessage);
      }
      catch (JMSException localJMSException)
      {
        Gems.debug("GemsReqReplyTester.onAsyncReplyMessage: Exception: " + localJMSException.toString());
      }
      catch (InterruptedException localInterruptedException)
      {
        Gems.debug("GemsReqReplyTester.onRespMessage: Exception: " + localInterruptedException.toString());
      }
    }
  }
  
  class MessageWizardAction
    implements ActionListener
  {
    MessageWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsReqReplyTester.this.m_msgType.getSelectedItem() == GemsReqReplyTester.MSG_TYPE.TextMessage)
      {
        if (GemsReqReplyTester.this.m_textMsgFrame == null) {
          GemsReqReplyTester.this.m_textMsgFrame = new GemsMessageFrame(GemsReqReplyTester.this.m_cn, true, GemsReqReplyTester.this.m_destination, GemsReqReplyTester.this.m_isQueue, GemsReqReplyTester.this.m_frame, false, false, true);
        }
        GemsReqReplyTester.this.m_textMsgFrame.show();
      }
      else
      {
        if (GemsReqReplyTester.this.m_mapMsgFrame == null) {
          GemsReqReplyTester.this.m_mapMsgFrame = new GemsMessageFrame(GemsReqReplyTester.this.m_cn, true, GemsReqReplyTester.this.m_destination, GemsReqReplyTester.this.m_isQueue, GemsReqReplyTester.this.m_frame, false, true, true);
        }
        GemsReqReplyTester.this.m_mapMsgFrame.show();
      }
    }
  }
  
  class DestinationWizardAction
    implements ActionListener
  {
    DestinationWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsReqReplyTester.this.m_frame, GemsReqReplyTester.this.m_cn, GemsReqReplyTester.this.m_isQueue ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null)
      {
        GemsReqReplyTester.this.m_destination = localGemsDestinationPicker.m_retDest.m_destName;
        GemsReqReplyTester.this.m_reqDest.setText(GemsReqReplyTester.this.m_destination);
      }
    }
  }
  
  class EditOptionsAction
    implements ActionListener
  {
    EditOptionsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      new GemsBrowserOptionsDialog(GemsReqReplyTester.this.m_frame, "Edit Options", false, true, false);
      GemsReqReplyTester.this.m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
      GemsReqReplyTester.this.m_RRTimeout = (Gems.getGems().getRequestReplyTimeout() * 1000);
    }
  }
  
  class StopPressed
    implements ActionListener
  {
    StopPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsReqReplyTester.this.stop();
    }
  }
  
  class StartPressed
    implements ActionListener
  {
    StartPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsReqReplyTester.this.start();
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if ((GemsReqReplyTester.this.m_running) && (GemsReqReplyTester.this.m_msgCount < GemsReqReplyTester.this.m_maxMsgs)) {
        try
        {
          Message localMessage1;
          if (GemsReqReplyTester.this.m_msgType.getSelectedItem() == GemsReqReplyTester.MSG_TYPE.TextMessage) {
            localMessage1 = GemsReqReplyTester.this.m_textMsgFrame.createMessage(GemsReqReplyTester.this.m_session);
          } else {
            localMessage1 = GemsReqReplyTester.this.m_mapMsgFrame.createMessage(GemsReqReplyTester.this.m_session);
          }
          localMessage1.setJMSReplyTo(GemsReqReplyTester.this.m_replyDestination);
          if (GemsReqReplyTester.this.m_mode.getSelectedItem() == GemsReqReplyTester.MODE_TYPE.Synchronous)
          {
            if (GemsReqReplyTester.this.m_isQueue) {
              GemsReqReplyTester.this.m_replyDestination = GemsReqReplyTester.this.m_session.createTemporaryQueue();
            } else {
              GemsReqReplyTester.this.m_replyDestination = GemsReqReplyTester.this.m_session.createTemporaryTopic();
            }
            GemsReqReplyTester.this.m_consumer = GemsReqReplyTester.this.m_session.createConsumer(GemsReqReplyTester.this.m_replyDestination);
          }
          else
          {
            localMessage1.setJMSCorrelationID(String.valueOf(++GemsReqReplyTester.this.m_msgSeq));
          }
          GemsReqReplyTester.this.m_producer.send(GemsReqReplyTester.this.m_requestDestination, localMessage1, localMessage1.getJMSDeliveryMode(), localMessage1.getJMSPriority(), localMessage1.getJMSExpiration());
          GemsReqReplyTester.this.m_msgCount += 1;
          if (GemsReqReplyTester.this.m_mode.getSelectedItem() == GemsReqReplyTester.MODE_TYPE.Asynchronous)
          {
            GemsReqReplyTester.this.m_mutex.acquire();
            GemsReqReplyTester.this.m_pending.put(localMessage1.getJMSCorrelationID(), localMessage1);
            GemsReqReplyTester.this.m_mutex.release();
          }
          GemsReqReplyTester.this.m_tableModel.addRequestMessage(localMessage1, null, GemsReqReplyTester.this.m_viewoldestFirst);
          if (GemsReqReplyTester.this.m_mode.getSelectedItem() == GemsReqReplyTester.MODE_TYPE.Synchronous)
          {
            Message localMessage2 = GemsReqReplyTester.this.m_consumer.receive(GemsReqReplyTester.this.m_RRTimeout);
            if (localMessage2 != null) {
              GemsReqReplyTester.this.m_tableModel.updateRequestMessage(localMessage1, localMessage2);
            } else {
              GemsReqReplyTester.this.m_tableModel.timeoutRequestMessage(localMessage1);
            }
            GemsReqReplyTester.this.m_consumer.close();
            if (GemsReqReplyTester.this.m_isQueue) {
              ((TemporaryQueue)GemsReqReplyTester.this.m_replyDestination).delete();
            } else {
              ((TemporaryTopic)GemsReqReplyTester.this.m_replyDestination).delete();
            }
            GemsReqReplyTester.this.m_replyDestination = null;
            GemsReqReplyTester.this.m_consumer = null;
          }
        }
        catch (JMSException localJMSException)
        {
          System.err.println("Exception: " + localJMSException.getMessage());
          GemsReqReplyTester.this.m_frame.stop();
        }
        catch (InterruptedException localInterruptedException)
        {
          Gems.debug("GemsReqReplyTester.Exception: " + localInterruptedException.toString());
        }
      } else {
        GemsReqReplyTester.this.m_frame.stop();
      }
    }
  }
  
  class StopTimerAction
    implements ActionListener
  {
    StopTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsReqReplyTester.this.m_frame.stop();
    }
  }
  
  class UpdateTimerAction
    implements ActionListener
  {
    Message msg;
    Message rep;
    
    public UpdateTimerAction(Message paramMessage1, Message paramMessage2)
    {
      this.msg = paramMessage1;
      this.rep = paramMessage2;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        GemsReqReplyTester.this.m_frame.m_mutex.acquire();
        if (this.rep != null) {
          GemsReqReplyTester.this.m_frame.m_tableModel.updateRequestMessage(this.msg, this.rep);
        } else {
          GemsReqReplyTester.this.m_frame.m_tableModel.timeoutRequestMessage(this.msg);
        }
        GemsReqReplyTester.this.m_frame.m_mutex.release();
      }
      catch (Exception localException)
      {
        GemsReqReplyTester.this.m_frame.m_mutex.release();
      }
    }
  }
  
  class SyncThread
    extends Thread
  {
    long m_delay;
    
    SyncThread(long paramLong)
    {
      this.m_delay = paramLong;
    }
    
    public void run()
    {
      while ((GemsReqReplyTester.this.m_running) && (GemsReqReplyTester.this.m_msgCount < GemsReqReplyTester.this.m_maxMsgs))
      {
        try
        {
          Message localMessage1;
          if (GemsReqReplyTester.this.m_msgType.getSelectedItem() == GemsReqReplyTester.MSG_TYPE.TextMessage) {
            localMessage1 = GemsReqReplyTester.this.m_textMsgFrame.createMessage(GemsReqReplyTester.this.m_session);
          } else {
            localMessage1 = GemsReqReplyTester.this.m_mapMsgFrame.createMessage(GemsReqReplyTester.this.m_session);
          }
          if (GemsReqReplyTester.this.m_mode.getSelectedItem() == GemsReqReplyTester.MODE_TYPE.Synchronous)
          {
            if (GemsReqReplyTester.this.m_isQueue) {
              GemsReqReplyTester.this.m_replyDestination = GemsReqReplyTester.this.m_session.createTemporaryQueue();
            } else {
              GemsReqReplyTester.this.m_replyDestination = GemsReqReplyTester.this.m_session.createTemporaryTopic();
            }
            GemsReqReplyTester.this.m_consumer = GemsReqReplyTester.this.m_session.createConsumer(GemsReqReplyTester.this.m_replyDestination);
          }
          else
          {
            localMessage1.setJMSCorrelationID(String.valueOf(++GemsReqReplyTester.this.m_msgSeq));
          }
          localMessage1.setJMSReplyTo(GemsReqReplyTester.this.m_replyDestination);
          GemsReqReplyTester.this.m_producer.send(GemsReqReplyTester.this.m_requestDestination, localMessage1, localMessage1.getJMSDeliveryMode(), localMessage1.getJMSPriority(), localMessage1.getJMSExpiration());
          GemsReqReplyTester.this.m_msgCount += 1;
          if (GemsReqReplyTester.this.m_mode.getSelectedItem() == GemsReqReplyTester.MODE_TYPE.Asynchronous)
          {
            GemsReqReplyTester.this.m_mutex.acquire();
            GemsReqReplyTester.this.m_pending.put(localMessage1.getJMSCorrelationID(), localMessage1);
            GemsReqReplyTester.this.m_mutex.release();
          }
          GemsReqReplyTester.this.m_tableModel.addRequestMessage(localMessage1, null, GemsReqReplyTester.this.m_viewoldestFirst);
          if (GemsReqReplyTester.this.m_mode.getSelectedItem() == GemsReqReplyTester.MODE_TYPE.Synchronous)
          {
            Message localMessage2 = GemsReqReplyTester.this.m_consumer.receive(GemsReqReplyTester.this.m_RRTimeout);
            GemsReqReplyTester.this.updateByTimer(localMessage1, localMessage2);
            if (GemsReqReplyTester.this.m_consumer != null)
            {
              GemsReqReplyTester.this.m_consumer.close();
              GemsReqReplyTester.this.m_consumer = null;
            }
            if (GemsReqReplyTester.this.m_replyDestination != null) {
              if (GemsReqReplyTester.this.m_isQueue) {
                ((TemporaryQueue)GemsReqReplyTester.this.m_replyDestination).delete();
              } else {
                ((TemporaryTopic)GemsReqReplyTester.this.m_replyDestination).delete();
              }
            }
            GemsReqReplyTester.this.m_replyDestination = null;
          }
        }
        catch (JMSException localJMSException)
        {
          System.err.println("Exception: " + localJMSException.getMessage());
          GemsReqReplyTester.this.m_frame.stop();
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          Gems.debug("GemsReqReplyTester.Exception: " + localInterruptedException.toString());
        }
        try
        {
          sleep(this.m_delay);
        }
        catch (Exception localException)
        {
          System.err.println("Exception: " + localException.getMessage());
        }
      }
      GemsReqReplyTester.this.m_frame.stop();
    }
  }
  
  public static enum MSG_TYPE
  {
    TextMessage,  MapMessage;
    
    private MSG_TYPE() {}
  }
  
  public static enum MODE_TYPE
  {
    Synchronous,  Asynchronous;
    
    private MODE_TYPE() {}
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsReqReplyTester.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */