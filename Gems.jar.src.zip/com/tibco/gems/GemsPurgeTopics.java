package com.tibco.gems;

import com.tibco.tibjms.admin.DestinationInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class GemsPurgeTopics
  extends GemsPurgeBase
{
  public GemsPurgeTopics(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode)
  {
    super(paramJFrame, paramGemsConnectionNode, "Topic", ">");
  }
  
  public GemsPurgeTopics(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, String paramString)
  {
    super(paramJFrame, paramGemsConnectionNode, "Topic", paramString);
  }
  
  public DestinationInfo[] getDestinationInfo()
  {
    try
    {
      return this.m_cn.getJmsAdmin().getTopics(this.m_pattern.getText(), this.m_pattern.getText().startsWith("$TMP$") ? 4 : 3);
    }
    catch (Throwable localThrowable)
    {
      return this.m_cn.getJmsAdmin().getTopics(this.m_pattern.getText());
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
    }
    return null;
  }
  
  public void purgeDestinations(Vector paramVector)
  {
    if (paramVector.size() == 0)
    {
      JOptionPane.showMessageDialog(this.m_frame, "Select topics to purge", "Error", 1);
      return;
    }
    int i = JOptionPane.showConfirmDialog(this, "Purge Selected Topics? Messages will be destroyed", "Purge Topics", 0);
    if (i != 0) {
      return;
    }
    try
    {
      for (int j = 0; j < paramVector.size(); j++) {
        this.m_cn.getJmsAdmin().purgeTopic((String)paramVector.get(j));
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsPurgeTopics.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */