package com.tibco.gems;

import com.tibco.tibjms.admin.DestinationInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class GemsPurgeQueues
  extends GemsPurgeBase
{
  public GemsPurgeQueues(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode)
  {
    super(paramJFrame, paramGemsConnectionNode, "Queue", ">");
  }
  
  public GemsPurgeQueues(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, String paramString)
  {
    super(paramJFrame, paramGemsConnectionNode, "Queue", paramString);
  }
  
  public DestinationInfo[] getDestinationInfo()
  {
    try
    {
      return this.m_cn.getJmsAdmin().getQueues(this.m_pattern.getText(), this.m_pattern.getText().startsWith("$TMP$") ? 4 : 3);
    }
    catch (Throwable localThrowable)
    {
      return this.m_cn.getJmsAdmin().getQueues(this.m_pattern.getText());
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
    }
    return null;
  }
  
  public void purgeDestinations(Vector paramVector)
  {
    if (paramVector.size() == 0)
    {
      JOptionPane.showMessageDialog(this.m_frame, "Select queues to purge", "Error", 1);
      return;
    }
    int i = JOptionPane.showConfirmDialog(this, "Purge Selected Queues? Messages will be destroyed", "Purge Queues", 0);
    if (i != 0) {
      return;
    }
    try
    {
      for (int j = 0; j < paramVector.size(); j++) {
        this.m_cn.getJmsAdmin().purgeQueue((String)paramVector.get(j));
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsPurgeQueues.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */