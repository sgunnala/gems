package com.tibco.gems;

public class MsgCellValue
  implements Comparable
{
  public long m_cellValue;
  public long m_warnLimit = 1L;
  public long m_errorLimit = 0L;
  
  public MsgCellValue(long paramLong1, long paramLong2, long paramLong3)
  {
    this.m_cellValue = paramLong1;
    this.m_warnLimit = paramLong2;
    this.m_errorLimit = paramLong3;
  }
  
  public MsgCellValue(long paramLong1, long paramLong2)
  {
    this.m_cellValue = paramLong1;
    this.m_errorLimit = paramLong2;
  }
  
  public MsgCellValue(long paramLong)
  {
    this.m_cellValue = paramLong;
  }
  
  public String toString()
  {
    return String.valueOf(this.m_cellValue);
  }
  
  public int compareTo(Object paramObject)
    throws ClassCastException
  {
    MsgCellValue localMsgCellValue = (MsgCellValue)paramObject;
    if (this.m_cellValue > localMsgCellValue.m_cellValue) {
      return 1;
    }
    if (this.m_cellValue == localMsgCellValue.m_cellValue) {
      return 0;
    }
    return -1;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\MsgCellValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */