package com.tibco.gems;

import java.awt.Color;
import java.awt.Component;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.Hashtable;
import javax.swing.Icon;
import javax.swing.plaf.metal.MetalIconFactory.TreeLeafIcon;

class TextIcons
  extends MetalIconFactory.TreeLeafIcon
{
  protected String label;
  private static Hashtable labels;
  private Color foreground = null;
  
  public void paintIcon(Component paramComponent, Graphics paramGraphics, int paramInt1, int paramInt2)
  {
    super.paintIcon(paramComponent, paramGraphics, paramInt1, paramInt2);
    if (this.label != null)
    {
      paramGraphics.setFont(paramComponent.getFont());
      if (this.foreground == null) {
        this.foreground = paramComponent.getForeground();
      }
      paramGraphics.setColor(this.foreground);
      FontMetrics localFontMetrics = paramGraphics.getFontMetrics();
      int i = (getIconWidth() - localFontMetrics.stringWidth(this.label)) / 2;
      int j = (getIconHeight() - localFontMetrics.getHeight()) / 2 - 2;
      paramGraphics.drawString(this.label, paramInt1 + i, paramInt2 + j + localFontMetrics.getHeight());
    }
  }
  
  public static Icon getIcon(String paramString)
  {
    if (labels == null)
    {
      labels = new Hashtable();
      setDefaultSet();
    }
    TextIcons localTextIcons = new TextIcons();
    localTextIcons.label = ((String)labels.get(paramString));
    return localTextIcons;
  }
  
  public static void setLabelSet(String paramString1, String paramString2)
  {
    if (labels == null)
    {
      labels = new Hashtable();
      setDefaultSet();
    }
    labels.put(paramString1, paramString2);
  }
  
  private static void setDefaultSet()
  {
    labels.put("c", "C");
    labels.put("java", "J");
    labels.put("html", "H");
    labels.put("htm", "H");
    labels.put("queue", "Q");
    labels.put("topic", "T");
    labels.put("routedqueue", "q");
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\TextIcons.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */