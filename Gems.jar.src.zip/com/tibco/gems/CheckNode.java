package com.tibco.gems;

import java.util.Enumeration;
import java.util.Vector;
import javax.swing.tree.DefaultMutableTreeNode;

public class CheckNode
  extends DefaultMutableTreeNode
{
  public static final int SINGLE_SELECTION = 0;
  public static final int DIG_IN_SELECTION = 4;
  protected int selectionMode;
  protected boolean isSelected;
  
  public CheckNode()
  {
    this(null);
  }
  
  public CheckNode(Object paramObject)
  {
    this(paramObject, true, false);
  }
  
  public CheckNode(Object paramObject, boolean paramBoolean1, boolean paramBoolean2)
  {
    super(paramObject, paramBoolean1);
    this.isSelected = paramBoolean2;
    setSelectionMode(4);
  }
  
  public void setSelectionMode(int paramInt)
  {
    this.selectionMode = paramInt;
  }
  
  public int getSelectionMode()
  {
    return this.selectionMode;
  }
  
  public void setSelected(boolean paramBoolean)
  {
    this.isSelected = paramBoolean;
    if (this.selectionMode == 4)
    {
      if (this.children != null)
      {
        localObject = this.children.elements();
        while (((Enumeration)localObject).hasMoreElements())
        {
          CheckNode localCheckNode = (CheckNode)((Enumeration)localObject).nextElement();
          localCheckNode.setSelected(paramBoolean);
        }
      }
      Object localObject = (CheckNode)getParent();
      if (localObject != null) {
        ((CheckNode)localObject).updateSelection();
      }
    }
  }
  
  public void updateSelection()
  {
    if (this.selectionMode == 4)
    {
      Gems.debug("UpSel " + toString());
      if (this.children != null)
      {
        localObject = this.children.elements();
        int i = 0;
        while (((Enumeration)localObject).hasMoreElements())
        {
          CheckNode localCheckNode = (CheckNode)((Enumeration)localObject).nextElement();
          if (localCheckNode.isSelected()) {
            i++;
          }
        }
        if (i > 0) {
          this.isSelected = true;
        } else {
          this.isSelected = false;
        }
      }
      Object localObject = (CheckNode)getParent();
      if (localObject != null) {
        ((CheckNode)localObject).updateSelection();
      }
    }
  }
  
  public int getSelectedLeafCount(int paramInt)
  {
    if ((children() != null) && (getChildCount() > 0))
    {
      Enumeration localEnumeration = children();
      while (localEnumeration.hasMoreElements())
      {
        CheckNode localCheckNode = (CheckNode)localEnumeration.nextElement();
        paramInt = localCheckNode.getSelectedLeafCount(paramInt);
      }
      return paramInt;
    }
    if (isSelected()) {
      paramInt++;
    }
    return paramInt;
  }
  
  public boolean areAllChildrenSelected()
  {
    if (this.children != null)
    {
      Enumeration localEnumeration = this.children.elements();
      int i = 0;
      int j = 0;
      while (localEnumeration.hasMoreElements())
      {
        j++;
        CheckNode localCheckNode = (CheckNode)localEnumeration.nextElement();
        if (localCheckNode.isSelected()) {
          i++;
        }
      }
      return (j > 0) && (i == j);
    }
    return false;
  }
  
  public boolean isSelected()
  {
    return this.isSelected;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\CheckNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */