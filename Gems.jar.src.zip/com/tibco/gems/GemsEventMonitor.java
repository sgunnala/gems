package com.tibco.gems;

import com.tibco.tibjms.TibjmsTopicConnectionFactory;
import java.io.PrintStream;
import java.util.Random;
import java.util.Vector;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;

public class GemsEventMonitor
  implements MessageListener
{
  public Vector m_subscriptions = new Vector();
  public Vector m_subscribers = new Vector();
  public Vector m_messages = new Vector();
  public boolean m_running = false;
  protected long m_maxEvents;
  protected GemsConnectionNode m_cn;
  protected TopicSession m_sess = null;
  protected TopicConnection m_connection = null;
  public Mutex m_mutex = new Mutex();
  protected StartThread m_timer = null;
  protected Random m_random = new Random();
  public boolean m_enabled = false;
  
  public GemsEventMonitor(GemsConnectionNode paramGemsConnectionNode, long paramLong, boolean paramBoolean)
  {
    this.m_cn = paramGemsConnectionNode;
    this.m_maxEvents = paramLong;
    this.m_enabled = paramBoolean;
  }
  
  public synchronized void systemStart()
  {
    if (this.m_enabled) {
      userStart();
    }
  }
  
  public synchronized void systemStop()
  {
    userStop();
  }
  
  public synchronized void userStart()
  {
    stopMonitor();
    reset();
    this.m_timer = new StartThread();
    this.m_timer.start();
  }
  
  public synchronized void userStop()
  {
    this.m_running = false;
    if (this.m_timer != null) {
      this.m_timer.interrupt();
    }
    stopMonitor();
    reset();
  }
  
  public synchronized void reset()
  {
    try
    {
      this.m_mutex.acquire();
      this.m_messages.removeAllElements();
    }
    catch (InterruptedException localInterruptedException)
    {
      Gems.debug("GemsEventMonitor.reset: Exception: " + localInterruptedException.toString());
    }
    this.m_mutex.release();
    Gems.getGems().treeRepaint();
  }
  
  public synchronized Vector getMessages()
  {
    return this.m_messages;
  }
  
  public synchronized void startMonitor()
  {
    if (this.m_subscriptions.size() == 0)
    {
      System.err.println("GemsEventMonitor:start: No subscriptions found");
      return;
    }
    try
    {
      TibjmsTopicConnectionFactory localTibjmsTopicConnectionFactory = new TibjmsTopicConnectionFactory(this.m_cn.m_url, null, this.m_cn.m_sslParams);
      this.m_connection = localTibjmsTopicConnectionFactory.createTopicConnection(this.m_cn.m_user, this.m_cn.m_password);
      this.m_sess = this.m_connection.createTopicSession(false, 22);
      for (int i = 0; i < this.m_subscriptions.size(); i++)
      {
        subscription localsubscription = (subscription)this.m_subscriptions.get(i);
        Topic localTopic = this.m_sess.createTopic(localsubscription.m_dest);
        TopicSubscriber localTopicSubscriber = this.m_sess.createSubscriber(localTopic, localsubscription.m_sel, false);
        localTopicSubscriber.setMessageListener(this);
        this.m_subscribers.add(localTopicSubscriber);
        Gems.debug("GemsEventMonitor:start: Adding subscription: " + localsubscription.m_dest);
      }
      this.m_connection.start();
      this.m_running = true;
    }
    catch (JMSException localJMSException)
    {
      System.err.println("GemsEventMonitor:start: Exception: " + localJMSException.getMessage());
      return;
    }
  }
  
  public synchronized void stopMonitor()
  {
    try
    {
      if (this.m_connection == null) {
        return;
      }
      this.m_connection.stop();
      for (int i = 0; i < this.m_subscribers.size(); i++)
      {
        TopicSubscriber localTopicSubscriber = (TopicSubscriber)this.m_subscribers.get(i);
        localTopicSubscriber.close();
      }
      this.m_subscribers.removeAllElements();
      if (this.m_sess != null)
      {
        this.m_sess.close();
        this.m_sess = null;
      }
      this.m_connection.close();
      this.m_connection = null;
      this.m_messages.removeAllElements();
    }
    catch (Exception localException)
    {
      Gems.debug("GemsEventMonitor:stop: Exception: " + localException.toString());
      return;
    }
  }
  
  public synchronized void addSubscription(String paramString1, String paramString2)
  {
    this.m_subscriptions.add(new subscription(paramString1, paramString2));
  }
  
  public int getMessageCount()
  {
    return this.m_messages.size();
  }
  
  public void onMessage(Message paramMessage)
  {
    try
    {
      this.m_mutex.acquire();
      this.m_messages.add(paramMessage);
      if (this.m_messages.size() > this.m_maxEvents) {
        this.m_messages.removeElementAt(0);
      }
      if (this.m_messages.size() == 1) {
        Gems.getGems().treeRepaint();
      }
    }
    catch (InterruptedException localInterruptedException)
    {
      Gems.debug("GemsServiceTable.onRespMessage: Exception: " + localInterruptedException.toString());
    }
    this.m_mutex.release();
  }
  
  class StartThread
    extends Thread
  {
    StartThread() {}
    
    public void run()
    {
      try
      {
        sleep(3000 + GemsEventMonitor.this.m_random.nextInt(5000));
      }
      catch (Exception localException)
      {
        Gems.debug("StartThread.Exception: " + localException.getMessage());
        return;
      }
      GemsEventMonitor.this.startMonitor();
    }
  }
  
  class subscription
  {
    String m_dest;
    String m_sel;
    
    public subscription(String paramString1, String paramString2)
    {
      this.m_dest = paramString1;
      this.m_sel = paramString2;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsEventMonitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */