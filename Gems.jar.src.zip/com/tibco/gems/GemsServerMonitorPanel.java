package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class GemsServerMonitorPanel
  extends JPanel
{
  protected GemsServerMonitorTableModel m_tableModel;
  JTable m_table;
  
  public GemsServerMonitorPanel()
  {
    super(true);
    setLayout(new BorderLayout());
    this.m_tableModel = new GemsServerMonitorTableModel();
    this.m_table = new JTable(this.m_tableModel);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    this.m_table.setSelectionMode(0);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    add(localJScrollPane, "Center");
  }
  
  GemsServerMonitorTableModel getModel()
  {
    return this.m_tableModel;
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          Gems.getGems().getTreeModel().serverMonitorDoubleClick(GemsServerMonitorPanel.this.m_tableModel.getSelectedCol1());
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsServerMonitorPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */