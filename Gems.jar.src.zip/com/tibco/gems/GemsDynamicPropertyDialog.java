package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GemsDynamicPropertyDialog
  extends JDialog
  implements ActionListener
{
  private JButton okButton = new JButton("OK");
  private JButton cancelButton = new JButton("Cancel");
  private boolean isOK = false;
  private Map propertyControls;
  private String m_className;
  private JPanel m_panel;
  
  public GemsDynamicPropertyDialog(JFrame paramJFrame, String paramString1, String paramString2, String paramString3)
  {
    super(paramJFrame, paramString1, true);
    this.m_className = paramString2;
    this.okButton.addActionListener(this);
    this.cancelButton.addActionListener(this);
    this.m_panel = getPanel(paramString2);
    getContentPane().setLayout(new BorderLayout());
    if (paramString3 != null) {
      getContentPane().add(new JLabel(paramString3), "North");
    }
    getContentPane().add(this.m_panel, "Center");
    JPanel localJPanel1 = new JPanel(new GridLayout(1, 2, 4, 0));
    localJPanel1.add(this.okButton);
    localJPanel1.add(this.cancelButton);
    JPanel localJPanel2 = new JPanel(new FlowLayout(1));
    localJPanel2.add(localJPanel1);
    getContentPane().add(localJPanel2, "South");
  }
  
  public Object getObject()
  {
    Dimension localDimension1 = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension localDimension2 = this.m_panel.getSize();
    int i = localDimension2.width;
    int j = localDimension2.height + 30;
    setSize(i, j);
    setLocation(localDimension1.width / 2 - i / 2, localDimension1.height / 2 - j / 2);
    pack();
    setVisible(true);
    if (!this.isOK) {
      return null;
    }
    TreeMap localTreeMap = new TreeMap();
    Iterator localIterator = this.propertyControls.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      String str2 = null;
      JComponent localJComponent = (JComponent)this.propertyControls.get(str1);
      if ((localJComponent instanceof JTextField)) {
        str2 = ((JTextField)localJComponent).getText();
      } else if ((localJComponent instanceof JCheckBox)) {
        str2 = Boolean.toString(((JCheckBox)localJComponent).isSelected());
      }
      localTreeMap.put(str1, str2);
    }
    return ReflectionUtils.buildObject(this.m_className, localTreeMap);
  }
  
  protected JPanel getPanel(String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramString);
      return getPanel(localClass);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      localClassNotFoundException.printStackTrace();
    }
    return null;
  }
  
  protected JPanel getPanel(Class paramClass)
  {
    GridBagLayout localGridBagLayout = new GridBagLayout();
    GridBagConstraints localGridBagConstraints = new GridBagConstraints();
    localGridBagConstraints.gridwidth = 1;
    localGridBagConstraints.gridheight = 1;
    localGridBagConstraints.gridy = 0;
    localGridBagConstraints.ipadx = 2;
    localGridBagConstraints.ipady = 1;
    int i = 0;
    JPanel localJPanel = new JPanel(localGridBagLayout);
    Map localMap = ReflectionUtils.getWriteableProperties(paramClass);
    this.propertyControls = new TreeMap();
    Iterator localIterator = localMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str1 = (String)localIterator.next();
      String str2 = (String)localMap.get(str1);
      if (ReflectionUtils.isPrimitiveType(str2))
      {
        StringBuffer localStringBuffer = new StringBuffer();
        localStringBuffer.append(Character.toUpperCase(str1.charAt(0)));
        int j = 0;
        int k = 0;
        for (int m = 1; m < str1.length(); m++)
        {
          char c = str1.charAt(m);
          if (Character.isUpperCase(c))
          {
            if ((j == 0) && (m > 1)) {
              localStringBuffer.append(" ");
            }
            j = 1;
          }
          else
          {
            j = 0;
          }
          localStringBuffer.append(c);
        }
        localStringBuffer.append(":");
        JLabel localJLabel = new JLabel(localStringBuffer.toString());
        localGridBagConstraints.gridx = 0;
        localGridBagConstraints.anchor = 12;
        localGridBagLayout.setConstraints(localJLabel, localGridBagConstraints);
        localJPanel.add(localJLabel);
        localGridBagConstraints.gridx = 1;
        localGridBagConstraints.anchor = 18;
        Object localObject;
        if ((str2.equals("boolean")) || (str2.equals("java.lang.Boolean")))
        {
          localObject = new JCheckBox();
          this.propertyControls.put(str1, localObject);
          localGridBagLayout.setConstraints((Component)localObject, localGridBagConstraints);
          localJPanel.add((Component)localObject);
        }
        else
        {
          localObject = new JTextField(30);
          this.propertyControls.put(str1, localObject);
          localGridBagLayout.setConstraints((Component)localObject, localGridBagConstraints);
          localJPanel.add((Component)localObject);
        }
        i += 30;
      }
      localGridBagConstraints.gridy += 1;
    }
    localJPanel.setSize(425, i);
    return localJPanel;
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    if (paramActionEvent.getSource() == this.okButton) {
      this.isOK = true;
    } else {
      this.isOK = false;
    }
    setVisible(false);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDynamicPropertyDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */