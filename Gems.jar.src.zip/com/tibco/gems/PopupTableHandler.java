package com.tibco.gems;

import java.awt.Point;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JFileChooser;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

public class PopupTableHandler
  extends PopupHandler
{
  public JTable m_table;
  public int m_row = 0;
  public int m_col = 0;
  public Object m_value = null;
  public AbstractAction copy = null;
  public AbstractAction save2csv = null;
  static File m_currentdir = null;
  
  public PopupTableHandler(JTable paramJTable)
  {
    this.m_table = paramJTable;
  }
  
  public JPopupMenu createPopup(Point paramPoint)
  {
    JPopupMenu localJPopupMenu = super.createPopup(paramPoint);
    this.m_col = this.m_table.columnAtPoint(paramPoint);
    this.m_row = this.m_table.rowAtPoint(paramPoint);
    this.m_value = this.m_table.getModel().getValueAt(this.m_row, this.m_col);
    if (this.copy == null) {
      this.copy = new TableCopyAction("Copy Cell", null);
    }
    if (this.save2csv == null) {
      this.save2csv = new TableSave2CSVAction("Save Table To CSV File...", null);
    }
    localJPopupMenu.add(this.copy);
    localJPopupMenu.addSeparator();
    localJPopupMenu.add(this.save2csv);
    return localJPopupMenu;
  }
  
  public class TableSave2CSVAction
    extends AbstractAction
  {
    public TableSave2CSVAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        TableModel localTableModel = PopupTableHandler.this.m_table.getModel();
        JFileChooser localJFileChooser = new JFileChooser(PopupTableHandler.m_currentdir);
        localJFileChooser.setApproveButtonText("Save");
        localJFileChooser.setDialogTitle("Save Table To CSV File");
        int i = localJFileChooser.showOpenDialog(PopupTableHandler.this.m_table);
        PopupTableHandler.m_currentdir = localJFileChooser.getCurrentDirectory();
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          localFile.createNewFile();
          FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
          PrintWriter localPrintWriter = new PrintWriter(localFileOutputStream);
          int j = localTableModel.getColumnCount();
          int k = localTableModel.getRowCount();
          StringBuffer localStringBuffer = new StringBuffer();
          Object localObject;
          for (int m = 0; m < j; m++)
          {
            localObject = PopupTableHandler.this.m_table.getColumnModel().getColumn(m);
            localStringBuffer.append(((TableColumn)localObject).getHeaderValue());
            if (m + 1 < j) {
              localStringBuffer.append(Gems.getGems().getCSVFileDelimiter());
            }
          }
          if ((localStringBuffer.charAt(0) == 'I') && (localStringBuffer.charAt(1) == 'D')) {
            localPrintWriter.print('\'');
          }
          localPrintWriter.println(localStringBuffer.toString());
          for (m = 0; m < k; m++)
          {
            localObject = new StringBuffer();
            for (int n = 0; n < j; n++)
            {
              ((StringBuffer)localObject).append(localTableModel.getValueAt(m, n));
              if (n + 1 < j) {
                ((StringBuffer)localObject).append(Gems.getGems().getCSVFileDelimiter());
              }
            }
            localPrintWriter.println(((StringBuffer)localObject).toString());
          }
          localPrintWriter.close();
        }
      }
      catch (IOException localIOException)
      {
        System.err.println("JavaIOException: " + localIOException.getMessage());
        return;
      }
    }
    
    public boolean isEnabled()
    {
      return PopupTableHandler.this.m_table != null;
    }
  }
  
  public class TableCopyAction
    extends AbstractAction
  {
    public TableCopyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      StringSelection localStringSelection = new StringSelection(PopupTableHandler.this.m_value.toString());
      Toolkit.getDefaultToolkit().getSystemClipboard().setContents(localStringSelection, localStringSelection);
    }
    
    public boolean isEnabled()
    {
      return PopupTableHandler.this.m_table != null;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\PopupTableHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */