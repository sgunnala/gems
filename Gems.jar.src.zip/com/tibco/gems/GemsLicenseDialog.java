package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

public class GemsLicenseDialog
  extends JDialog
{
  private JPanel dialogPane;
  private JPanel contentPanel;
  private JLabel lblWarning;
  private JScrollPane scrollPane1;
  private JTextPane txtLicense;
  private JPanel buttonBar;
  private JButton okButton;
  
  public GemsLicenseDialog(Frame paramFrame)
  {
    super(paramFrame);
    initComponents();
  }
  
  public GemsLicenseDialog(Dialog paramDialog)
  {
    super(paramDialog);
    initComponents();
  }
  
  private void okButtonActionPerformed()
  {
    dispose();
  }
  
  private void initComponents()
  {
    this.dialogPane = new JPanel();
    this.contentPanel = new JPanel();
    this.lblWarning = new JLabel();
    this.scrollPane1 = new JScrollPane();
    this.txtLicense = new JTextPane();
    this.buttonBar = new JPanel();
    this.okButton = new JButton();
    setTitle("Gems License");
    setModal(true);
    setDefaultCloseOperation(2);
    setResizable(false);
    this.dialogPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    this.dialogPane.setLayout(new BorderLayout(20, 20));
    this.contentPanel.setLayout(new BorderLayout(10, 10));
    this.lblWarning.setText("By using this software you agree to the following license agreement:");
    this.lblWarning.setFont(new Font("Tahoma", 1, 14));
    this.contentPanel.add(this.lblWarning, "First");
    this.scrollPane1.setHorizontalScrollBarPolicy(31);
    this.scrollPane1.setVerticalScrollBarPolicy(22);
    this.scrollPane1.setPreferredSize(new Dimension(550, 475));
    this.txtLicense.setText("text");
    this.txtLicense.setEditable(false);
    this.txtLicense.setFont(new Font("Courier New", 0, 11));
    this.scrollPane1.setViewportView(this.txtLicense);
    this.contentPanel.add(this.scrollPane1, "Center");
    this.dialogPane.add(this.contentPanel, "Center");
    this.okButton.setText("OK");
    this.okButton.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsLicenseDialog.this.okButtonActionPerformed();
      }
    });
    this.buttonBar.add(this.okButton);
    this.dialogPane.add(this.buttonBar, "Last");
    pack();
    setLocationRelativeTo(getOwner());
    this.txtLicense.setText(License.getLicenseAgreement());
    this.txtLicense.setCaretPosition(0);
    setContentPane(this.dialogPane);
    pack();
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsLicenseDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */