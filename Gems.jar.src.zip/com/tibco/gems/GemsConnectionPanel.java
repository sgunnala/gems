package com.tibco.gems;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class GemsConnectionPanel
  extends JPanel
{
  protected GemsTreeModel m_treeModel;
  protected JTextField m_alias;
  protected JTextField m_url;
  protected JTextField m_user;
  protected JTextField m_password;
  protected JButton m_connButton;
  protected JButton m_disconnButton;
  
  public GemsConnectionPanel(GemsTreeModel paramGemsTreeModel)
  {
    super(true);
    setLayout(new BoxLayout(this, 3));
    this.m_treeModel = paramGemsTreeModel;
    JPanel localJPanel1 = new JPanel(new SpringLayout(), true);
    add(localJPanel1);
    JLabel localJLabel1 = new JLabel("Connection Alias:", 11);
    this.m_alias = new JTextField("EMS Connection", 20);
    this.m_alias.setMaximumSize(new Dimension(1000, 24));
    localJLabel1.setLabelFor(this.m_alias);
    localJPanel1.add(localJLabel1);
    localJPanel1.add(this.m_alias);
    JLabel localJLabel2 = new JLabel("URL:", 11);
    this.m_url = new JTextField("tcp://localhost:7222", 20);
    this.m_url.setMaximumSize(new Dimension(0, 24));
    localJLabel2.setLabelFor(this.m_url);
    localJPanel1.add(localJLabel2);
    localJPanel1.add(this.m_url);
    JLabel localJLabel3 = new JLabel("Admin Username:", 11);
    this.m_user = new JTextField("admin", 20);
    this.m_user.setMaximumSize(new Dimension(0, 24));
    localJLabel3.setLabelFor(this.m_user);
    localJPanel1.add(localJLabel3);
    localJPanel1.add(this.m_user);
    JLabel localJLabel4 = new JLabel("Password:", 11);
    this.m_password = new JPasswordField(20);
    this.m_password.setMaximumSize(new Dimension(0, 24));
    localJLabel4.setLabelFor(this.m_password);
    localJPanel1.add(localJLabel4);
    localJPanel1.add(this.m_password);
    JPanel localJPanel2 = new JPanel(true);
    localJPanel2.setLayout(new BoxLayout(localJPanel2, 2));
    this.m_connButton = new JButton("Connect");
    this.m_connButton.addActionListener(new ConnectPressed());
    this.m_disconnButton = new JButton("Disconnect");
    this.m_disconnButton.addActionListener(new DisconnectPressed());
    this.m_disconnButton.setEnabled(false);
    localJPanel2.add(this.m_connButton);
    localJPanel2.add(this.m_disconnButton);
    add(localJPanel2);
    SpringUtilities.makeCompactGrid(localJPanel1, 4, 2, 5, 5, 5, 5);
  }
  
  public void setDetails(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
  {
    this.m_alias.setText(paramString1);
    this.m_url.setText(paramString2);
    this.m_user.setText(paramString3);
    if (paramBoolean)
    {
      this.m_connButton.setEnabled(false);
      this.m_disconnButton.setEnabled(true);
      this.m_alias.setEnabled(false);
      this.m_url.setEnabled(false);
      this.m_user.setEnabled(false);
      this.m_password.setEnabled(false);
    }
    else
    {
      this.m_connButton.setEnabled(true);
      this.m_disconnButton.setEnabled(false);
      this.m_alias.setEnabled(true);
      this.m_url.setEnabled(true);
      this.m_user.setEnabled(true);
      this.m_password.setEnabled(true);
    }
  }
  
  class DisconnectPressed
    implements ActionListener
  {
    DisconnectPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionPanel.this.m_treeModel.disconnectCurrentNode();
      GemsConnectionPanel.this.m_connButton.setEnabled(true);
      GemsConnectionPanel.this.m_disconnButton.setEnabled(false);
    }
  }
  
  class ConnectPressed
    implements ActionListener
  {
    ConnectPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsConnectionPanel.this.m_treeModel.connectCurrentNode(GemsConnectionPanel.this.m_alias.getText(), GemsConnectionPanel.this.m_url.getText(), GemsConnectionPanel.this.m_user.getText(), GemsConnectionPanel.this.m_password.getText()))
      {
        GemsConnectionPanel.this.m_connButton.setEnabled(false);
        GemsConnectionPanel.this.m_disconnButton.setEnabled(true);
      }
      else
      {
        GemsConnectionPanel.this.m_connButton.setEnabled(true);
        GemsConnectionPanel.this.m_disconnButton.setEnabled(false);
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsConnectionPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */