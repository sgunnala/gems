package com.tibco.gems;

import java.awt.Color;

public class SSCellValue
  implements Comparable
{
  String m_datatype = "S";
  public String m_cellValue;
  public long m_cellValueLong;
  public String m_cellType;
  public String m_errorValue;
  public long m_warnLimit = 10L;
  public long m_errorLimit = 100L;
  
  public SSCellValue(long paramLong1, String paramString, long paramLong2, long paramLong3)
  {
    this.m_cellValueLong = paramLong1;
    this.m_datatype = "L";
    this.m_cellValue = String.valueOf(this.m_cellValueLong);
    this.m_cellType = paramString;
    this.m_warnLimit = paramLong2;
    this.m_errorLimit = paramLong3;
  }
  
  public SSCellValue(long paramLong1, String paramString, long paramLong2)
  {
    this.m_cellValueLong = paramLong1;
    this.m_datatype = "L";
    this.m_cellValue = String.valueOf(this.m_cellValueLong);
    this.m_cellType = paramString;
    this.m_errorLimit = paramLong2;
    this.m_warnLimit = paramLong2;
  }
  
  public SSCellValue(String paramString1, String paramString2, String paramString3)
  {
    this.m_cellValue = paramString1;
    this.m_datatype = "S";
    this.m_cellType = paramString2;
    this.m_errorValue = paramString3;
  }
  
  public SSCellValue(String paramString1, String paramString2)
  {
    this.m_cellValue = paramString1;
    this.m_cellType = paramString2;
  }
  
  public SSCellValue(String paramString)
  {
    this.m_cellValue = paramString;
    this.m_cellType = "";
  }
  
  public String toString()
  {
    return String.valueOf(this.m_cellValue);
  }
  
  public int compareTo(Object paramObject)
    throws ClassCastException
  {
    SSCellValue localSSCellValue = (SSCellValue)paramObject;
    if (!this.m_cellValue.equals(localSSCellValue.m_cellValue)) {
      return 1;
    }
    if (this.m_cellValue == localSSCellValue.m_cellValue) {
      return 0;
    }
    return -1;
  }
  
  public Color CellColour()
  {
    if (this.m_cellType.equals("Head")) {
      return Color.lightGray;
    }
    if ((this.m_cellType.equals("Error")) && (this.m_datatype.equals("L")))
    {
      if (this.m_cellValueLong >= this.m_errorLimit) {
        return Color.red;
      }
      if (this.m_cellValueLong >= this.m_warnLimit) {
        return Color.yellow;
      }
      return Color.green;
    }
    if ((this.m_cellType.equals("Large")) && (this.m_datatype.equals("L")))
    {
      if (this.m_cellValueLong >= this.m_errorLimit) {
        return Color.yellow;
      }
      if (this.m_cellValueLong >= this.m_warnLimit) {
        return Color.cyan;
      }
    }
    if ((this.m_cellType.equals("Status")) && (this.m_datatype.equals("S")))
    {
      if (this.m_cellValue.equals(this.m_errorValue)) {
        return Color.red;
      }
      return Color.green;
    }
    return Color.white;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\SSCellValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */