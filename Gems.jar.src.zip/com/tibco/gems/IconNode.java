package com.tibco.gems;

import javax.swing.Icon;
import javax.swing.tree.DefaultMutableTreeNode;

public class IconNode
  extends DefaultMutableTreeNode
{
  protected Icon icon = null;
  protected String iconName;
  
  public IconNode()
  {
    this(null);
  }
  
  public IconNode(Object paramObject)
  {
    this(paramObject, true, null);
  }
  
  public IconNode(Object paramObject, boolean paramBoolean)
  {
    super(paramObject, paramBoolean);
  }
  
  public IconNode(Object paramObject, boolean paramBoolean, Icon paramIcon)
  {
    super(paramObject, paramBoolean);
    this.icon = paramIcon;
  }
  
  public void setIcon(Icon paramIcon)
  {
    this.icon = paramIcon;
  }
  
  public Icon getIcon()
  {
    return this.icon;
  }
  
  public String getIconName()
  {
    if (this.iconName != null) {
      return this.iconName;
    }
    String str = this.userObject.toString();
    int i = str.lastIndexOf(".");
    if (i != -1) {
      return str.substring(++i);
    }
    return null;
  }
  
  public void setIconName(String paramString)
  {
    this.iconName = paramString;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\IconNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */