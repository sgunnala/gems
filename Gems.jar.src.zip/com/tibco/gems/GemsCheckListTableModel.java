package com.tibco.gems;

import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class GemsCheckListTableModel
  extends DefaultTableModel
{
  JTable m_table;
  String m_header;
  Object m_obj = new Object();
  MyCheckboxRenderer m_checkRenderer = new MyCheckboxRenderer();
  
  public GemsCheckListTableModel(String paramString)
  {
    this.m_header = paramString;
  }
  
  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject != null) {
      return localObject.getClass();
    }
    return String.class;
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return paramInt2 < 1;
  }
  
  public Vector getSelectedObjects()
  {
    Vector localVector = new Vector();
    for (int i = 0; i < getRowCount(); i++) {
      if (((Boolean)this.m_table.getValueAt(i, 0)).booleanValue()) {
        localVector.add(this.m_table.getValueAt(i, 1));
      }
    }
    return localVector;
  }
  
  public void selectAllRows()
  {
    for (int i = 0; i < getRowCount(); i++) {
      this.m_table.setValueAt(new Boolean(true), i, 0);
    }
  }
  
  public void toggleSelectedRow()
  {
    this.m_table.setValueAt(new Boolean(!((Boolean)this.m_table.getValueAt(this.m_table.getSelectedRow(), 0)).booleanValue()), this.m_table.getSelectedRow(), 0);
  }
  
  public void buildColumnHeaders()
  {
    setRowCount(0);
    setColumnCount(0);
    this.m_table.setDefaultRenderer(Boolean.class, this.m_checkRenderer);
    String[] arrayOfString = { "", this.m_header };
    setColumnIdentifiers(arrayOfString);
    this.m_table.getColumn("").setMaxWidth(30);
  }
  
  public void addObject(boolean paramBoolean, Object paramObject)
  {
    if (paramObject != null)
    {
      Object[] arrayOfObject = { new Boolean(paramBoolean), paramObject };
      addRow(arrayOfObject);
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsCheckListTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */