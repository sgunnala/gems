package com.tibco.gems.chart;

import com.tibco.gems.ReflectionUtils;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;

public class GemsSubscriber
{
  private Vector _chartTableViews;
  private Vector _rowData;
  private Vector _chartableFields;
  private Vector _columnHeaders;
  private String _title;
  
  public void constructColumnHeaders() {}
  
  public boolean anyChartableField()
  {
    return this._chartableFields.size() > 0;
  }
  
  public Vector getChartableFields()
  {
    return this._chartableFields;
  }
  
  public String getTitle()
  {
    return this._title;
  }
  
  public void addChart(GemsChartFrame paramGemsChartFrame)
  {
    this._chartTableViews.addElement(paramGemsChartFrame);
  }
  
  public void doneSelectedInTabbedPane(GemsChartFrame paramGemsChartFrame)
  {
    this._chartTableViews.removeElement(paramGemsChartFrame);
  }
  
  public void doneSelectedInTableView()
  {
    this._rowData.removeAllElements();
    this._rowData = null;
  }
  
  public void onData(Object paramObject)
  {
    Hashtable localHashtable = ReflectionUtils.getGetterMethodValues(paramObject);
    Date localDate = new Date();
    for (int i = 0; i < this._chartTableViews.size(); i++)
    {
      GemsChartFrame localGemsChartFrame = (GemsChartFrame)this._chartTableViews.elementAt(i);
      localGemsChartFrame.newDataAvailable(localDate, localHashtable);
    }
  }
  
  public GemsSubscriber(Vector paramVector, String paramString)
  {
    this._columnHeaders = paramVector;
    this._chartableFields = paramVector;
    this._rowData = new Vector();
    this._chartTableViews = new Vector(10);
    this._title = paramString;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsSubscriber.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */