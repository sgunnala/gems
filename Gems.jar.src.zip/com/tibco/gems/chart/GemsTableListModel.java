package com.tibco.gems.chart;

import java.io.PrintStream;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

public class GemsTableListModel
  extends DefaultTableModel
  implements GemsTableListModelBase
{
  GemsTableListModelBase _tableListModel;
  String[] m_arrColumnIdentifiers;
  JTable _table;
  
  public void removeAll()
  {
    int i = getRowCount();
    for (int j = 0; j < i; j++) {
      removeRow(0);
    }
  }
  
  public JTable getTable()
  {
    return this._table;
  }
  
  public void setTable(JTable paramJTable)
  {
    this._table = paramJTable;
  }
  
  public void setColumnRenderer(int paramInt, TableCellRenderer paramTableCellRenderer)
  {
    TableColumn localTableColumn = this._table.getColumn(this.m_arrColumnIdentifiers[paramInt]);
    if (localTableColumn != null) {
      localTableColumn.setCellRenderer(paramTableCellRenderer);
    }
  }
  
  public void setColumnSizes()
  {
    int[] arrayOfInt = getColumnSizes();
    setColumnSizes(arrayOfInt);
  }
  
  public void setColumnSizes(int[] paramArrayOfInt)
  {
    int i = paramArrayOfInt.length <= getColumnCount() ? paramArrayOfInt.length : getColumnCount();
    String[] arrayOfString = this.m_arrColumnIdentifiers != null ? this.m_arrColumnIdentifiers : getColumnHeadings();
    for (int j = 0; j < i; j++)
    {
      TableColumn localTableColumn = this._table.getColumn(arrayOfString[j]);
      if (localTableColumn != null)
      {
        localTableColumn.setWidth(paramArrayOfInt[j]);
        localTableColumn.setPreferredWidth(paramArrayOfInt[j]);
      }
      else
      {
        System.out.println(" >>> TableListModelAdapter:setColumnSizes - column[" + j + "]=[" + arrayOfString[j] + "] is null, columnCount=" + getColumnCount());
      }
    }
  }
  
  public void setColumnHeadings(String[] paramArrayOfString)
  {
    this.m_arrColumnIdentifiers = paramArrayOfString;
    setColumnIdentifiers(this.m_arrColumnIdentifiers);
  }
  
  public void setColumnHeadings()
  {
    this.m_arrColumnIdentifiers = getColumnHeadings();
    setColumnIdentifiers(this.m_arrColumnIdentifiers);
  }
  
  public void setHeadings(JTable paramJTable)
  {
    String[] arrayOfString = this.m_arrColumnIdentifiers != null ? this.m_arrColumnIdentifiers : getColumnHeadings();
    setColumnIdentifiers(arrayOfString);
    int[] arrayOfInt = getColumnSizes();
    for (int i = 0; i < getColumnCount(); i++)
    {
      TableColumn localTableColumn = paramJTable.getColumn(new Integer(i));
      if (localTableColumn != null) {
        localTableColumn.setWidth(arrayOfInt[i]);
      }
    }
  }
  
  public int getRowIndex(Object paramObject)
  {
    if ((paramObject instanceof Integer)) {
      return ((Integer)paramObject).intValue();
    }
    for (int i = 0; i < getRowCount(); i++)
    {
      String str = (String)super.getValueAt(i, 0);
      if ((str != null) && (str.equalsIgnoreCase((String)paramObject))) {
        return i;
      }
    }
    return -1;
  }
  
  public int getColumnIndex(Object paramObject)
  {
    String[] arrayOfString = this.m_arrColumnIdentifiers != null ? this.m_arrColumnIdentifiers : getColumnHeadings();
    for (int i = 0; i < arrayOfString.length; i++) {
      if ((arrayOfString[i] != null) && (arrayOfString[i].equalsIgnoreCase((String)paramObject))) {
        return i;
      }
    }
    return -1;
  }
  
  public void setColumnID(String[] paramArrayOfString)
  {
    setColumnIdentifiers(paramArrayOfString);
  }
  
  public GemsTableListModel(GemsTableListModelBase paramGemsTableListModelBase)
  {
    this._tableListModel = paramGemsTableListModelBase;
  }
  
  public int getColumnCount()
  {
    if (this._tableListModel == null) {
      return 0;
    }
    return this._tableListModel.getColumnCount();
  }
  
  public int getRowCount()
  {
    if (this._tableListModel == null) {
      return 0;
    }
    return this._tableListModel.getRowCount();
  }
  
  public Vector getDataVector()
  {
    return this._tableListModel.getDataVector();
  }
  
  public void setValueAt(Object paramObject, int paramInt1, int paramInt2) {}
  
  public Object getValueAt(int paramInt1, int paramInt2)
  {
    return this._tableListModel.getValueAt(paramInt1, paramInt2);
  }
  
  public int[] getColumnSizes()
  {
    return this._tableListModel.getColumnSizes();
  }
  
  public String[] getColumnHeadings()
  {
    return this._tableListModel.getColumnHeadings();
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }
  
  public Class getColumnClass(int paramInt)
  {
    return this._tableListModel.getColumnClass(paramInt);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsTableListModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */