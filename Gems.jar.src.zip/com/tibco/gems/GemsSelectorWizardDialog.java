package com.tibco.gems;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class GemsSelectorWizardDialog
  extends JDialog
{
  protected JComboBox m_ba;
  protected Date m_start = null;
  protected Frame m_frame = null;
  protected boolean m_cancelled = false;
  protected JTextField m_st;
  public String m_selector = new String();
  
  public GemsSelectorWizardDialog(Frame paramFrame, String paramString1, String paramString2)
  {
    super(paramFrame, paramString1, true);
    this.m_frame = paramFrame;
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 1));
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2);
    JLabel localJLabel = new JLabel(paramString2 + " messages with timestamps ", 11);
    localJLabel.setMaximumSize(new Dimension(0, 24));
    this.m_ba = new JComboBox();
    this.m_ba.addItem(" After ");
    this.m_ba.addItem(" Before ");
    localJLabel.setLabelFor(this.m_ba);
    localJPanel2.add(localJLabel);
    localJPanel2.add(this.m_ba);
    this.m_start = new Date(System.currentTimeMillis() - 600000L);
    this.m_st = new JTextField(this.m_start.toString(), 20);
    this.m_st.setEditable(false);
    JButton localJButton1 = new JButton("Select...");
    localJButton1.addActionListener(new DatePickerAction());
    localJPanel2.add(this.m_st);
    localJPanel2.add(localJButton1);
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 2, 5, 5, 8, 8);
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setLayout(new FlowLayout());
    JButton localJButton2 = new JButton("OK ");
    JButton localJButton3 = new JButton("Cancel ");
    localJPanel3.add(localJButton2);
    localJPanel3.add(localJButton3);
    localJButton2.addActionListener(new OkPressed());
    localJButton3.addActionListener(new CancelPressed());
    localJPanel1.add(localJPanel3);
    setContentPane(localJPanel1);
    setLocationRelativeTo(paramFrame);
    pack();
    show();
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsSelectorWizardDialog.this.m_cancelled = true;
      GemsSelectorWizardDialog.this.dispose();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsSelectorWizardDialog.this.m_selector = "JMSTimestamp ";
      String str = (String)GemsSelectorWizardDialog.this.m_ba.getSelectedItem();
      if (str.equals(" Before ")) {
        GemsSelectorWizardDialog.this.m_selector += "< ";
      } else {
        GemsSelectorWizardDialog.this.m_selector += "> ";
      }
      GemsSelectorWizardDialog.this.m_selector += GemsSelectorWizardDialog.this.m_start.getTime();
      GemsSelectorWizardDialog.this.dispose();
    }
  }
  
  class DatePickerAction
    implements ActionListener
  {
    DatePickerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      DateTimePicker localDateTimePicker = new DateTimePicker(GemsSelectorWizardDialog.this.m_frame, "Select Date and Time:");
      localDateTimePicker.setLocationRelativeTo(GemsSelectorWizardDialog.this.m_frame);
      Date localDate = localDateTimePicker.select(GemsSelectorWizardDialog.this.m_start);
      if (localDate != null)
      {
        GemsSelectorWizardDialog.this.m_start = localDate;
        GemsSelectorWizardDialog.this.m_st.setText(GemsSelectorWizardDialog.this.m_start.toString());
      }
      localDateTimePicker.dispose();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsSelectorWizardDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */