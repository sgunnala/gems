package com.tibco.gems;

import java.awt.Point;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.TableModel;

public class PopupDestDisplayHandler
  extends PopupTableHandler
{
  public AbstractAction bq = null;
  public AbstractAction qp = null;
  public AbstractAction stm = null;
  public AbstractAction smm = null;
  public AbstractAction ts = null;
  public AbstractAction tp = null;
  public AbstractAction ptm = null;
  public AbstractAction pmm = null;
  public GemsDetailsTableModel m_model;
  public GemsConnectionNode m_cn;
  public JFrame m_frame;
  
  public PopupDestDisplayHandler(JTable paramJTable, GemsDetailsTableModel paramGemsDetailsTableModel, GemsConnectionNode paramGemsConnectionNode, JFrame paramJFrame)
  {
    super(paramJTable);
    this.m_model = paramGemsDetailsTableModel;
    this.m_cn = paramGemsConnectionNode;
    this.m_frame = paramJFrame;
  }
  
  public JPopupMenu createPopup(Point paramPoint)
  {
    JPopupMenu localJPopupMenu = super.createPopup(paramPoint);
    if (this.m_model.getColumnName(0).equals("QueueName"))
    {
      if (this.bq == null) {
        this.bq = new BrowseQueueAction("Browse Queue...", null);
      }
      if (this.qp == null) {
        this.qp = new SetPropertyAction("Queue Properties...", null);
      }
      if (this.stm == null) {
        this.stm = new SendTextMessageAction("Send TextMessage...", null);
      }
      if (this.smm == null) {
        this.smm = new SendMapMessageAction("Send MapMessage...", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.bq);
      localJPopupMenu.add(this.qp);
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.stm);
      localJPopupMenu.add(this.smm);
    }
    else if (this.m_model.getColumnName(0).equals("TopicName"))
    {
      if (this.ts == null) {
        this.ts = new TopicSubscriberAction("Topic Subscriber...", null);
      }
      if (this.tp == null) {
        this.tp = new SetPropertyAction("Topic Properties...", null);
      }
      if (this.ptm == null) {
        this.ptm = new PublishTextMessageAction("Publish TextMessage...", null);
      }
      if (this.pmm == null) {
        this.pmm = new PublishMapMessageAction("Publish MapMessage...", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.ts);
      localJPopupMenu.add(this.tp);
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.ptm);
      localJPopupMenu.add(this.pmm);
    }
    return localJPopupMenu;
  }
  
  public class BrowseQueueAction
    extends AbstractAction
  {
    public BrowseQueueAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (PopupDestDisplayHandler.this.m_cn != null) {
        new GemsQueueBrowser(PopupDestDisplayHandler.this.m_cn, (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0));
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class SendTextMessageAction
    extends AbstractAction
  {
    public SendTextMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (PopupDestDisplayHandler.this.m_cn != null) {
        new GemsMessageFrame(PopupDestDisplayHandler.this.m_cn, true, (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0), true, PopupDestDisplayHandler.this.m_frame, false);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class SendMapMessageAction
    extends AbstractAction
  {
    public SendMapMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (PopupDestDisplayHandler.this.m_cn != null) {
        new GemsMessageFrame(PopupDestDisplayHandler.this.m_cn, true, (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0), true, PopupDestDisplayHandler.this.m_frame, false, true);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class TopicSubscriberAction
    extends AbstractAction
  {
    public TopicSubscriberAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (PopupDestDisplayHandler.this.m_cn != null) {
        new GemsTopicSubscriber(PopupDestDisplayHandler.this.m_cn, (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0), "Topic Subscriber");
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class PublishMapMessageAction
    extends AbstractAction
  {
    public PublishMapMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (PopupDestDisplayHandler.this.m_cn != null) {
        new GemsMessageFrame(PopupDestDisplayHandler.this.m_cn, true, (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0), false, PopupDestDisplayHandler.this.m_frame, false, true);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class PublishTextMessageAction
    extends AbstractAction
  {
    public PublishTextMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (PopupDestDisplayHandler.this.m_cn != null) {
        new GemsMessageFrame(PopupDestDisplayHandler.this.m_cn, true, (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0), false, PopupDestDisplayHandler.this.m_frame, false);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class SetPropertyAction
    extends AbstractAction
  {
    public SetPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      String str = null;
      Object localObject = null;
      if (PopupDestDisplayHandler.this.m_cn != null)
      {
        GemsDestPropEditor localGemsDestPropEditor;
        if (PopupDestDisplayHandler.this.m_model.getColumnName(0).equals("TopicName"))
        {
          str = (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0);
          localGemsDestPropEditor = new GemsDestPropEditor(PopupDestDisplayHandler.this.m_frame, PopupDestDisplayHandler.this.m_cn, "Topic", str);
        }
        else if (PopupDestDisplayHandler.this.m_model.getColumnName(0).equals("QueueName"))
        {
          str = (String)PopupDestDisplayHandler.this.m_table.getModel().getValueAt(PopupDestDisplayHandler.this.m_row, 0);
          localGemsDestPropEditor = new GemsDestPropEditor(PopupDestDisplayHandler.this.m_frame, PopupDestDisplayHandler.this.m_cn, "Queue", str);
        }
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\PopupDestDisplayHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */