package com.tibco.gems;

import com.tibco.tibjms.admin.ACLEntry;
import com.tibco.tibjms.admin.AdminACLEntry;
import com.tibco.tibjms.admin.AdminPermissions;
import com.tibco.tibjms.admin.BridgeInfo;
import com.tibco.tibjms.admin.ChannelInfo;
import com.tibco.tibjms.admin.ConnectionFactoryInfo;
import com.tibco.tibjms.admin.ConnectionInfo;
import com.tibco.tibjms.admin.ConsumerInfo;
import com.tibco.tibjms.admin.DbStoreInfo;
import com.tibco.tibjms.admin.DestinationBridgeInfo;
import com.tibco.tibjms.admin.DestinationInfo;
import com.tibco.tibjms.admin.DurableInfo;
import com.tibco.tibjms.admin.FileStoreInfo;
import com.tibco.tibjms.admin.GroupInfo;
import com.tibco.tibjms.admin.MStoreInfo;
import com.tibco.tibjms.admin.Permissions;
import com.tibco.tibjms.admin.PrincipalInfo;
import com.tibco.tibjms.admin.ProducerInfo;
import com.tibco.tibjms.admin.QueueInfo;
import com.tibco.tibjms.admin.RVCMTransportInfo;
import com.tibco.tibjms.admin.RVQueuePolicy;
import com.tibco.tibjms.admin.RVTransportInfo;
import com.tibco.tibjms.admin.RouteInfo;
import com.tibco.tibjms.admin.SSTransportInfo;
import com.tibco.tibjms.admin.StatData;
import com.tibco.tibjms.admin.StoreInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import com.tibco.tibjms.admin.TopicInfo;
import com.tibco.tibjms.admin.TransactionInfo;
import com.tibco.tibjms.admin.TransportInfo;
import com.tibco.tibjms.admin.UserInfo;
import com.tibco.tibjms.admin.VersionInfo;
import java.awt.Color;
import java.awt.Component;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.PrintStream;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class GemsDetailsTableModel
  extends DefaultTableModel
  implements GetPopupHandler
{
  JTable m_table;
  MyRenderer m_renderer = new MyRenderer();
  Hashtable m_colWidths = null;
  boolean flag = true;
  PopupHandler m_popup = null;
  SimpleDateFormat dateFormatMillis = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
  static String[] s_error_cols = { "Error" };
  static String[] s_service_cols = { "ServiceName", "StartPeriod", "RequestCount", "ResponseCount", "AvgRequests/Min", "AvgRespTime(ms)", "MaxRespTime(ms)", "RespTimeLimit(ms)", "%WithinLimit", "OverLimitCount", "LastRequestAt" };
  static String[] s_queues_cols = { "QueueName", "PendingMsgCount", "PendingMsgSize", "ReceiverCount", "InTotalMsgs", "OutTotalMsgs", "InMsgRate", "OutMsgRate", "Static", "Routed", "RouteConnected", "RouteName" };
  static String[] s_topics_cols = { "TopicName", "PendingMsgCount", "PendingMsgSize", "SubscriberCount", "InTotalMsgs", "OutTotalMsgs", "InMsgRate", "OutMsgRate", "DurableCount", "Static", "Global" };
  static String[] s_conn_cols = { "ID", "Type", "Host", "Address", "ClientID", "ConsumerCount", "ProducerCount", "SessionCount", "StartTime", "UpTime", "URL", "Username", "ClientVersion", "ClientType", "isFT", "isXA", "isAdmin", "UncommittedCount", "UncommittedSize" };
  static String[] s_sys_conn_cols = { "ID", "Type", "Host", "Address", "ConsumerCount", "ProducerCount", "SessionCount", "StartTime", "UpTime", "URL", "Username", "ClientVersion", "isFT", "UncommittedCount", "UncommittedSize" };
  static String[] s_bridge_cols = { "SourceName", "SourceType", "Targets" };
  static String[] s_destbridge_cols = { "Source", "SourceType", "Target", "TargetType", "Selector" };
  static String[] s_storesFile_cols = { "StoreName", "FileName", "FileSize", "FreeSpace", "UsedSpace", "Fragmentation", "MsgSize", "MsgCount", "SyncWrites", "SwappedSize", "SwappedCount" };
  static String[] s_storesDb_cols = { "StoreName", "URL", "UserName", "MsgCount", "SwappedCount", "DriverName", "DriverDialect" };
  static String[] s_storesMStore_cols = { "StoreName", "FileName", "FileSize", "FreeSpace", "UsedSpace", "MsgCount", "SwappedCount", "DiscardScanInterval", "DiscardScanBytes", "FirstScanFinished" };
  static String[] s_group_cols = { "GroupName", "Description", "isExternal", "Users" };
  static String[] s_chan_cols = { "Name", "Address", "Interface", "Active", "ByteRate", "MsgRate", "TotalBytes", "TotalMsgs", "BacklogCount", "BacklogSize", "BufferedBytes", "MaxRate", "MaxTime", "TransmittedBytes", "RetransmittedBytes", "TTL", "Priority" };
  static String[] s_fact_cols = { "Aliases", "URL", "Type", "ClientID", "ConnectCount", "ConnectDelay", "ReconnectCount", "ReconnectDelay", "XA", "LB Metric" };
  static String[] s_cons_cols = { "ID", "CreateTime", "DestinationName", "DestinationType", "DurableName", "PendingMsgCount", "PendingMsgSize", "Selector", "ConnectionID", "SessionID", "Username", "ByteRate", "MsgRate", "TotalBytes", "TotalMsgs", "Multicast" };
  static String[] s_route_cols = { "Name", "URL", "Connected", "ConnectionID", "Stalled", "ZoneName", "ZoneType", "InTotalMsgs", "OutTotalMsgs", "InMsgRate", "OutMsgRate", "inSelectors", "outSelectors", "Configured", "BacklogCount", "BacklogSize" };
  static String[] s_dur_cols = { "DurableName", "TopicName", "Active", "PendingMsgCount", "PendingMsgSize", "ClientID", "ConsumerID", "Username", "Selector", "NoLocal", "DeliveredMsgCount", "Static" };
  static String[] s_qprop_cols = { "QueueProperty", "Value" };
  static String[] s_tprop_cols = { "TopicProperty", "Value" };
  static String[] s_prod_cols = { "ID", "CreateTime", "DestinationName", "DestinationType", "ConnectionID", "SessionID", "Username", "ByteRate", "MsgRate", "TotalBytes", "TotalMsgs" };
  static String[] s_acl_cols = { "DestinationName", "DestinationType", "PrincipalName", "PrincipalType", "isExternal", "Permissions" };
  static String[] s_adminacl_cols = { "PrincipalName", "PrincipalType", "isExternal", "AdministrativePermissions" };
  static String[] s_prop_cols = { "Property", "Value" };
  static String[] s_ssactive_cols = { "Identifier", "Date", "Time" };
  static String[] s_ssactiveL_cols = { "Destination" };
  static String[] s_ssinactive_cols = { "Identifier", "SSType", "Reason", "Disable Date", "Disable Time" };
  static String[] s_ssinterface_cols = { "Interface ID", "Type", "Date", "Time", "Busy", "Applid", "Status" };
  static String[] s_ssimsstats_cols = { "IMS Buffer", "Value" };
  static String[] s_ssimsbuffs_cols = { "IMS Property", "Value" };
  static String[] s_ssimsgen_cols = { "IMS Connection Property", "Con Value" };
  static String[] s_user_cols = { "UserName", "Desciption", "isExternal" };
  static String[] s_transact_cols = { "State", "GlobalTransactionId", "FormatId", "BranchQualifier" };
  static String[] s_transprt_cols = { "TransportName", "Type", "QueueImportDelMode", "TopicImportDelMode", "ExportHeaders", "ExportProperties", "FurtherInfo" };
  static String[] s_client_cols = { "ClientID", "ConnectionID", "ConsumerCount", "ProducerCount", "SessionCount", "InTotalMsgs", "OutTotalMsgs", "InMsgRate", "OutMsgRate" };
  
  public GemsDetailsTableModel()
  {
    initColumnWidths();
  }
  
  public PopupHandler getPopupHandler()
  {
    if (this.m_popup == null) {
      this.m_popup = new PopupDetailsTableHandler(this.m_table, this);
    }
    return this.m_popup;
  }
  
  public void setPopupHandler(PopupHandler paramPopupHandler)
  {
    this.m_popup = paramPopupHandler;
  }
  
  public void setTable(JTable paramJTable)
  {
    this.m_table = paramJTable;
    if (Gems.getGems().getColourPendingMsgs())
    {
      this.m_table.setDefaultRenderer(new Long(1L).getClass(), this.m_renderer);
      this.m_table.setDefaultRenderer(new Object().getClass(), this.m_renderer);
      this.m_table.setDefaultRenderer(new MsgCellValue(0L).getClass(), this.m_renderer);
      this.m_table.setDefaultRenderer(new CellValue("").getClass(), this.m_renderer);
      this.m_table.setDefaultRenderer(new SSCellValue("", "Head").getClass(), this.m_renderer);
    }
  }
  
  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject != null)
    {
      if ((localObject instanceof MsgCellValue)) {
        return new Long(0L).getClass();
      }
      if ((localObject instanceof SSCellValue)) {
        return new String().getClass();
      }
      if ((localObject instanceof CellValue)) {
        return new String().getClass();
      }
      return localObject.getClass();
    }
    return new String().getClass();
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }
  
  public String getSelectedCol1()
  {
    if (this.m_table.getSelectedRow() < 0) {
      return null;
    }
    if ((getColumnCount() == 1) && (getColumnName(0).equals("Error"))) {
      return null;
    }
    Object localObject = this.m_table.getValueAt(this.m_table.getSelectedRow(), 0);
    if ((localObject instanceof Long)) {
      return String.valueOf((Long)localObject);
    }
    return (String)localObject;
  }
  
  public String getSelectedCol(int paramInt)
  {
    if (this.m_table.getSelectedRow() < 0) {
      return null;
    }
    Object localObject = this.m_table.getValueAt(this.m_table.getSelectedRow(), paramInt - 1);
    if ((localObject instanceof Long)) {
      return String.valueOf((Long)localObject);
    }
    return (String)localObject;
  }
  
  public int getSelectedRow()
  {
    return this.m_table.getSelectedRow();
  }
  
  public void maintainSelection(int paramInt, String paramString)
  {
    if ((paramInt < 0) || (paramInt >= this.m_table.getRowCount())) {
      return;
    }
    Object localObject = this.m_table.getValueAt(paramInt, 0);
    String str;
    if ((localObject instanceof Long)) {
      str = String.valueOf((Long)localObject);
    } else {
      str = (String)localObject;
    }
    if (str.equals(paramString)) {
      this.m_table.addRowSelectionInterval(paramInt, paramInt);
    }
  }
  
  public void populateErrorInfo(String paramString)
  {
    setRowCount(0);
    setColumnCount(0);
    this.m_table.setAutoResizeMode(4);
    setColumnIdentifiers(s_error_cols);
    addRow(new Object[] { paramString });
  }
  
  public void populateServiceInfo(GemsServiceTable paramGemsServiceTable)
  {
    if (paramGemsServiceTable == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 11) || (!getColumnName(0).equals("ServiceName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_service_cols);
      setupColumnWidths();
    }
    try
    {
      Enumeration localEnumeration = paramGemsServiceTable.m_services.keys();
      while (localEnumeration.hasMoreElements())
      {
        GemsService localGemsService = (GemsService)paramGemsServiceTable.m_services.get(localEnumeration.nextElement());
        Date localDate1 = new Date();
        Date localDate2 = new Date();
        localDate1.setTime(localGemsService.m_started);
        localDate2.setTime(localGemsService.m_lastRequest);
        long l = System.currentTimeMillis();
        double d1 = 0.0D;
        double d2 = (l - localGemsService.m_started) / 60000.0D;
        if (d2 >= 1.0D) {
          d1 = localGemsService.m_hits / d2;
        }
        double d3 = 0.0D;
        if (localGemsService.m_responses > 0L) {
          d3 = localGemsService.m_totalLatency / localGemsService.m_responses;
        }
        double d4 = 100.0D;
        if (localGemsService.m_responses > 0L) {
          d4 -= localGemsService.m_overLimitCount / localGemsService.m_responses * 100.0D;
        }
        Object[] arrayOfObject = { localGemsService.m_name, paramGemsServiceTable.m_running ? localDate1.toString() : "Disabled", new Long(localGemsService.m_hits), new Long(localGemsService.m_responses), new Double(d1), new Double(d3), new Long(localGemsService.m_maxLatency), new Long(localGemsService.m_respLimit), new Double(d4), new Long(localGemsService.m_overLimitCount), localGemsService.m_lastRequest > 0L ? this.dateFormatMillis.format(localDate2).toString() : "" };
        addRow(arrayOfObject);
      }
    }
    catch (Exception localException)
    {
      System.err.println("JMSException: " + localException.getMessage());
      return;
    }
  }
  
  public void populateQueuesInfo(QueueInfo[] paramArrayOfQueueInfo)
  {
    if (paramArrayOfQueueInfo == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 12) || (!getColumnName(0).equals("QueueName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_queues_cols);
      setupColumnWidths();
    }
    try
    {
      for (int i = 0; i < paramArrayOfQueueInfo.length; i++)
      {
        String str1 = "?";
        String str2 = "";
        try
        {
          str1 = String.valueOf(paramArrayOfQueueInfo[i].isRouted());
          str2 = paramArrayOfQueueInfo[i].getRouteName();
        }
        catch (Throwable localThrowable1) {}
        long l = 0L;
        try
        {
          l = paramArrayOfQueueInfo[i].getMaxMsgs();
        }
        catch (Throwable localThrowable2) {}
        Object[] arrayOfObject = { paramArrayOfQueueInfo[i].getName(), new MsgCellValue(paramArrayOfQueueInfo[i].getPendingMessageCount(), l), new CellValue(StringUtilities.getHumanReadableSize(paramArrayOfQueueInfo[i].getPendingMessageSize()), paramArrayOfQueueInfo[i].getPendingMessageSize(), Long.valueOf(1L), Long.valueOf(paramArrayOfQueueInfo[i].getMaxBytes())), new Long(paramArrayOfQueueInfo[i].getReceiverCount()), new Long(paramArrayOfQueueInfo[i].getInboundStatistics().getTotalMessages()), new Long(paramArrayOfQueueInfo[i].getOutboundStatistics().getTotalMessages()), new Long(paramArrayOfQueueInfo[i].getInboundStatistics().getMessageRate()), new Long(paramArrayOfQueueInfo[i].getOutboundStatistics().getMessageRate()), String.valueOf(paramArrayOfQueueInfo[i].isStatic()), str1, String.valueOf(paramArrayOfQueueInfo[i].isRouteConnected()), str2 };
        addRow(arrayOfObject);
      }
    }
    catch (Exception localException)
    {
      System.err.println("JMSException: " + localException.getMessage());
      return;
    }
  }
  
  public void populateTopicsInfo(TopicInfo[] paramArrayOfTopicInfo)
  {
    if (paramArrayOfTopicInfo == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 11) || (!getColumnName(0).equals("TopicName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_topics_cols);
      setupColumnWidths();
    }
    try
    {
      for (int i = 0; i < paramArrayOfTopicInfo.length; i++)
      {
        long l = 0L;
        try
        {
          l = paramArrayOfTopicInfo[i].getMaxMsgs();
        }
        catch (Throwable localThrowable) {}
        Object[] arrayOfObject = { paramArrayOfTopicInfo[i].getName(), new MsgCellValue(paramArrayOfTopicInfo[i].getPendingMessageCount(), l), new CellValue(StringUtilities.getHumanReadableSize(paramArrayOfTopicInfo[i].getPendingMessageSize()), paramArrayOfTopicInfo[i].getPendingMessageSize(), Long.valueOf(1L), Long.valueOf(paramArrayOfTopicInfo[i].getMaxBytes())), new Long(paramArrayOfTopicInfo[i].getSubscriberCount()), new Long(paramArrayOfTopicInfo[i].getInboundStatistics().getTotalMessages()), new Long(paramArrayOfTopicInfo[i].getOutboundStatistics().getTotalMessages()), new Long(paramArrayOfTopicInfo[i].getInboundStatistics().getMessageRate()), new Long(paramArrayOfTopicInfo[i].getOutboundStatistics().getMessageRate()), new Long(paramArrayOfTopicInfo[i].getDurableCount()), String.valueOf(paramArrayOfTopicInfo[i].isStatic()), String.valueOf(paramArrayOfTopicInfo[i].isGlobal()) };
        addRow(arrayOfObject);
      }
    }
    catch (Exception localException)
    {
      System.err.println("JMSException: " + localException.getMessage());
      return;
    }
  }
  
  public void populateConnectionInfo(TibjmsAdmin paramTibjmsAdmin)
  {
    if (paramTibjmsAdmin == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 19) || (!getColumnName(2).equals("Host")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_conn_cols);
      setupColumnWidths();
    }
    try
    {
      ConnectionInfo[] arrayOfConnectionInfo = paramTibjmsAdmin.getConnections();
      Date localDate = new Date();
      for (int i = 0; (arrayOfConnectionInfo != null) && (i < arrayOfConnectionInfo.length); i++)
      {
        Long localLong = new Long(-1L);
        String str = "?";
        try
        {
          localLong = new Long(arrayOfConnectionInfo[i].getUncommittedCount());
          str = StringUtilities.getHumanReadableSize(new Long(arrayOfConnectionInfo[i].getUncommittedSize()).longValue());
        }
        catch (Throwable localThrowable) {}
        localDate.setTime(arrayOfConnectionInfo[i].getStartTime());
        Object[] arrayOfObject = { new Long(arrayOfConnectionInfo[i].getID()), arrayOfConnectionInfo[i].getType() != null ? arrayOfConnectionInfo[i].getType() : "<unknown>", arrayOfConnectionInfo[i].getHost() != null ? arrayOfConnectionInfo[i].getHost() : "<unknown>", arrayOfConnectionInfo[i].getAddress(), arrayOfConnectionInfo[i].getClientID() != null ? arrayOfConnectionInfo[i].getClientID() : new String(), new Long(arrayOfConnectionInfo[i].getConsumerCount()), new Long(arrayOfConnectionInfo[i].getProducerCount()), new Long(arrayOfConnectionInfo[i].getSessionCount()), localDate.toString(), new Long(arrayOfConnectionInfo[i].getUpTime()), arrayOfConnectionInfo[i].getURL(), arrayOfConnectionInfo[i].getUserName(), arrayOfConnectionInfo[i].getVersionInfo().toString(), arrayOfConnectionInfo[i].getClientType(), String.valueOf(arrayOfConnectionInfo[i].isFT()), String.valueOf(arrayOfConnectionInfo[i].isXA()), String.valueOf(arrayOfConnectionInfo[i].isAdmin()), localLong, str };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateSystemConnectionInfo(TibjmsAdmin paramTibjmsAdmin)
  {
    if (paramTibjmsAdmin == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 15) || (!getColumnName(2).equals("Host")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_sys_conn_cols);
      setupColumnWidths();
    }
    try
    {
      ConnectionInfo[] arrayOfConnectionInfo = paramTibjmsAdmin.getSystemConnections();
      Date localDate = new Date();
      for (int i = 0; (arrayOfConnectionInfo != null) && (i < arrayOfConnectionInfo.length); i++)
      {
        Long localLong = new Long(-1L);
        String str = "?";
        try
        {
          localLong = new Long(arrayOfConnectionInfo[i].getUncommittedCount());
          str = StringUtilities.getHumanReadableSize(new Long(arrayOfConnectionInfo[i].getUncommittedSize()).longValue());
        }
        catch (Throwable localThrowable) {}
        localDate.setTime(arrayOfConnectionInfo[i].getStartTime());
        Object[] arrayOfObject = { new Long(arrayOfConnectionInfo[i].getID()), arrayOfConnectionInfo[i].getType() != null ? arrayOfConnectionInfo[i].getType() : "<unknown>", arrayOfConnectionInfo[i].getHost() != null ? arrayOfConnectionInfo[i].getHost() : "<unknown>", arrayOfConnectionInfo[i].getAddress(), new Long(arrayOfConnectionInfo[i].getConsumerCount()), new Long(arrayOfConnectionInfo[i].getProducerCount()), new Long(arrayOfConnectionInfo[i].getSessionCount()), localDate.toString(), new Long(arrayOfConnectionInfo[i].getUpTime()), arrayOfConnectionInfo[i].getURL(), arrayOfConnectionInfo[i].getUserName(), arrayOfConnectionInfo[i].getVersionInfo().toString(), String.valueOf(arrayOfConnectionInfo[i].isFT()), localLong, str };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
    catch (Exception localException) {}
  }
  
  public void populateBridgeInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    try
    {
      DestinationBridgeInfo[] arrayOfDestinationBridgeInfo = paramGemsConnectionNode.m_adminConn.getDestinationBridges(0, ">");
      populatetDesBridgeInfo(arrayOfDestinationBridgeInfo);
      return;
    }
    catch (Throwable localThrowable)
    {
      setRowCount(0);
      if ((getColumnCount() != 3) || (!getColumnName(0).equals("SourceName")))
      {
        setColumnCount(0);
        this.m_table.setAutoResizeMode(0);
        setColumnIdentifiers(s_bridge_cols);
        setupColumnWidths();
      }
      try
      {
        BridgeInfo[] arrayOfBridgeInfo = paramGemsConnectionNode.m_adminConn.getBridges();
        for (int i = 0; (arrayOfBridgeInfo != null) && (i < arrayOfBridgeInfo.length); i++)
        {
          Object[] arrayOfObject = { arrayOfBridgeInfo[i].getName(), arrayOfBridgeInfo[i].getType() == 1 ? new String("Queue") : new String("Topic"), StringUtilities.arrayToString(arrayOfBridgeInfo[i].getTargets()) };
          addRow(arrayOfObject);
        }
      }
      catch (TibjmsAdminException localTibjmsAdminException)
      {
        System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
        return;
      }
    }
  }
  
  public void populatetDesBridgeInfo(DestinationBridgeInfo[] paramArrayOfDestinationBridgeInfo)
  {
    if ((getColumnCount() != 5) || (!getColumnName(0).equals("Source")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_destbridge_cols);
      setupColumnWidths();
    }
    for (int i = 0; (paramArrayOfDestinationBridgeInfo != null) && (i < paramArrayOfDestinationBridgeInfo.length); i++)
    {
      Object[] arrayOfObject = { paramArrayOfDestinationBridgeInfo[i].getSourceName(), paramArrayOfDestinationBridgeInfo[i].getSourceType() == 1 ? new String("Queue") : new String("Topic"), paramArrayOfDestinationBridgeInfo[i].getTargetName(), paramArrayOfDestinationBridgeInfo[i].getTargetType() == 1 ? new String("Queue") : new String("Topic"), paramArrayOfDestinationBridgeInfo[i].getSelector() };
      addRow(arrayOfObject);
    }
  }
  
  public void populateStoresFileInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 11) || (!getColumnName(1).equals("FileName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_storesFile_cols);
      setupColumnWidths();
    }
    String[] arrayOfString;
    Object localObject;
    try
    {
      arrayOfString = paramGemsConnectionNode.m_adminConn.getStores();
    }
    catch (Throwable localThrowable1)
    {
      try
      {
        StoreInfo localStoreInfo = paramGemsConnectionNode.m_adminConn.getStoreInfo(2);
        localObject = new Object[] { "$sys.nonfailsafe", "async-msgs.db", StringUtilities.getHumanReadableSize(localStoreInfo.getFileSize()), StringUtilities.getHumanReadableSize(localStoreInfo.getFreeSpace()), StringUtilities.getHumanReadableSize(localStoreInfo.getUsedSpace()), "N/A", StringUtilities.getHumanReadableSize(localStoreInfo.getMsgBytes()), String.valueOf(localStoreInfo.getMsgCount()), "false", StringUtilities.getHumanReadableSize(localStoreInfo.getSwappedBytes()), String.valueOf(localStoreInfo.getSwappedCount()) };
        addRow((Object[])localObject);
        localStoreInfo = paramGemsConnectionNode.m_adminConn.getStoreInfo(1);
        localObject = new Object[] { "$sys.failsafe", "sync-msgs.db", StringUtilities.getHumanReadableSize(localStoreInfo.getFileSize()), StringUtilities.getHumanReadableSize(localStoreInfo.getFreeSpace()), StringUtilities.getHumanReadableSize(localStoreInfo.getUsedSpace()), "N/A", StringUtilities.getHumanReadableSize(localStoreInfo.getMsgBytes()), String.valueOf(localStoreInfo.getMsgCount()), "true", StringUtilities.getHumanReadableSize(localStoreInfo.getSwappedBytes()), String.valueOf(localStoreInfo.getSwappedCount()) };
        addRow((Object[])localObject);
      }
      catch (TibjmsAdminException localTibjmsAdminException2)
      {
        System.err.println("JMSException: " + localTibjmsAdminException2.getMessage());
        return;
      }
      return;
    }
    try
    {
      for (int i = 0; i < arrayOfString.length; i++)
      {
        String str1 = arrayOfString[i];
        localObject = paramGemsConnectionNode.m_adminConn.getStoreInfo(str1);
        FileStoreInfo localFileStoreInfo = null;
        if ((localObject instanceof FileStoreInfo))
        {
          localFileStoreInfo = (FileStoreInfo)localObject;
          String str2 = "N/A";
          try
          {
            str2 = String.valueOf(localFileStoreInfo.getFragmentation()) + "%";
          }
          catch (Throwable localThrowable2) {}
          Object[] arrayOfObject = { str1, localFileStoreInfo.getFileName(), StringUtilities.getHumanReadableSize(localFileStoreInfo.getSize()), StringUtilities.getHumanReadableSize(localFileStoreInfo.getNotInUseSpace()), StringUtilities.getHumanReadableSize(localFileStoreInfo.getInUseSpace()), str2, StringUtilities.getHumanReadableSize(((StoreInfo)localObject).getMsgBytes()), String.valueOf(((StoreInfo)localObject).getMsgCount()), String.valueOf(localFileStoreInfo.isSynchronousWriteEnabled()), StringUtilities.getHumanReadableSize(((StoreInfo)localObject).getSwappedBytes()), String.valueOf(((StoreInfo)localObject).getSwappedCount()) };
          addRow(arrayOfObject);
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException1)
    {
      System.err.println("JMSException: " + localTibjmsAdminException1.getMessage());
      return;
    }
  }
  
  public void populateStoresDbInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 7) || (!getColumnName(5).equals("DriverName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_storesDb_cols);
      setupColumnWidths();
    }
    String[] arrayOfString;
    try
    {
      arrayOfString = paramGemsConnectionNode.m_adminConn.getStores();
    }
    catch (Throwable localThrowable)
    {
      return;
    }
    try
    {
      for (int i = 0; i < arrayOfString.length; i++)
      {
        String str = arrayOfString[i];
        StoreInfo localStoreInfo = paramGemsConnectionNode.m_adminConn.getStoreInfo(str);
        DbStoreInfo localDbStoreInfo = null;
        if ((localStoreInfo instanceof DbStoreInfo))
        {
          localDbStoreInfo = (DbStoreInfo)localStoreInfo;
          Object[] arrayOfObject = { str, localDbStoreInfo.getURL(), localDbStoreInfo.getUserName(), String.valueOf(localStoreInfo.getMsgCount()), String.valueOf(localStoreInfo.getSwappedCount()), localDbStoreInfo.getDriverName(), localDbStoreInfo.getDriverDialect() };
          addRow(arrayOfObject);
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateStoresMStoreInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 10) || (!getColumnName(7).equals("DiscardScanInterval")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_storesMStore_cols);
      setupColumnWidths();
    }
    String[] arrayOfString;
    try
    {
      arrayOfString = paramGemsConnectionNode.m_adminConn.getStores();
    }
    catch (Throwable localThrowable)
    {
      return;
    }
    try
    {
      for (int i = 0; i < arrayOfString.length; i++)
      {
        String str = arrayOfString[i];
        StoreInfo localStoreInfo = paramGemsConnectionNode.m_adminConn.getStoreInfo(str);
        MStoreInfo localMStoreInfo = null;
        if ((localStoreInfo instanceof MStoreInfo))
        {
          localMStoreInfo = (MStoreInfo)localStoreInfo;
          Object[] arrayOfObject = { str, localMStoreInfo.getFileName(), StringUtilities.getHumanReadableSize(localMStoreInfo.getSize()), StringUtilities.getHumanReadableSize(localMStoreInfo.getNotInUseSpace()), StringUtilities.getHumanReadableSize(localMStoreInfo.getInUseSpace()), String.valueOf(localStoreInfo.getMsgCount()), String.valueOf(localStoreInfo.getSwappedCount()), String.valueOf(localMStoreInfo.getDiscardScanInterval()), StringUtilities.getHumanReadableSize(localMStoreInfo.getDiscardScanBytes()), String.valueOf(localMStoreInfo.isFirstScanFinished()) };
          addRow(arrayOfObject);
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateGroupInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 4) || (!getColumnName(0).equals("GroupName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_group_cols);
      setupColumnWidths();
    }
    try
    {
      GroupInfo[] arrayOfGroupInfo = paramGemsConnectionNode.m_adminConn.getGroups();
      for (int i = 0; (arrayOfGroupInfo != null) && (i < arrayOfGroupInfo.length); i++)
      {
        StringBuffer localStringBuffer = new StringBuffer();
        UserInfo[] arrayOfUserInfo = arrayOfGroupInfo[i].getUsers();
        for (int j = 0; j < arrayOfUserInfo.length; j++)
        {
          if (j > 0) {
            localStringBuffer.append(", ");
          }
          localStringBuffer.append(arrayOfUserInfo[j].getName());
        }
        Object[] arrayOfObject = { arrayOfGroupInfo[i].getName(), arrayOfGroupInfo[i].getDescription(), String.valueOf(arrayOfGroupInfo[i].isExternal()), new String(localStringBuffer) };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateChannelsInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 17) || (!getColumnName(1).equals("Address")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_chan_cols);
      setupColumnWidths();
    }
    ChannelInfo[] arrayOfChannelInfo;
    try
    {
      arrayOfChannelInfo = paramGemsConnectionNode.m_adminConn.getChannels();
    }
    catch (Throwable localThrowable)
    {
      return;
    }
    try
    {
      for (int i = 0; (arrayOfChannelInfo != null) && (i < arrayOfChannelInfo.length); i++)
      {
        Object[] arrayOfObject = { arrayOfChannelInfo[i].getName(), arrayOfChannelInfo[i].getAddress(), arrayOfChannelInfo[i].getInterface(), String.valueOf(arrayOfChannelInfo[i].isActive()), new Long(arrayOfChannelInfo[i].getStatistics().getByteRate()), new Long(arrayOfChannelInfo[i].getStatistics().getMessageRate()), new Long(arrayOfChannelInfo[i].getStatistics().getTotalBytes()), new Long(arrayOfChannelInfo[i].getStatistics().getTotalMessages()), new Long(arrayOfChannelInfo[i].getBacklogCount()), StringUtilities.getHumanReadableSize(new Long(arrayOfChannelInfo[i].getBacklogSize()).longValue()), StringUtilities.getHumanReadableSize(new Long(arrayOfChannelInfo[i].getBufferedBytes()).longValue()), StringUtilities.getHumanReadableSize(new Long(arrayOfChannelInfo[i].getMaxRate()).longValue()), new Long(arrayOfChannelInfo[i].getMaxTime()), StringUtilities.getHumanReadableSize(new Long(arrayOfChannelInfo[i].getTransmittedBytes()).longValue()), StringUtilities.getHumanReadableSize(new Long(arrayOfChannelInfo[i].getRetransmittedBytes()).longValue()), new Long(arrayOfChannelInfo[i].getTtl()), new Long(arrayOfChannelInfo[i].getPriority()) };
        addRow(arrayOfObject);
      }
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
      return;
    }
  }
  
  public void populateFactoryInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 10) || (!getColumnName(0).equals("Aliases")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_fact_cols);
      setupColumnWidths();
    }
    try
    {
      ConnectionFactoryInfo[] arrayOfConnectionFactoryInfo = paramGemsConnectionNode.m_adminConn.getConnectionFactories();
      for (int i = 0; (arrayOfConnectionFactoryInfo != null) && (i < arrayOfConnectionFactoryInfo.length); i++)
      {
        String str1 = "Generic";
        if (arrayOfConnectionFactoryInfo[i].getDestinationType() == 1) {
          str1 = "Queue";
        } else if (arrayOfConnectionFactoryInfo[i].getDestinationType() == 2) {
          str1 = "Topic";
        }
        String str2 = "None";
        if (arrayOfConnectionFactoryInfo[i].getMetric() == 1) {
          str2 = "Connections";
        } else if (arrayOfConnectionFactoryInfo[i].getMetric() == 2) {
          str2 = "ByteRate";
        }
        Object[] arrayOfObject = { StringUtilities.arrayToString(arrayOfConnectionFactoryInfo[i].getJNDINames()), arrayOfConnectionFactoryInfo[i].getURL(), str1, arrayOfConnectionFactoryInfo[i].getClientID(), new Long(arrayOfConnectionFactoryInfo[i].getConnectAttemptCount()), new Long(arrayOfConnectionFactoryInfo[i].getConnectAttemptDelay()), new Long(arrayOfConnectionFactoryInfo[i].getReconnectAttemptCount()), new Long(arrayOfConnectionFactoryInfo[i].getReconnectAttemptDelay()), String.valueOf(arrayOfConnectionFactoryInfo[i].getXAType()), str2 };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateConsumerInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 16) || (!getColumnName(4).equals("DurableName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_cons_cols);
      setupColumnWidths();
    }
    try
    {
      try
      {
        arrayOfConsumerInfo = paramGemsConnectionNode.m_adminConn.getConsumers(null, null, null, false, 5);
        addConsumerInfo(arrayOfConsumerInfo);
      }
      catch (Throwable localThrowable)
      {
        setRowCount(0);
        ConsumerInfo[] arrayOfConsumerInfo = paramGemsConnectionNode.m_adminConn.getConsumersStatistics();
        addConsumerInfo(arrayOfConsumerInfo);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void addConsumerInfo(ConsumerInfo[] paramArrayOfConsumerInfo)
  {
    try
    {
      Date localDate = new Date();
      for (int i = 0; (paramArrayOfConsumerInfo != null) && (i < paramArrayOfConsumerInfo.length); i++)
      {
        String str1 = "?";
        Long localLong1 = new Long(-1L);
        Long localLong2 = new Long(-1L);
        try
        {
          str1 = paramArrayOfConsumerInfo[i].getSelector();
          localLong1 = new Long(paramArrayOfConsumerInfo[i].getPendingMessageCount());
          localLong2 = new Long(paramArrayOfConsumerInfo[i].getPendingMessageSize());
        }
        catch (Throwable localThrowable1) {}
        localDate.setTime(paramArrayOfConsumerInfo[i].getCreateTime());
        boolean bool = false;
        try
        {
          bool = paramArrayOfConsumerInfo[i].isMulticast();
        }
        catch (Throwable localThrowable2) {}
        String str2 = "Generic";
        if (paramArrayOfConsumerInfo[i].getDestinationType() == 1) {
          str2 = "Queue";
        } else if (paramArrayOfConsumerInfo[i].getDestinationType() == 2) {
          str2 = "Topic";
        }
        Object[] arrayOfObject = { new Long(paramArrayOfConsumerInfo[i].getID()), localDate.toString(), paramArrayOfConsumerInfo[i].getDestinationName(), str2, paramArrayOfConsumerInfo[i].getDurableName(), localLong1, localLong2, str1, new Long(paramArrayOfConsumerInfo[i].getConnectionID()), new Long(paramArrayOfConsumerInfo[i].getSessionID()), paramArrayOfConsumerInfo[i].getUsername(), new Long(paramArrayOfConsumerInfo[i].getStatistics().getByteRate()), new Long(paramArrayOfConsumerInfo[i].getStatistics().getMessageRate()), new Long(paramArrayOfConsumerInfo[i].getStatistics().getTotalBytes()), new Long(paramArrayOfConsumerInfo[i].getStatistics().getTotalMessages()), String.valueOf(bool) };
        addRow(arrayOfObject);
      }
    }
    catch (Exception localException)
    {
      System.err.println("JMSException: " + localException.getMessage());
      return;
    }
  }
  
  public void populateRoutesInfo(TibjmsAdmin paramTibjmsAdmin)
  {
    if (paramTibjmsAdmin == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 16) || (!getColumnName(1).equals("URL")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_route_cols);
      setupColumnWidths();
    }
    try
    {
      RouteInfo[] arrayOfRouteInfo = paramTibjmsAdmin.getRoutes();
      for (int i = 0; (arrayOfRouteInfo != null) && (i < arrayOfRouteInfo.length); i++)
      {
        Long localLong = new Long(-1L);
        String str = "?";
        try
        {
          localLong = new Long(arrayOfRouteInfo[i].getBacklogCount());
          str = StringUtilities.getHumanReadableSize(new Long(arrayOfRouteInfo[i].getBacklogSize()).longValue());
        }
        catch (Throwable localThrowable) {}
        int j = arrayOfRouteInfo[i].getZoneType();
        Object[] arrayOfObject = { arrayOfRouteInfo[i].getName(), arrayOfRouteInfo[i].getURL(), String.valueOf(arrayOfRouteInfo[i].isConnected()), new Long(arrayOfRouteInfo[i].getConnectionID()), String.valueOf(arrayOfRouteInfo[i].isStalled()), arrayOfRouteInfo[i].getZoneName(), j == 1 ? new String("OneHop") : j == 0 ? new String("MultiHop") : new String("Unknown"), new Long(arrayOfRouteInfo[i].getInboundStatistics().getTotalMessages()), new Long(arrayOfRouteInfo[i].getOutboundStatistics().getTotalMessages()), new Long(arrayOfRouteInfo[i].getInboundStatistics().getMessageRate()), new Long(arrayOfRouteInfo[i].getOutboundStatistics().getMessageRate()), StringUtilities.arrayToString(arrayOfRouteInfo[i].getIncomingSelectors()), StringUtilities.arrayToString(arrayOfRouteInfo[i].getOutgoingSelectors()), String.valueOf(arrayOfRouteInfo[i].isConfigured()), localLong, str };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateDurablesInfo(TibjmsAdmin paramTibjmsAdmin)
  {
    if (paramTibjmsAdmin == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 12) || (!getColumnName(0).equals("DurableName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_dur_cols);
      setupColumnWidths();
    }
    try
    {
      DurableInfo[] arrayOfDurableInfo = paramTibjmsAdmin.getDurables();
      for (int i = 0; (arrayOfDurableInfo != null) && (i < arrayOfDurableInfo.length); i++)
      {
        String str = new String();
        Long localLong = new Long(-1L);
        try
        {
          str = String.valueOf(arrayOfDurableInfo[i].isStatic());
          localLong = new Long(arrayOfDurableInfo[i].getDeliveredMessageCount());
        }
        catch (Throwable localThrowable1) {}
        boolean bool = false;
        try
        {
          bool = arrayOfDurableInfo[i].isConnected();
        }
        catch (Throwable localThrowable2)
        {
          bool = arrayOfDurableInfo[i].isActive();
        }
        Object[] arrayOfObject = { arrayOfDurableInfo[i].getDurableName(), arrayOfDurableInfo[i].getTopicName(), String.valueOf(bool), new Long(arrayOfDurableInfo[i].getPendingMessageCount()), new Long(arrayOfDurableInfo[i].getPendingMessageSize()), arrayOfDurableInfo[i].getClientID() != null ? arrayOfDurableInfo[i].getClientID() : new String(), new Long(arrayOfDurableInfo[i].getConsumerID()), arrayOfDurableInfo[i].getUserName(), arrayOfDurableInfo[i].getSelector(), String.valueOf(arrayOfDurableInfo[i].isNoLocalEnabled()), localLong, str };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateQueueInfo(TibjmsAdmin paramTibjmsAdmin, String paramString)
  {
    setRowCount(0);
    if ((getColumnCount() != 2) || (!getColumnName(0).equals("QueueProperty")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(2);
      setColumnIdentifiers(s_qprop_cols);
    }
    if (paramTibjmsAdmin == null) {
      return;
    }
    QueueInfo localQueueInfo;
    try
    {
      localQueueInfo = paramTibjmsAdmin.getQueue(paramString);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
    if (localQueueInfo == null) {
      return;
    }
    String[] arrayOfString = { "Name", paramString };
    addRow(arrayOfString);
    arrayOfString = new String[] { "PendingMessageCount", String.valueOf(localQueueInfo.getPendingMessageCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "PendingMessageSize", StringUtilities.getHumanReadableSize(localQueueInfo.getPendingMessageSize()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundByteRate", String.valueOf(localQueueInfo.getInboundStatistics().getByteRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundMessageRate", String.valueOf(localQueueInfo.getInboundStatistics().getMessageRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundTotalBytes", String.valueOf(localQueueInfo.getInboundStatistics().getTotalBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundTotalMessages", String.valueOf(localQueueInfo.getInboundStatistics().getTotalMessages()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundByteRate", String.valueOf(localQueueInfo.getOutboundStatistics().getByteRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundMessageRate", String.valueOf(localQueueInfo.getOutboundStatistics().getMessageRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundTotalBytes", String.valueOf(localQueueInfo.getOutboundStatistics().getTotalBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundTotalMessages", String.valueOf(localQueueInfo.getOutboundStatistics().getTotalMessages()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ConsumerCount", String.valueOf(localQueueInfo.getConsumerCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "DeliveredMessageCount", String.valueOf(localQueueInfo.getDeliveredMessageCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InTransitMessageCount", String.valueOf(localQueueInfo.getInTransitMessageCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MaxRedelivery", String.valueOf(localQueueInfo.getMaxRedelivery()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isMaxRedeliveryInherited", String.valueOf(localQueueInfo.isMaxRedeliveryInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "Prefetch", String.valueOf(localQueueInfo.getPrefetch()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isPrefetchInherited", String.valueOf(localQueueInfo.isPrefetchInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ReceiverCount", String.valueOf(localQueueInfo.getReceiverCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isExclusive", String.valueOf(localQueueInfo.isExclusive()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isExclusiveInherited", String.valueOf(localQueueInfo.isExclusiveInherited()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "isRouted", String.valueOf(localQueueInfo.isRouted()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "getRouteName", localQueueInfo.getRouteName() };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable1) {}
    arrayOfString = new String[] { "isRouteConnected", String.valueOf(localQueueInfo.isRouteConnected()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FlowControl", String.valueOf(localQueueInfo.getFlowControlMaxBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFlowControlInherited", String.valueOf(localQueueInfo.isFlowControlMaxBytesInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MaxBytes", String.valueOf(localQueueInfo.getMaxBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isMaxBytesInherited", String.valueOf(localQueueInfo.isMaxBytesInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MsgTrace", String.valueOf(localQueueInfo.getMsgTrace()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isMsgTraceInherited", String.valueOf(localQueueInfo.isMsgTraceInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFailsafe", String.valueOf(localQueueInfo.isFailsafe()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFailsafeInherited", String.valueOf(localQueueInfo.isFailsafeInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isGlobal", String.valueOf(localQueueInfo.isGlobal()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isGlobalInherited", String.valueOf(localQueueInfo.isGlobalInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isStatic", String.valueOf(localQueueInfo.isStatic()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isTemporary", String.valueOf(localQueueInfo.isTemporary()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSecure", String.valueOf(localQueueInfo.isSecure()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSecureInherited", String.valueOf(localQueueInfo.isSecureInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderName", String.valueOf(localQueueInfo.isSenderName()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderNameInherited", String.valueOf(localQueueInfo.isSenderNameInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderNameEnforced", String.valueOf(localQueueInfo.isSenderNameEnforced()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderNameEnforcedInherited", String.valueOf(localQueueInfo.isSenderNameEnforcedInherited()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ExpiryOverride", String.valueOf(localQueueInfo.getExpiryOverride()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isExpiryOverrideInherited", String.valueOf(localQueueInfo.isExpiryOverrideInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable2) {}
    try
    {
      arrayOfString = new String[] { "OverflowPolicy", String.valueOf(localQueueInfo.getOverflowPolicy()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isOverflowPolicyInherited", String.valueOf(localQueueInfo.isOverflowPolicyInherited()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "MaxMsgs", String.valueOf(localQueueInfo.getMaxMsgs()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isMaxMsgsInherited", String.valueOf(localQueueInfo.isMaxMsgsInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable3) {}
    arrayOfString = new String[] { "JNDINames", StringUtilities.arrayToString(localQueueInfo.getJNDINames()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ImportTransports", StringUtilities.arrayToString(localQueueInfo.getImportTransports()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "isImportTransportsInherited", String.valueOf(localQueueInfo.isImportTransportsInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable4) {}
    arrayOfString = new String[] { "BridgeTargets", StringUtilities.arrayToString(localQueueInfo.getBridgeTargets()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "isBridgeTargetsInherited", String.valueOf(localQueueInfo.isBridgeTargetsInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable5) {}
    try
    {
      arrayOfString = new String[] { "Store", localQueueInfo.getStore() };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isStoreInherited", String.valueOf(localQueueInfo.isStoreInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable6) {}
    try
    {
      arrayOfString = new String[] { "RedeliveryDelay", String.valueOf(localQueueInfo.getRedeliveryDelay()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isRedeliveryDelayInherited", String.valueOf(localQueueInfo.isRedeliveryDelayInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable7) {}
  }
  
  public void populateTopicInfo(TibjmsAdmin paramTibjmsAdmin, String paramString)
  {
    setRowCount(0);
    if ((getColumnCount() != 2) || (!getColumnName(0).equals("TopicProperty")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(2);
      setColumnIdentifiers(s_tprop_cols);
    }
    if (paramTibjmsAdmin == null) {
      return;
    }
    TopicInfo localTopicInfo;
    try
    {
      localTopicInfo = paramTibjmsAdmin.getTopic(paramString);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
    if (localTopicInfo == null) {
      return;
    }
    String[] arrayOfString = { "Name", paramString };
    addRow(arrayOfString);
    arrayOfString = new String[] { "PendingMessageCount", String.valueOf(localTopicInfo.getPendingMessageCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "PendingMessageSize", StringUtilities.getHumanReadableSize(localTopicInfo.getPendingMessageSize()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundByteRate", String.valueOf(localTopicInfo.getInboundStatistics().getByteRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundMessageRate", String.valueOf(localTopicInfo.getInboundStatistics().getMessageRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundTotalBytes", String.valueOf(localTopicInfo.getInboundStatistics().getTotalBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundTotalMessages", String.valueOf(localTopicInfo.getInboundStatistics().getTotalMessages()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundByteRate", String.valueOf(localTopicInfo.getOutboundStatistics().getByteRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundMessageRate", String.valueOf(localTopicInfo.getOutboundStatistics().getMessageRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundTotalBytes", String.valueOf(localTopicInfo.getOutboundStatistics().getTotalBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundTotalMessages", String.valueOf(localTopicInfo.getOutboundStatistics().getTotalMessages()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ActiveDurableCount", String.valueOf(localTopicInfo.getActiveDurableCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "DurableCount", String.valueOf(localTopicInfo.getDurableCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ConsumerCount", String.valueOf(localTopicInfo.getConsumerCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "SubscriberCount", String.valueOf(localTopicInfo.getSubscriberCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FlowControl", String.valueOf(localTopicInfo.getFlowControlMaxBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFlowControlInherited", String.valueOf(localTopicInfo.isFlowControlMaxBytesInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MaxBytes", String.valueOf(localTopicInfo.getMaxBytes()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isMaxBytesInherited", String.valueOf(localTopicInfo.isMaxBytesInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MsgTrace", String.valueOf(localTopicInfo.getMsgTrace()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isMsgTraceInherited", String.valueOf(localTopicInfo.isMsgTraceInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFailsafe", String.valueOf(localTopicInfo.isFailsafe()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFailsafeInherited", String.valueOf(localTopicInfo.isFailsafeInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isGlobal", String.valueOf(localTopicInfo.isGlobal()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isGlobalInherited", String.valueOf(localTopicInfo.isGlobalInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isStatic", String.valueOf(localTopicInfo.isStatic()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isTemporary", String.valueOf(localTopicInfo.isTemporary()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSecure", String.valueOf(localTopicInfo.isSecure()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSecureInherited", String.valueOf(localTopicInfo.isSecureInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderName", String.valueOf(localTopicInfo.isSenderName()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderNameInherited", String.valueOf(localTopicInfo.isSenderNameInherited()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderNameEnforced", String.valueOf(localTopicInfo.isSenderNameEnforced()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSenderNameEnforcedInherited", String.valueOf(localTopicInfo.isSenderNameEnforcedInherited()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ExpiryOverride", String.valueOf(localTopicInfo.getExpiryOverride()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isExpiryOverrideInherited", String.valueOf(localTopicInfo.isExpiryOverrideInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable1) {}
    try
    {
      arrayOfString = new String[] { "OverflowPolicy", String.valueOf(localTopicInfo.getOverflowPolicy()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isOverflowPolicyInherited", String.valueOf(localTopicInfo.isOverflowPolicyInherited()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "MaxMsgs", String.valueOf(localTopicInfo.getMaxMsgs()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isMaxMsgsInherited", String.valueOf(localTopicInfo.isMaxMsgsInherited()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "Prefetch", String.valueOf(localTopicInfo.getPrefetch()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isPrefetchInherited", String.valueOf(localTopicInfo.isPrefetchInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable2) {}
    arrayOfString = new String[] { "JNDINames", StringUtilities.arrayToString(localTopicInfo.getJNDINames()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ImportTransports", StringUtilities.arrayToString(localTopicInfo.getImportTransports()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "isImportTransportsInherited", String.valueOf(localTopicInfo.isImportTransportsInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable3) {}
    arrayOfString = new String[] { "ExportTransports", StringUtilities.arrayToString(localTopicInfo.getExportTransports()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "isExportTransportsInherited", String.valueOf(localTopicInfo.isExportTransportsInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable4) {}
    arrayOfString = new String[] { "BridgeTargets", StringUtilities.arrayToString(localTopicInfo.getBridgeTargets()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "isBridgeTargetsInherited", String.valueOf(localTopicInfo.isBridgeTargetsInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable5) {}
    try
    {
      arrayOfString = new String[] { "Channel", localTopicInfo.getChannel() };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isChannelInherited", String.valueOf(localTopicInfo.isChannelInherited()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isMulticastEnabled", String.valueOf(localTopicInfo.isMulticastEnabled()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "Store", localTopicInfo.getStore() };
      addRow(arrayOfString);
      arrayOfString = new String[] { "isStoreInherited", String.valueOf(localTopicInfo.isStoreInherited()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable6) {}
  }
  
  public void populateProducerInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 11) || (!getColumnName(5).equals("SessionID")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_prod_cols);
      setupColumnWidths();
    }
    try
    {
      ProducerInfo[] arrayOfProducerInfo;
      try
      {
        arrayOfProducerInfo = paramGemsConnectionNode.m_adminConn.getProducersStatistics();
      }
      catch (Throwable localThrowable)
      {
        arrayOfProducerInfo = paramGemsConnectionNode.m_adminConn.getProducersStatistics();
      }
      Date localDate = new Date();
      for (int i = 0; (arrayOfProducerInfo != null) && (i < arrayOfProducerInfo.length); i++)
      {
        String str1 = null;
        if (Gems.getGems().getShowClientId()) {
          str1 = paramGemsConnectionNode.getClientID(arrayOfProducerInfo[i].getConnectionID());
        }
        if (str1 == null) {
          str1 = new String();
        }
        localDate.setTime(arrayOfProducerInfo[i].getCreateTime());
        String str2 = "Generic";
        if (arrayOfProducerInfo[i].getDestinationType() == 1) {
          str2 = "Queue";
        } else if (arrayOfProducerInfo[i].getDestinationType() == 2) {
          str2 = "Topic";
        }
        Object[] arrayOfObject = { new Long(arrayOfProducerInfo[i].getID()), localDate.toString(), arrayOfProducerInfo[i].getDestinationName(), str2, new Long(arrayOfProducerInfo[i].getConnectionID()), new Long(arrayOfProducerInfo[i].getSessionID()), arrayOfProducerInfo[i].getUsername(), new Long(arrayOfProducerInfo[i].getStatistics().getByteRate()), new Long(arrayOfProducerInfo[i].getStatistics().getMessageRate()), new Long(arrayOfProducerInfo[i].getStatistics().getTotalBytes()), new Long(arrayOfProducerInfo[i].getStatistics().getTotalMessages()) };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateACLInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 6) || (!getColumnName(2).equals("PrincipalName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_acl_cols);
      setupColumnWidths();
    }
    try
    {
      ACLEntry[] arrayOfACLEntry = paramGemsConnectionNode.m_adminConn.getACLEntries();
      Date localDate = new Date();
      for (int i = 0; (arrayOfACLEntry != null) && (i < arrayOfACLEntry.length); i++)
      {
        Object[] arrayOfObject = { arrayOfACLEntry[i].getDestination().getName(), (arrayOfACLEntry[i].getDestination() instanceof QueueInfo) ? new String("Queue") : new String("Topic"), arrayOfACLEntry[i].getPrincipal().getName(), (arrayOfACLEntry[i].getPrincipal() instanceof UserInfo) ? new String("User") : new String("Group"), String.valueOf(arrayOfACLEntry[i].getPrincipal().isExternal()), arrayOfACLEntry[i].getPermissions().toString() };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateAdminACLInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 4) || (!getColumnName(0).equals("PrincipalName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_adminacl_cols);
      setupColumnWidths();
    }
    try
    {
      Object[] arrayOfObject1 = paramGemsConnectionNode.m_adminConn.getPermissions();
      Date localDate = new Date();
      for (int i = 0; (arrayOfObject1 != null) && (i < arrayOfObject1.length); i++) {
        if ((arrayOfObject1[i] instanceof AdminACLEntry))
        {
          Object[] arrayOfObject2 = { ((AdminACLEntry)arrayOfObject1[i]).getPrincipal().getName(), (((AdminACLEntry)arrayOfObject1[i]).getPrincipal() instanceof UserInfo) ? new String("User") : new String("Group"), String.valueOf(((AdminACLEntry)arrayOfObject1[i]).getPrincipal().isExternal()), ((AdminACLEntry)arrayOfObject1[i]).getPermissions().toString() };
          addRow(arrayOfObject2);
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateSSInfo(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 2) || (!getColumnName(0).equals("Property")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(2);
      setColumnIdentifiers(s_prop_cols);
    }
    MessageFormat localMessageFormat1 = new MessageFormat("SXS0800I -  {0} - {1}");
    MessageFormat localMessageFormat2 = new MessageFormat("SXS0800I -  UoW - {0} - {1}");
    MessageFormat localMessageFormat3 = new MessageFormat("SXS0850I -  IId:{0} UoW Que statistics request");
    MessageFormat localMessageFormat4 = new MessageFormat("SXS0851I -  {0} - {1}");
    String[] arrayOfString = paramGemsSSNode.RunCommand("SHOW,ALL").split("\n");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      Object localObject;
      if (arrayOfString[i].startsWith("SXS0800I"))
      {
        int j = arrayOfString[i].indexOf("Statistics request");
        if (j == -1) {
          try
          {
            Object[] arrayOfObject3 = localMessageFormat1.parse(arrayOfString[i]);
            if (arrayOfObject3[0].toString().startsWith("UoW Stress Status"))
            {
              localObject = new Object[] { arrayOfObject3[0].toString(), new SSCellValue(Long.valueOf(arrayOfObject3[1].toString()).longValue(), "Error", 1L, 100L) };
            }
            else if (arrayOfObject3[0].toString().compareTo("UoW") == 0)
            {
              arrayOfObject3 = localMessageFormat2.parse(arrayOfString[i]);
              localObject = new String[] { "UoW " + arrayOfObject3[0].toString(), arrayOfObject3[1].toString() };
            }
            else
            {
              localObject = new String[] { arrayOfObject3[0].toString(), arrayOfObject3[1].toString() };
            }
            addRow((Object[])localObject);
          }
          catch (ParseException localParseException3)
          {
            System.err.println("Message Format Error(): " + localParseException3.getMessage() + " " + arrayOfString[i]);
          }
        }
      }
      if (arrayOfString[i].startsWith("SXS0850I")) {
        try
        {
          Object[] arrayOfObject1 = localMessageFormat3.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Interface", "Head"), arrayOfObject1[0].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException1)
        {
          System.err.println("Message Format Error(): " + localParseException1.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXS0851I")) {
        try
        {
          Object[] arrayOfObject2 = localMessageFormat4.parse(arrayOfString[i]);
          localObject = new String[] { arrayOfObject2[0].toString(), arrayOfObject2[1].toString() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException2)
        {
          System.err.println("Message Format Error(): " + localParseException2.getMessage() + " " + arrayOfString[i]);
        }
      }
    }
  }
  
  public void populateSSActive(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode, String paramString1, String paramString2)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 3) || (!getColumnName(0).equals("Identifier")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_ssactive_cols);
      setupColumnWidths();
    }
    MessageFormat localMessageFormat1 = new MessageFormat("SXT5587I Since Date:{1} Time:{2} RID:{3}");
    MessageFormat localMessageFormat2 = new MessageFormat("SXT5587I IId:{0} Since Date:{1} Time:{2} RID:{3}");
    MessageFormat localMessageFormat3 = new MessageFormat("SXT5589I Since Date:{1} Time:{2} TID:{3}");
    MessageFormat localMessageFormat4 = new MessageFormat("SXT5589I IId:{0} Since Date:{1} Time:{2} TID:{3}");
    String[] arrayOfString1 = paramGemsSSNode.RunCommand("SHOW,ACT," + paramString1 + ",INTF=" + paramString2).split("\n");
    for (int i = 1; i < arrayOfString1.length; i++) {
      try
      {
        Object[] arrayOfObject;
        String[] arrayOfString2;
        if (arrayOfString1[i].startsWith("SXT5587I Since"))
        {
          arrayOfObject = localMessageFormat1.parse(arrayOfString1[i]);
          arrayOfString2 = new String[] { arrayOfObject[3].toString(), arrayOfObject[1].toString(), arrayOfObject[2].toString().substring(0, 8) };
          addRow(arrayOfString2);
        }
        if (arrayOfString1[i].startsWith("SXT5587I IId"))
        {
          arrayOfObject = localMessageFormat2.parse(arrayOfString1[i]);
          arrayOfString2 = new String[] { arrayOfObject[3].toString(), arrayOfObject[1].toString(), arrayOfObject[2].toString().substring(0, 8) };
          addRow(arrayOfString2);
        }
        if (arrayOfString1[i].startsWith("SXT5589I Since"))
        {
          arrayOfObject = localMessageFormat3.parse(arrayOfString1[i]);
          arrayOfString2 = new String[] { arrayOfObject[3].toString(), arrayOfObject[1].toString(), arrayOfObject[2].toString().substring(0, 8) };
          addRow(arrayOfString2);
        }
        if (arrayOfString1[i].startsWith("SXT5589I IId"))
        {
          arrayOfObject = localMessageFormat4.parse(arrayOfString1[i]);
          arrayOfString2 = new String[] { arrayOfObject[3].toString(), arrayOfObject[1].toString(), arrayOfObject[2].toString().substring(0, 8) };
          addRow(arrayOfString2);
        }
      }
      catch (ParseException localParseException)
      {
        System.err.println("Message Format Error(): " + localParseException.getMessage() + " " + arrayOfString1[i]);
      }
    }
  }
  
  public void populateSSListeners(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode, String paramString)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 1) || (!getColumnName(0).equals("Destination")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_ssactiveL_cols);
      setupColumnWidths();
    }
    MessageFormat localMessageFormat = new MessageFormat("SXT5585I Dest:{0}");
    String[] arrayOfString1 = paramGemsSSNode.RunCommand("SHOW,ACT,LISTENERS,INTF=" + paramString).split("\n");
    for (int i = 1; i < arrayOfString1.length; i++) {
      if (arrayOfString1[i].startsWith("SXT5585I")) {
        try
        {
          Object[] arrayOfObject = localMessageFormat.parse(arrayOfString1[i]);
          String[] arrayOfString2 = { arrayOfObject[0].toString() };
          addRow(arrayOfString2);
        }
        catch (ParseException localParseException)
        {
          System.err.println("Message Format Error(): " + localParseException.getMessage() + " " + arrayOfString1[i]);
        }
      }
    }
  }
  
  public void populateSSInActive(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode, String paramString)
  {
    setRowCount(0);
    if ((getColumnCount() != 5) || (!getColumnName(0).equals("Identifier")))
    {
      if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
        return;
      }
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_ssinactive_cols);
      setupColumnWidths();
    }
    MessageFormat localMessageFormat = new MessageFormat("SXT5594I Disabled Date:{1} Time:{2} {3}:{4}, Rsn: {5}");
    String[] arrayOfString1 = paramGemsSSNode.RunCommand("SHOW,DIS,INTF=" + paramString).split("\n");
    String str1 = "";
    String str2 = "";
    String str3 = "";
    for (int i = 1; i < arrayOfString1.length; i++) {
      if (arrayOfString1[i].startsWith("SXT5594I")) {
        try
        {
          Object[] arrayOfObject = localMessageFormat.parse(arrayOfString1[i]);
          if (arrayOfObject[3].toString().startsWith("RID")) {
            str1 = "Recipe";
          } else {
            str1 = "Trigger";
          }
          if (arrayOfObject[1].toString().startsWith("<None>")) {
            str2 = "";
          } else {
            str2 = arrayOfObject[1].toString();
          }
          if (arrayOfObject[2].toString().equals("")) {
            str3 = "";
          } else {
            str3 = arrayOfObject[2].toString().substring(0, 8);
          }
          String[] arrayOfString2 = { arrayOfObject[4].toString(), str1, arrayOfObject[5].toString(), str2, str3 };
          addRow(arrayOfString2);
        }
        catch (ParseException localParseException)
        {
          System.err.println("Error(): " + localParseException.getMessage() + " " + arrayOfString1[i]);
        }
      }
    }
  }
  
  public void populateSSCounters(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 2) || (!getColumnName(0).equals("Property")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(2);
      setColumnIdentifiers(s_prop_cols);
    }
    MessageFormat localMessageFormat1 = new MessageFormat("SXS0960I {3} IId:{0} Type:{1} Vers:{2}");
    MessageFormat localMessageFormat2 = new MessageFormat("SXS0965I - {3}:{0} - Used:{1} Errors:{2}");
    MessageFormat localMessageFormat3 = null;
    MessageFormat localMessageFormat4 = new MessageFormat("SXT5840I {3}:{0} - Used:{1} Errors:{2}");
    if (paramGemsSSNode.m_ver != "2.4") {
      localMessageFormat3 = new MessageFormat("SXS0961I {0}:{1}");
    } else {
      localMessageFormat3 = new MessageFormat("SXS0961I - {0}:{1}");
    }
    String[] arrayOfString = paramGemsSSNode.RunCommand("SHOW,COUNTERS").split("\n");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      Object localObject;
      if (arrayOfString[i].startsWith("SXS0960I")) {
        try
        {
          Object[] arrayOfObject1 = localMessageFormat1.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Interface Name", "Head"), arrayOfObject1[0].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "Interface Type", arrayOfObject1[1].toString() };
          addRow((Object[])localObject);
          localObject = new String[] { "Interface Version", arrayOfObject1[2].toString() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException1)
        {
          System.err.println("Message Format Error(): " + localParseException1.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXS0965I")) {
        try
        {
          Object[] arrayOfObject2 = localMessageFormat2.parse(arrayOfString[i]);
          if (arrayOfObject2[3].toString().equals("RID")) {
            localObject = new Object[] { new SSCellValue("Recipe Name", "Head"), arrayOfObject2[0].toString() };
          } else {
            localObject = new Object[] { new SSCellValue("Trigger Name", "Head"), arrayOfObject2[0].toString() };
          }
          addRow((Object[])localObject);
          localObject = new Object[] { "Used", new SSCellValue(Long.valueOf(arrayOfObject2[1].toString()).longValue(), "Large", 1000L, 10000L) };
          addRow((Object[])localObject);
          localObject = new Object[] { "Errors", new SSCellValue(Long.valueOf(arrayOfObject2[2].toString()).longValue(), "Error", 1L, 100L) };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException2)
        {
          System.err.println("Message Format Error(): " + localParseException2.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXT5840I")) {
        try
        {
          Object[] arrayOfObject3 = localMessageFormat4.parse(arrayOfString[i]);
          if (arrayOfObject3[3].toString().equals("RID")) {
            localObject = new Object[] { new SSCellValue("Recipe Name", "Head"), arrayOfObject3[0].toString() };
          } else {
            localObject = new Object[] { new SSCellValue("Trigger Name", "Head"), arrayOfObject3[0].toString() };
          }
          addRow((Object[])localObject);
          localObject = new Object[] { "Used", new SSCellValue(Long.valueOf(arrayOfObject3[1].toString()).longValue(), "Large", 1000L, 10000L) };
          addRow((Object[])localObject);
          localObject = new Object[] { "Errors", new SSCellValue(Long.valueOf(arrayOfObject3[2].toString()).longValue(), "Error", 1L, 100L) };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException3)
        {
          System.err.println("Message Format Error(): " + localParseException3.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXS0961I")) {
        try
        {
          Object[] arrayOfObject4 = localMessageFormat3.parse(arrayOfString[i]);
          localObject = new String[] { arrayOfObject4[0].toString(), arrayOfObject4[1].toString() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException4)
        {
          System.err.println("Error: " + localParseException4.getMessage());
        }
      }
    }
  }
  
  public void populateSSInterface(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 6) || (!getColumnName(0).equals("Interface ID")))
    {
      if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
        return;
      }
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_ssinterface_cols);
      setupColumnWidths();
    }
    MessageFormat localMessageFormat1 = null;
    if ((paramGemsSSNode.m_ver.equals("2.4")) || (paramGemsSSNode.m_ver.equals("2.3")) || (paramGemsSSNode.m_ver.equals("2.2")) || (paramGemsSSNode.m_ver.equals("2.1")) || (paramGemsSSNode.m_ver.equals("2.0"))) {
      localMessageFormat1 = new MessageFormat("SXS0951I - IId:{0} Type:{1} TCB:{2} Vers:{3} Start Date:{4}  Time:{5} All Workers Busy:{6} Times");
    } else {
      localMessageFormat1 = new MessageFormat("SXS0951I - IId:{0} Type:{1} TCB:{2} Vers:{3} All Workers Busy:{6} Times");
    }
    MessageFormat localMessageFormat2 = new MessageFormat("SXS0990I - IId:{0} Type:{1} Applid:{2} Connection:{3}");
    MessageFormat localMessageFormat3 = new MessageFormat("SXS0951I - IId:{0} Type:{1} TCB:{2} Vers:{3}   Start Date:{4}  Time:{5}    All Workers Busy:{6} Times");
    MessageFormat localMessageFormat4 = new MessageFormat("SXS0951I - IId:{0} Type:{1} TCB:{2} Vers:{3} All Workers Busy:{6} Times    Connection:{7} (UP/DOWN)");
    String[] arrayOfString1 = paramGemsSSNode.RunCommand("SHOW,INTF").split("\n");
    Vector localVector = new Vector();
    int i = -1;
    String str;
    for (int j = 1; j < arrayOfString1.length; j++) {
      if ((!arrayOfString1[j].startsWith("SXA1008I")) && (!arrayOfString1[j].startsWith("SXS0950I"))) {
        if (arrayOfString1[j].startsWith("SXS0951I"))
        {
          i++;
          localVector.add(arrayOfString1[j]);
        }
        else if (arrayOfString1[j].startsWith("SXS0990I"))
        {
          str = localVector.get(i).toString() + "\n" + arrayOfString1[j];
          localVector.setElementAt(str, i);
        }
        else
        {
          str = localVector.get(i).toString() + arrayOfString1[j];
          localVector.setElementAt(str, i);
        }
      }
    }
    for (j = 0; j < localVector.size(); j++)
    {
      str = localVector.get(j).toString();
      if (str.startsWith("SXS0951I"))
      {
        String[] arrayOfString2 = str.split("\n");
        try
        {
          Object[] arrayOfObject2;
          Object[] arrayOfObject1;
          if (arrayOfString2.length > 1)
          {
            arrayOfObject2 = localMessageFormat1.parse(arrayOfString2[0]);
            Object[] arrayOfObject3 = localMessageFormat2.parse(arrayOfString2[1]);
            arrayOfObject1 = new Object[] { arrayOfObject2[0].toString(), arrayOfObject2[1].toString(), arrayOfObject2[4].toString(), arrayOfObject2[5].toString(), new SSCellValue(Long.valueOf(arrayOfObject2[6].toString()).longValue(), "Error", 10L, 100L), arrayOfObject3[2].toString(), new SSCellValue(arrayOfObject3[3].toString(), "Status", "DOWN") };
          }
          else
          {
            arrayOfObject2 = null;
            if (str.contains("Type:Master"))
            {
              arrayOfObject2 = localMessageFormat3.parse(arrayOfString2[0]);
              arrayOfObject1 = new Object[] { arrayOfObject2[0].toString(), arrayOfObject2[1].toString(), arrayOfObject2[4].toString(), arrayOfObject2[5].toString(), new SSCellValue(Long.valueOf(arrayOfObject2[6].toString()).longValue(), "Error", 10L, 100L) };
            }
            else if (str.contains("Connection:"))
            {
              arrayOfObject2 = localMessageFormat4.parse(arrayOfString2[0]);
              arrayOfObject1 = new Object[] { arrayOfObject2[0].toString(), arrayOfObject2[1].toString(), "", "", new SSCellValue(Long.valueOf(arrayOfObject2[6].toString()).longValue(), "Error", 10L, 100L), "", new SSCellValue(arrayOfObject2[7].toString(), "Status", "DOWN") };
            }
            else
            {
              arrayOfObject2 = localMessageFormat1.parse(arrayOfString2[0]);
              if (paramGemsSSNode.m_ver.equals("2.4")) {
                arrayOfObject1 = new Object[] { arrayOfObject2[0].toString(), arrayOfObject2[1].toString(), arrayOfObject2[4].toString(), arrayOfObject2[5].toString(), new SSCellValue(Long.valueOf(arrayOfObject2[6].toString()).longValue(), "Error", 10L, 100L) };
              } else {
                arrayOfObject1 = new Object[] { arrayOfObject2[0].toString(), arrayOfObject2[1].toString(), "", "", new SSCellValue(Long.valueOf(arrayOfObject2[6].toString()).longValue(), "Error", 10L, 100L) };
              }
            }
          }
          addRow(arrayOfObject1);
        }
        catch (ParseException localParseException)
        {
          System.err.println("Message Format Error(): " + localParseException.getMessage() + " " + str);
        }
      }
    }
  }
  
  public void populateSSTransport(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 2) || (!getColumnName(0).equals("Property")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(2);
      setColumnIdentifiers(s_prop_cols);
    }
    MessageFormat localMessageFormat1 = new MessageFormat("SXT5670I Transports active {1}, in-error {2}, unused {3}, disabled {4}");
    MessageFormat localMessageFormat2 = new MessageFormat("SXT5670I IId:{5} Transports active {1}, in-error {2}, unused {3}, disabled {4}");
    MessageFormat localMessageFormat3 = new MessageFormat("SXT5669I Transport {1} used {2}, state={3}, process-err={4}");
    MessageFormat localMessageFormat4 = new MessageFormat("SXT5669I IId:{5} Transport {1} used {2}, state={3}, process-err={4}");
    String[] arrayOfString = paramGemsSSNode.RunCommand("SHOW,TPORT").split("\n");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      Object localObject;
      if (arrayOfString[i].startsWith("SXT5670I IId:")) {
        try
        {
          Object[] arrayOfObject1 = localMessageFormat2.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Summary", "Head"), "Interface: " + arrayOfObject1[5].toString() };
          addRow((Object[])localObject);
          localObject = new String[] { "Active", arrayOfObject1[1].toString() };
          addRow((Object[])localObject);
          localObject = new String[] { "Unused", arrayOfObject1[3].toString() };
          addRow((Object[])localObject);
          localObject = new Object[] { "Disabled", new SSCellValue(Long.valueOf(arrayOfObject1[4].toString()).longValue(), "Error", 1L, 2L) };
          addRow((Object[])localObject);
          localObject = new Object[] { "In Error", new SSCellValue(Long.valueOf(arrayOfObject1[2].toString()).longValue(), "Error", 1L, 1L) };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException1)
        {
          System.err.println("Message Format Error(): " + localParseException1.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXT5670I Trans")) {
        try
        {
          Object[] arrayOfObject2 = localMessageFormat1.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Summary", "Head"), "" };
          addRow((Object[])localObject);
          localObject = new String[] { "Active", arrayOfObject2[1].toString() };
          addRow((Object[])localObject);
          localObject = new String[] { "Unused", arrayOfObject2[3].toString() };
          addRow((Object[])localObject);
          localObject = new Object[] { "Disabled", new SSCellValue(Long.valueOf(arrayOfObject2[4].toString()).longValue(), "Error", 1L, 2L) };
          addRow((Object[])localObject);
          localObject = new Object[] { "In Error", new SSCellValue(Long.valueOf(arrayOfObject2[2].toString()).longValue(), "Error", 1L, 1L) };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException2)
        {
          System.err.println("Message Format Error(): " + localParseException2.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXT5669I IId:")) {
        try
        {
          Object[] arrayOfObject3 = localMessageFormat4.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Transport", "Head"), arrayOfObject3[1].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "Used", arrayOfObject3[2].toString() };
          addRow((Object[])localObject);
          localObject = new String[] { "State", arrayOfObject3[3].toString() };
          addRow((Object[])localObject);
          localObject = new Object[] { "Error", arrayOfObject3[4].toString() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException3)
        {
          System.err.println("Message Format Error(): " + localParseException3.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXT5669I Tran")) {
        try
        {
          Object[] arrayOfObject4 = localMessageFormat3.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Transport", "Head"), arrayOfObject4[1].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "Used", arrayOfObject4[2].toString() };
          addRow((Object[])localObject);
          localObject = new String[] { "State", arrayOfObject4[3].toString() };
          addRow((Object[])localObject);
          localObject = new Object[] { "Error", arrayOfObject4[4].toString() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException4)
        {
          System.err.println("Message Format Error(): " + localParseException4.getMessage() + " " + arrayOfString[i]);
        }
      }
    }
  }
  
  public void populateSSIMSStats(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 6) || (!getColumnName(0).equals("Interface ID")))
    {
      if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
        return;
      }
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_ssimsstats_cols);
      setupColumnWidths();
    }
    MessageFormat localMessageFormat1 = new MessageFormat("SXI4967I Count {0} - {1}");
    MessageFormat localMessageFormat2 = new MessageFormat("SXG2077I Operational Request Feedback for IId:{0}");
    String[] arrayOfString = paramGemsSSNode.RunCommand("SHOW,IMS,STATS").split("\n");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      Object localObject;
      if (arrayOfString[i].startsWith("SXG2077I")) {
        try
        {
          Object[] arrayOfObject1 = localMessageFormat2.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Interface Name", "Head"), arrayOfObject1[0].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException1)
        {
          System.err.println("Message Format Error(): " + localParseException1.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXI4967I")) {
        try
        {
          Object[] arrayOfObject2 = localMessageFormat1.parse(arrayOfString[i]);
          localObject = new String[] { arrayOfObject2[1].toString(), arrayOfObject2[0].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException2)
        {
          System.err.println("Message Format Error(): " + localParseException2.getMessage() + " " + arrayOfString[i]);
        }
      }
    }
  }
  
  public void populateSSIMSBuffers(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 6) || (!getColumnName(0).equals("Interface ID")))
    {
      if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
        return;
      }
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_ssimsbuffs_cols);
      setupColumnWidths();
    }
    MessageFormat localMessageFormat1 = new MessageFormat("SXI4969I Have {0} active buffers - {1} SRB, {2} GRP {3} TRN");
    MessageFormat localMessageFormat2 = new MessageFormat("SXG2077I Operational Request Feedback for IId:{0}");
    String[] arrayOfString = paramGemsSSNode.RunCommand("SHOW,IMS,BUFFERS").split("\n");
    for (int i = 0; i < arrayOfString.length; i++)
    {
      Object localObject;
      if (arrayOfString[i].startsWith("SXG2077I")) {
        try
        {
          Object[] arrayOfObject1 = localMessageFormat2.parse(arrayOfString[i]);
          localObject = new Object[] { new SSCellValue("Interface Name", "Head"), arrayOfObject1[0].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException1)
        {
          System.err.println("Message Format Error(): " + localParseException1.getMessage() + " " + arrayOfString[i]);
        }
      }
      if (arrayOfString[i].startsWith("SXI4969I")) {
        try
        {
          Object[] arrayOfObject2 = localMessageFormat1.parse(arrayOfString[i]);
          localObject = new String[] { "Total Active", arrayOfObject2[0].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "SRB", arrayOfObject2[1].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "GRP", arrayOfObject2[2].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "TRN", arrayOfObject2[3].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException2)
        {
          System.err.println("Message Format Error(): " + localParseException2.getMessage() + " " + arrayOfString[i]);
        }
      }
    }
  }
  
  public void populateSSIMSGen(GemsConnectionNode paramGemsConnectionNode, GemsSSNode paramGemsSSNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 6) || (!getColumnName(0).equals("Interface ID")))
    {
      if ((paramGemsConnectionNode == null) || (paramGemsSSNode == null)) {
        return;
      }
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_ssimsgen_cols);
      setupColumnWidths();
    }
    MessageFormat localMessageFormat1 = new MessageFormat("SXG2077I Operational Request Feedback for IId:{0}");
    MessageFormat localMessageFormat2 = new MessageFormat("SXI4965I Group:{0}, SS:{1}  , IMS:{2}");
    MessageFormat localMessageFormat3 = new MessageFormat("SXI4964I Connecton status: {0}");
    String[] arrayOfString1 = paramGemsSSNode.RunCommand("SHOW,IMS,CONNAME").split("\n");
    String[] arrayOfString2 = paramGemsSSNode.RunCommand("SHOW,IMS,CONNECT").split("\n");
    Object localObject;
    for (int i = 0; i < arrayOfString1.length; i++)
    {
      if (arrayOfString1[i].startsWith("SXG2077I")) {
        try
        {
          Object[] arrayOfObject1 = localMessageFormat1.parse(arrayOfString1[i]);
          localObject = new Object[] { new SSCellValue("Interface Name", "Head"), arrayOfObject1[0].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException1)
        {
          System.err.println("Message Format Error(): " + localParseException1.getMessage() + " " + arrayOfString1[i]);
        }
      }
      if (arrayOfString1[i].startsWith("SXI4965I")) {
        try
        {
          Object[] arrayOfObject2 = localMessageFormat2.parse(arrayOfString1[i]);
          localObject = new String[] { "Group Name", arrayOfObject2[0].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "Member Name", arrayOfObject2[1].toString().trim() };
          addRow((Object[])localObject);
          localObject = new String[] { "IMS Name", arrayOfObject2[2].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException2)
        {
          System.err.println("Message Format Error(): " + localParseException2.getMessage() + " " + arrayOfString1[i]);
        }
      }
    }
    for (i = 0; i < arrayOfString2.length; i++)
    {
      if (arrayOfString1[i].startsWith("SXG2077I")) {
        try
        {
          Object[] arrayOfObject3 = localMessageFormat1.parse(arrayOfString2[i]);
          localObject = new Object[] { new SSCellValue("Interface Name", "Head"), arrayOfObject3[0].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException3)
        {
          System.err.println("Message Format Error(): " + localParseException3.getMessage() + " " + arrayOfString1[i]);
        }
      }
      if (arrayOfString2[i].startsWith("SXI4964I")) {
        try
        {
          Object[] arrayOfObject4 = localMessageFormat3.parse(arrayOfString2[i]);
          localObject = new String[] { "Connection Status", arrayOfObject4[0].toString().trim() };
          addRow((Object[])localObject);
        }
        catch (ParseException localParseException4)
        {
          System.err.println("Message Format Error(): " + localParseException4.getMessage() + " " + arrayOfString1[i]);
        }
      }
    }
  }
  
  public void populateUserInfo(TibjmsAdmin paramTibjmsAdmin)
  {
    if (paramTibjmsAdmin == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 3) || (!getColumnName(0).equals("UserName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(2);
      setColumnIdentifiers(s_user_cols);
    }
    try
    {
      UserInfo[] arrayOfUserInfo = paramTibjmsAdmin.getUsers();
      for (int i = 0; (arrayOfUserInfo != null) && (i < arrayOfUserInfo.length); i++)
      {
        Object[] arrayOfObject = { String.valueOf(arrayOfUserInfo[i].getName()), arrayOfUserInfo[i].getDescription(), String.valueOf(arrayOfUserInfo[i].isExternal()) };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateTransactionInfo(TibjmsAdmin paramTibjmsAdmin)
  {
    if (paramTibjmsAdmin == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 4) || (!getColumnName(1).equals("GlobalTransactionId")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_transact_cols);
      setupColumnWidths();
    }
    try
    {
      TransactionInfo[] arrayOfTransactionInfo = paramTibjmsAdmin.getTransactions();
      for (int i = 0; (arrayOfTransactionInfo != null) && (i < arrayOfTransactionInfo.length); i++)
      {
        StringBuffer localStringBuffer1 = new StringBuffer();
        StringBuffer localStringBuffer2 = new StringBuffer();
        byte[] arrayOfByte1 = arrayOfTransactionInfo[i].getGlobalTransactionId();
        for (int j = 0; j < arrayOfByte1.length; j++) {
          if ((arrayOfByte1[j] >= 32) && (arrayOfByte1[j] <= 126) && (arrayOfByte1[j] != 37)) {
            localStringBuffer1.append((char)arrayOfByte1[j]);
          } else {
            localStringBuffer1.append("%" + Byte.toString(arrayOfByte1[j]));
          }
        }
        byte[] arrayOfByte2 = arrayOfTransactionInfo[i].getBranchQualifier();
        for (int k = 0; k < arrayOfByte2.length; k++) {
          if ((arrayOfByte2[k] >= 32) && (arrayOfByte2[k] <= 126) && (arrayOfByte2[k] != 37)) {
            localStringBuffer2.append((char)arrayOfByte2[k]);
          } else {
            localStringBuffer2.append("%" + Byte.toString(arrayOfByte2[k]));
          }
        }
        Object[] arrayOfObject = { TxStateToString(arrayOfTransactionInfo[i].getState()), localStringBuffer1.toString(), String.valueOf(arrayOfTransactionInfo[i].getFormatId()), localStringBuffer2.toString() };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public String TxStateToString(char paramChar)
  {
    if (paramChar == 'A') {
      return new String("Active");
    }
    if (paramChar == 'E') {
      return new String("EndSuccess");
    }
    if (paramChar == 'P') {
      return new String("Prepared");
    }
    if (paramChar == 'R') {
      return new String("RollbackOnly");
    }
    if (paramChar == 'S') {
      return new String("Suspended");
    }
    return new String("Unknown");
  }
  
  public void populateTransportInfo(TibjmsAdmin paramTibjmsAdmin)
  {
    if (paramTibjmsAdmin == null) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 7) || (!getColumnName(0).equals("TransportName")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_transprt_cols);
      setupColumnWidths();
    }
    try
    {
      TransportInfo[] arrayOfTransportInfo = paramTibjmsAdmin.getTransports();
      for (int i = 0; (arrayOfTransportInfo != null) && (i < arrayOfTransportInfo.length); i++)
      {
        int j = arrayOfTransportInfo[i].getType();
        int k = arrayOfTransportInfo[i].getTopicImportDeliveryMode();
        int m = arrayOfTransportInfo[i].getQueueImportDeliveryMode();
        String str = new String();
        Object localObject;
        if ((arrayOfTransportInfo[i] instanceof RVTransportInfo))
        {
          localObject = (RVTransportInfo)arrayOfTransportInfo[i];
          str = str + "Service='" + ((RVTransportInfo)localObject).getService() + "', ";
          str = str + "Network='" + ((RVTransportInfo)localObject).getNetwork() + "', ";
          str = str + "Daemon='" + ((RVTransportInfo)localObject).getDaemon() + "', ";
          try
          {
            str = str + ((RVTransportInfo)localObject).getPolicy().toString();
          }
          catch (Throwable localThrowable1) {}
        }
        else if ((arrayOfTransportInfo[i] instanceof RVCMTransportInfo))
        {
          localObject = (RVCMTransportInfo)arrayOfTransportInfo[i];
          str = str + "RV Tport='" + ((RVCMTransportInfo)localObject).getRVTransportName() + "', ";
          str = str + "CM Name='" + ((RVCMTransportInfo)localObject).getCMName() + "', ";
          str = str + "CM Ledger='" + ((RVCMTransportInfo)localObject).getLedger() + "', ";
          str = str + "Sync Ledger=" + ((RVCMTransportInfo)localObject).getSyncLedger() + ", ";
          str = str + "Request Old=" + ((RVCMTransportInfo)localObject).getRequestOld() + ", ";
          str = str + "Default Time Limit=" + ((RVCMTransportInfo)localObject).getDefaultTimeLimit() + ", ";
          try
          {
            str = str + "Explicit Config Only=" + ((RVCMTransportInfo)localObject).getExplicitConfigOnly() + ", ";
          }
          catch (Throwable localThrowable2) {}
          try
          {
            str = str + ((RVCMTransportInfo)localObject).getPolicy().toString();
          }
          catch (Throwable localThrowable3) {}
        }
        else if ((arrayOfTransportInfo[i] instanceof SSTransportInfo))
        {
          localObject = (SSTransportInfo)arrayOfTransportInfo[i];
          str = str + "ServerNames='" + ((SSTransportInfo)localObject).getServerNames() + "', ";
          str = str + "Username='" + ((SSTransportInfo)localObject).getUsername() + "', ";
          str = str + "Project='" + ((SSTransportInfo)localObject).getProject() + "', ";
          str = str + "DeliveryMode=" + deliveryModeAsString(((SSTransportInfo)localObject).getDeliveryMode()) + ", ";
          str = str + "LoadBalanceMode=" + loadBalanceModeAsString(((SSTransportInfo)localObject).getLoadBalanceMode()) + ", ";
          str = str + "OverrideLoadBalanceMode=" + (((SSTransportInfo)localObject).getOverrideLoadBalanceMode() ? "enabled" : "disabled") + ", ";
          str = str + "GMDFileDelete=" + (((SSTransportInfo)localObject).getGmdFileDelete() ? "enabled" : "disabled") + ", ";
          str = str + "SubscribeMode=" + subscribeModeAsString(((SSTransportInfo)localObject).getSubscribeMode()) + ", ";
          try
          {
            str = str + "ImportSSHeaders=" + importSSHeadersAsString(((SSTransportInfo)localObject).getImportSSHeaders()) + ", ";
            str = str + "PreserveGMD=" + preserveGMDAsString(((SSTransportInfo)localObject).getPreserveGMD()) + "";
          }
          catch (Throwable localThrowable4) {}
        }
        Object[] arrayOfObject = { arrayOfTransportInfo[i].getName(), j != 0 ? "RV" : j != 1 ? "RVCM" : j != 2 ? "SS" : j != 3 ? "UNKNOWN" : "ALL", m != 1 ? "PERSISTENT" : m != 2 ? "RELIABLE" : m != 22 ? "UNKNOWN" : "NON_PERSISTENT", k != 1 ? "PERSISTENT" : k != 2 ? "RELIABLE" : k != 22 ? "UNKNOWN" : "NON_PERSISTENT", String.valueOf(arrayOfTransportInfo[i].getExportHeaders()), String.valueOf(arrayOfTransportInfo[i].getExportProperties()), str };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  private static String deliveryModeAsString(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return "best_effort";
    case 1: 
      return "some";
    case 2: 
      return "all";
    case 3: 
      return "ordered";
    case 4: 
      return "persistent";
    }
    return "unknown";
  }
  
  private static String loadBalanceModeAsString(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return "none";
    case 1: 
      return "round_robin";
    case 2: 
      return "weighted";
    case 3: 
      return "sorted";
    }
    return "unknown";
  }
  
  private static String subscribeModeAsString(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return "exact";
    case 1: 
      return "all";
    }
    return "unknown";
  }
  
  private static String importSSHeadersAsString(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return "none";
    case 1: 
      return "type_num";
    case 2: 
      return "all";
    }
    return "unknown";
  }
  
  private static String preserveGMDAsString(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
      return "never";
    case 1: 
      return "always";
    case 2: 
      return "receivers";
    }
    return "unknown";
  }
  
  public void populateStringInfo(Object[] paramArrayOfObject)
  {
    setRowCount(0);
    setColumnCount(0);
    if (paramArrayOfObject == null) {
      return;
    }
    this.m_table.setAutoResizeMode(2);
    addColumn("Info");
    for (int i = 0; i < paramArrayOfObject.length; i++)
    {
      String[] arrayOfString = { paramArrayOfObject[i].toString() };
      addRow(arrayOfString);
    }
  }
  
  public void populateClientsInfoOld(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    Object localObject1;
    if ((getColumnCount() != 9) || (!getColumnName(0).equals("ClientID")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      localObject1 = new String[] { "ClientID", "ConnectionCount", "ConsumerCount", "ProducerCount", "SessionCount", "InTotalMsgs", "OutTotalMsgs", "InMsgRate", "OutMsgRate" };
      setColumnIdentifiers((Object[])localObject1);
      setupColumnWidths();
    }
    try
    {
      localObject1 = new Hashtable();
      ConnectionInfo[] arrayOfConnectionInfo = paramGemsConnectionNode.m_adminConn.getConnections();
      Client localClient;
      for (int i = 0; (arrayOfConnectionInfo != null) && (i < arrayOfConnectionInfo.length); i++)
      {
        localObject2 = arrayOfConnectionInfo[i].getClientID();
        if ((localObject2 != null) && (((String)localObject2).length() != 0))
        {
          localClient = (Client)((Hashtable)localObject1).get(localObject2);
          if (localClient != null)
          {
            localClient.m_connCount += 1L;
            localClient.m_consCount += arrayOfConnectionInfo[i].getConsumerCount();
            localClient.m_prodCount += arrayOfConnectionInfo[i].getProducerCount();
            localClient.m_sessCount += arrayOfConnectionInfo[i].getSessionCount();
          }
          else
          {
            localClient = new Client((String)localObject2, arrayOfConnectionInfo[i].getConsumerCount(), arrayOfConnectionInfo[i].getProducerCount(), arrayOfConnectionInfo[i].getSessionCount());
            ((Hashtable)localObject1).put(localObject2, localClient);
          }
          ProducerInfo[] arrayOfProducerInfo = paramGemsConnectionNode.m_adminConn.getProducersStatistics(new Long(arrayOfConnectionInfo[i].getID()), null, null);
          for (int j = 0; (arrayOfProducerInfo != null) && (j < arrayOfProducerInfo.length); j++) {
            if (localClient != null)
            {
              localClient.m_outMsgs += arrayOfProducerInfo[j].getStatistics().getTotalMessages();
              localClient.m_outMsgRate += arrayOfProducerInfo[j].getStatistics().getMessageRate();
            }
          }
          ConsumerInfo[] arrayOfConsumerInfo = paramGemsConnectionNode.m_adminConn.getConsumersStatistics(new Long(arrayOfConnectionInfo[i].getID()), null, null);
          for (int k = 0; (arrayOfConsumerInfo != null) && (k < arrayOfConsumerInfo.length); k++) {
            if (localClient != null)
            {
              localClient.m_inMsgs += arrayOfConsumerInfo[k].getStatistics().getTotalMessages();
              localClient.m_inMsgRate += arrayOfConsumerInfo[k].getStatistics().getMessageRate();
            }
          }
        }
      }
      Object localObject2 = ((Hashtable)localObject1).elements();
      while (((Enumeration)localObject2).hasMoreElements())
      {
        localClient = (Client)((Enumeration)localObject2).nextElement();
        Object[] arrayOfObject = { localClient.m_id, new Long(localClient.m_connCount), new Long(localClient.m_consCount), new Long(localClient.m_prodCount), new Long(localClient.m_sessCount), new Long(localClient.m_inMsgs), new Long(localClient.m_outMsgs), new Long(localClient.m_inMsgRate), new Long(localClient.m_outMsgRate) };
        addRow(arrayOfObject);
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void populateClientsInfo(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    setRowCount(0);
    if ((getColumnCount() != 9) || (!getColumnName(0).equals("ClientID")))
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      setColumnIdentifiers(s_client_cols);
      setupColumnWidths();
    }
    try
    {
      ConnectionInfo[] arrayOfConnectionInfo = paramGemsConnectionNode.m_adminConn.getConnections();
      for (int i = 0; (arrayOfConnectionInfo != null) && (i < arrayOfConnectionInfo.length); i++)
      {
        String str = arrayOfConnectionInfo[i].getClientID();
        if ((str != null) && (str.length() != 0))
        {
          long l1 = 0L;
          long l2 = 0L;
          long l3 = 0L;
          long l4 = 0L;
          ProducerInfo[] arrayOfProducerInfo = paramGemsConnectionNode.m_adminConn.getProducersStatistics(new Long(arrayOfConnectionInfo[i].getID()), null, null);
          for (int j = 0; (arrayOfProducerInfo != null) && (j < arrayOfProducerInfo.length); j++)
          {
            l2 += arrayOfProducerInfo[j].getStatistics().getTotalMessages();
            l4 += arrayOfProducerInfo[j].getStatistics().getMessageRate();
          }
          ConsumerInfo[] arrayOfConsumerInfo = paramGemsConnectionNode.m_adminConn.getConsumersStatistics(new Long(arrayOfConnectionInfo[i].getID()), null, null);
          for (int k = 0; (arrayOfConsumerInfo != null) && (k < arrayOfConsumerInfo.length); k++)
          {
            l1 += arrayOfConsumerInfo[k].getStatistics().getTotalMessages();
            l3 += arrayOfConsumerInfo[k].getStatistics().getMessageRate();
          }
          Object[] arrayOfObject = { str, new Long(arrayOfConnectionInfo[i].getID()), new Long(arrayOfConnectionInfo[i].getConsumerCount()), new Long(arrayOfConnectionInfo[i].getProducerCount()), new Long(arrayOfConnectionInfo[i].getSessionCount()), new Long(l1), new Long(l2), new Long(l3), new Long(l4) };
          addRow(arrayOfObject);
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void initColumnWidths()
  {
    this.m_colWidths = new Hashtable();
    this.m_colWidths.put(new String("ClientID"), new Integer(150));
    this.m_colWidths.put(new String("ConnectionID"), new Integer(80));
    this.m_colWidths.put(new String("ConnectionCount"), new Integer(100));
    this.m_colWidths.put(new String("ConsumerCount"), new Integer(100));
    this.m_colWidths.put(new String("ProducerCount"), new Integer(100));
    this.m_colWidths.put(new String("SessionCount"), new Integer(100));
    this.m_colWidths.put(new String("InTotalMsgs"), new Integer(80));
    this.m_colWidths.put(new String("InMsgRate"), new Integer(80));
    this.m_colWidths.put(new String("OutTotalMsgs"), new Integer(80));
    this.m_colWidths.put(new String("OutMsgRate"), new Integer(80));
    this.m_colWidths.put(new String("PrincipalName"), new Integer(100));
    this.m_colWidths.put(new String("PrincipalType"), new Integer(100));
    this.m_colWidths.put(new String("AdministrativePermissions"), new Integer(600));
    this.m_colWidths.put(new String("DestinationName"), new Integer(200));
    this.m_colWidths.put(new String("DestinationType"), new Integer(100));
    this.m_colWidths.put(new String("PrincipalName"), new Integer(100));
    this.m_colWidths.put(new String("Permissions"), new Integer(400));
    this.m_colWidths.put(new String("QueueName"), new Integer(275));
    this.m_colWidths.put(new String("PendingMsgCount"), new Integer(120));
    this.m_colWidths.put(new String("PendingMsgSize"), new Integer(110));
    this.m_colWidths.put(new String("ReceiverCount"), new Integer(90));
    this.m_colWidths.put(new String("RouteConnected"), new Integer(100));
    this.m_colWidths.put(new String("RouteName"), new Integer(100));
    this.m_colWidths.put(new String("TopicName"), new Integer(275));
    this.m_colWidths.put(new String("SubscriberCount"), new Integer(100));
    this.m_colWidths.put(new String("DurableCount"), new Integer(90));
    this.m_colWidths.put(new String("ID"), new Integer(50));
    this.m_colWidths.put(new String("Type"), new Integer(100));
    this.m_colWidths.put(new String("Address"), new Integer(100));
    this.m_colWidths.put(new String("ClientID"), new Integer(100));
    this.m_colWidths.put(new String("Host"), new Integer(110));
    this.m_colWidths.put(new String("ClientVersion"), new Integer(100));
    this.m_colWidths.put(new String("StartTime"), new Integer(200));
    this.m_colWidths.put(new String("SourceName"), new Integer(200));
    this.m_colWidths.put(new String("Source"), new Integer(200));
    this.m_colWidths.put(new String("SourceType"), new Integer(100));
    this.m_colWidths.put(new String("Targets"), new Integer(500));
    this.m_colWidths.put(new String("Target"), new Integer(200));
    this.m_colWidths.put(new String("TargetType"), new Integer(100));
    this.m_colWidths.put(new String("FileName"), new Integer(200));
    this.m_colWidths.put(new String("SwappedSize"), new Integer(100));
    this.m_colWidths.put(new String("SwappedCount"), new Integer(100));
    this.m_colWidths.put(new String("GroupName"), new Integer(100));
    this.m_colWidths.put(new String("Description"), new Integer(150));
    this.m_colWidths.put(new String("Users"), new Integer(500));
    this.m_colWidths.put(new String("Aliases"), new Integer(200));
    this.m_colWidths.put(new String("URL"), new Integer(200));
    this.m_colWidths.put(new String("ConnectDelay"), new Integer(100));
    this.m_colWidths.put(new String("ConnectCount"), new Integer(100));
    this.m_colWidths.put(new String("ReconnectCount"), new Integer(110));
    this.m_colWidths.put(new String("ReconnectDelay"), new Integer(110));
    this.m_colWidths.put(new String("XA"), new Integer(50));
    this.m_colWidths.put(new String("LB Metric"), new Integer(80));
    this.m_colWidths.put(new String("CreateTime"), new Integer(200));
    this.m_colWidths.put(new String("DurableName"), new Integer(100));
    this.m_colWidths.put(new String("Selector"), new Integer(180));
    this.m_colWidths.put(new String("Name"), new Integer(100));
    this.m_colWidths.put(new String("inSelectors"), new Integer(120));
    this.m_colWidths.put(new String("outSelectors"), new Integer(120));
    this.m_colWidths.put(new String("Configured"), new Integer(70));
    this.m_colWidths.put(new String("Stalled"), new Integer(60));
    this.m_colWidths.put(new String("ZoneName"), new Integer(120));
    this.m_colWidths.put(new String("ZoneType"), new Integer(120));
    this.m_colWidths.put(new String("Active"), new Integer(40));
    this.m_colWidths.put(new String("Static"), new Integer(50));
    this.m_colWidths.put(new String("Global"), new Integer(50));
    this.m_colWidths.put(new String("DeliveredMsgCount"), new Integer(110));
    this.m_colWidths.put(new String("ServiceName"), new Integer(150));
    this.m_colWidths.put(new String("StartPeriod"), new Integer(200));
    this.m_colWidths.put(new String("RequestCount"), new Integer(100));
    this.m_colWidths.put(new String("ResponseCount"), new Integer(100));
    this.m_colWidths.put(new String("AvgRequests/Min"), new Integer(110));
    this.m_colWidths.put(new String("AvgRespTime(ms)"), new Integer(110));
    this.m_colWidths.put(new String("MaxRespTime(ms)"), new Integer(110));
    this.m_colWidths.put(new String("RespTimeLimit(ms)"), new Integer(120));
    this.m_colWidths.put(new String("%WithinLimit"), new Integer(90));
    this.m_colWidths.put(new String("OverLimitCount"), new Integer(100));
    this.m_colWidths.put(new String("LastRequestAt"), new Integer(200));
    this.m_colWidths.put(new String("StoreName"), new Integer(100));
    this.m_colWidths.put(new String("BacklogCount"), new Integer(100));
    this.m_colWidths.put(new String("BacklogSize"), new Integer(100));
    this.m_colWidths.put(new String("BufferedBytes"), new Integer(100));
    this.m_colWidths.put(new String("TransmittedBytes"), new Integer(120));
    this.m_colWidths.put(new String("RetransmittedBytes"), new Integer(130));
    this.m_colWidths.put(new String("Interface"), new Integer(100));
    this.m_colWidths.put(new String("DriverName"), new Integer(150));
    this.m_colWidths.put(new String("DriverDialect"), new Integer(150));
    this.m_colWidths.put(new String("UncommittedSize"), new Integer(110));
    this.m_colWidths.put(new String("UncommittedCount"), new Integer(110));
    this.m_colWidths.put(new String("SyncWrites"), new Integer(80));
    this.m_colWidths.put(new String("Identifier"), new Integer(280));
    this.m_colWidths.put(new String("Date"), new Integer(100));
    this.m_colWidths.put(new String("Time"), new Integer(110));
    this.m_colWidths.put(new String("Reason"), new Integer(110));
    this.m_colWidths.put(new String("SSType"), new Integer(80));
    this.m_colWidths.put(new String("Disable Date"), new Integer(100));
    this.m_colWidths.put(new String("Disable Time"), new Integer(100));
    this.m_colWidths.put(new String("Interface ID"), new Integer(80));
    this.m_colWidths.put(new String("Type"), new Integer(80));
    this.m_colWidths.put(new String("Busy"), new Integer(80));
    this.m_colWidths.put(new String("Applid"), new Integer(100));
    this.m_colWidths.put(new String("Status"), new Integer(200));
    this.m_colWidths.put(new String("Destination"), new Integer(400));
    this.m_colWidths.put(new String("IMS Property"), new Integer(200));
    this.m_colWidths.put(new String("IMS Buffer"), new Integer(200));
    this.m_colWidths.put(new String("IMS Connection Property"), new Integer(300));
    this.m_colWidths.put(new String("Con Value"), new Integer(300));
    this.m_colWidths.put(new String("Fragmentation"), new Integer(100));
    this.m_colWidths.put(new String("DiscardScanInterval"), new Integer(120));
    this.m_colWidths.put(new String("DiscardScanBytes"), new Integer(115));
    this.m_colWidths.put(new String("FirstScanFinished"), new Integer(100));
    this.m_colWidths.put(new String("State"), new Integer(150));
    this.m_colWidths.put(new String("GlobalTransactionId"), new Integer(300));
    this.m_colWidths.put(new String("FormatId"), new Integer(200));
    this.m_colWidths.put(new String("BranchQualifier"), new Integer(300));
    this.m_colWidths.put(new String("TransportName"), new Integer(100));
    this.m_colWidths.put(new String("QueueImportDelMode"), new Integer(135));
    this.m_colWidths.put(new String("TopicImportDelMode"), new Integer(130));
    this.m_colWidths.put(new String("ExportHeaders"), new Integer(95));
    this.m_colWidths.put(new String("ExportProperties"), new Integer(105));
    this.m_colWidths.put(new String("FurtherInfo"), new Integer(700));
    String str1 = Gems.getGems().getDetailPaneColWidths();
    String[] arrayOfString = str1.split(",");
    for (int i = 0; i < arrayOfString.length; i++) {
      try
      {
        int j = arrayOfString[i].indexOf(':');
        if (j > 0)
        {
          String str2 = arrayOfString[i].substring(0, j);
          String str3 = arrayOfString[i].substring(j + 1);
          this.m_colWidths.put(str2, Integer.valueOf(str3));
        }
      }
      catch (NumberFormatException localNumberFormatException)
      {
        System.err.println("NumberFormatException: " + localNumberFormatException.getMessage());
        return;
      }
    }
  }
  
  public void setupColumnWidths()
  {
    for (int i = 0; i < getColumnCount(); i++)
    {
      TableColumn localTableColumn = this.m_table.getColumnModel().getColumn(i);
      localTableColumn.addPropertyChangeListener(new ColumnListener());
      Integer localInteger = (Integer)this.m_colWidths.get(localTableColumn.getHeaderValue());
      if (localInteger != null) {
        localTableColumn.setPreferredWidth(localInteger.intValue());
      }
    }
  }
  
  class ColumnListener
    implements PropertyChangeListener
  {
    ColumnListener() {}
    
    public void propertyChange(PropertyChangeEvent paramPropertyChangeEvent)
    {
      if (!GemsDetailsTableModel.this.flag) {
        return;
      }
      if (paramPropertyChangeEvent.getPropertyName().equals("preferredWidth"))
      {
        TableColumn localTableColumn = (TableColumn)paramPropertyChangeEvent.getSource();
        GemsDetailsTableModel.this.m_colWidths.put(localTableColumn.getHeaderValue(), paramPropertyChangeEvent.getNewValue());
      }
    }
  }
  
  class MyRenderer
    extends DefaultTableCellRenderer
  {
    public MyRenderer() {}
    
    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      if (paramJTable.getColumnModel().getColumn(paramInt2).getPreferredWidth() <= 15) {
        paramObject = null;
      }
      Component localComponent = super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
      Object localObject1;
      if ((paramObject instanceof MsgCellValue))
      {
        localObject1 = (MsgCellValue)paramObject;
        setHorizontalAlignment(4);
        if ((((MsgCellValue)localObject1).m_errorLimit > 0L) && (((MsgCellValue)localObject1).m_cellValue >= ((MsgCellValue)localObject1).m_errorLimit * 8L / 10L))
        {
          localComponent.setBackground(Color.red);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else if ((((MsgCellValue)localObject1).m_warnLimit > 0L) && (((MsgCellValue)localObject1).m_cellValue >= ((MsgCellValue)localObject1).m_warnLimit))
        {
          localComponent.setBackground(Color.orange);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else if (paramBoolean1)
        {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        }
        else
        {
          localComponent.setBackground(Color.white);
        }
      }
      else if ((paramObject instanceof CellValue))
      {
        localObject1 = (CellValue)paramObject;
        setHorizontalAlignment(4);
        if ((((CellValue)localObject1).m_errorLimit.longValue() > 0L) && (((CellValue)localObject1).m_value >= ((CellValue)localObject1).m_errorLimit.longValue() * 8L / 10L))
        {
          localComponent.setBackground(Color.red);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else if ((((CellValue)localObject1).m_warnLimit.longValue() > 0L) && (((CellValue)localObject1).m_value >= ((CellValue)localObject1).m_warnLimit.longValue()))
        {
          localComponent.setBackground(Color.orange);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else if (paramBoolean1)
        {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        }
        else
        {
          localComponent.setBackground(Color.white);
        }
      }
      else if ((paramObject instanceof SSCellValue))
      {
        localObject1 = (SSCellValue)paramObject;
        localComponent.setBackground(((SSCellValue)localObject1).CellColour());
      }
      else if ((paramObject instanceof Long))
      {
        setHorizontalAlignment(4);
        if ((((Long)paramObject).longValue() > 0L) && (paramJTable.getColumnName(paramInt2).startsWith("Pending")))
        {
          localComponent.setBackground(Color.orange);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else if ((((Long)paramObject).longValue() == 0L) && (paramJTable.getColumnName(paramInt2).equals("ConnectionID")))
        {
          localComponent.setBackground(Color.orange);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else if (paramBoolean1)
        {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        }
        else
        {
          localComponent.setBackground(Color.white);
        }
      }
      else if ((paramObject instanceof String))
      {
        setHorizontalAlignment(2);
        localObject1 = (String)paramObject;
        if ((paramJTable.getColumnName(paramInt2).equals("Connected")) && (((String)localObject1).equals("false")))
        {
          localComponent.setBackground(Color.red);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else if ((paramJTable.getColumnName(paramInt2).equals("Stalled")) && (((String)localObject1).equals("true")))
        {
          localComponent.setBackground(Color.orange);
          localComponent.setForeground(paramJTable.getForeground());
        }
        else
        {
          Object localObject2;
          if ((paramJTable.getColumnName(paramInt2).equals("RouteConnected")) && (((String)localObject1).equals("false")) && (paramInt2 > 1))
          {
            if (paramJTable.getColumnName(paramInt2 - 1).equals("Routed"))
            {
              localObject2 = paramJTable.getValueAt(paramInt1, paramInt2 - 1);
              if (((localObject2 instanceof String)) && (((String)localObject2).equals("true")))
              {
                localComponent.setBackground(Color.red);
                localComponent.setForeground(paramJTable.getForeground());
              }
            }
          }
          else if ((paramJTable.getColumnName(paramInt2).equals("Routed")) && (((String)localObject1).equals("true")) && (paramJTable.getColumnCount() > paramInt2))
          {
            if (paramJTable.getColumnName(paramInt2 + 1).equals("RouteConnected"))
            {
              localObject2 = paramJTable.getValueAt(paramInt1, paramInt2 + 1);
              if (((localObject2 instanceof String)) && (((String)localObject2).equals("false")))
              {
                localComponent.setBackground(Color.red);
                localComponent.setForeground(paramJTable.getForeground());
              }
            }
          }
          else if (paramBoolean1) {
            localComponent.setBackground(paramJTable.getSelectionBackground());
          } else {
            localComponent.setBackground(Color.white);
          }
        }
      }
      else
      {
        setHorizontalAlignment(2);
        if (paramBoolean1) {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        } else {
          localComponent.setBackground(Color.white);
        }
      }
      return localComponent;
    }
  }
  
  class Client
  {
    String m_id;
    long m_connCount;
    long m_consCount;
    long m_prodCount;
    long m_sessCount;
    long m_inMsgs;
    long m_outMsgs;
    long m_inMsgRate;
    long m_outMsgRate;
    
    Client(String paramString, long paramLong1, long paramLong2, long paramLong3)
    {
      this.m_id = paramString;
      this.m_connCount = 1L;
      this.m_consCount = paramLong1;
      this.m_prodCount = paramLong2;
      this.m_sessCount = paramLong3;
      this.m_inMsgs = 0L;
      this.m_outMsgs = 0L;
      this.m_inMsgRate = 0L;
      this.m_outMsgRate = 0L;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDetailsTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */