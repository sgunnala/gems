package com.tibco.gems;

import com.tibco.tibjms.TibjmsTopicConnectionFactory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Random;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;

public class GemsServiceTable
  implements ActionListener
{
  public Hashtable m_services = new Hashtable();
  public boolean m_running = false;
  public boolean m_enabled = false;
  protected long m_period;
  protected boolean m_useQTemps;
  boolean m_useTTemps;
  protected PeriodThread m_timer = null;
  protected GemsConnectionNode m_cn;
  protected TopicSession m_reqSess = null;
  protected TopicSession m_respSess = null;
  protected TopicConnection m_connection = null;
  protected TopicSubscriber m_tempQueueSubscriber = null;
  protected TopicSubscriber m_tempTopicSubscriber = null;
  protected Random m_random = new Random();
  protected boolean m_useCache = true;
  protected int m_cacheIndex = 0;
  public Mutex m_mutex = new Mutex();
  public Hashtable m_syncRequests = new Hashtable();
  public Hashtable m_cacheResp = null;
  public cacheResp[] m_cacheRespArray = null;
  
  public GemsServiceTable(GemsConnectionNode paramGemsConnectionNode, long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    this.m_cn = paramGemsConnectionNode;
    this.m_period = paramLong;
    this.m_useQTemps = paramBoolean1;
    this.m_useTTemps = paramBoolean2;
    this.m_enabled = paramBoolean3;
    if (this.m_useCache)
    {
      this.m_cacheResp = new Hashtable();
      this.m_cacheRespArray = new cacheResp['Ϩ'];
      this.m_cacheIndex = 0;
    }
  }
  
  public synchronized void addToCache(String paramString1, String paramString2, long paramLong)
  {
    cacheResp localcacheResp1 = this.m_cacheRespArray[this.m_cacheIndex];
    if (localcacheResp1 != null)
    {
      cacheResp localcacheResp2 = null;
      if ((localcacheResp1.m_cid != null) && (localcacheResp1.m_cid.length() > 0)) {
        localcacheResp2 = (cacheResp)this.m_cacheResp.remove(localcacheResp1.m_cid);
      }
      if ((localcacheResp2 == null) && (localcacheResp1.m_target != null) && (localcacheResp1.m_target.length() > 0)) {
        localcacheResp2 = (cacheResp)this.m_cacheResp.remove(localcacheResp1.m_target);
      }
      if (localcacheResp2 != null) {
        Gems.debug("GemsService.addToCache: Warning cache full, removed: " + localcacheResp2.m_target + " " + localcacheResp2.m_cid + " " + localcacheResp2.m_timestamp + " " + this.m_cacheIndex);
      }
    }
    this.m_cacheRespArray[this.m_cacheIndex] = new cacheResp(paramString1, paramString2, paramLong);
    if ((paramString2 != null) && (paramString2.length() > 0)) {
      this.m_cacheResp.put(paramString2, this.m_cacheRespArray[this.m_cacheIndex]);
    } else {
      this.m_cacheResp.put(paramString1, this.m_cacheRespArray[this.m_cacheIndex]);
    }
    if (++this.m_cacheIndex >= this.m_cacheRespArray.length) {
      this.m_cacheIndex = 0;
    }
  }
  
  public synchronized void systemStart()
  {
    if (this.m_enabled) {
      userStart();
    }
  }
  
  public synchronized void userStart()
  {
    stopServices();
    reset();
    if (this.m_timer != null) {
      this.m_timer.interrupt();
    }
    this.m_timer = new PeriodThread(this.m_period * 60000L);
    this.m_timer.start();
  }
  
  public synchronized void systemStop()
  {
    userStop();
  }
  
  public synchronized void userStop()
  {
    this.m_running = false;
    stopServices();
    reset();
    if (this.m_timer != null) {
      this.m_timer.interrupt();
    }
    this.m_timer = null;
  }
  
  public synchronized void reset()
  {
    Enumeration localEnumeration = this.m_services.keys();
    while (localEnumeration.hasMoreElements())
    {
      GemsService localGemsService = (GemsService)this.m_services.get(localEnumeration.nextElement());
      localGemsService.reset();
    }
    this.m_syncRequests.clear();
    this.m_cacheResp.clear();
  }
  
  public synchronized void startServices()
  {
    if (this.m_services.size() == 0)
    {
      Gems.debug("GemsServiceTable:startServices: No services found");
      return;
    }
    try
    {
      Gems.debug("GemsServiceTable:startServices: Connecting to: " + this.m_cn.m_url);
      TibjmsTopicConnectionFactory localTibjmsTopicConnectionFactory = new TibjmsTopicConnectionFactory(this.m_cn.m_url, null, this.m_cn.m_sslParams);
      this.m_connection = localTibjmsTopicConnectionFactory.createTopicConnection(this.m_cn.m_user, this.m_cn.m_password);
      this.m_reqSess = this.m_connection.createTopicSession(false, 22);
      this.m_respSess = this.m_connection.createTopicSession(false, 22);
      int i = 0;
      int j = 0;
      Enumeration localEnumeration = this.m_services.keys();
      Object localObject;
      while (localEnumeration.hasMoreElements())
      {
        localObject = (GemsService)this.m_services.get(localEnumeration.nextElement());
        ((GemsService)localObject).start(this.m_reqSess, this.m_respSess);
      }
      if (this.m_useQTemps)
      {
        localObject = this.m_reqSess.createTopic("$sys.monitor.q.r.$TMP$.>");
        this.m_tempQueueSubscriber = this.m_respSess.createSubscriber((Topic)localObject);
        this.m_tempQueueSubscriber.setMessageListener(new OnSyncRespMessage());
        Gems.debug("GemsServiceTable:startServices: Adding queue $TMP$.>");
      }
      if (this.m_useTTemps)
      {
        localObject = this.m_reqSess.createTopic("$sys.monitor.t.r.$TMP$.>");
        this.m_tempTopicSubscriber = this.m_respSess.createSubscriber((Topic)localObject);
        this.m_tempTopicSubscriber.setMessageListener(new OnSyncRespMessage());
        Gems.debug("GemsServiceTable:startServices: Adding topic $TMP$.>");
      }
      this.m_connection.start();
    }
    catch (JMSException localJMSException)
    {
      Gems.debug("GemsServiceTable:startServices: Exception: " + localJMSException.getMessage());
      return;
    }
  }
  
  public synchronized void stopServices()
  {
    try
    {
      if (this.m_connection == null) {
        return;
      }
      this.m_connection.stop();
      Enumeration localEnumeration = this.m_services.keys();
      while (localEnumeration.hasMoreElements())
      {
        GemsService localGemsService = (GemsService)this.m_services.get(localEnumeration.nextElement());
        localGemsService.stop();
      }
      if (this.m_reqSess != null)
      {
        this.m_reqSess.close();
        this.m_reqSess = null;
      }
      if (this.m_respSess != null)
      {
        this.m_respSess.close();
        this.m_respSess = null;
      }
      this.m_connection.close();
      this.m_connection = null;
    }
    catch (Exception localException)
    {
      Gems.debug("GemsServiceTable:stop: Exception: " + localException.toString());
      return;
    }
  }
  
  public synchronized void addService(String paramString1, String paramString2, boolean paramBoolean1, String paramString3, boolean paramBoolean2, long paramLong)
  {
    this.m_services.put(paramString1, new GemsService(paramString1, paramString2, paramBoolean1, paramString3, paramBoolean2, paramLong, this));
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    reset();
  }
  
  public synchronized void newSyncRequest(GemsService paramGemsService, String paramString, long paramLong)
  {
    this.m_syncRequests.put(paramString, new syncRequest(paramGemsService, paramLong));
  }
  
  class OnSyncRespMessage
    implements MessageListener
  {
    OnSyncRespMessage() {}
    
    public void onMessage(Message paramMessage)
    {
      try
      {
        String str1 = paramMessage.getStringProperty("msg_correlation_id");
        String str2 = paramMessage.getStringProperty("target_dest_name");
        long l = paramMessage.getLongProperty("msg_timestamp");
        if (l == 0L) {
          return;
        }
        if ((str2 == null) || (!str2.startsWith("$TMP$")))
        {
          Gems.debug("GemsServiceTable.onSyncRespMessage: No $TMP target");
          return;
        }
        GemsServiceTable.this.m_mutex.acquire();
        GemsServiceTable.syncRequest localsyncRequest = null;
        if ((str1 != null) && (str1.length() > 0)) {
          localsyncRequest = (GemsServiceTable.syncRequest)GemsServiceTable.this.m_syncRequests.remove(str1);
        }
        if ((localsyncRequest == null) && (str2 != null) && (str2.length() > 0)) {
          localsyncRequest = (GemsServiceTable.syncRequest)GemsServiceTable.this.m_syncRequests.remove(str2);
        }
        if (localsyncRequest != null) {
          localsyncRequest.m_service.newResponse(localsyncRequest.m_timestamp, l, 0L);
        } else if (GemsServiceTable.this.m_useCache) {
          GemsServiceTable.this.addToCache(str2, str1, l);
        }
      }
      catch (JMSException localJMSException) {}catch (NumberFormatException localNumberFormatException) {}catch (InterruptedException localInterruptedException)
      {
        Gems.debug("GemsServiceTable.onRespMessage: Exception: " + localInterruptedException.toString());
      }
      GemsServiceTable.this.m_mutex.release();
    }
  }
  
  class PeriodThread
    extends Thread
  {
    long m_delay;
    
    PeriodThread(long paramLong)
    {
      this.m_delay = paramLong;
    }
    
    public void run()
    {
      GemsServiceTable.this.m_running = true;
      try
      {
        sleep(2000 + GemsServiceTable.this.m_random.nextInt(5000));
      }
      catch (Exception localException1)
      {
        Gems.debug("PeriodThread.Exception: " + localException1.getMessage());
        return;
      }
      GemsServiceTable.this.startServices();
      while ((this.m_delay > 0L) && (GemsServiceTable.this.m_running)) {
        try
        {
          sleep(this.m_delay);
          if (GemsServiceTable.this.m_running) {
            GemsServiceTable.this.reset();
          }
        }
        catch (Exception localException2)
        {
          Gems.debug("PeriodThread.Exception: " + localException2.getMessage());
          return;
        }
      }
    }
  }
  
  class cacheResp
  {
    String m_cid;
    String m_target;
    long m_timestamp;
    
    public cacheResp(String paramString1, String paramString2, long paramLong)
    {
      this.m_target = paramString1;
      this.m_timestamp = paramLong;
      this.m_cid = paramString2;
    }
  }
  
  class syncRequest
  {
    long m_timestamp;
    GemsService m_service;
    
    public syncRequest(GemsService paramGemsService, long paramLong)
    {
      this.m_timestamp = paramLong;
      this.m_service = paramGemsService;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsServiceTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */