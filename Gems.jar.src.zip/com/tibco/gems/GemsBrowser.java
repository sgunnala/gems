package com.tibco.gems;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkEvent.EventType;
import javax.swing.event.HyperlinkListener;
import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;

public class GemsBrowser
  extends JFrame
  implements HyperlinkListener, ActionListener
{
  private JTextField urlField;
  private JEditorPane htmlPane;
  private String initialURL;
  
  public GemsBrowser(String paramString)
  {
    super("Gems Help");
    this.initialURL = paramString;
    setDefaultCloseOperation(2);
    setIconImage(Gems.getGems().m_icon.getImage());
    JPanel localJPanel = new JPanel();
    JLabel localJLabel = new JLabel("URL:");
    this.urlField = new JTextField(60);
    this.urlField.setText(paramString);
    this.urlField.addActionListener(this);
    localJPanel.add(localJLabel);
    localJPanel.add(this.urlField);
    getContentPane().add(localJPanel, "North");
    try
    {
      this.htmlPane = new JEditorPane(paramString);
      this.htmlPane.setEditable(false);
      this.htmlPane.addHyperlinkListener(this);
      JScrollPane localJScrollPane = new JScrollPane(this.htmlPane);
      getContentPane().add(localJScrollPane, "Center");
    }
    catch (IOException localIOException)
    {
      System.err.println("JMSException: " + localIOException.getMessage());
    }
    Dimension localDimension = getToolkit().getScreenSize();
    int i = localDimension.width * 7 / 10;
    int j = localDimension.height * 8 / 10 + 20;
    setBounds(i / 7, j / 7, i, j);
    setVisible(true);
  }
  
  public void actionPerformed(ActionEvent paramActionEvent)
  {
    String str = "";
    str = this.urlField.getText();
    try
    {
      this.htmlPane.setPage(new URL(str));
    }
    catch (IOException localIOException)
    {
      System.err.println("JMSException: " + localIOException.getMessage());
    }
  }
  
  public void hyperlinkUpdate(HyperlinkEvent paramHyperlinkEvent)
  {
    if (paramHyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
      try
      {
        if ((paramHyperlinkEvent instanceof HTMLFrameHyperlinkEvent))
        {
          HTMLFrameHyperlinkEvent localHTMLFrameHyperlinkEvent = (HTMLFrameHyperlinkEvent)paramHyperlinkEvent;
          HTMLDocument localHTMLDocument = (HTMLDocument)this.htmlPane.getDocument();
          localHTMLDocument.processHTMLFrameHyperlinkEvent(localHTMLFrameHyperlinkEvent);
        }
        else
        {
          this.htmlPane.setPage(paramHyperlinkEvent.getURL());
          this.urlField.setText(paramHyperlinkEvent.getURL().toExternalForm());
        }
      }
      catch (IOException localIOException)
      {
        System.err.println("JMSException: " + localIOException.getMessage());
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsBrowser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */