package com.tibco.gems;

import java.io.PrintStream;
import java.lang.reflect.Method;

public class GemsProperty
{
  protected String name;
  protected Class type;
  protected String help;
  
  public GemsProperty(String paramString, Class paramClass)
  {
    this.name = paramString;
    this.type = paramClass;
    this.help = "<html> <br> <br> </html>";
  }
  
  public GemsProperty(String paramString1, Class paramClass, String paramString2)
  {
    this.name = paramString1;
    this.type = paramClass;
    this.help = paramString2;
  }
  
  public void setValue(Object paramObject, String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramObject.getClass().getName());
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = this.type;
      Method localMethod = localClass.getMethod(getSetMethod(), arrayOfClass);
      Object[] arrayOfObject = new Object[1];
      if (this.type.isAssignableFrom(Long.TYPE)) {
        arrayOfObject[0] = new Long(paramString);
      } else if (this.type.isAssignableFrom(Boolean.TYPE)) {
        arrayOfObject[0] = new Boolean(paramString);
      } else if (this.type.isAssignableFrom(Class.forName("java.lang.String"))) {
        arrayOfObject[0] = paramString;
      } else if (this.type.isAssignableFrom(Integer.TYPE)) {
        arrayOfObject[0] = new Integer(paramString);
      } else if (this.type.isAssignableFrom(Byte.TYPE)) {
        arrayOfObject[0] = new Byte(paramString);
      } else {
        System.err.println("GemsProperty type not supported: " + this.type.getName());
      }
      localMethod.invoke(paramObject, arrayOfObject);
    }
    catch (Throwable localThrowable)
    {
      System.err.println(localThrowable);
    }
  }
  
  public String getValue(Object paramObject)
  {
    try
    {
      Class localClass = Class.forName(paramObject.getClass().getName());
      Method localMethod = localClass.getMethod(getGetMethod(), (Class[])null);
      Object localObject = localMethod.invoke(paramObject, (Object[])null);
      return localObject == null ? "" : localObject.toString();
    }
    catch (Throwable localThrowable)
    {
      System.err.println(localThrowable);
    }
    return new String();
  }
  
  public void setBoolean(Object paramObject, boolean paramBoolean)
  {
    try
    {
      Class localClass = Class.forName(paramObject.getClass().getName());
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = this.type;
      Method localMethod = localClass.getMethod(getSetMethod(), arrayOfClass);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = new Boolean(paramBoolean);
      localMethod.invoke(paramObject, arrayOfObject);
    }
    catch (Throwable localThrowable)
    {
      System.err.println(localThrowable);
    }
  }
  
  public void setLong(Object paramObject, long paramLong)
  {
    try
    {
      Class localClass = Class.forName(paramObject.getClass().getName());
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = this.type;
      Method localMethod = localClass.getMethod(getSetMethod(), arrayOfClass);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = new Long(paramLong);
      localMethod.invoke(paramObject, arrayOfObject);
    }
    catch (Throwable localThrowable)
    {
      System.err.println(localThrowable);
    }
  }
  
  public void setString(Object paramObject, String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramObject.getClass().getName());
      Class[] arrayOfClass = new Class[1];
      arrayOfClass[0] = this.type;
      Method localMethod = localClass.getMethod(getSetMethod(), arrayOfClass);
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = new String(paramString);
      localMethod.invoke(paramObject, arrayOfObject);
    }
    catch (Throwable localThrowable)
    {
      System.err.println(localThrowable);
    }
  }
  
  public String getSetMethod()
  {
    return "set" + this.name;
  }
  
  public String getGetMethod()
  {
    if (this.type.isAssignableFrom(Boolean.TYPE)) {
      return "is" + this.name;
    }
    return "get" + this.name;
  }
  
  public String getHelpText()
  {
    return this.help;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */