package com.tibco.gems;

import com.tibco.tibjms.TibjmsQueueConnectionFactory;
import com.tibco.tibjms.admin.TibjmsAdmin;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueBrowser;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;
import javax.swing.Timer;
import javax.swing.table.JTableHeader;
import javax.swing.text.DefaultEditorKit.CopyAction;
import javax.swing.text.DefaultEditorKit.CutAction;
import javax.swing.text.DefaultEditorKit.PasteAction;

public class GemsQueueBrowser
  extends JFrame
{
  JFrame m_frame;
  JPanel m_panel;
  boolean m_running = false;
  int m_msgs = 0;
  int m_maxMsgs = 10;
  Message m_msg = null;
  TibjmsAdmin m_admin = null;
  QueueSession m_session = null;
  GemsConnectionNode m_cn;
  QueueConnection m_connection = null;
  QueueBrowser m_browser = null;
  Enumeration m_msgsEnum = null;
  Pattern m_pattern = null;
  Timer m_timer = new Timer(Gems.getGems().getMsgReadDelay(), new RefreshTimerAction());
  protected JTextField m_conn;
  protected JTextField m_queue;
  protected JTextField m_msgsRead;
  protected JTextField m_msgsDisplay;
  protected JTextField m_selector;
  protected JButton m_startButton;
  protected JButton m_stopButton;
  protected JButton m_selwiz;
  protected JButton m_destwiz;
  protected JCheckBox m_noLimit;
  JTable m_table;
  protected GemsMessageTableModel m_tableModel;
  protected boolean m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
  protected JMenuItem m_optMenuItem;
  protected JMenuItem m_filterMenuItem;
  protected JMenuItem m_selectorMenuItem;
  protected JMenuItem m_dumpMenuItem;
  TableSorter m_sorter;
  
  public GemsQueueBrowser(GemsConnectionNode paramGemsConnectionNode, String paramString)
  {
    super(Gems.getGems().getTitlePrefix() + "Queue Browser");
    setLocation(400, 175);
    setDefaultCloseOperation(2);
    this.m_frame = this;
    this.m_cn = paramGemsConnectionNode;
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    JLabel localJLabel2 = new JLabel("Queue Name:", 11);
    this.m_queue = new JTextField(paramString, 20);
    localJLabel2.setLabelFor(this.m_queue);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_queue);
    this.m_destwiz = new JButton("...");
    this.m_destwiz.setPreferredSize(new Dimension(18, 16));
    this.m_destwiz.addActionListener(new DestinationWizardAction());
    localJPanel3.add(this.m_destwiz);
    localJPanel2.add(localJPanel3);
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    localJPanel4.setMinimumSize(new Dimension(140, 24));
    JLabel localJLabel3 = new JLabel("Selector:", 11);
    this.m_selector = new JTextField("", 20);
    localJLabel3.setLabelFor(this.m_selector);
    localJPanel2.add(localJLabel3);
    localJPanel4.add(this.m_selector);
    this.m_selwiz = new JButton("...");
    this.m_selwiz.setPreferredSize(new Dimension(18, 16));
    this.m_selwiz.addActionListener(new SelectorWizardAction());
    localJPanel4.add(this.m_selwiz);
    localJPanel2.add(localJPanel4);
    JPanel localJPanel5 = new JPanel(true);
    localJPanel5.setLayout(new BoxLayout(localJPanel5, 0));
    JLabel localJLabel4 = new JLabel("Msgs to Read:", 11);
    this.m_msgsRead = new JTextField("10", 20);
    this.m_msgsRead.setMinimumSize(new Dimension(40, 24));
    localJPanel4.setMinimumSize(new Dimension(140, 24));
    localJLabel4.setLabelFor(this.m_msgsRead);
    localJPanel2.add(localJLabel4);
    localJPanel5.add(this.m_msgsRead);
    this.m_noLimit = new JCheckBox("No Limit", false);
    localJPanel5.add(this.m_noLimit);
    localJPanel2.add(localJPanel5);
    this.m_tableModel = new GemsMessageTableModel(false, true);
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setSelectionMode(0);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(650, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel6 = new JPanel(true);
    localJPanel6.setLayout(new BoxLayout(localJPanel6, 0));
    Component localComponent = Box.createRigidArea(new Dimension(250, 10));
    localJPanel6.add(localComponent);
    this.m_startButton = new JButton("Start");
    this.m_startButton.addActionListener(new StartPressed());
    this.m_stopButton = new JButton("Stop");
    this.m_stopButton.addActionListener(new StopPressed());
    this.m_stopButton.setEnabled(false);
    localJPanel6.add(this.m_startButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel6.add(localComponent);
    localJPanel6.add(this.m_stopButton);
    localJPanel1.add(localJPanel6, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 4, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    pack();
    show();
  }
  
  public void start()
  {
    this.m_running = true;
    this.m_msgs = 0;
    this.m_queue.setEnabled(false);
    this.m_msgsRead.setEnabled(false);
    this.m_startButton.setEnabled(false);
    this.m_stopButton.setEnabled(true);
    this.m_noLimit.setEnabled(false);
    this.m_selector.setEnabled(false);
    this.m_filterMenuItem.setEnabled(false);
    this.m_selwiz.setEnabled(false);
    this.m_destwiz.setEnabled(false);
    this.m_optMenuItem.setEnabled(false);
    this.m_selectorMenuItem.setEnabled(false);
    this.m_dumpMenuItem.setEnabled(false);
    try
    {
      this.m_maxMsgs = Integer.parseInt(this.m_msgsRead.getText());
    }
    catch (Exception localException)
    {
      this.m_maxMsgs = 10;
    }
    this.m_tableModel.buildColumnHeaders();
    try
    {
      TibjmsQueueConnectionFactory localTibjmsQueueConnectionFactory = new TibjmsQueueConnectionFactory(this.m_cn.m_url, null, this.m_cn.m_sslParams);
      this.m_connection = localTibjmsQueueConnectionFactory.createQueueConnection(this.m_cn.m_user, this.m_cn.m_password);
      this.m_session = this.m_connection.createQueueSession(false, 1);
      Queue localQueue = this.m_session.createQueue(this.m_queue.getText());
      this.m_connection.start();
      if ((this.m_selector != null) && (this.m_selector.getText().length() > 0)) {
        this.m_browser = this.m_session.createBrowser(localQueue, this.m_selector.getText());
      } else {
        this.m_browser = this.m_session.createBrowser(localQueue);
      }
      this.m_msgsEnum = this.m_browser.getEnumeration();
      this.m_timer.start();
    }
    catch (JMSException localJMSException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localJMSException.getMessage(), "Error", 1);
      stop();
    }
  }
  
  public void stop()
  {
    this.m_timer.stop();
    this.m_running = false;
    try
    {
      this.m_msgsEnum = null;
      if (this.m_browser != null)
      {
        this.m_browser.close();
        this.m_browser = null;
      }
      if (this.m_session != null)
      {
        this.m_session.close();
        this.m_session = null;
      }
      if (this.m_connection != null)
      {
        this.m_connection.close();
        this.m_connection = null;
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("Exception: " + localJMSException.getMessage());
    }
    this.m_queue.setEnabled(true);
    this.m_msgsRead.setEnabled(true);
    this.m_startButton.setEnabled(true);
    this.m_stopButton.setEnabled(false);
    this.m_noLimit.setEnabled(true);
    this.m_selector.setEnabled(true);
    this.m_selwiz.setEnabled(true);
    this.m_destwiz.setEnabled(true);
    this.m_optMenuItem.setEnabled(true);
    this.m_filterMenuItem.setEnabled(true);
    this.m_selectorMenuItem.setEnabled(true);
    this.m_dumpMenuItem.setEnabled(true);
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          GemsQueueBrowser.this.showMessageFrame();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    this.m_dumpMenuItem = new JMenuItem("Save Messages To File...");
    this.m_dumpMenuItem.addActionListener(new DumpToFile());
    localJMenu.add(this.m_dumpMenuItem);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsQueueBrowser.this.dispose();
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CutAction());
    localJMenuItem.setText("Cut");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CopyAction());
    localJMenuItem.setText("Copy");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(67, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.PasteAction());
    localJMenuItem.setText("Paste");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(86, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem("Select All");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(65, 2));
    localJMenuItem.addActionListener(new SelectAllAction());
    localJMenu.add(localJMenuItem);
    localJMenu.addSeparator();
    this.m_selectorMenuItem = localJMenu.add(new JMenuItem("Selector..."));
    this.m_selectorMenuItem.addActionListener(new SelectorWizardAction());
    this.m_filterMenuItem = localJMenu.add(new JMenuItem("TextMessage Filter..."));
    this.m_filterMenuItem.addActionListener(new FilterWizardAction());
    this.m_optMenuItem = localJMenu.add(new JMenuItem("Options..."));
    this.m_optMenuItem.addActionListener(new EditOptionsAction());
    localJMenuBar.add(localJMenu);
    localJMenu = new JMenu("Message");
    localJMenu.setMnemonic(77);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("View Message..."));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsQueueBrowser.this.showMessageFrame();
      }
    });
    if (!Gems.getGems().getViewOnlyMode())
    {
      localJMenuItem = localJMenu.add(new JMenuItem("Copy Checked Messages..."));
      localJMenuItem.addActionListener(new CopyMessageAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Destroy Checked Messages..."));
      localJMenuItem.addActionListener(new DestroyMessageAction());
    }
    return localJMenuBar;
  }
  
  public void showMessageFrame()
  {
    Message localMessage = this.m_tableModel.getSelectedMessage();
    if (localMessage != null)
    {
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, null, true, null, false);
      localGemsMessageFrame.populate(localMessage);
    }
    else
    {
      JOptionPane.showMessageDialog(this.m_frame, "Select a Message to view!", "View Message", 1);
    }
  }
  
  public void dispose()
  {
    stop();
    super.dispose();
  }
  
  class DumpToFile
    implements ActionListener
  {
    DumpToFile() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        JFileChooser localJFileChooser = new JFileChooser();
        localJFileChooser.setApproveButtonText("Save");
        localJFileChooser.setDialogTitle("Save Messages To File (appends)");
        int i = localJFileChooser.showOpenDialog(GemsQueueBrowser.this.m_frame);
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          GemsQueueBrowser.this.m_tableModel.dumpMsgsToFile(localFile);
        }
      }
      catch (IOException localIOException)
      {
        JOptionPane.showMessageDialog(GemsQueueBrowser.this.m_frame, localIOException.getMessage(), "Error", 1);
        return;
      }
    }
  }
  
  class SelectAllAction
    implements ActionListener
  {
    SelectAllAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsQueueBrowser.this.m_tableModel.selectAllRows();
    }
  }
  
  class DestroyMessageAction
    implements ActionListener
  {
    DestroyMessageAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Vector localVector = GemsQueueBrowser.this.m_tableModel.getSelectedMessages();
      if (localVector.size() == 0) {
        JOptionPane.showMessageDialog(GemsQueueBrowser.this.m_frame, "Select Messages to destroy using checkbox!", "Destroy Messages", 1);
      }
      if (localVector.size() > 0) {
        GemsMessageDestroyer localGemsMessageDestroyer = new GemsMessageDestroyer(GemsQueueBrowser.this.m_frame, GemsQueueBrowser.this.m_cn, localVector, GemsQueueBrowser.this.m_queue.getText());
      }
    }
  }
  
  class CopyMessageAction
    implements ActionListener
  {
    CopyMessageAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Vector localVector = GemsQueueBrowser.this.m_tableModel.getSelectedMessages();
      if (localVector.size() == 0) {
        JOptionPane.showMessageDialog(GemsQueueBrowser.this.m_frame, "Select Messages to copy using checkbox!", "Copy Messages", 1);
      }
      if (localVector.size() > 0) {
        GemsMessageCopier localGemsMessageCopier = new GemsMessageCopier(GemsQueueBrowser.this.m_frame, GemsQueueBrowser.this.m_cn, localVector);
      }
    }
  }
  
  class FilterWizardAction
    implements ActionListener
  {
    FilterWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsBrowserFilterDialog localGemsBrowserFilterDialog = new GemsBrowserFilterDialog(GemsQueueBrowser.this.m_frame, "TextMessage Filter Editor:");
      Pattern localPattern = localGemsBrowserFilterDialog.getFilter(GemsQueueBrowser.this.m_pattern, "messages");
      if (!localGemsBrowserFilterDialog.m_cancelled) {
        GemsQueueBrowser.this.m_pattern = localPattern;
      }
      if ((GemsQueueBrowser.this.m_pattern != null) && (GemsQueueBrowser.this.m_pattern.pattern().length() == 0)) {
        GemsQueueBrowser.this.m_pattern = null;
      }
    }
  }
  
  class DestinationWizardAction
    implements ActionListener
  {
    DestinationWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsQueueBrowser.this.m_frame, GemsQueueBrowser.this.m_cn, GemsDestination.DEST_TYPE.Queue);
      if (localGemsDestinationPicker.m_retDest != null) {
        GemsQueueBrowser.this.m_queue.setText(localGemsDestinationPicker.m_retDest.m_destName);
      }
    }
  }
  
  class SelectorWizardAction
    implements ActionListener
  {
    SelectorWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsSelectorWizardDialog localGemsSelectorWizardDialog = new GemsSelectorWizardDialog(GemsQueueBrowser.this.m_frame, "Selector Editor:", "Browse");
      if ((!localGemsSelectorWizardDialog.m_cancelled) && (localGemsSelectorWizardDialog.m_selector.length() > 0)) {
        GemsQueueBrowser.this.m_selector.setText(localGemsSelectorWizardDialog.m_selector);
      }
    }
  }
  
  class EditOptionsAction
    implements ActionListener
  {
    EditOptionsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      new GemsBrowserOptionsDialog(GemsQueueBrowser.this.m_frame, "Edit Queue Browser Options");
      GemsQueueBrowser.this.m_timer.setDelay(Gems.getGems().getMsgReadDelay());
      GemsQueueBrowser.this.m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
    }
  }
  
  class StopPressed
    implements ActionListener
  {
    StopPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsQueueBrowser.this.stop();
    }
  }
  
  class StartPressed
    implements ActionListener
  {
    StartPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsQueueBrowser.this.start();
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsQueueBrowser.this.m_running) {
        if (!GemsQueueBrowser.this.m_msgsEnum.hasMoreElements())
        {
          GemsQueueBrowser.this.stop();
        }
        else
        {
          Message localMessage = (Message)GemsQueueBrowser.this.m_msgsEnum.nextElement();
          if (localMessage != null)
          {
            try
            {
              if ((GemsQueueBrowser.this.m_pattern != null) && ((localMessage instanceof TextMessage)) && (!GemsQueueBrowser.this.m_pattern.matcher(((TextMessage)localMessage).getText()).matches())) {
                return;
              }
            }
            catch (JMSException localJMSException)
            {
              System.err.println("Exception: " + localJMSException.getMessage());
              return;
            }
            GemsQueueBrowser.this.m_tableModel.addMessage(localMessage, GemsQueueBrowser.this.m_viewoldestFirst);
            if (!GemsQueueBrowser.this.m_noLimit.isSelected()) {
              if (++GemsQueueBrowser.this.m_msgs >= GemsQueueBrowser.this.m_maxMsgs) {
                GemsQueueBrowser.this.stop();
              }
            }
          }
        }
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsQueueBrowser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */