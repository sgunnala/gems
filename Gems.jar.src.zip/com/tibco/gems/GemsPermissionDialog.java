package com.tibco.gems;

import com.tibco.tibjms.admin.ACLEntry;
import com.tibco.tibjms.admin.DestinationInfo;
import com.tibco.tibjms.admin.GroupInfo;
import com.tibco.tibjms.admin.Permissions;
import com.tibco.tibjms.admin.PrincipalInfo;
import com.tibco.tibjms.admin.QueueInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import com.tibco.tibjms.admin.TopicInfo;
import com.tibco.tibjms.admin.UserInfo;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.PrintStream;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SpringLayout;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

public class GemsPermissionDialog
  extends JDialog
{
  protected JTree m_perms;
  protected JFrame m_frame;
  protected JCheckBox m_isAdmin;
  protected JTextField m_dest;
  protected JComboBox m_principal;
  protected boolean m_cancelled = false;
  protected String m_selected;
  protected CheckNode[] m_px;
  protected GemsConnectionNode m_cn;
  protected boolean m_isQueue = false;
  protected JButton m_destwiz;
  
  public GemsPermissionDialog(JFrame paramJFrame, String paramString1, boolean paramBoolean, GemsConnectionNode paramGemsConnectionNode, String paramString2)
  {
    super(paramJFrame, paramString1, true);
    this.m_cn = paramGemsConnectionNode;
    this.m_frame = paramJFrame;
    this.m_isQueue = paramBoolean;
    buildFrame(paramJFrame, paramString2);
    updatePermissions(true);
    pack();
    show();
  }
  
  public GemsPermissionDialog(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
  {
    super(paramJFrame, "Set " + paramString2 + " Permissions", true);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    if (paramString2.equals("Queue")) {
      this.m_isQueue = true;
    } else {
      this.m_isQueue = false;
    }
    String str = paramString3;
    if (paramString4.equals("User")) {
      str = str + " (user";
    } else {
      str = str + " (group";
    }
    if (paramString5.equals("true")) {
      str = str + ", external)";
    } else {
      str = str + ")";
    }
    buildFrame(paramJFrame, paramString1);
    this.m_principal.setSelectedItem(str);
    this.m_selected = ((String)this.m_principal.getSelectedItem());
    updatePermissions(true);
    pack();
    show();
  }
  
  public void buildFrame(Frame paramFrame, String paramString)
  {
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 1));
    JPanel localJPanel2 = new JPanel(new SpringLayout());
    localJPanel1.add(localJPanel2);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    JLabel localJLabel1 = new JLabel(this.m_isQueue ? "Queue:" : "Topic:", 11);
    this.m_dest = new JTextField(20);
    this.m_dest.setText(paramString);
    localJPanel2.add(localJLabel1);
    localJPanel3.add(this.m_dest);
    this.m_destwiz = new JButton("...");
    this.m_destwiz.setPreferredSize(new Dimension(18, 16));
    this.m_destwiz.addActionListener(new DestinationWizardAction());
    localJPanel3.add(this.m_destwiz);
    localJPanel2.add(localJPanel3);
    JLabel localJLabel2 = new JLabel("Principal:", 11);
    this.m_principal = new JComboBox();
    populatePrincipals();
    this.m_principal.addActionListener(new PrincipalSelected());
    localJPanel2.add(localJLabel2);
    localJPanel2.add(this.m_principal);
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 2, 5, 5, 5, 5);
    if (this.m_isQueue) {
      this.m_px = new CheckNode[] { new CheckNode("All Permissions:"), new CheckNode("JMS Permissions:"), new CheckNode("Send To Queue"), new CheckNode("Receive From Queue"), new CheckNode("Browse Queue"), new CheckNode("Admin Permissions:"), new CheckNode("View Queue"), new CheckNode("Create Queue"), new CheckNode("Modify Queue"), new CheckNode("Delete Queue"), new CheckNode("Purge Queue") };
    } else {
      this.m_px = new CheckNode[] { new CheckNode("All Permissions:"), new CheckNode("JMS Permissions:"), new CheckNode("Subscribe To Topic"), new CheckNode("Publish To Topic"), new CheckNode("Create Durable"), new CheckNode("Use Durable"), new CheckNode("Admin Permissions:"), new CheckNode("View Topic"), new CheckNode("Create Topic"), new CheckNode("Modify Topic"), new CheckNode("Delete Topic"), new CheckNode("Purge Topic") };
    }
    this.m_perms = new JTree(this.m_px[0]);
    this.m_perms.setBorder(new EtchedBorder());
    this.m_perms.setCellRenderer(new CheckRenderer());
    this.m_perms.getSelectionModel().setSelectionMode(1);
    this.m_perms.putClientProperty("JTree.lineStyle", "Angled");
    this.m_perms.addMouseListener(new NodeSelectionListener(this.m_perms));
    int i = 0;
    for (int j = 1; j < this.m_px.length; j++)
    {
      if ((((String)this.m_px[j].getUserObject()).endsWith(":")) && (i > 0)) {
        i = 0;
      }
      this.m_px[i].add(this.m_px[j]);
      if ((((String)this.m_px[j].getUserObject()).endsWith(":")) && (i == 0)) {
        i = j;
      }
    }
    this.m_perms.expandRow(0);
    this.m_perms.expandRow(1);
    this.m_perms.expandRow(5);
    this.m_perms.expandRow(6);
    JScrollPane localJScrollPane = new JScrollPane(this.m_perms);
    localJScrollPane.setPreferredSize(new Dimension(350, 300));
    JPanel localJPanel4 = new JPanel();
    localJPanel4.setBorder(new TitledBorder("Permissions"));
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 1));
    JPanel localJPanel5 = new JPanel(new FlowLayout());
    JButton localJButton1 = new JButton("Apply");
    localJButton1.addActionListener(new ApplyPressed());
    localJPanel5.add(localJButton1);
    JButton localJButton2 = new JButton("Reset");
    localJButton2.addActionListener(new ResetPressed());
    localJPanel5.add(localJButton2);
    localJPanel4.add(localJScrollPane);
    JPanel localJPanel6 = new JPanel(new FlowLayout());
    JButton localJButton3 = new JButton("Permit All");
    JButton localJButton4 = new JButton("Restrict All");
    localJPanel6.add(localJButton3);
    localJPanel6.add(localJButton4);
    localJPanel4.add(localJPanel5);
    localJPanel1.add(localJPanel4);
    JPanel localJPanel7 = new JPanel();
    localJPanel7.setLayout(new FlowLayout());
    JButton localJButton5 = new JButton("OK");
    JButton localJButton6 = new JButton("Cancel");
    localJPanel7.add(localJButton5);
    localJPanel7.add(localJButton6);
    localJButton5.addActionListener(new OkPressed());
    localJButton6.addActionListener(new CancelPressed());
    localJPanel1.add(localJPanel7);
    setContentPane(localJPanel1);
    setLocationRelativeTo(paramFrame);
  }
  
  public String getSelectedProp()
  {
    return this.m_selected;
  }
  
  public void populatePrincipals()
  {
    try
    {
      UserInfo[] arrayOfUserInfo = this.m_cn.m_adminConn.getUsers();
      for (int i = 0; i < arrayOfUserInfo.length; i++) {
        if (!arrayOfUserInfo[i].getName().equals("admin"))
        {
          String str1 = arrayOfUserInfo[i].getName() + " (user";
          if (arrayOfUserInfo[i].isExternal()) {
            str1 = str1 + ", external)";
          } else {
            str1 = str1 + ")";
          }
          this.m_principal.addItem(str1);
        }
      }
      GroupInfo[] arrayOfGroupInfo = this.m_cn.m_adminConn.getGroups();
      for (int j = 0; j < arrayOfGroupInfo.length; j++) {
        if (!arrayOfGroupInfo[j].getName().equals("$admin"))
        {
          String str2 = arrayOfGroupInfo[j].getName() + " (group";
          if (arrayOfGroupInfo[j].isExternal()) {
            str2 = str2 + ", external)";
          } else {
            str2 = str2 + ")";
          }
          this.m_principal.addItem(str2);
        }
      }
      this.m_selected = ((String)this.m_principal.getSelectedItem());
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
    }
  }
  
  public void updatePermissions(boolean paramBoolean)
  {
    if ((paramBoolean) && (this.m_dest.getText().length() == 0)) {
      return;
    }
    try
    {
      for (int i = 0; i < this.m_px.length; i++) {
        this.m_px[i].setSelected(false);
      }
      ACLEntry[] arrayOfACLEntry;
      if (this.m_isQueue) {
        arrayOfACLEntry = this.m_cn.m_adminConn.getQueueACLEntries(this.m_dest.getText());
      } else {
        arrayOfACLEntry = this.m_cn.m_adminConn.getTopicACLEntries(this.m_dest.getText());
      }
      for (int j = 0; j < arrayOfACLEntry.length; j++)
      {
        String str = arrayOfACLEntry[j].getPrincipal().getName();
        if ((arrayOfACLEntry[j].getPrincipal() instanceof UserInfo)) {
          str = str + " (user";
        } else {
          str = str + " (group";
        }
        if (this.m_selected.startsWith(str))
        {
          Permissions localPermissions = arrayOfACLEntry[j].getPermissions();
          if (this.m_isQueue)
          {
            if (localPermissions.hasPermission(1L)) {
              this.m_px[2].setSelected(true);
            }
            if (localPermissions.hasPermission(2L)) {
              this.m_px[3].setSelected(true);
            }
            if (localPermissions.hasPermission(4L)) {
              this.m_px[4].setSelected(true);
            }
            if (localPermissions.hasPermission(65536L)) {
              this.m_px[6].setSelected(true);
            }
            if (localPermissions.hasPermission(131072L)) {
              this.m_px[7].setSelected(true);
            }
            if (localPermissions.hasPermission(524288L)) {
              this.m_px[8].setSelected(true);
            }
            if (localPermissions.hasPermission(262144L)) {
              this.m_px[9].setSelected(true);
            }
            if (!localPermissions.hasPermission(1048576L)) {
              break;
            }
            this.m_px[10].setSelected(true);
            break;
          }
          if (localPermissions.hasPermission(32L)) {
            this.m_px[2].setSelected(true);
          }
          if (localPermissions.hasPermission(16L)) {
            this.m_px[3].setSelected(true);
          }
          if (localPermissions.hasPermission(64L)) {
            this.m_px[4].setSelected(true);
          }
          if (localPermissions.hasPermission(128L)) {
            this.m_px[5].setSelected(true);
          }
          if (localPermissions.hasPermission(65536L)) {
            this.m_px[7].setSelected(true);
          }
          if (localPermissions.hasPermission(131072L)) {
            this.m_px[8].setSelected(true);
          }
          if (localPermissions.hasPermission(524288L)) {
            this.m_px[9].setSelected(true);
          }
          if (localPermissions.hasPermission(262144L)) {
            this.m_px[10].setSelected(true);
          }
          if (!localPermissions.hasPermission(1048576L)) {
            break;
          }
          this.m_px[11].setSelected(true);
          break;
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this, localTibjmsAdminException.getMessage(), "Error", 1);
    }
    this.m_perms.repaint();
  }
  
  public void setPermissions()
  {
    try
    {
      Permissions localPermissions1 = new Permissions();
      Permissions localPermissions2 = new Permissions();
      Object localObject1;
      if (this.m_isQueue)
      {
        localObject1 = new QueueInfo(this.m_dest.getText());
        if (this.m_px[2].isSelected()) {
          localPermissions1.setPermission(1L, true);
        } else {
          localPermissions2.setPermission(1L, true);
        }
        if (this.m_px[3].isSelected()) {
          localPermissions1.setPermission(2L, true);
        } else {
          localPermissions2.setPermission(2L, true);
        }
        if (this.m_px[4].isSelected()) {
          localPermissions1.setPermission(4L, true);
        } else {
          localPermissions2.setPermission(4L, true);
        }
        if (this.m_px[6].isSelected()) {
          localPermissions1.setPermission(65536L, true);
        } else {
          localPermissions2.setPermission(65536L, true);
        }
        if (this.m_px[7].isSelected()) {
          localPermissions1.setPermission(131072L, true);
        } else {
          localPermissions2.setPermission(131072L, true);
        }
        if (this.m_px[8].isSelected()) {
          localPermissions1.setPermission(524288L, true);
        } else {
          localPermissions2.setPermission(524288L, true);
        }
        if (this.m_px[9].isSelected()) {
          localPermissions1.setPermission(262144L, true);
        } else {
          localPermissions2.setPermission(262144L, true);
        }
        if (this.m_px[10].isSelected()) {
          localPermissions1.setPermission(1048576L, true);
        } else {
          localPermissions2.setPermission(1048576L, true);
        }
      }
      else
      {
        localObject1 = new TopicInfo(this.m_dest.getText());
        if (this.m_px[2].isSelected()) {
          localPermissions1.setPermission(32L, true);
        } else {
          localPermissions2.setPermission(32L, true);
        }
        if (this.m_px[3].isSelected()) {
          localPermissions1.setPermission(16L, true);
        } else {
          localPermissions2.setPermission(16L, true);
        }
        if (this.m_px[4].isSelected()) {
          localPermissions1.setPermission(64L, true);
        } else {
          localPermissions2.setPermission(64L, true);
        }
        if (this.m_px[5].isSelected()) {
          localPermissions1.setPermission(128L, true);
        } else {
          localPermissions2.setPermission(128L, true);
        }
        if (this.m_px[7].isSelected()) {
          localPermissions1.setPermission(65536L, true);
        } else {
          localPermissions2.setPermission(65536L, true);
        }
        if (this.m_px[8].isSelected()) {
          localPermissions1.setPermission(131072L, true);
        } else {
          localPermissions2.setPermission(131072L, true);
        }
        if (this.m_px[9].isSelected()) {
          localPermissions1.setPermission(524288L, true);
        } else {
          localPermissions2.setPermission(524288L, true);
        }
        if (this.m_px[10].isSelected()) {
          localPermissions1.setPermission(262144L, true);
        } else {
          localPermissions2.setPermission(262144L, true);
        }
        if (this.m_px[11].isSelected()) {
          localPermissions1.setPermission(1048576L, true);
        } else {
          localPermissions2.setPermission(1048576L, true);
        }
      }
      int i;
      Object localObject2;
      if ((i = this.m_selected.lastIndexOf(" (user")) > 0)
      {
        localObject2 = new UserInfo(this.m_selected.substring(0, i));
      }
      else
      {
        i = this.m_selected.lastIndexOf(" (group");
        localObject2 = new GroupInfo(this.m_selected.substring(0, i));
      }
      if (!localPermissions1.isEmpty()) {
        this.m_cn.m_adminConn.grant(new ACLEntry((DestinationInfo)localObject1, (PrincipalInfo)localObject2, localPermissions1));
      }
      if (!localPermissions2.isEmpty()) {
        this.m_cn.m_adminConn.revoke(new ACLEntry((DestinationInfo)localObject1, (PrincipalInfo)localObject2, localPermissions2));
      }
      Gems.getGems().scheduleRepaint();
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this, localTibjmsAdminException.getMessage(), "Error", 1);
      updatePermissions(false);
    }
  }
  
  class NodeSelectionListener
    extends MouseAdapter
  {
    JTree tree;
    
    NodeSelectionListener(JTree paramJTree)
    {
      this.tree = paramJTree;
    }
    
    public void mouseClicked(MouseEvent paramMouseEvent)
    {
      int i = paramMouseEvent.getX();
      int j = paramMouseEvent.getY();
      int k = this.tree.getRowForLocation(i, j);
      TreePath localTreePath = this.tree.getPathForRow(k);
      if (localTreePath != null)
      {
        CheckNode localCheckNode = (CheckNode)localTreePath.getLastPathComponent();
        boolean bool = !localCheckNode.isSelected();
        localCheckNode.setSelected(bool);
        if (localCheckNode.getSelectionMode() == 4) {
          this.tree.expandPath(localTreePath);
        }
        ((DefaultTreeModel)this.tree.getModel()).nodeChanged(localCheckNode);
        if (k >= 0)
        {
          this.tree.revalidate();
          this.tree.repaint();
        }
      }
    }
  }
  
  class DestinationWizardAction
    implements ActionListener
  {
    DestinationWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsPermissionDialog.this.m_frame, GemsPermissionDialog.this.m_cn, GemsPermissionDialog.this.m_isQueue ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null) {
        GemsPermissionDialog.this.m_dest.setText(localGemsDestinationPicker.m_retDest.m_destName);
      }
    }
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPermissionDialog.this.m_cancelled = true;
      GemsPermissionDialog.this.dispose();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPermissionDialog.this.setPermissions();
      GemsPermissionDialog.this.dispose();
    }
  }
  
  class ApplyPressed
    implements ActionListener
  {
    ApplyPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPermissionDialog.this.setPermissions();
    }
  }
  
  class PrincipalSelected
    implements ActionListener
  {
    PrincipalSelected() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPermissionDialog.this.m_selected = ((String)GemsPermissionDialog.this.m_principal.getSelectedItem());
      GemsPermissionDialog.this.updatePermissions(false);
    }
  }
  
  class ResetPressed
    implements ActionListener
  {
    ResetPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPermissionDialog.this.updatePermissions(false);
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsPermissionDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */