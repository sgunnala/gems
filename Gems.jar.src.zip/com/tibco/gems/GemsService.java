package com.tibco.gems;

import java.util.Hashtable;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Topic;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;

public class GemsService
{
  public String m_name = null;
  public String m_reqDest = null;
  public String m_respDest = null;
  public long m_hits = 0L;
  public long m_responses = 0L;
  public long m_totalLatency = 0L;
  public long m_minLatency = 0L;
  public long m_maxLatency = 0L;
  public long m_faults = 0L;
  public long m_started = 0L;
  public long m_totalReqSize = 0L;
  public long m_minReqSize = 0L;
  public long m_maxReqSize = 0L;
  public long m_totalRespSize = 0L;
  public long m_minRespSize = 0L;
  public long m_maxRespSize = 0L;
  public long m_respLimit = 0L;
  public long m_overLimitCount = 0L;
  public long m_lastRequest = 0L;
  public boolean m_reqIsQueue = true;
  public boolean m_respIsQueue = true;
  protected TopicSubscriber m_reqsub = null;
  protected TopicSubscriber m_respsub = null;
  protected GemsServiceTable m_table = null;
  public Hashtable m_requests = new Hashtable();
  protected boolean m_useCache = true;
  protected int m_cacheIndex = 0;
  public Hashtable m_cacheResp = null;
  public cacheResp[] m_cacheRespArray = null;
  
  public GemsService(String paramString1, String paramString2, boolean paramBoolean1, String paramString3, boolean paramBoolean2, long paramLong, GemsServiceTable paramGemsServiceTable)
  {
    this.m_reqIsQueue = paramBoolean1;
    this.m_respIsQueue = paramBoolean2;
    this.m_respLimit = paramLong;
    if (this.m_useCache)
    {
      this.m_cacheResp = new Hashtable();
      this.m_cacheRespArray = new cacheResp['Ǵ'];
      this.m_cacheIndex = 0;
    }
    this.m_name = paramString1;
    if (paramBoolean1) {
      this.m_reqDest = ("$sys.monitor.q.r." + paramString2);
    } else {
      this.m_reqDest = ("$sys.monitor.t.r." + paramString2);
    }
    if ((paramString3 != null) && (paramString3.length() > 0)) {
      if (paramBoolean2) {
        this.m_respDest = ("$sys.monitor.q.r." + paramString3);
      } else {
        this.m_respDest = ("$sys.monitor.t.r." + paramString3);
      }
    }
    this.m_started = System.currentTimeMillis();
    this.m_table = paramGemsServiceTable;
    Gems.debug("GemsService: " + paramString1 + " " + this.m_reqDest + " " + this.m_respDest);
  }
  
  public synchronized void reset()
  {
    this.m_hits = 0L;
    this.m_responses = 0L;
    this.m_totalLatency = 0L;
    this.m_minLatency = 0L;
    this.m_maxLatency = 0L;
    this.m_faults = 0L;
    this.m_totalReqSize = 0L;
    this.m_minReqSize = 0L;
    this.m_maxReqSize = 0L;
    this.m_totalRespSize = 0L;
    this.m_minRespSize = 0L;
    this.m_maxRespSize = 0L;
    this.m_overLimitCount = 0L;
    this.m_lastRequest = 0L;
    this.m_started = System.currentTimeMillis();
    this.m_requests.clear();
    this.m_cacheResp.clear();
  }
  
  public synchronized void addToCache(String paramString, long paramLong)
  {
    cacheResp localcacheResp1 = this.m_cacheRespArray[this.m_cacheIndex];
    if (localcacheResp1 != null)
    {
      cacheResp localcacheResp2 = null;
      if ((localcacheResp1.m_cid != null) && (localcacheResp1.m_cid.length() > 0)) {
        localcacheResp2 = (cacheResp)this.m_cacheResp.remove(localcacheResp1.m_cid);
      }
      if (localcacheResp2 != null) {
        Gems.debug("GemsService.addToCache: Warning cache full, removed:  " + localcacheResp2.m_cid + " " + localcacheResp2.m_timestamp + " " + this.m_cacheIndex);
      }
    }
    this.m_cacheRespArray[this.m_cacheIndex] = new cacheResp(paramString, paramLong);
    this.m_cacheResp.put(paramString, this.m_cacheRespArray[this.m_cacheIndex]);
    if (++this.m_cacheIndex >= this.m_cacheRespArray.length) {
      this.m_cacheIndex = 0;
    }
  }
  
  public synchronized void newRequest(long paramLong1, long paramLong2)
  {
    this.m_hits += 1L;
    if (paramLong2 < this.m_minReqSize) {
      this.m_minReqSize = paramLong2;
    }
    if (paramLong2 > this.m_maxReqSize) {
      this.m_maxReqSize = paramLong2;
    }
    this.m_totalReqSize += paramLong2;
    this.m_lastRequest = paramLong1;
  }
  
  public synchronized void newResponse(long paramLong1, long paramLong2, long paramLong3)
  {
    if (paramLong2 < paramLong1)
    {
      Gems.debug("GemsService:newResponse: Error response timestamp before request");
      return;
    }
    long l = paramLong2 - paramLong1;
    this.m_responses += 1L;
    if (l < this.m_minLatency) {
      this.m_minLatency = l;
    }
    if (l > this.m_maxLatency) {
      this.m_maxLatency = l;
    }
    this.m_totalLatency += l;
    if (paramLong3 < this.m_minRespSize) {
      this.m_minRespSize = paramLong3;
    }
    if (paramLong3 > this.m_maxRespSize) {
      this.m_maxRespSize = paramLong3;
    }
    this.m_totalRespSize += paramLong3;
    if (l > this.m_respLimit) {
      this.m_overLimitCount += 1L;
    }
  }
  
  public synchronized void start(TopicSession paramTopicSession1, TopicSession paramTopicSession2)
  {
    try
    {
      Gems.debug("GemsService:start " + this.m_name);
      Topic localTopic = paramTopicSession1.createTopic(this.m_reqDest);
      this.m_reqsub = paramTopicSession1.createSubscriber(localTopic);
      this.m_reqsub.setMessageListener(new OnReqMessage());
      if ((this.m_respDest != null) && (this.m_respDest.length() > 0))
      {
        localTopic = paramTopicSession1.createTopic(this.m_respDest);
        this.m_respsub = paramTopicSession1.createSubscriber(localTopic);
        this.m_respsub.setMessageListener(new OnRespMessage());
      }
    }
    catch (Exception localException)
    {
      Gems.debug("GemsService.start: Exception: " + localException.getMessage());
    }
  }
  
  public synchronized void stop()
  {
    try
    {
      if (this.m_reqsub != null)
      {
        this.m_reqsub.close();
        this.m_reqsub = null;
      }
      if (this.m_respsub != null)
      {
        this.m_respsub.close();
        this.m_respsub = null;
      }
    }
    catch (Exception localException)
    {
      Gems.debug("GemsService.stop: Exception: " + localException.getMessage());
    }
  }
  
  class OnRespMessage
    implements MessageListener
  {
    OnRespMessage() {}
    
    public void onMessage(Message paramMessage)
    {
      try
      {
        String str = paramMessage.getStringProperty("msg_correlation_id");
        if ((str == null) || (str.length() == 0))
        {
          Gems.debug("GemsService.onRespMessage: No correlationID ");
          return;
        }
        long l = paramMessage.getLongProperty("msg_timestamp");
        Long localLong = (Long)GemsService.this.m_requests.remove(str);
        if (localLong == null)
        {
          if (GemsService.this.m_useCache)
          {
            GemsService.this.addToCache(str, l);
            return;
          }
          Gems.debug("GemsService.onRespMessage: No request found for CID: " + str);
        }
        GemsService.this.newResponse(localLong.longValue(), l, 0L);
      }
      catch (JMSException localJMSException) {}catch (NumberFormatException localNumberFormatException) {}
    }
  }
  
  class OnReqMessage
    implements MessageListener
  {
    OnReqMessage() {}
    
    public void onMessage(Message paramMessage)
    {
      try
      {
        if (!paramMessage.propertyExists("msg_timestamp"))
        {
          Gems.debug("GemsService.onReqMessage: No msg_timestamp!");
          return;
        }
        long l = paramMessage.getLongProperty("msg_timestamp");
        Object localObject1 = paramMessage.getStringProperty("msg_correlation_id");
        String str = paramMessage.getStringProperty("replyTo");
        if ((str == null) || (str.length() == 0))
        {
          Gems.debug("GemsServiceTable.onReqMessage: No replyTo");
          return;
        }
        Object localObject2;
        if (str.startsWith("$TMP$"))
        {
          if ((localObject1 == null) || (((String)localObject1).length() == 0)) {
            localObject1 = str;
          }
          GemsService.this.m_table.m_mutex.acquire();
          if (GemsService.this.m_table.m_useCache)
          {
            localObject2 = (GemsServiceTable.cacheResp)GemsService.this.m_table.m_cacheResp.remove(localObject1);
            if ((localObject2 == null) && (localObject1 != str)) {
              localObject2 = (GemsServiceTable.cacheResp)GemsService.this.m_table.m_cacheResp.remove(str);
            }
            if (localObject2 != null)
            {
              GemsService.this.newRequest(l, 0L);
              GemsService.this.newResponse(l, ((GemsServiceTable.cacheResp)localObject2).m_timestamp, 0L);
              GemsService.this.m_table.m_mutex.release();
              return;
            }
          }
          GemsService.this.m_table.newSyncRequest(GemsService.this, (String)localObject1, l);
          GemsService.this.newRequest(l, 0L);
          GemsService.this.m_table.m_mutex.release();
        }
        else
        {
          if ((localObject1 == null) || (((String)localObject1).length() == 0))
          {
            localObject2 = paramMessage.getStringProperty("msg_id");
            Gems.debug("GemsServiceTable.onReqMessage: No correlationId using MsgId");
            if ((localObject2 != null) && (((String)localObject2).length() > 0))
            {
              localObject1 = localObject2;
            }
            else
            {
              Gems.debug("GemsServiceTable.onReqMessage: No correlationId or MsgId");
              return;
            }
          }
          if (GemsService.this.m_useCache)
          {
            localObject2 = (GemsService.cacheResp)GemsService.this.m_cacheResp.remove(localObject1);
            if (localObject2 == null) {
              localObject2 = (GemsService.cacheResp)GemsService.this.m_cacheResp.remove(localObject1);
            }
            if (localObject2 != null)
            {
              GemsService.this.newRequest(l, 0L);
              GemsService.this.newResponse(l, ((GemsService.cacheResp)localObject2).m_timestamp, 0L);
              return;
            }
          }
          GemsService.this.m_requests.put(localObject1, new Long(l));
          GemsService.this.newRequest(l, 0L);
        }
      }
      catch (JMSException localJMSException)
      {
        Gems.debug("GemsService.onReqMessage: Exception: " + localJMSException.toString());
      }
      catch (NumberFormatException localNumberFormatException)
      {
        Gems.debug("GemsService.onReqMessage: Exception: " + localNumberFormatException.toString());
      }
      catch (InterruptedException localInterruptedException)
      {
        Gems.debug("GemsService.onReqMessage: Exception: " + localInterruptedException.toString());
      }
      GemsService.this.m_table.m_mutex.release();
    }
  }
  
  class cacheResp
  {
    String m_cid;
    long m_timestamp;
    
    public cacheResp(String paramString, long paramLong)
    {
      this.m_timestamp = paramLong;
      this.m_cid = paramString;
    }
  }
  
  class request
  {
    long m_timestamp;
    String m_cid;
    
    public request(long paramLong, String paramString)
    {
      this.m_timestamp = paramLong;
      this.m_cid = paramString;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */