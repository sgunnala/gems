package com.tibco.gems;

import com.tibco.tibjms.admin.ServerInfo;
import java.awt.Color;
import java.awt.Component;
import java.io.PrintStream;
import java.util.Enumeration;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.tree.DefaultMutableTreeNode;

public class GemsServerMonitorTableModel
  extends DefaultTableModel
{
  JTable m_table;
  MyRenderer m_renderer = new MyRenderer();
  Object m_obj = new Object();
  long[] totals = new long[17];
  String[] m_colPositions = null;
  final int MAX_COLS = 21;
  static String[] cols = { "Alias", "State", "ServerName", "BackupName", "Connections", "Sessions", "Queues", "Topics", "Durables", "PendingMsgs", "PendingMsgSize", "MsgMem", "InMsgCount", "InMsgRate", "OutMsgCount", "OutMsgRate", "DiskReadRate", "DiskWriteRate", "AsyncDBSize", "SyncDBSize" };
  static String[] cols1 = { "Alias", "State", "ServerName", "BackupName", "Events", "Connections", "Sessions", "Queues", "Topics", "Durables", "PendingMsgs", "PendingMsgSize", "MsgMem", "InMsgCount", "InMsgRate", "OutMsgCount", "OutMsgRate", "DiskReadRate", "DiskWriteRate", "AsyncDBSize", "SyncDBSize" };
  
  public GemsServerMonitorTableModel()
  {
    initColumnPositions();
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }
  
  public String getSelectedCol1()
  {
    if (this.m_table.getSelectedRow() < 0) {
      return null;
    }
    Object localObject = this.m_table.getValueAt(this.m_table.getSelectedRow(), 0);
    if ((localObject instanceof CellValue)) {
      return ((CellValue)localObject).m_cellValue;
    }
    return null;
  }
  
  public boolean populateTable(DefaultMutableTreeNode paramDefaultMutableTreeNode, boolean paramBoolean1, boolean paramBoolean2)
  {
    setRowCount(0);
    for (int i = 0; i < 17; i++) {
      this.totals[i] = 0L;
    }
    i = cols.length;
    if (paramBoolean2) {
      i++;
    }
    if (getColumnCount() != i)
    {
      setColumnCount(0);
      this.m_table.setAutoResizeMode(0);
      this.m_table.setDefaultRenderer(this.m_obj.getClass(), this.m_renderer);
      if (paramBoolean2) {
        setColumnIdentifiers(cols1);
      } else {
        setColumnIdentifiers(cols);
      }
      this.m_table.getColumn("Alias").setPreferredWidth(100);
      this.m_table.getColumn("ServerName").setPreferredWidth(100);
      this.m_table.getColumn("BackupName").setPreferredWidth(100);
      this.m_table.getColumn("State").setPreferredWidth(65);
      this.m_table.getColumn("PendingMsgs").setPreferredWidth(80);
      this.m_table.getColumn("PendingMsgSize").setPreferredWidth(100);
      this.m_table.getColumn("InMsgRate").setPreferredWidth(70);
      this.m_table.getColumn("OutMsgRate").setPreferredWidth(80);
      this.m_table.getColumn("InMsgCount").setPreferredWidth(80);
      this.m_table.getColumn("OutMsgCount").setPreferredWidth(80);
      this.m_table.getColumn("MsgMem").setPreferredWidth(70);
      this.m_table.getColumn("Topics").setPreferredWidth(50);
      this.m_table.getColumn("Queues").setPreferredWidth(55);
      this.m_table.getColumn("Durables").setPreferredWidth(60);
      this.m_table.getColumn("Sessions").setPreferredWidth(60);
      this.m_table.getColumn("Connections").setPreferredWidth(80);
      this.m_table.getColumn("DiskReadRate").setPreferredWidth(90);
      this.m_table.getColumn("DiskWriteRate").setPreferredWidth(90);
      if (paramBoolean2) {
        this.m_table.getColumn("Events").setPreferredWidth(55);
      }
    }
    if (paramDefaultMutableTreeNode != null)
    {
      boolean bool = findServers(paramDefaultMutableTreeNode, false, paramBoolean2);
      if (this.m_table.getRowCount() == 0) {
        return true;
      }
      if (Gems.getGems().getShowTotals())
      {
        String[] arrayOfString;
        if (paramBoolean2)
        {
          arrayOfString = new String[] { new String("Total"), new String(""), new String(""), new String(""), new String(String.valueOf(this.totals[0])), new String(String.valueOf(this.totals[1])), new String(String.valueOf(this.totals[2])), new String(String.valueOf(this.totals[3])), new String(String.valueOf(this.totals[4])), new String(String.valueOf(this.totals[5])), new String(String.valueOf(this.totals[6])), new String(StringUtilities.getHumanReadableSize(this.totals[7])), new String(StringUtilities.getHumanReadableSize(this.totals[8])), new String(String.valueOf(this.totals[11])), new String(String.valueOf(this.totals[12])), new String(String.valueOf(this.totals[13])), new String(String.valueOf(this.totals[14])), new String(StringUtilities.getHumanReadableSize(this.totals[15])), new String(StringUtilities.getHumanReadableSize(this.totals[16])), new String(StringUtilities.getHumanReadableSize(this.totals[9])), new String(StringUtilities.getHumanReadableSize(this.totals[10])) };
          addRow(arrayOfString);
        }
        else
        {
          arrayOfString = new String[] { new String("Total"), new String(""), new String(""), new String(""), new String(String.valueOf(this.totals[1])), new String(String.valueOf(this.totals[2])), new String(String.valueOf(this.totals[3])), new String(String.valueOf(this.totals[4])), new String(String.valueOf(this.totals[5])), new String(String.valueOf(this.totals[6])), new String(StringUtilities.getHumanReadableSize(this.totals[7])), new String(StringUtilities.getHumanReadableSize(this.totals[8])), new String(String.valueOf(this.totals[11])), new String(String.valueOf(this.totals[12])), new String(String.valueOf(this.totals[13])), new String(String.valueOf(this.totals[14])), new String(StringUtilities.getHumanReadableSize(this.totals[15])), new String(StringUtilities.getHumanReadableSize(this.totals[16])), new String(StringUtilities.getHumanReadableSize(this.totals[9])), new String(StringUtilities.getHumanReadableSize(this.totals[10])) };
          addRow(arrayOfString);
        }
      }
      setupColumnPositions();
      return bool;
    }
    return false;
  }
  
  public void setupColumnPositions()
  {
    if (this.m_colPositions == null) {
      return;
    }
    for (int i = 0; i < 21; i++) {
      if (this.m_colPositions[i] != null)
      {
        int j = this.m_table.getColumnModel().getColumnIndex(this.m_colPositions[i]);
        this.m_table.moveColumn(j, i);
      }
    }
  }
  
  public void initColumnPositions()
  {
    String str1 = Gems.getGems().getServerInfoColPositions();
    if ((str1 == null) || (str1.length() == 0)) {
      return;
    }
    this.m_colPositions = new String[21];
    for (int i = 0; i < 21; i++) {
      this.m_colPositions[i] = null;
    }
    String[] arrayOfString = str1.split(",");
    for (int j = 0; j < arrayOfString.length; j++) {
      try
      {
        int k = arrayOfString[j].indexOf(':');
        if (k > 0)
        {
          String str2 = arrayOfString[j].substring(0, k);
          String str3 = arrayOfString[j].substring(k + 1);
          int m = Integer.valueOf(str3).intValue();
          if ((m != 0) && (str2.equals("Alias"))) {
            continue;
          }
          if (m >= 21) {
            m = 20;
          }
          this.m_colPositions[m] = str2;
        }
      }
      catch (NumberFormatException localNumberFormatException)
      {
        System.err.println("NumberFormatException: " + localNumberFormatException.getMessage());
        return;
      }
    }
  }
  
  public boolean findServers(DefaultMutableTreeNode paramDefaultMutableTreeNode, boolean paramBoolean1, boolean paramBoolean2)
  {
    boolean bool = false;
    Enumeration localEnumeration = paramDefaultMutableTreeNode.children();
    if (localEnumeration != null) {
      while (localEnumeration.hasMoreElements())
      {
        DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localEnumeration.nextElement();
        if (localDefaultMutableTreeNode == null) {
          return bool;
        }
        if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
        {
          GemsConnectionNode localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
          if (paramBoolean1)
          {
            if ((!localGemsConnectionNode.isConnected()) && (localGemsConnectionNode.isAutoConnect()))
            {
              localGemsConnectionNode.connect();
              bool = true;
            }
            else if (localGemsConnectionNode.getJmsServerInfo(true) == null)
            {
              bool = true;
            }
          }
          else
          {
            ServerInfo localServerInfo = localGemsConnectionNode.getJmsServerInfo(false);
            populateServer((String)localDefaultMutableTreeNode.getUserObject(), localServerInfo, localGemsConnectionNode, paramBoolean2);
          }
        }
        if (findServers(localDefaultMutableTreeNode, paramBoolean1, paramBoolean2)) {
          bool = true;
        }
      }
    }
    return bool;
  }
  
  public void populateServer(String paramString, ServerInfo paramServerInfo, GemsConnectionNode paramGemsConnectionNode, boolean paramBoolean)
  {
    CellValue[] arrayOfCellValue;
    if (paramServerInfo == null)
    {
      if (paramBoolean) {
        arrayOfCellValue = new CellValue[] { new CellValue(paramString), new CellValue("Unknown", -1), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue("") };
      } else {
        arrayOfCellValue = new CellValue[] { new CellValue(paramString), new CellValue("Unknown", -1), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue(""), new CellValue("") };
      }
      addRow(arrayOfCellValue);
      return;
    }
    try
    {
      boolean bool = paramGemsConnectionNode.isFtUrl();
      String str = "?";
      long l = 0L;
      try
      {
        str = String.valueOf(paramServerInfo.getSessionCount());
        l = paramServerInfo.getSessionCount();
      }
      catch (Throwable localThrowable) {}
      if (!paramBoolean)
      {
        arrayOfCellValue = new CellValue[] { new CellValue(paramString), new CellValue(paramServerInfo.getState() == 4 ? "Active" : "Standby", -1), new CellValue(paramServerInfo.getServerName()), new CellValue((bool) && (paramServerInfo.getState() == 4) && (paramServerInfo.getBackupName() == null) ? "Disconnected" : paramServerInfo.getBackupName(), -2), new CellValue(String.valueOf(paramServerInfo.getConnectionCount()), paramServerInfo.getConnectionCount(), paramGemsConnectionNode.getWarnLimit("Connections"), paramGemsConnectionNode.getErrorLimit("Connections")), new CellValue(str, l, paramGemsConnectionNode.getWarnLimit("Sessions"), paramGemsConnectionNode.getErrorLimit("Sessions")), new CellValue(String.valueOf(paramServerInfo.getQueueCount()), paramServerInfo.getQueueCount(), paramGemsConnectionNode.getWarnLimit("Queues"), paramGemsConnectionNode.getErrorLimit("Queues")), new CellValue(String.valueOf(paramServerInfo.getTopicCount()), paramServerInfo.getTopicCount(), paramGemsConnectionNode.getWarnLimit("Topics"), paramGemsConnectionNode.getErrorLimit("Topics")), new CellValue(String.valueOf(paramServerInfo.getDurableCount()), paramServerInfo.getDurableCount(), paramGemsConnectionNode.getWarnLimit("Durables"), paramGemsConnectionNode.getErrorLimit("Durables")), new CellValue(String.valueOf(paramServerInfo.getPendingMessageCount()), paramServerInfo.getPendingMessageCount(), paramGemsConnectionNode.getWarnLimit("PendingMsgs"), paramGemsConnectionNode.getErrorLimit("PendingMsgs")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getPendingMessageSize()), paramServerInfo.getPendingMessageSize(), paramGemsConnectionNode.getWarnLimit("PendingMsgSize"), paramGemsConnectionNode.getErrorLimit("PendingMsgSize")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getMsgMem()), paramServerInfo.getMsgMem(), paramGemsConnectionNode.getWarnLimit("MsgMem"), paramGemsConnectionNode.getErrorLimit("MsgMem")), new CellValue(String.valueOf(paramServerInfo.getInboundMessageCount()), paramServerInfo.getInboundMessageCount(), paramGemsConnectionNode.getWarnLimit("InMsgCount"), paramGemsConnectionNode.getErrorLimit("InMsgCount")), new CellValue(String.valueOf(paramServerInfo.getInboundMessageRate()), paramServerInfo.getInboundMessageRate(), paramGemsConnectionNode.getWarnLimit("InMsgRate"), paramGemsConnectionNode.getErrorLimit("InMsgRate")), new CellValue(String.valueOf(paramServerInfo.getOutboundMessageCount()), paramServerInfo.getOutboundMessageCount(), paramGemsConnectionNode.getWarnLimit("OutMsgCount"), paramGemsConnectionNode.getErrorLimit("OutMsgCount")), new CellValue(String.valueOf(paramServerInfo.getOutboundMessageRate()), paramServerInfo.getOutboundMessageRate(), paramGemsConnectionNode.getWarnLimit("OutMsgRate"), paramGemsConnectionNode.getErrorLimit("OutMsgRate")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getDiskReadRate()), paramServerInfo.getDiskReadRate(), paramGemsConnectionNode.getWarnLimit("DiskReadRate"), paramGemsConnectionNode.getErrorLimit("DiskReadRate")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getDiskWriteRate()), paramServerInfo.getDiskWriteRate(), paramGemsConnectionNode.getWarnLimit("DiskWriteRate"), paramGemsConnectionNode.getErrorLimit("DiskWriteRate")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getAsyncDBSize()), paramServerInfo.getAsyncDBSize(), paramGemsConnectionNode.getWarnLimit("AsyncDBSize"), paramGemsConnectionNode.getErrorLimit("AsyncDBSize")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getSyncDBSize()), paramServerInfo.getSyncDBSize(), paramGemsConnectionNode.getWarnLimit("SyncDBSize"), paramGemsConnectionNode.getErrorLimit("SyncDBSize")) };
      }
      else
      {
        this.totals[0] += paramGemsConnectionNode.getEventCount();
        Long localLong1 = paramGemsConnectionNode.getWarnLimit("Events");
        Long localLong2 = paramGemsConnectionNode.getErrorLimit("Events");
        arrayOfCellValue = new CellValue[] { new CellValue(paramString), new CellValue(paramServerInfo.getState() == 4 ? "Active" : "Standby", -1), new CellValue(paramServerInfo.getServerName()), new CellValue((bool) && (paramServerInfo.getState() == 4) && (paramServerInfo.getBackupName() == null) ? "Disconnected" : paramServerInfo.getBackupName(), -2), new CellValue(String.valueOf(paramGemsConnectionNode.getEventCount()), paramGemsConnectionNode.getEventCount(), localLong1 == null ? new Long(0L) : localLong1, localLong2 == null ? new Long(0L) : localLong2), new CellValue(String.valueOf(paramServerInfo.getConnectionCount()), paramServerInfo.getConnectionCount(), paramGemsConnectionNode.getWarnLimit("Connections"), paramGemsConnectionNode.getErrorLimit("Connections")), new CellValue(str, l, paramGemsConnectionNode.getWarnLimit("Sessions"), paramGemsConnectionNode.getErrorLimit("Sessions")), new CellValue(String.valueOf(paramServerInfo.getQueueCount()), paramServerInfo.getQueueCount(), paramGemsConnectionNode.getWarnLimit("Queues"), paramGemsConnectionNode.getErrorLimit("Queues")), new CellValue(String.valueOf(paramServerInfo.getTopicCount()), paramServerInfo.getTopicCount(), paramGemsConnectionNode.getWarnLimit("Topics"), paramGemsConnectionNode.getErrorLimit("Topics")), new CellValue(String.valueOf(paramServerInfo.getDurableCount()), paramServerInfo.getDurableCount(), paramGemsConnectionNode.getWarnLimit("Durables"), paramGemsConnectionNode.getErrorLimit("Durables")), new CellValue(String.valueOf(paramServerInfo.getPendingMessageCount()), paramServerInfo.getPendingMessageCount(), paramGemsConnectionNode.getWarnLimit("PendingMsgs"), paramGemsConnectionNode.getErrorLimit("PendingMsgs")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getPendingMessageSize()), paramServerInfo.getPendingMessageSize(), paramGemsConnectionNode.getWarnLimit("PendingMsgSize"), paramGemsConnectionNode.getErrorLimit("PendingMsgSize")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getMsgMem()), paramServerInfo.getMsgMem(), paramGemsConnectionNode.getWarnLimit("MsgMem"), paramGemsConnectionNode.getErrorLimit("MsgMem")), new CellValue(String.valueOf(paramServerInfo.getInboundMessageCount()), paramServerInfo.getInboundMessageCount(), paramGemsConnectionNode.getWarnLimit("InMsgCount"), paramGemsConnectionNode.getErrorLimit("InMsgCount")), new CellValue(String.valueOf(paramServerInfo.getInboundMessageRate()), paramServerInfo.getInboundMessageRate(), paramGemsConnectionNode.getWarnLimit("InMsgRate"), paramGemsConnectionNode.getErrorLimit("InMsgRate")), new CellValue(String.valueOf(paramServerInfo.getOutboundMessageCount()), paramServerInfo.getOutboundMessageCount(), paramGemsConnectionNode.getWarnLimit("OutMsgCount"), paramGemsConnectionNode.getErrorLimit("OutMsgCount")), new CellValue(String.valueOf(paramServerInfo.getOutboundMessageRate()), paramServerInfo.getOutboundMessageRate(), paramGemsConnectionNode.getWarnLimit("OutMsgRate"), paramGemsConnectionNode.getErrorLimit("OutMsgRate")), new CellValue(String.valueOf(paramServerInfo.getDiskReadRate()), paramServerInfo.getDiskReadRate(), paramGemsConnectionNode.getWarnLimit("DiskReadRate"), paramGemsConnectionNode.getErrorLimit("DiskReadRate")), new CellValue(String.valueOf(paramServerInfo.getDiskWriteRate()), paramServerInfo.getDiskWriteRate(), paramGemsConnectionNode.getWarnLimit("DiskWriteRate"), paramGemsConnectionNode.getErrorLimit("DiskWriteRate")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getAsyncDBSize()), paramServerInfo.getAsyncDBSize(), paramGemsConnectionNode.getWarnLimit("AsyncDBSize"), paramGemsConnectionNode.getErrorLimit("AsyncDBSize")), new CellValue(StringUtilities.getHumanReadableSize(paramServerInfo.getSyncDBSize()), paramServerInfo.getSyncDBSize(), paramGemsConnectionNode.getWarnLimit("SyncDBSize"), paramGemsConnectionNode.getErrorLimit("SyncDBSize")) };
      }
      if (Gems.getGems().getShowTotals())
      {
        this.totals[1] += paramServerInfo.getConnectionCount();
        this.totals[2] += l;
        this.totals[3] += paramServerInfo.getQueueCount();
        this.totals[4] += paramServerInfo.getTopicCount();
        this.totals[5] += paramServerInfo.getDurableCount();
        this.totals[6] += paramServerInfo.getPendingMessageCount();
        this.totals[7] += paramServerInfo.getPendingMessageSize();
        this.totals[8] += paramServerInfo.getMsgMem();
        this.totals[9] += paramServerInfo.getAsyncDBSize();
        this.totals[10] += paramServerInfo.getSyncDBSize();
        this.totals[11] += paramServerInfo.getInboundMessageCount();
        this.totals[12] += paramServerInfo.getInboundMessageRate();
        this.totals[13] += paramServerInfo.getOutboundMessageCount();
        this.totals[14] += paramServerInfo.getOutboundMessageRate();
        this.totals[15] += paramServerInfo.getDiskReadRate();
        this.totals[16] += paramServerInfo.getDiskWriteRate();
      }
      addRow(arrayOfCellValue);
    }
    catch (Exception localException)
    {
      System.err.println("JMSException: " + localException.getMessage());
      return;
    }
  }
  
  class MyRenderer
    extends DefaultTableCellRenderer
  {
    public MyRenderer() {}
    
    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      Component localComponent = super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
      localComponent.setForeground(Color.black);
      if ((paramObject instanceof CellValue))
      {
        CellValue localCellValue = (CellValue)paramObject;
        setText(localCellValue.toString());
        if (localCellValue.m_value < -2L)
        {
          setHorizontalAlignment(2);
          localComponent.setBackground(Color.white);
        }
        else if (localCellValue.m_value == -1L)
        {
          setHorizontalAlignment(2);
          if (localCellValue.m_cellValue.equals("Active")) {
            localComponent.setBackground(Color.green);
          } else if (localCellValue.m_cellValue.equals("Standby")) {
            localComponent.setBackground(Color.yellow);
          } else if (localCellValue.m_cellValue.equals("Unknown")) {
            localComponent.setBackground(Color.red);
          } else {
            localComponent.setBackground(Color.white);
          }
        }
        else if (localCellValue.m_value == -2L)
        {
          setHorizontalAlignment(2);
          localComponent.setBackground(Color.white);
          if ((localCellValue.m_cellValue != null) && (localCellValue.m_cellValue.equals("Disconnected"))) {
            localComponent.setBackground(Color.red);
          }
        }
        else
        {
          setHorizontalAlignment(4);
          if ((localCellValue.m_errorLimit != null) && (localCellValue.m_value > localCellValue.m_errorLimit.longValue())) {
            localComponent.setBackground(Color.red);
          } else if ((localCellValue.m_warnLimit != null) && (localCellValue.m_value > localCellValue.m_warnLimit.longValue())) {
            localComponent.setBackground(Color.orange);
          } else {
            localComponent.setBackground(Color.white);
          }
        }
      }
      else if ((paramObject instanceof String))
      {
        if (paramInt2 > 3) {
          setHorizontalAlignment(4);
        } else {
          setHorizontalAlignment(2);
        }
        localComponent.setBackground(Color.cyan);
      }
      return localComponent;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsServerMonitorTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */