package com.tibco.gems;

import java.lang.reflect.Method;

public class Property
{
  private String name;
  private Method setter;
  private Method getter;
  private boolean readable;
  private boolean writeable;
  private String classType;
  
  public Property() {}
  
  public Property(String paramString1, String paramString2, Method paramMethod1, Method paramMethod2)
  {
    this.name = paramString1;
    this.classType = paramString2;
    this.setter = paramMethod1;
    this.getter = paramMethod2;
    if (paramMethod1 != null) {
      this.writeable = true;
    } else {
      this.writeable = false;
    }
    if (paramMethod2 != null) {
      this.readable = true;
    } else {
      this.readable = false;
    }
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String paramString)
  {
    this.name = paramString;
  }
  
  public Method getSetter()
  {
    return this.setter;
  }
  
  public void setSetter(Method paramMethod)
  {
    this.setter = paramMethod;
    if (paramMethod != null) {
      this.writeable = true;
    }
  }
  
  public Method getGetter()
  {
    return this.getter;
  }
  
  public void setGetter(Method paramMethod)
  {
    this.getter = paramMethod;
    if (paramMethod != null) {
      this.readable = true;
    }
  }
  
  public boolean isReadable()
  {
    return this.readable;
  }
  
  public void setReadable(boolean paramBoolean)
  {
    this.readable = paramBoolean;
  }
  
  public boolean isWriteable()
  {
    return this.writeable;
  }
  
  public void setWriteable(boolean paramBoolean)
  {
    this.writeable = paramBoolean;
  }
  
  public String getClassType()
  {
    return this.classType;
  }
  
  public void setClassType(String paramString)
  {
    this.classType = paramString;
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer("Property(").append(this.name).append(": ");
    localStringBuffer.append(this.classType).append(") -> ");
    if (this.readable) {
      localStringBuffer.append("getter: ").append(this.getter.getName());
    }
    if (this.writeable) {
      localStringBuffer.append(", setter: ").append(this.setter.getName());
    }
    return localStringBuffer.toString();
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\Property.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */