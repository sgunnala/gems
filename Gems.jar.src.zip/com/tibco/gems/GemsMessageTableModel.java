package com.tibco.gems;

import com.tibco.tibjms.Tibjms;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.QueueBrowser;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class GemsMessageTableModel
  extends DefaultTableModel
  implements GetPopupHandler
{
  JTable m_table;
  Hashtable m_msgs = new Hashtable();
  Hashtable m_replymsgs = null;
  boolean m_isEditable;
  public boolean m_showCheckbox = false;
  public boolean m_showEvents = false;
  public boolean m_monitor = false;
  static long s_msgId = 0L;
  Object m_obj = new Object();
  PopupHandler m_popup = null;
  MyRenderer m_renderer = null;
  MyCheckboxRenderer m_checkRenderer = new MyCheckboxRenderer();
  SimpleDateFormat dateFormatMillis = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
  
  public GemsMessageTableModel(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.m_isEditable = paramBoolean1;
    this.m_showCheckbox = paramBoolean2;
    this.m_renderer = new MyRenderer();
  }
  
  public PopupHandler getPopupHandler()
  {
    if (this.m_popup == null) {
      this.m_popup = new PopupMsgTableHandler(this.m_table, this);
    }
    return this.m_popup;
  }
  
  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject != null) {
      return localObject.getClass();
    }
    return String.class;
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    if ((this.m_showCheckbox) && (paramInt2 < 1)) {
      return true;
    }
    return this.m_isEditable;
  }
  
  public Message getSelectedMessage()
  {
    if (this.m_msgs == null) {
      return null;
    }
    if (this.m_table.getSelectedRow() < 0) {
      return null;
    }
    if (this.m_showCheckbox) {
      return (Message)this.m_msgs.get((String)this.m_table.getValueAt(this.m_table.getSelectedRow(), 1));
    }
    return (Message)this.m_msgs.get((String)this.m_table.getValueAt(this.m_table.getSelectedRow(), 0));
  }
  
  public Message getSelectedReplyMessage()
  {
    if (this.m_replymsgs == null) {
      return null;
    }
    if (this.m_table.getSelectedRow() < 0) {
      return null;
    }
    Message localMessage = null;
    String str = (String)this.m_table.getValueAt(this.m_table.getSelectedRow(), 4);
    if (str != null) {
      localMessage = (Message)this.m_replymsgs.get(str);
    }
    if (localMessage == null)
    {
      str = (String)this.m_table.getValueAt(this.m_table.getSelectedRow(), 5);
      if (str != null) {
        localMessage = (Message)this.m_replymsgs.get(str);
      }
    }
    return localMessage;
  }
  
  public Message getMessageAt(int paramInt)
  {
    if (this.m_msgs == null) {
      return null;
    }
    if (this.m_showCheckbox) {
      return (Message)this.m_msgs.get((String)this.m_table.getValueAt(paramInt, 1));
    }
    return (Message)this.m_msgs.get((String)this.m_table.getValueAt(paramInt, 0));
  }
  
  public Message getReplyMessageAt(int paramInt)
  {
    if (this.m_replymsgs == null) {
      return null;
    }
    Message localMessage = null;
    String str = (String)this.m_table.getValueAt(paramInt, 4);
    if (str != null) {
      localMessage = (Message)this.m_replymsgs.get(str);
    }
    if (localMessage == null)
    {
      str = (String)this.m_table.getValueAt(paramInt, 5);
      if (str != null) {
        localMessage = (Message)this.m_replymsgs.get(str);
      }
    }
    return localMessage;
  }
  
  public Message getReplyMessageFor(String paramString)
  {
    if (this.m_replymsgs == null) {
      return null;
    }
    Message localMessage = null;
    if (paramString != null) {
      localMessage = (Message)this.m_replymsgs.get(paramString);
    }
    return localMessage;
  }
  
  public Message getNextPendingRequest(boolean paramBoolean)
  {
    if (this.m_msgs == null) {
      return null;
    }
    int i;
    String str;
    if (paramBoolean) {
      for (i = 0; i < this.m_table.getRowCount(); i++)
      {
        str = (String)this.m_table.getValueAt(i, 2);
        if (str.startsWith("pending")) {
          return (Message)this.m_msgs.get((String)this.m_table.getValueAt(i, 0));
        }
      }
    } else {
      for (i = this.m_table.getRowCount() - 1; i >= 0; i--)
      {
        str = (String)this.m_table.getValueAt(i, 2);
        if (str.startsWith("pending")) {
          return (Message)this.m_msgs.get((String)this.m_table.getValueAt(i, 0));
        }
      }
    }
    return null;
  }
  
  public Vector getSelectedMessages()
  {
    Vector localVector = new Vector();
    if (this.m_showCheckbox) {
      for (int i = 0; i < getRowCount(); i++) {
        if (((Boolean)this.m_table.getValueAt(i, 0)).booleanValue()) {
          localVector.add(this.m_msgs.get((String)this.m_table.getValueAt(i, 1)));
        }
      }
    }
    return localVector;
  }
  
  public void selectAllRows()
  {
    if (this.m_showCheckbox) {
      for (int i = 0; i < getRowCount(); i++) {
        this.m_table.setValueAt(new Boolean(true), i, 0);
      }
    }
  }
  
  public void toggleSelectedRow()
  {
    this.m_table.setValueAt(new Boolean(!((Boolean)this.m_table.getValueAt(this.m_table.getSelectedRow(), 0)).booleanValue()), this.m_table.getSelectedRow(), 0);
  }
  
  public void buildColumnHeaders()
  {
    setRowCount(0);
    setColumnCount(0);
    this.m_msgs.clear();
    this.m_table.setAutoResizeMode(0);
    this.m_table.setDefaultRenderer(Object.class, this.m_renderer);
    this.m_table.setDefaultRenderer(String.class, this.m_renderer);
    this.m_table.setDefaultRenderer(Date.class, this.m_renderer);
    this.m_table.setDefaultRenderer(Boolean.class, this.m_checkRenderer);
    String[] arrayOfString;
    if (this.m_showCheckbox) {
      arrayOfString = new String[] { "Sel", "MessageID", "Timestamp", "Type", "MsgSize", "Destination", "CorrelationID", "DeliveryMode" };
    } else {
      arrayOfString = new String[] { "MessageID", "Timestamp", "Type", "MsgSize", "Destination", "CorrelationID", "DeliveryMode" };
    }
    setColumnIdentifiers(arrayOfString);
    if (this.m_showCheckbox) {
      this.m_table.getColumn("Sel").setPreferredWidth(30);
    }
    this.m_table.getColumn("MessageID").setPreferredWidth(220);
    this.m_table.getColumn("Destination").setPreferredWidth(150);
    this.m_table.getColumn("DeliveryMode").setPreferredWidth(100);
    this.m_table.getColumn("CorrelationID").setPreferredWidth(100);
    this.m_table.getColumn("Timestamp").setPreferredWidth(200);
  }
  
  public void buildRequestReplyColumnHeaders()
  {
    setRowCount(0);
    setColumnCount(0);
    this.m_msgs.clear();
    if (this.m_replymsgs == null) {
      this.m_replymsgs = new Hashtable();
    }
    this.m_replymsgs.clear();
    this.m_table.setAutoResizeMode(0);
    this.m_table.setDefaultRenderer(Object.class, this.m_renderer);
    this.m_table.setDefaultRenderer(String.class, this.m_renderer);
    this.m_table.setDefaultRenderer(Date.class, this.m_renderer);
    this.m_table.setDefaultRenderer(Boolean.class, this.m_checkRenderer);
    String[] arrayOfString = { "RequestMessageID", "Timestamp", "ResponseTime(ms)", "Destination", "CorrelationID", "ReplyTo", "ReqMsgSize", "ReplyMsgSize" };
    setColumnIdentifiers(arrayOfString);
    if (this.m_showCheckbox) {
      this.m_table.getColumn("").setPreferredWidth(30);
    }
    this.m_table.getColumn("RequestMessageID").setPreferredWidth(220);
    this.m_table.getColumn("Destination").setPreferredWidth(150);
    this.m_table.getColumn("ReplyTo").setPreferredWidth(150);
    this.m_table.getColumn("ReplyMsgSize").setPreferredWidth(100);
    this.m_table.getColumn("ResponseTime(ms)").setPreferredWidth(120);
    this.m_table.getColumn("CorrelationID").setPreferredWidth(100);
    this.m_table.getColumn("Timestamp").setPreferredWidth(200);
  }
  
  public void buildMonitorColumnHeaders(boolean paramBoolean)
  {
    this.m_monitor = true;
    setRowCount(0);
    setColumnCount(0);
    this.m_msgs.clear();
    this.m_table.setAutoResizeMode(0);
    this.m_table.setDefaultRenderer(this.m_obj.getClass(), this.m_renderer);
    this.m_table.setDefaultRenderer(Date.class, this.m_renderer);
    String[] arrayOfString;
    if (paramBoolean) {
      arrayOfString = new String[] { "MessageID", "Timestamp", "EventAction", "EventReason", "ConnHostname", "ConnUsername", "TargetDestination" };
    } else {
      arrayOfString = new String[] { "MessageID", "Timestamp", "EventAction", "EventReason", "ConnHostname", "ConnUsername" };
    }
    setColumnIdentifiers(arrayOfString);
    this.m_table.getColumn("MessageID").setPreferredWidth(100);
    if (paramBoolean) {
      this.m_table.getColumn("TargetDestination").setPreferredWidth(200);
    }
    this.m_table.getColumn("ConnHostname").setPreferredWidth(120);
    this.m_table.getColumn("ConnUsername").setPreferredWidth(120);
    this.m_table.getColumn("EventAction").setPreferredWidth(90);
    this.m_table.getColumn("EventReason").setPreferredWidth(90);
    this.m_table.getColumn("Timestamp").setPreferredWidth(180);
  }
  
  public void buildEventColumnHeaders()
  {
    this.m_showEvents = true;
    setRowCount(0);
    this.m_msgs.clear();
    this.m_table.setAutoResizeMode(0);
    this.m_table.setDefaultRenderer(this.m_obj.getClass(), this.m_renderer);
    this.m_table.setDefaultRenderer(Date.class, this.m_renderer);
    String[] arrayOfString = { "MessageID", "Timestamp", "EventType", "EventReason", "ConnHostname", "ConnUsername", "TargetDestination" };
    if ((getColumnCount() != 7) || (!getColumnName(2).equals("EventType")))
    {
      setColumnCount(0);
      setColumnIdentifiers(arrayOfString);
      this.m_table.getColumn("MessageID").setPreferredWidth(100);
      this.m_table.getColumn("TargetDestination").setPreferredWidth(200);
      this.m_table.getColumn("ConnHostname").setPreferredWidth(120);
      this.m_table.getColumn("ConnUsername").setPreferredWidth(120);
      this.m_table.getColumn("EventType").setPreferredWidth(100);
      this.m_table.getColumn("EventReason").setPreferredWidth(120);
      this.m_table.getColumn("Timestamp").setPreferredWidth(180);
    }
  }
  
  public void addMessage(Message paramMessage, boolean paramBoolean)
  {
    Date localDate = new Date();
    try
    {
      if (paramMessage != null)
      {
        if (paramMessage.getJMSMessageID() == null) {
          paramMessage.setJMSMessageID("tmpId" + String.valueOf(++s_msgId));
        }
        this.m_msgs.put(paramMessage.getJMSMessageID(), paramMessage);
        String str1 = paramMessage.getJMSDeliveryMode() == 1 ? "NON_PERSISTENT" : paramMessage.getJMSDeliveryMode() == 2 ? "PERSISTENT" : "RELIABLE";
        String str2 = paramMessage.getJMSType();
        if ((str2 == null) || (str2.length() == 0)) {
          if ((paramMessage instanceof TextMessage)) {
            str2 = "[Text]";
          } else if ((paramMessage instanceof MapMessage)) {
            str2 = "[Map]";
          } else if ((paramMessage instanceof BytesMessage)) {
            str2 = "[Bytes]";
          } else if ((paramMessage instanceof StreamMessage)) {
            str2 = "[Stream]";
          } else if ((paramMessage instanceof ObjectMessage)) {
            str2 = "[Object]";
          } else {
            str2 = "";
          }
        }
        localDate.setTime(paramMessage.getJMSTimestamp());
        Object[] arrayOfObject;
        if (this.m_showCheckbox) {
          arrayOfObject = new Object[] { new Boolean(false), paramMessage.getJMSMessageID(), localDate, str2, StringUtilities.getHumanReadableSize(Tibjms.getMessageSize(paramMessage)), paramMessage.getJMSDestination().toString(), paramMessage.getJMSCorrelationID(), str1 };
        } else {
          arrayOfObject = new Object[] { paramMessage.getJMSMessageID(), localDate, str2, StringUtilities.getHumanReadableSize(Tibjms.getMessageSize(paramMessage)), paramMessage.getJMSDestination().toString(), paramMessage.getJMSCorrelationID(), str1 };
        }
        if (paramBoolean) {
          addRow(arrayOfObject);
        } else {
          insertRow(0, arrayOfObject);
        }
      }
      else
      {
        System.err.println("Empty message!");
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void updateRequestMessage(Message paramMessage1, Message paramMessage2)
  {
    try
    {
      String str1 = paramMessage1.getJMSMessageID();
      for (int i = 0; i < this.m_table.getRowCount(); i++)
      {
        String str2 = (String)this.m_table.getValueAt(i, 0);
        String str3 = StringUtilities.getHumanReadableSize(Tibjms.getMessageSize(paramMessage2));
        if (str2.equals(str1))
        {
          long l = paramMessage2.getJMSTimestamp() - paramMessage1.getJMSTimestamp();
          this.m_table.setValueAt(String.valueOf(l), i, 2);
          this.m_table.setValueAt(str3, i, 7);
          String str4 = paramMessage1.getJMSCorrelationID();
          if ((str4 != null) && (str4.length() > 0))
          {
            this.m_replymsgs.put(str4, paramMessage2);
          }
          else
          {
            String str5 = paramMessage1.getJMSReplyTo().toString();
            if ((str5 != null) && (str5.length() > 0)) {
              this.m_replymsgs.put(str5, paramMessage2);
            } else {
              System.err.println("GemsReqReplyMonitor.updateRequestMessage: Could not update request " + paramMessage1.getJMSMessageID());
            }
          }
        }
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void timeoutRequestMessage(Message paramMessage)
  {
    try
    {
      String str1 = paramMessage.getJMSMessageID();
      for (int i = 0; i < this.m_table.getRowCount(); i++)
      {
        String str2 = (String)this.m_table.getValueAt(i, 0);
        if (str2.equals(str1)) {
          this.m_table.setValueAt("no reply", i, 2);
        }
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void addRequestMessage(Message paramMessage1, Message paramMessage2, boolean paramBoolean)
  {
    Date localDate = new Date();
    try
    {
      if (paramMessage1 != null)
      {
        if (paramMessage1.getJMSMessageID() == null) {
          paramMessage1.setJMSMessageID("tmpId" + String.valueOf(++s_msgId));
        }
        this.m_msgs.put(paramMessage1.getJMSMessageID(), paramMessage1);
        if (paramMessage2 != null)
        {
          str1 = paramMessage1.getJMSCorrelationID();
          if ((str1 != null) && (str1.length() > 0))
          {
            this.m_replymsgs.put(str1, paramMessage2);
          }
          else
          {
            String str2 = paramMessage1.getJMSReplyTo().toString();
            if ((str2 != null) && (str2.length() > 0)) {
              this.m_replymsgs.put(str2, paramMessage2);
            }
          }
        }
        String str1 = paramMessage1.getJMSDeliveryMode() == 1 ? "NON_PERSISTENT" : paramMessage1.getJMSDeliveryMode() == 2 ? "PERSISTENT" : "RELIABLE";
        long l = -99L;
        String str3 = "";
        if (paramMessage2 != null)
        {
          l = paramMessage2.getJMSTimestamp() - paramMessage1.getJMSTimestamp();
          str3 = StringUtilities.getHumanReadableSize(Tibjms.getMessageSize(paramMessage2));
        }
        localDate.setTime(paramMessage1.getJMSTimestamp());
        if (paramMessage1.getJMSMessageID() == null) {
          paramMessage1.setJMSMessageID("tmpId" + String.valueOf(++s_msgId));
        }
        Object[] arrayOfObject = { paramMessage1.getJMSMessageID(), localDate, l == -99L ? "pending..." : String.valueOf(l), paramMessage1.getJMSDestination().toString(), paramMessage1.getJMSCorrelationID(), paramMessage1.getJMSReplyTo() != null ? paramMessage1.getJMSReplyTo().toString() : "", StringUtilities.getHumanReadableSize(Tibjms.getMessageSize(paramMessage1)), str3 };
        if (paramBoolean) {
          addRow(arrayOfObject);
        } else {
          insertRow(0, arrayOfObject);
        }
      }
      else
      {
        System.err.println("Empty message!");
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void addMonitorMessage(Message paramMessage, boolean paramBoolean1, boolean paramBoolean2)
  {
    Date localDate = new Date();
    try
    {
      if (paramMessage != null)
      {
        if (paramMessage.getJMSMessageID() == null) {
          paramMessage.setJMSMessageID("tmpId" + String.valueOf(++s_msgId));
        }
        this.m_msgs.put(paramMessage.getJMSMessageID(), paramMessage);
        localDate.setTime(paramMessage.getJMSTimestamp());
        Object[] arrayOfObject;
        if (paramBoolean2) {
          arrayOfObject = new Object[] { paramMessage.getJMSMessageID(), localDate, paramMessage.getStringProperty("event_action"), paramMessage.getStringProperty("event_reason"), paramMessage.getStringProperty("conn_hostname"), paramMessage.getStringProperty("conn_username"), paramMessage.getStringProperty("target_dest_name") };
        } else {
          arrayOfObject = new Object[] { paramMessage.getJMSMessageID(), localDate, paramMessage.getStringProperty("event_action"), paramMessage.getStringProperty("event_reason"), paramMessage.getStringProperty("conn_hostname"), paramMessage.getStringProperty("conn_username") };
        }
        if (paramBoolean1) {
          addRow(arrayOfObject);
        } else {
          insertRow(0, arrayOfObject);
        }
      }
      else
      {
        System.err.println("Empty message!");
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void addEventMessage(Message paramMessage, boolean paramBoolean)
  {
    Date localDate = new Date();
    try
    {
      if (paramMessage != null)
      {
        if (paramMessage.getJMSMessageID() == null) {
          paramMessage.setJMSMessageID("tmpId" + String.valueOf(++s_msgId));
        }
        this.m_msgs.put(paramMessage.getJMSMessageID(), paramMessage);
        String str = paramMessage.getStringProperty("event_class");
        if (str == null) {
          paramMessage.getStringProperty("event_action");
        }
        localDate.setTime(paramMessage.getJMSTimestamp());
        Object[] arrayOfObject = { paramMessage.getJMSMessageID(), localDate, str, paramMessage.getStringProperty("event_reason"), paramMessage.getStringProperty("conn_hostname"), paramMessage.getStringProperty("conn_username"), paramMessage.getStringProperty("target_dest_name") };
        if (paramBoolean) {
          addRow(arrayOfObject);
        } else {
          insertRow(0, arrayOfObject);
        }
      }
      else
      {
        System.err.println("Empty message!");
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void populateEventMessageInfo(Vector paramVector)
  {
    if (paramVector == null)
    {
      setRowCount(0);
      setColumnCount(0);
      this.m_msgs.clear();
      return;
    }
    buildEventColumnHeaders();
    for (int i = 0; i < paramVector.size(); i++)
    {
      Message localMessage = (Message)paramVector.elementAt(i);
      addEventMessage(localMessage, false);
    }
  }
  
  public void populateMessageInfo(Vector paramVector)
  {
    if (paramVector == null) {
      return;
    }
    boolean bool = Gems.getGems().getViewOldMessagesFirst();
    buildColumnHeaders();
    for (int i = 0; i < paramVector.size(); i++)
    {
      Message localMessage = (Message)paramVector.elementAt(i);
      addMessage(localMessage, bool);
    }
  }
  
  public void populateMessageInfoOld(Vector paramVector)
  {
    boolean bool = Gems.getGems().getViewOldMessagesFirst();
    buildColumnHeaders();
    setRowCount(0);
    setColumnCount(0);
    this.m_msgs.clear();
    if (paramVector == null) {
      return;
    }
    this.m_table.setAutoResizeMode(0);
    String[] arrayOfString1 = { "MessageID", "Timestamp", "DeliveryMode", "Destination", "CorrelationID", "Expiration", "Priority", "ReplyTo", "Type" };
    setColumnIdentifiers(arrayOfString1);
    this.m_table.getColumn("MessageID").setPreferredWidth(200);
    this.m_table.getColumn("Destination").setPreferredWidth(100);
    this.m_table.getColumn("DeliveryMode").setPreferredWidth(100);
    this.m_table.getColumn("CorrelationID").setPreferredWidth(100);
    this.m_table.getColumn("Expiration").setPreferredWidth(100);
    this.m_table.getColumn("Priority").setPreferredWidth(100);
    this.m_table.getColumn("Timestamp").setPreferredWidth(200);
    try
    {
      Date localDate = new Date();
      for (int i = 0; i < paramVector.size(); i++)
      {
        Message localMessage = (Message)paramVector.elementAt(i);
        if (localMessage != null)
        {
          if (localMessage.getJMSMessageID() == null) {
            localMessage.setJMSMessageID("tmpId" + String.valueOf(++s_msgId));
          }
          this.m_msgs.put(localMessage.getJMSMessageID(), localMessage);
          String str = localMessage.getJMSDeliveryMode() == 1 ? "NON_PERSISTENT" : localMessage.getJMSDeliveryMode() == 2 ? "PERSISTENT" : "RELIABLE";
          localDate.setTime(localMessage.getJMSTimestamp());
          String[] arrayOfString2 = { localMessage.getJMSMessageID(), localDate.toString(), str, localMessage.getJMSDestination().toString(), localMessage.getJMSCorrelationID(), String.valueOf(localMessage.getJMSExpiration()), String.valueOf(localMessage.getJMSPriority()), localMessage.getJMSReplyTo() != null ? localMessage.getJMSReplyTo().toString() : new String(), localMessage.getJMSType() };
          if (bool) {
            addRow(arrayOfString2);
          } else {
            insertRow(0, arrayOfString2);
          }
        }
        else
        {
          System.err.println("Empty message!");
        }
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void populateMessageInfo(QueueBrowser paramQueueBrowser)
  {
    System.err.println("NOT USED");
    boolean bool = Gems.getGems().getViewOldMessagesFirst();
    setRowCount(0);
    setColumnCount(0);
    this.m_msgs.clear();
    if (paramQueueBrowser == null) {
      return;
    }
    this.m_table.setAutoResizeMode(0);
    String[] arrayOfString1 = { "ID", "Timestamp", "DeliveryMode", "CorrelationID", "Expiration", "Priority", "ReplyTo", "Type" };
    setColumnIdentifiers(arrayOfString1);
    this.m_table.getColumn("ID").setPreferredWidth(200);
    this.m_table.getColumn("DeliveryMode").setPreferredWidth(100);
    this.m_table.getColumn("CorrelationID").setPreferredWidth(100);
    this.m_table.getColumn("Expiration").setPreferredWidth(100);
    this.m_table.getColumn("Priority").setPreferredWidth(100);
    this.m_table.getColumn("Timestamp").setPreferredWidth(200);
    try
    {
      Enumeration localEnumeration = paramQueueBrowser.getEnumeration();
      Date localDate = new Date();
      int i = 0;
      int j = Gems.getGems().getMaxMessageView();
      while ((localEnumeration.hasMoreElements()) && (i < j))
      {
        Message localMessage = (Message)localEnumeration.nextElement();
        if (localMessage != null)
        {
          this.m_msgs.put(localMessage.getJMSMessageID(), localMessage);
          String str = localMessage.getJMSDeliveryMode() == 1 ? "NON_PERSISTENT" : localMessage.getJMSDeliveryMode() == 2 ? "PERSISTENT" : "RELIABLE";
          localDate.setTime(localMessage.getJMSTimestamp());
          String[] arrayOfString2 = { localMessage.getJMSMessageID(), localDate.toString(), str, localMessage.getJMSCorrelationID(), String.valueOf(localMessage.getJMSExpiration()), String.valueOf(localMessage.getJMSPriority()), localMessage.getJMSReplyTo() != null ? localMessage.getJMSReplyTo().toString() : new String(), localMessage.getJMSType() };
          if (bool) {
            addRow(arrayOfString2);
          } else {
            insertRow(0, arrayOfString2);
          }
          i++;
        }
        else
        {
          System.err.println("Empty message!");
        }
      }
      if (localEnumeration.hasMoreElements()) {
        System.err.println("Warning: Display Limited to" + j + " messages");
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  void dumpMsgsToFile(File paramFile)
    throws IOException
  {
    FileOutputStream localFileOutputStream = new FileOutputStream(paramFile, true);
    PrintStream localPrintStream = new PrintStream(localFileOutputStream);
    for (int i = 0; i < this.m_table.getRowCount(); i++)
    {
      String str;
      if (this.m_showCheckbox) {
        str = (String)this.m_table.getValueAt(i, 1);
      } else {
        str = (String)this.m_table.getValueAt(i, 0);
      }
      writeMessage((Message)this.m_msgs.get(str), localPrintStream);
      if (this.m_replymsgs != null) {
        writeMessage(getReplyMessageAt(i), localPrintStream);
      }
    }
    localPrintStream.close();
  }
  
  void writeMessage(Message paramMessage, PrintStream paramPrintStream)
  {
    if (paramMessage == null) {
      return;
    }
    try
    {
      paramPrintStream.println("$MsgStart$");
      paramPrintStream.println("$MsgHeader$");
      paramPrintStream.println("JMSMessageID=" + paramMessage.getJMSMessageID());
      Date localDate = new Date();
      localDate.setTime(paramMessage.getJMSTimestamp());
      paramPrintStream.println("JMSTimestamp=" + this.dateFormatMillis.format(localDate).toString());
      paramPrintStream.println("JMSDestination=" + paramMessage.getJMSDestination());
      String str1 = paramMessage.getJMSDeliveryMode() == 1 ? "NON_PERSISTENT" : paramMessage.getJMSDeliveryMode() == 2 ? "PERSISTENT" : "RELIABLE";
      paramPrintStream.println("JMSDeliveryMode=" + str1);
      if (paramMessage.getJMSCorrelationID() != null) {
        paramPrintStream.println("JMSCorrelationID=" + paramMessage.getJMSCorrelationID());
      }
      if (paramMessage.getJMSType() != null) {
        paramPrintStream.println("JMSType=" + paramMessage.getJMSType());
      }
      if (paramMessage.getJMSReplyTo() != null) {
        paramPrintStream.println("JMSReplyTo=" + paramMessage.getJMSReplyTo());
      }
      if (paramMessage.getJMSExpiration() > 0L)
      {
        localDate.setTime(paramMessage.getJMSExpiration());
        paramPrintStream.println("JMSExpiration=" + localDate.toString());
      }
      paramPrintStream.println("$MsgProperties$");
      Enumeration localEnumeration1 = paramMessage.getPropertyNames();
      while (localEnumeration1.hasMoreElements())
      {
        String str2 = (String)localEnumeration1.nextElement();
        paramPrintStream.println(str2 + "=" + GemsMsgPropTableModel.toTypedString(null, paramMessage.getObjectProperty(str2)));
      }
      Object localObject;
      if ((paramMessage instanceof TextMessage))
      {
        paramPrintStream.println("$MsgTextBody$");
        localObject = (TextMessage)paramMessage;
        paramPrintStream.println(((TextMessage)localObject).getText());
      }
      else if ((paramMessage instanceof MapMessage))
      {
        localObject = (MapMessage)paramMessage;
        paramPrintStream.println("$MsgMapBody$");
        Enumeration localEnumeration2 = ((MapMessage)localObject).getMapNames();
        while (localEnumeration2.hasMoreElements())
        {
          String str3 = (String)localEnumeration2.nextElement();
          paramPrintStream.println(str3 + "=" + GemsMsgPropTableModel.toTypedString(null, ((MapMessage)localObject).getObject(str3)));
        }
      }
      else if ((paramMessage instanceof BytesMessage))
      {
        paramPrintStream.println("$MsgBytesBody$");
        localObject = (BytesMessage)paramMessage;
        ((BytesMessage)localObject).reset();
        long l = ((BytesMessage)localObject).getBodyLength();
        byte[] arrayOfByte = new byte[(int)l];
        ((BytesMessage)localObject).readBytes(arrayOfByte, (int)l);
        paramPrintStream.println(StringUtilities.dumpBytes(arrayOfByte));
      }
      else if ((paramMessage instanceof StreamMessage))
      {
        paramPrintStream.println("$MsgStreamBody$");
        localObject = (StreamMessage)paramMessage;
        paramPrintStream.println(localObject.toString());
      }
      else if ((paramMessage instanceof ObjectMessage))
      {
        paramPrintStream.println("$MsgObjectBody$");
        localObject = (ObjectMessage)paramMessage;
        paramPrintStream.println(localObject.toString());
      }
      paramPrintStream.println("$MsgEnd$");
      paramPrintStream.println("");
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  class MyRenderer
    extends DefaultTableCellRenderer
  {
    public MyRenderer()
    {
      if (GemsMessageTableModel.this.m_showCheckbox) {
        setToolTipText("Double-click to display message, select checkbox for messages to copy or destroy");
      } else {
        setToolTipText("Double-click to display message");
      }
    }
    
    public void setValue(Object paramObject)
    {
      if ((paramObject instanceof Date)) {
        setText(paramObject == null ? "" : GemsMessageTableModel.this.dateFormatMillis.format(paramObject).toString());
      } else {
        super.setValue(paramObject);
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsMessageTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */