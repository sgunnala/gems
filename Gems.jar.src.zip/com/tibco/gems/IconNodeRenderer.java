package com.tibco.gems;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.util.Hashtable;
import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

public class IconNodeRenderer
  extends DefaultTreeCellRenderer
{
  Font font = null;
  Font bfont;
  Color col = null;
  Color scol = null;
  
  public Component getTreeCellRendererComponent(JTree paramJTree, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt, boolean paramBoolean4)
  {
    if (this.font == null)
    {
      this.font = getFont();
      if (this.font != null) {
        this.bfont = new Font(this.font.getName(), 1, this.font.getSize());
      }
    }
    if ((paramObject != null) && ((paramObject instanceof GemsConnectionNode)))
    {
      if (((GemsConnectionNode)paramObject).isStandbyMode())
      {
        setTextNonSelectionColor(this.col);
        setTextSelectionColor(this.scol);
        setFont(this.font);
      }
      else if (((GemsConnectionNode)paramObject).showError())
      {
        setTextNonSelectionColor(Color.red);
        setTextSelectionColor(Color.red);
        setFont(this.bfont);
      }
      else if (((GemsConnectionNode)paramObject).showWarning())
      {
        setTextNonSelectionColor(Color.orange);
        setTextSelectionColor(Color.orange);
        setFont(this.bfont);
      }
      else
      {
        setTextNonSelectionColor(this.col);
        setTextSelectionColor(this.scol);
        setFont(this.font);
      }
    }
    else
    {
      setTextNonSelectionColor(this.col);
      setTextSelectionColor(this.scol);
      setFont(this.font);
    }
    super.getTreeCellRendererComponent(paramJTree, paramObject, paramBoolean1, paramBoolean2, paramBoolean3, paramInt, paramBoolean4);
    if ((paramObject != null) && ((paramObject instanceof IconNode)))
    {
      Icon localIcon = ((IconNode)paramObject).getIcon();
      if (localIcon == null)
      {
        Hashtable localHashtable = (Hashtable)paramJTree.getClientProperty("JTree.icons");
        String str = ((IconNode)paramObject).getIconName();
        if ((localHashtable != null) && (str != null))
        {
          localIcon = (Icon)localHashtable.get(str);
          if (localIcon != null) {
            setIcon(localIcon);
          }
        }
      }
      else
      {
        setIcon(localIcon);
      }
    }
    else
    {
      setIcon(null);
    }
    return this;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\IconNodeRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */