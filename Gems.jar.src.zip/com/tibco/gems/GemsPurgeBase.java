package com.tibco.gems;

import com.tibco.tibjms.admin.DestinationInfo;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;
import javax.swing.table.JTableHeader;

public abstract class GemsPurgeBase
  extends JDialog
{
  JFrame m_frame;
  JPanel m_panel;
  GemsConnectionNode m_cn;
  protected String m_type;
  protected JTextField m_conn;
  protected JTextField m_pattern;
  protected JButton m_startButton;
  protected JButton m_stopButton;
  protected JButton m_lookup;
  JTable m_table;
  protected GemsDestTableModel m_tableModel;
  TableSorter m_sorter;
  
  public GemsPurgeBase(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, String paramString1, String paramString2)
  {
    super(paramJFrame, Gems.getGems().getTitlePrefix() + "Purge " + paramString1 + "s", true);
    setLocationRelativeTo(paramJFrame);
    setDefaultCloseOperation(2);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_type = paramString1;
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    localJPanel3.setMinimumSize(new Dimension(300, 24));
    JLabel localJLabel2 = new JLabel(paramString1 + " Pattern:", 11);
    this.m_pattern = new JTextField(paramString2, 32);
    localJLabel2.setLabelFor(this.m_pattern);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_pattern);
    this.m_lookup = new JButton("LookUp");
    this.m_lookup.addActionListener(new LookupAction());
    localJPanel3.add(this.m_lookup);
    localJPanel2.add(localJPanel3);
    this.m_tableModel = new GemsDestTableModel(false, true);
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setRowSelectionAllowed(false);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(635, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    Component localComponent = Box.createRigidArea(new Dimension(225, 10));
    localJPanel4.add(localComponent);
    this.m_startButton = new JButton("Purge");
    this.m_startButton.addActionListener(new StartPressed());
    this.m_stopButton = new JButton("Cancel");
    this.m_stopButton.addActionListener(new StopPressed());
    localJPanel4.add(this.m_startButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel4.add(localComponent);
    localJPanel4.add(this.m_stopButton);
    localJPanel1.add(localJPanel4, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 2, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    pack();
    show();
  }
  
  public void start()
  {
    purgeDestinations(this.m_tableModel.getSelectedDestinations());
    this.m_tableModel.populateDestinationInfo(getDestinationInfo());
  }
  
  public void stop()
  {
    dispose();
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if ((paramAnonymousMouseEvent.getClickCount() == 2) && (GemsPurgeBase.this.m_table.getSelectedColumn() > 0)) {
          GemsPurgeBase.this.m_tableModel.toggleSelectedRow();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsPurgeBase.this.dispose();
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuBar.add(localJMenu);
    localJMenuItem = new JMenuItem("Select All");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(65, 2));
    localJMenuItem.addActionListener(new SelectAllAction());
    localJMenu.add(localJMenuItem);
    return localJMenuBar;
  }
  
  public abstract DestinationInfo[] getDestinationInfo();
  
  public abstract void purgeDestinations(Vector paramVector);
  
  public void dispose()
  {
    super.dispose();
  }
  
  class SelectAllAction
    implements ActionListener
  {
    SelectAllAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPurgeBase.this.m_tableModel.selectAllRows();
    }
  }
  
  class LookupAction
    implements ActionListener
  {
    LookupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPurgeBase.this.m_tableModel.buildColumnHeaders();
      GemsPurgeBase.this.m_sorter.setSortingStatus(3, -1);
      GemsPurgeBase.this.m_tableModel.populateDestinationInfo(GemsPurgeBase.this.getDestinationInfo());
    }
  }
  
  class StopPressed
    implements ActionListener
  {
    StopPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPurgeBase.this.stop();
    }
  }
  
  class StartPressed
    implements ActionListener
  {
    StartPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsPurgeBase.this.start();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsPurgeBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */