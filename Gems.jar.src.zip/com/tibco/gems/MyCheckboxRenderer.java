package com.tibco.gems;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class MyCheckboxRenderer
  extends JCheckBox
  implements TableCellRenderer
{
  public MyCheckboxRenderer()
  {
    setHorizontalAlignment(0);
  }
  
  public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
  {
    Color localColor = paramJTable.getBackground();
    setBackground(localColor);
    setSelected((paramObject != null) && (((Boolean)paramObject).booleanValue()));
    return this;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\MyCheckboxRenderer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */