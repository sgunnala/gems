package com.tibco.gems;

public abstract interface GetPopupHandler
{
  public abstract PopupHandler getPopupHandler();
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GetPopupHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */