package com.tibco.gems;

import com.tibco.tibjms.admin.SSLParams;
import com.tibco.tibjms.admin.ServerInfo;
import com.tibco.tibjms.admin.VersionInfo;
import java.util.Date;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class GemsServerInfoTableModel
  extends DefaultTableModel
{
  JTable m_table;
  Object m_obj = new Object();
  MyRenderer m_renderer = new MyRenderer();
  
  public GemsServerInfoTableModel()
  {
    addColumn("Property");
    addColumn("Value");
  }
  
  public void setTable(JTable paramJTable)
  {
    this.m_table = paramJTable;
    if (!Gems.getGems().getViewOnlyMode()) {
      this.m_table.setDefaultRenderer(this.m_obj.getClass(), this.m_renderer);
    }
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }
  
  public String getSelectedCol1()
  {
    if (this.m_table.getSelectedRow() < 0) {
      return null;
    }
    Object localObject = this.m_table.getValueAt(this.m_table.getSelectedRow(), 0);
    if ((localObject instanceof Long)) {
      return String.valueOf((Long)localObject);
    }
    return (String)localObject;
  }
  
  public void populateTable(ServerInfo paramServerInfo)
  {
    Date localDate = new Date();
    setRowCount(0);
    if (paramServerInfo == null) {
      return;
    }
    String[] arrayOfString = { "ACLsFile", paramServerInfo.getACLsFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "AsyncDBSize", StringUtilities.getHumanReadableSize(paramServerInfo.getAsyncDBSize()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "BackupName", paramServerInfo.getBackupName() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "BridgesFile", paramServerInfo.getBridgesFile() };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ChannelsFile", paramServerInfo.getChannelsFile() };
      addRow(arrayOfString);
      arrayOfString = new String[] { "ClientHeartbeatServerInterval", String.valueOf(paramServerInfo.getClientHeartbeatServerInterval()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "ClientTimeoutServerConnection", String.valueOf(paramServerInfo.getClientTimeoutServerConnection()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable1) {}
    arrayOfString = new String[] { "ClientTraceFilterType", String.valueOf(paramServerInfo.getClientTraceFilterType()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ClientTraceTarget", String.valueOf(paramServerInfo.getClientTraceTarget()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ConfigFile", paramServerInfo.getConfigFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ConnectionCount", String.valueOf(paramServerInfo.getConnectionCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ConsoleTraceInfo", GemsTraceDialog.TraceInfoToString(paramServerInfo.getConsoleTraceInfo()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ConsumerCount", String.valueOf(paramServerInfo.getConsumerCount()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable2) {}
    try
    {
      arrayOfString = new String[] { "DestinationBacklogSwapout", String.valueOf(paramServerInfo.getDestinationBacklogSwapout()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable3) {}
    arrayOfString = new String[] { "DetailedStatistics", String.valueOf(paramServerInfo.getDetailedStatistics()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "DiskReadRate", StringUtilities.getHumanReadableSize(paramServerInfo.getDiskReadRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "DiskWriteRate", StringUtilities.getHumanReadableSize(paramServerInfo.getDiskWriteRate()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "DiskReadOperationsRate", String.valueOf(paramServerInfo.getDiskReadOperationsRate()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "DiskWriteOperationsRate", String.valueOf(paramServerInfo.getDiskWriteOperationsRate()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable4) {}
    arrayOfString = new String[] { "DurableCount", String.valueOf(paramServerInfo.getDurableCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "DurablesFile", paramServerInfo.getDurablesFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FactoriesFile", paramServerInfo.getFactoriesFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FaultTolerantActivation", String.valueOf(paramServerInfo.getFaultTolerantActivation()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FaultTolerantFailoverReread", String.valueOf(paramServerInfo.getFaultTolerantFailoverReread()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FaultTolerantHeartbeat", String.valueOf(paramServerInfo.getFaultTolerantHeartbeat()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FaultTolerantReconnectTimeout", String.valueOf(paramServerInfo.getFaultTolerantReconnectTimeout()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "FaultTolerantURL", paramServerInfo.getFaultTolerantURL() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "GroupsFile", paramServerInfo.getGroupsFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundBytesRate", String.valueOf(paramServerInfo.getInboundBytesRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundMessageCount", String.valueOf(paramServerInfo.getInboundMessageCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "InboundMessageRate", String.valueOf(paramServerInfo.getInboundMessageRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ListenPorts", StringUtilities.arrayToString(paramServerInfo.getListenPorts()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "LogFileMaxSize", StringUtilities.getHumanReadableSize(paramServerInfo.getLogFileMaxSize()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "LogFileName", paramServerInfo.getLogFileName() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "LogTraceInfo", GemsTraceDialog.TraceInfoToString(paramServerInfo.getLogTraceInfo()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "MaxClientMsgSize", StringUtilities.getHumanReadableSize(paramServerInfo.getMaxClientMsgSize()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable5) {}
    arrayOfString = new String[] { "MaxConnections", String.valueOf(paramServerInfo.getMaxConnections()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MaxMsgMemory", StringUtilities.getHumanReadableSize(paramServerInfo.getMaxMsgMemory()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MaxStatisticsMemory", StringUtilities.getHumanReadableSize(paramServerInfo.getMaxStatisticsMemory()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "MessagePoolBlockSize", String.valueOf(paramServerInfo.getMessagePoolBlockSize()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "MessagePoolSize", String.valueOf(paramServerInfo.getMessagePoolSize()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable6) {}
    arrayOfString = new String[] { "MsgMem", StringUtilities.getHumanReadableSize(paramServerInfo.getMsgMem()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "MsgMemPooled", StringUtilities.getHumanReadableSize(paramServerInfo.getMsgMemPooled()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "MulticastStatisticsInterval", String.valueOf(paramServerInfo.getMulticastStatisticsInterval()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "NPSendCheckMode", String.valueOf(paramServerInfo.getNPSendCheckMode()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable7) {}
    arrayOfString = new String[] { "OutboundMessageCount", String.valueOf(paramServerInfo.getOutboundMessageCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "OutboundMessageRate", String.valueOf(paramServerInfo.getOutboundMessageRate()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "PendingMessageCount", String.valueOf(paramServerInfo.getPendingMessageCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "PendingMessageSize", StringUtilities.getHumanReadableSize(paramServerInfo.getPendingMessageSize()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ProcessId", String.valueOf(paramServerInfo.getProcessId()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ProducerCount", String.valueOf(paramServerInfo.getProducerCount()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable8) {}
    arrayOfString = new String[] { "QueueCount", String.valueOf(paramServerInfo.getQueueCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "QueuesFile", paramServerInfo.getQueuesFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "RateInterval", String.valueOf(paramServerInfo.getRateInterval()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ReserveMemory", StringUtilities.getHumanReadableSize(paramServerInfo.getReserveMemory()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "RouteRecoverInterval", String.valueOf(paramServerInfo.getRouteRecoverInterval()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "RouteRecoverCount", String.valueOf(paramServerInfo.getRouteRecoverCount()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable9) {}
    arrayOfString = new String[] { "RoutesFile", paramServerInfo.getRoutesFile() };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ServerConfigurationMode", paramServerInfo.getServerConfigurationMode() == 0 ? "Conf" : "XML" };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable10) {}
    try
    {
      arrayOfString = new String[] { "ServerHeartbeatClientInterval", String.valueOf(paramServerInfo.getServerHeartbeatClientInterval()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "ServerHeartbeatServerInterval", String.valueOf(paramServerInfo.getServerHeartbeatServerInterval()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable11) {}
    arrayOfString = new String[] { "ServerName", paramServerInfo.getServerName() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "ServerRateInterval", String.valueOf(paramServerInfo.getServerRateInterval()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "ServerTimeoutClientConnection", String.valueOf(paramServerInfo.getServerTimeoutClientConnection()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "ServerTimeoutServerConnection", String.valueOf(paramServerInfo.getServerTimeoutServerConnection()) };
      addRow(arrayOfString);
      arrayOfString = new String[] { "SessionCount", String.valueOf(paramServerInfo.getSessionCount()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable12) {}
    arrayOfString = new String[] { "SSLCertUserSpecname", String.valueOf(paramServerInfo.getSSLCertUserSpecname()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "SSLDHSize", String.valueOf(paramServerInfo.getSSLDHSize()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "SSLParams", paramServerInfo.getSSLParams() == null ? "" : paramServerInfo.getSSLParams().toString() };
    addRow(arrayOfString);
    localDate.setTime(paramServerInfo.getStartTime());
    arrayOfString = new String[] { "StartTime", localDate.toString() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "State", paramServerInfo.getState() == 4 ? "active" : "standby" };
    addRow(arrayOfString);
    arrayOfString = new String[] { "StatisticsCleanupInterval", String.valueOf(paramServerInfo.getStatisticsCleanupInterval()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "StoreAsyncMinimum", StringUtilities.getHumanReadableSize(paramServerInfo.getStoreAsyncMinimum()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "StoreDirectory", paramServerInfo.getStoreDirectory() };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "StoresFile", paramServerInfo.getStoresFile() };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable13) {}
    arrayOfString = new String[] { "StoreMinimum", StringUtilities.getHumanReadableSize(paramServerInfo.getStoreMinimum()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "StoreSyncMinimum", StringUtilities.getHumanReadableSize(paramServerInfo.getStoreSyncMinimum()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "SyncDBSize", StringUtilities.getHumanReadableSize(paramServerInfo.getSyncDBSize()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "TibrvcmFile", paramServerInfo.getTibrvcmFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "TopicCount", String.valueOf(paramServerInfo.getTopicCount()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "TopicsFile", paramServerInfo.getTopicsFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "TransportsFile", paramServerInfo.getTransportsFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "UpTime", StringUtilities.getFullHumanReadableTime(paramServerInfo.getUpTime()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "URL", String.valueOf(paramServerInfo.getURL()) };
    addRow(arrayOfString);
    try
    {
      int[] arrayOfInt = paramServerInfo.getUserAuthLocations();
      String str = "";
      for (int i = 0; (arrayOfInt != null) && (i < arrayOfInt.length); i++)
      {
        str = str + (arrayOfInt[i] == 1 ? "LDAP" : arrayOfInt[i] == 3 ? "Local" : "System");
        if (i < arrayOfInt.length - 1) {
          str = str + ",";
        }
      }
      arrayOfString = new String[] { "UserAuthLocations", str };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable14) {}
    arrayOfString = new String[] { "UsersFile", paramServerInfo.getUsersFile() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "VersionInfo", paramServerInfo.getVersionInfo().toString() };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isAuthorizationEnabled", String.valueOf(paramServerInfo.isAuthorizationEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isClientTraceEnabled", String.valueOf(paramServerInfo.isClientTraceEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isEvaluation", String.valueOf(paramServerInfo.isEvaluation()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFlowControlEnabled", String.valueOf(paramServerInfo.isFlowControlEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isFSyncEnabled", String.valueOf(paramServerInfo.isFSyncEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isMessageSwappingEnabled", String.valueOf(paramServerInfo.isMessageSwappingEnabled()) };
    addRow(arrayOfString);
    try
    {
      arrayOfString = new String[] { "isMulticastEnabled", String.valueOf(paramServerInfo.isMulticastEnabled()) };
      addRow(arrayOfString);
    }
    catch (Throwable localThrowable15) {}
    arrayOfString = new String[] { "isRoutingEnabled", String.valueOf(paramServerInfo.isRoutingEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSSLRequireClientCert", String.valueOf(paramServerInfo.isSSLRequireClientCert()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isSSLUserCertUsername", String.valueOf(paramServerInfo.isSSLUserCertUsername()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isStatisticsEnabled", String.valueOf(paramServerInfo.isStatisticsEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isStoreCRCEnabled", String.valueOf(paramServerInfo.isStoreCRCEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isStoreTruncateEnabled", String.valueOf(paramServerInfo.isStoreTruncateEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isTibrvTransportsEnabled", String.valueOf(paramServerInfo.isTibrvTransportsEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isTibssTransportsEnabled", String.valueOf(paramServerInfo.isTibssTransportsEnabled()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isTrackCorrelationIds", String.valueOf(paramServerInfo.isTrackCorrelationIds()) };
    addRow(arrayOfString);
    arrayOfString = new String[] { "isTrackMsgIds", String.valueOf(paramServerInfo.isTrackMsgIds()) };
    addRow(arrayOfString);
  }
  
  class MyRenderer
    extends DefaultTableCellRenderer
  {
    public MyRenderer()
    {
      setToolTipText("Double-click to set property");
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsServerInfoTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */