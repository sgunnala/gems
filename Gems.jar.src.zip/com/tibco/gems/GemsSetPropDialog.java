package com.tibco.gems;

import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class GemsSetPropDialog
  extends JDialog
{
  protected JComboBox m_props;
  protected JTextField m_type;
  protected JTextField m_value;
  protected JLabel m_help;
  protected boolean m_cancelled = true;
  protected String m_selProp;
  protected Hashtable m_propList;
  
  public GemsSetPropDialog(Frame paramFrame, String paramString)
  {
    super(paramFrame, paramString, true);
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 1));
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2);
    JLabel localJLabel1 = new JLabel("Property:", 11);
    this.m_props = new JComboBox();
    this.m_props.addActionListener(new PropSelected());
    localJLabel1.setLabelFor(this.m_props);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_props);
    JLabel localJLabel2 = new JLabel("Type:", 11);
    this.m_type = new JTextField("", 28);
    this.m_type.setEditable(false);
    localJLabel2.setLabelFor(this.m_type);
    localJPanel2.add(localJLabel2);
    localJPanel2.add(this.m_type);
    JLabel localJLabel3 = new JLabel("Value:", 11);
    this.m_value = new JTextField("", 28);
    localJLabel3.setLabelFor(this.m_value);
    localJPanel2.add(localJLabel3);
    localJPanel2.add(this.m_value);
    JLabel localJLabel4 = new JLabel("<html><br><br><br></html>");
    localJPanel2.add(localJLabel4);
    this.m_help = new JLabel("");
    localJLabel4.setLabelFor(this.m_help);
    localJPanel2.add(this.m_help);
    SpringUtilities.makeCompactGrid(localJPanel2, 4, 2, 5, 5, 5, 5);
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setLayout(new FlowLayout());
    JButton localJButton1 = new JButton("OK ");
    JButton localJButton2 = new JButton("Cancel ");
    localJPanel3.add(localJButton1);
    localJPanel3.add(localJButton2);
    localJButton1.addActionListener(new OkPressed());
    localJButton2.addActionListener(new CancelPressed());
    localJPanel1.add(localJPanel3);
    setContentPane(localJPanel1);
    setLocationRelativeTo(paramFrame);
  }
  
  public String getValue(Hashtable paramHashtable, String paramString1, String paramString2)
  {
    this.m_propList = paramHashtable;
    Enumeration localEnumeration = paramHashtable.keys();
    while (localEnumeration.hasMoreElements()) {
      this.m_props.addItem((String)localEnumeration.nextElement());
    }
    if (paramString1 != null)
    {
      this.m_props.setSelectedItem(paramString1);
      GemsProperty localGemsProperty = (GemsProperty)paramHashtable.get(paramString1);
      if (localGemsProperty != null)
      {
        this.m_type.setText(localGemsProperty.type.getName());
        this.m_help.setText(localGemsProperty.help);
      }
    }
    this.m_selProp = ((String)this.m_props.getSelectedItem());
    if (paramString2 != null) {
      this.m_value.setText(paramString2);
    }
    pack();
    show();
    if (this.m_cancelled) {
      return null;
    }
    return this.m_value.getText();
  }
  
  public String getSelectedProp()
  {
    return this.m_selProp;
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsSetPropDialog.this.m_cancelled = true;
      GemsSetPropDialog.this.dispose();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsSetPropDialog.this.m_cancelled = false;
      GemsSetPropDialog.this.dispose();
    }
  }
  
  class PropSelected
    implements ActionListener
  {
    PropSelected() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsSetPropDialog.this.m_selProp = ((String)GemsSetPropDialog.this.m_props.getSelectedItem());
      GemsProperty localGemsProperty = (GemsProperty)GemsSetPropDialog.this.m_propList.get(GemsSetPropDialog.this.m_selProp);
      GemsSetPropDialog.this.m_value.setText("");
      if (localGemsProperty != null)
      {
        GemsSetPropDialog.this.m_type.setText(localGemsProperty.type.getName());
        GemsSetPropDialog.this.m_help.setText(localGemsProperty.help);
      }
      GemsSetPropDialog.this.invalidate();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsSetPropDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */