package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SpringLayout;

public class GemsConnectionPicker
  extends JDialog
{
  Frame m_frame;
  JPanel m_panel;
  GemsConnectionNode m_cn;
  GemsConnectionNode m_result = null;
  protected JComboBox m_conn;
  protected JButton m_okButton;
  protected JButton m_cancelButton;
  protected Hashtable m_connTable;
  
  public GemsConnectionPicker(Frame paramFrame, GemsConnectionNode paramGemsConnectionNode, String paramString)
  {
    super(paramFrame, "Select the EMS server to " + paramString, true);
    setLocationRelativeTo(paramFrame);
    setDefaultCloseOperation(2);
    this.m_frame = paramFrame;
    this.m_cn = paramGemsConnectionNode;
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    this.m_connTable = GemsConnectionNode.getConnections();
    JLabel localJLabel = new JLabel("EMS Server:", 11);
    this.m_conn = new JComboBox();
    Enumeration localEnumeration = this.m_connTable.keys();
    if (this.m_connTable.size() == 0) {
      return;
    }
    ArrayList localArrayList = new ArrayList();
    while (localEnumeration.hasMoreElements())
    {
      localObject = (String)localEnumeration.nextElement();
      localArrayList.add(localObject);
      Collections.sort(localArrayList);
      this.m_conn.insertItemAt(localObject, localArrayList.indexOf(localObject));
      if ((paramGemsConnectionNode != null) && (((String)localObject).startsWith(paramGemsConnectionNode.getName()))) {
        this.m_conn.setSelectedItem(localObject);
      }
    }
    if (this.m_conn.getSelectedItem() == null) {
      this.m_conn.setSelectedIndex(0);
    }
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel);
    localJPanel2.add(this.m_conn);
    Object localObject = new JPanel(true);
    ((JPanel)localObject).setLayout(new BoxLayout((Container)localObject, 0));
    Component localComponent = Box.createRigidArea(new Dimension(110, 10));
    ((JPanel)localObject).add(localComponent);
    this.m_okButton = new JButton("Ok");
    this.m_okButton.addActionListener(new OkPressed());
    this.m_cancelButton = new JButton("Cancel");
    this.m_cancelButton.addActionListener(new CancelPressed());
    ((JPanel)localObject).add(this.m_okButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    ((JPanel)localObject).add(localComponent);
    ((JPanel)localObject).add(this.m_cancelButton);
    localJPanel1.add((Component)localObject, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 1, 2, 5, 5, 15, 15);
  }
  
  public GemsConnectionNode getConnection()
  {
    if (this.m_connTable.size() == 0) {
      return null;
    }
    if (this.m_connTable.size() == 1) {
      return (GemsConnectionNode)this.m_connTable.get(this.m_conn.getSelectedItem());
    }
    pack();
    show();
    return this.m_result;
  }
  
  public void ok()
  {
    this.m_result = ((GemsConnectionNode)this.m_connTable.get(this.m_conn.getSelectedItem()));
    dispose();
  }
  
  public void cancel()
  {
    this.m_result = null;
    dispose();
  }
  
  public void dispose()
  {
    super.dispose();
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionPicker.this.cancel();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionPicker.this.ok();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsConnectionPicker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */