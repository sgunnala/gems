package com.tibco.gems.chart;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.Vector;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

public class GemsTableChartData
  extends JTable
{
  public JPanel createView(Dimension paramDimension)
  {
    JScrollPane localJScrollPane = new JScrollPane(this);
    localJScrollPane.setPreferredSize(paramDimension);
    localJScrollPane.setPreferredSize(new Dimension(paramDimension.width, paramDimension.height * 7 / 8));
    localJScrollPane.setMinimumSize(new Dimension(paramDimension.width, paramDimension.height / 3));
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BorderLayout());
    localJPanel.add("Center", localJScrollPane);
    return localJPanel;
  }
  
  public GemsTableChartData(TableModel paramTableModel, Vector paramVector)
  {
    super(paramTableModel);
    setBackground(Color.white);
    for (int i = 0; i < paramVector.size(); i++)
    {
      TableColumn localTableColumn = getColumn((String)paramVector.elementAt(i));
      localTableColumn.setPreferredWidth(150);
    }
    if (paramVector.size() > 4) {
      setAutoResizeMode(0);
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsTableChartData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */