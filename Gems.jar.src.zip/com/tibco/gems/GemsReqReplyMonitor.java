package com.tibco.gems;

import com.tibco.tibjms.Tibjms;
import com.tibco.tibjms.TibjmsTopicConnectionFactory;
import com.tibco.tibjms.admin.TibjmsAdmin;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Hashtable;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;
import javax.swing.Timer;
import javax.swing.table.JTableHeader;
import javax.swing.text.DefaultEditorKit.CopyAction;
import javax.swing.text.DefaultEditorKit.CutAction;
import javax.swing.text.DefaultEditorKit.PasteAction;

public class GemsReqReplyMonitor
  extends JFrame
{
  JFrame m_frame;
  JPanel m_panel;
  boolean m_running = false;
  boolean m_useMonitorMsgTimestamp = Gems.getGems().getUseServerTimestamps();
  int m_msgs = 0;
  int m_maxMsgs = 10;
  Message m_msg = null;
  TibjmsAdmin m_admin = null;
  TopicSession m_session = null;
  TopicSession m_replysession = null;
  GemsConnectionNode m_cn;
  TopicConnection m_connection = null;
  TopicSubscriber m_subscriber = null;
  TopicSubscriber m_replySubscriber = null;
  Timer m_timer = new Timer(Gems.getGems().getMsgReadDelay(), new RefreshTimerAction());
  protected JTextField m_conn;
  protected JTextField m_reqDest;
  protected JTextField m_msgsRead;
  protected JTextField m_msgsDisplay;
  protected JTextField m_replyDest;
  protected JButton m_destwiz;
  protected JButton m_startButton;
  protected JButton m_stopButton;
  protected JCheckBox m_noLimit;
  JTable m_table;
  protected GemsMessageTableModel m_tableModel;
  protected boolean m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
  protected long m_failCount = Gems.getGems().getRequestReplyTimeout() * 1000 / Gems.getGems().getMsgReadDelay();
  protected JMenuItem m_optMenuItem;
  protected JMenuItem m_dumpMenuItem;
  TableSorter m_sorter;
  boolean m_isQueue = true;
  Mutex m_mutex = new Mutex();
  public Hashtable m_pending = new Hashtable();
  
  public GemsReqReplyMonitor(GemsConnectionNode paramGemsConnectionNode, String paramString1, boolean paramBoolean, String paramString2)
  {
    super(Gems.getGems().getTitlePrefix() + paramString2);
    setLocation(400, 175);
    setDefaultCloseOperation(2);
    this.m_frame = this;
    this.m_cn = paramGemsConnectionNode;
    this.m_isQueue = paramBoolean;
    String str;
    if (paramBoolean) {
      str = "Queue";
    } else {
      str = "Topic";
    }
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    JLabel localJLabel2 = new JLabel("Request " + str + " Name:", 11);
    this.m_reqDest = new JTextField(paramString1, 20);
    localJLabel2.setLabelFor(this.m_reqDest);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_reqDest);
    this.m_destwiz = new JButton("...");
    this.m_destwiz.setPreferredSize(new Dimension(18, 16));
    this.m_destwiz.addActionListener(new DestinationWizardAction());
    localJPanel3.add(this.m_destwiz);
    localJPanel2.add(localJPanel3);
    JLabel localJLabel3 = new JLabel("Reply " + str + " Name:", 11);
    this.m_replyDest = new JTextField("$TMP$.>", 20);
    this.m_replyDest.setMaximumSize(new Dimension(0, 24));
    localJLabel3.setLabelFor(this.m_replyDest);
    localJPanel2.add(localJLabel3);
    localJPanel2.add(this.m_replyDest);
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    JLabel localJLabel4 = new JLabel("Requests to Read:", 11);
    this.m_msgsRead = new JTextField("10", 20);
    this.m_msgsRead.setMinimumSize(new Dimension(40, 24));
    localJPanel4.setPreferredSize(new Dimension(100, 24));
    localJLabel4.setLabelFor(this.m_msgsRead);
    localJPanel2.add(localJLabel4);
    localJPanel4.add(this.m_msgsRead);
    this.m_noLimit = new JCheckBox("No Limit", false);
    localJPanel4.add(this.m_noLimit);
    localJPanel2.add(localJPanel4);
    this.m_tableModel = new GemsMessageTableModel(false, false);
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setSelectionMode(0);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(480, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel5 = new JPanel(true);
    localJPanel5.setLayout(new BoxLayout(localJPanel5, 0));
    Component localComponent = Box.createRigidArea(new Dimension(230, 10));
    localJPanel5.add(localComponent);
    this.m_startButton = new JButton("Start");
    this.m_startButton.addActionListener(new StartPressed());
    this.m_stopButton = new JButton("Stop");
    this.m_stopButton.addActionListener(new StopPressed());
    this.m_stopButton.setEnabled(false);
    localJPanel5.add(this.m_startButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel5.add(localComponent);
    localJPanel5.add(this.m_stopButton);
    localJPanel1.add(localJPanel5, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 4, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    pack();
    show();
  }
  
  public void start()
  {
    this.m_running = true;
    this.m_msgs = 0;
    this.m_reqDest.setEnabled(false);
    this.m_msgsRead.setEnabled(false);
    this.m_startButton.setEnabled(false);
    this.m_stopButton.setEnabled(true);
    this.m_noLimit.setEnabled(false);
    this.m_replyDest.setEnabled(false);
    this.m_destwiz.setEnabled(false);
    this.m_optMenuItem.setEnabled(false);
    this.m_dumpMenuItem.setEnabled(false);
    if (this.m_failCount < 2L) {
      this.m_failCount = 2L;
    }
    try
    {
      this.m_maxMsgs = Integer.parseInt(this.m_msgsRead.getText());
    }
    catch (Exception localException)
    {
      this.m_maxMsgs = 10;
    }
    this.m_tableModel.buildRequestReplyColumnHeaders();
    try
    {
      TibjmsTopicConnectionFactory localTibjmsTopicConnectionFactory = new TibjmsTopicConnectionFactory(this.m_cn.m_url, null, this.m_cn.m_sslParams);
      this.m_connection = localTibjmsTopicConnectionFactory.createTopicConnection(this.m_cn.m_user, this.m_cn.m_password);
      this.m_session = this.m_connection.createTopicSession(false, 22);
      this.m_replysession = this.m_connection.createTopicSession(false, 22);
      Topic localTopic1;
      Topic localTopic2;
      if (this.m_isQueue)
      {
        localTopic1 = this.m_session.createTopic("$sys.monitor.Q.r." + this.m_reqDest.getText());
        localTopic2 = this.m_replysession.createTopic("$sys.monitor.Q.r." + this.m_replyDest.getText());
      }
      else
      {
        localTopic1 = this.m_session.createTopic("$sys.monitor.T.r." + this.m_reqDest.getText());
        localTopic2 = this.m_replysession.createTopic("$sys.monitor.T.r." + this.m_replyDest.getText());
      }
      this.m_replySubscriber = this.m_replysession.createSubscriber(localTopic2);
      this.m_replySubscriber.setMessageListener(new OnSyncReplyMessage());
      this.m_subscriber = this.m_session.createSubscriber(localTopic1);
      this.m_connection.start();
      this.m_timer.start();
    }
    catch (JMSException localJMSException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localJMSException.getMessage(), "Error", 1);
      stop();
    }
  }
  
  public void stop()
  {
    this.m_timer.stop();
    this.m_running = false;
    try
    {
      if (this.m_replySubscriber != null)
      {
        this.m_replySubscriber.close();
        this.m_replySubscriber = null;
      }
      if (this.m_subscriber != null)
      {
        this.m_subscriber.close();
        this.m_subscriber = null;
      }
      if (this.m_replysession != null)
      {
        this.m_replysession.close();
        this.m_replysession = null;
      }
      if (this.m_session != null)
      {
        this.m_session.close();
        this.m_session = null;
      }
      if (this.m_connection != null)
      {
        this.m_connection.close();
        this.m_connection = null;
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("Exception: " + localJMSException.getMessage());
    }
    this.m_reqDest.setEnabled(true);
    this.m_msgsRead.setEnabled(true);
    this.m_startButton.setEnabled(true);
    this.m_stopButton.setEnabled(false);
    this.m_noLimit.setEnabled(true);
    this.m_replyDest.setEnabled(true);
    this.m_destwiz.setEnabled(true);
    this.m_optMenuItem.setEnabled(true);
    this.m_dumpMenuItem.setEnabled(true);
    this.m_pending.clear();
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          GemsReqReplyMonitor.this.showRequestMessageFrame();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    this.m_dumpMenuItem = new JMenuItem("Save Messages To File...");
    this.m_dumpMenuItem.addActionListener(new DumpToFile());
    localJMenu.add(this.m_dumpMenuItem);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsReqReplyMonitor.this.dispose();
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CutAction());
    localJMenuItem.setText("Cut");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CopyAction());
    localJMenuItem.setText("Copy");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(67, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.PasteAction());
    localJMenuItem.setText("Paste");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(86, 2));
    localJMenu.add(localJMenuItem);
    localJMenu.addSeparator();
    this.m_optMenuItem = localJMenu.add(new JMenuItem("Options..."));
    this.m_optMenuItem.addActionListener(new EditOptionsAction());
    localJMenuBar.add(localJMenu);
    localJMenu = new JMenu("View");
    localJMenu.setMnemonic(86);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("View Selected Request Message..."));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsReqReplyMonitor.this.showRequestMessageFrame();
      }
    });
    localJMenuItem = localJMenu.add(new JMenuItem("View Selected Reply Message..."));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsReqReplyMonitor.this.showReplyMessageFrame();
      }
    });
    return localJMenuBar;
  }
  
  public void showReplyMessageFrame()
  {
    Message localMessage = this.m_tableModel.getSelectedReplyMessage();
    if (localMessage != null)
    {
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, null, true, null, false);
      localGemsMessageFrame.populate(localMessage);
    }
    else
    {
      JOptionPane.showMessageDialog(this.m_frame, "There is no reply Message to view!", "View Reply Message", 1);
    }
  }
  
  public void showRequestMessageFrame()
  {
    Message localMessage = this.m_tableModel.getSelectedMessage();
    if (localMessage != null)
    {
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, null, true, null, false);
      localGemsMessageFrame.populate(localMessage);
    }
    else
    {
      JOptionPane.showMessageDialog(this.m_frame, "Select a Message to view!", "View Request Message", 1);
    }
  }
  
  public void dispose()
  {
    stop();
    super.dispose();
  }
  
  class DumpToFile
    implements ActionListener
  {
    DumpToFile() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        JFileChooser localJFileChooser = new JFileChooser();
        localJFileChooser.setApproveButtonText("Save");
        localJFileChooser.setDialogTitle("Save Messages To File (appends)");
        int i = localJFileChooser.showOpenDialog(GemsReqReplyMonitor.this.m_frame);
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          GemsReqReplyMonitor.this.m_tableModel.dumpMsgsToFile(localFile);
        }
      }
      catch (IOException localIOException)
      {
        JOptionPane.showMessageDialog(GemsReqReplyMonitor.this.m_frame, localIOException.getMessage(), "Error", 1);
        return;
      }
    }
  }
  
  class OnSyncReplyMessage
    implements MessageListener
  {
    OnSyncReplyMessage() {}
    
    public void onMessage(Message paramMessage)
    {
      try
      {
        if (paramMessage == null) {
          return;
        }
        MapMessage localMapMessage = (MapMessage)paramMessage;
        if (localMapMessage.itemExists("message_bytes"))
        {
          Message localMessage = Tibjms.createFromBytes(localMapMessage.getBytes("message_bytes"));
          if (GemsReqReplyMonitor.this.m_useMonitorMsgTimestamp) {
            localMessage.setJMSTimestamp(localMapMessage.getJMSTimestamp());
          }
          String str1 = localMessage.getJMSCorrelationID();
          if ((str1 != null) && (str1.length() > 0))
          {
            GemsReqReplyMonitor.this.m_mutex.acquire();
            GemsReqReplyMonitor.this.m_pending.put(str1, localMessage);
            GemsReqReplyMonitor.this.m_mutex.release();
            Gems.debug("GemsReqReplyMonitor.onRespMessage: CID: " + str1);
          }
          else
          {
            String str2 = localMessage.getJMSDestination().toString();
            if ((str2 != null) && (str2.length() > 0)) {
              if (str2.indexOf("$TMP$") >= 0)
              {
                GemsReqReplyMonitor.this.m_mutex.acquire();
                GemsReqReplyMonitor.this.m_pending.put(str2, localMessage);
                GemsReqReplyMonitor.this.m_mutex.release();
              }
              else
              {
                System.err.println("GemsReqReplyMonitor.onRespMessage: invalid response message, non-temporary replies must set JMSCorrelationID");
              }
            }
          }
        }
      }
      catch (JMSException localJMSException)
      {
        Gems.debug("GemsReqReplyMonitor.onRespMessage: Exception: " + localJMSException.toString());
      }
      catch (InterruptedException localInterruptedException)
      {
        Gems.debug("GemsReqReplyMonitor.onRespMessage: Exception: " + localInterruptedException.toString());
      }
      GemsReqReplyMonitor.this.m_mutex.release();
    }
  }
  
  class DestinationWizardAction
    implements ActionListener
  {
    DestinationWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsReqReplyMonitor.this.m_frame, GemsReqReplyMonitor.this.m_cn, GemsReqReplyMonitor.this.m_isQueue ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null) {
        GemsReqReplyMonitor.this.m_reqDest.setText(localGemsDestinationPicker.m_retDest.m_destName);
      }
    }
  }
  
  class EditOptionsAction
    implements ActionListener
  {
    EditOptionsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      new GemsBrowserOptionsDialog(GemsReqReplyMonitor.this.m_frame, "Edit Options", true);
      GemsReqReplyMonitor.this.m_timer.setDelay(Gems.getGems().getMsgReadDelay());
      GemsReqReplyMonitor.this.m_viewoldestFirst = Gems.getGems().getViewOldMessagesFirst();
      GemsReqReplyMonitor.this.m_useMonitorMsgTimestamp = Gems.getGems().getUseServerTimestamps();
      GemsReqReplyMonitor.this.m_failCount = (Gems.getGems().getRequestReplyTimeout() * 1000 / Gems.getGems().getMsgReadDelay());
      if (GemsReqReplyMonitor.this.m_failCount < 2L) {
        GemsReqReplyMonitor.this.m_failCount = 2L;
      }
    }
  }
  
  class StopPressed
    implements ActionListener
  {
    StopPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsReqReplyMonitor.this.stop();
    }
  }
  
  class StartPressed
    implements ActionListener
  {
    StartPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsReqReplyMonitor.this.start();
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    String m_lastmid = null;
    int m_repeatcount = 0;
    
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsReqReplyMonitor.this.m_running) {
        try
        {
          Message localMessage1 = GemsReqReplyMonitor.this.m_subscriber.receiveNoWait();
          String str2;
          String str3;
          if ((localMessage1 != null) && ((GemsReqReplyMonitor.this.m_noLimit.isSelected()) || (GemsReqReplyMonitor.this.m_msgs < GemsReqReplyMonitor.this.m_maxMsgs)))
          {
            localObject = (MapMessage)localMessage1;
            if (((MapMessage)localObject).itemExists("message_bytes"))
            {
              localMessage2 = Tibjms.createFromBytes(((MapMessage)localObject).getBytes("message_bytes"));
              if (GemsReqReplyMonitor.this.m_useMonitorMsgTimestamp) {
                localMessage2.setJMSTimestamp(((MapMessage)localObject).getJMSTimestamp());
              }
              int i = 1;
              str2 = localMessage2.getJMSCorrelationID();
              str3 = null;
              Destination localDestination = localMessage2.getJMSReplyTo();
              if (localDestination != null) {
                str3 = localDestination.toString();
              }
              Message localMessage3 = null;
              if ((str2 != null) && (str2.length() > 0))
              {
                GemsReqReplyMonitor.this.m_mutex.acquire();
                localMessage3 = (Message)GemsReqReplyMonitor.this.m_pending.remove(str2);
                GemsReqReplyMonitor.this.m_mutex.release();
              }
              else
              {
                if ((str3 != null) && (str3.length() > 0) && (str3.indexOf("$TMP$") >= 0))
                {
                  GemsReqReplyMonitor.this.m_mutex.acquire();
                  localMessage3 = (Message)GemsReqReplyMonitor.this.m_pending.remove(str3);
                  GemsReqReplyMonitor.this.m_mutex.release();
                }
                String str4 = localMessage2.getJMSMessageID();
                if ((localMessage3 == null) && (str4 != null))
                {
                  Gems.debug("GemsReqReplyMonitor.onReqMessage: checking pending replies for request MsgID:" + str4);
                  GemsReqReplyMonitor.this.m_mutex.acquire();
                  localMessage3 = (Message)GemsReqReplyMonitor.this.m_pending.remove(str4);
                  GemsReqReplyMonitor.this.m_mutex.release();
                }
              }
              if ((str3 == null) || (str3.length() == 0))
              {
                Gems.debug("GemsReqReplyMonitor.onReqMessage: request message: " + localMessage2.getJMSMessageID() + "  JMSReplyTo property not set");
                i = 0;
              }
              GemsReqReplyMonitor.this.m_tableModel.addRequestMessage(localMessage2, localMessage3, GemsReqReplyMonitor.this.m_viewoldestFirst);
              GemsReqReplyMonitor.this.m_msgs += 1;
            }
          }
          Object localObject = null;
          Message localMessage2 = null;
          localObject = GemsReqReplyMonitor.this.m_tableModel.getNextPendingRequest(GemsReqReplyMonitor.this.m_viewoldestFirst);
          if (localObject != null)
          {
            String str1 = ((Message)localObject).getJMSMessageID();
            if ((this.m_lastmid != null) && (str1 != null) && (this.m_lastmid.equals(str1)))
            {
              if (++this.m_repeatcount > GemsReqReplyMonitor.this.m_failCount)
              {
                GemsReqReplyMonitor.this.m_tableModel.timeoutRequestMessage((Message)localObject);
                this.m_repeatcount = 0;
                GemsReqReplyMonitor.this.m_timer.restart();
              }
            }
            else
            {
              this.m_lastmid = ((Message)localObject).getJMSMessageID();
              this.m_repeatcount = 0;
            }
            str2 = ((Message)localObject).getJMSCorrelationID();
            if ((str2 != null) && (str2.length() > 0))
            {
              GemsReqReplyMonitor.this.m_mutex.acquire();
              localMessage2 = (Message)GemsReqReplyMonitor.this.m_pending.remove(str2);
              GemsReqReplyMonitor.this.m_mutex.release();
              if (localMessage2 != null) {
                GemsReqReplyMonitor.this.m_tableModel.updateRequestMessage((Message)localObject, localMessage2);
              }
            }
            else
            {
              str3 = null;
              if (((Message)localObject).getJMSReplyTo() != null) {
                str3 = ((Message)localObject).getJMSReplyTo().toString();
              }
              if ((str3 != null) && (str3.length() > 0) && (str3.indexOf("$TMP$") >= 0))
              {
                GemsReqReplyMonitor.this.m_mutex.acquire();
                localMessage2 = (Message)GemsReqReplyMonitor.this.m_pending.remove(str3);
                GemsReqReplyMonitor.this.m_mutex.release();
                if (localMessage2 != null) {
                  GemsReqReplyMonitor.this.m_tableModel.updateRequestMessage((Message)localObject, localMessage2);
                }
              }
              if ((localMessage2 == null) && (str1 != null))
              {
                Gems.debug("GemsReqReplyMonitor.onReqMessage: checking pending request MsgID: " + str1);
                GemsReqReplyMonitor.this.m_mutex.acquire();
                localMessage2 = (Message)GemsReqReplyMonitor.this.m_pending.remove(str1);
                GemsReqReplyMonitor.this.m_mutex.release();
                if (localMessage2 != null) {
                  GemsReqReplyMonitor.this.m_tableModel.updateRequestMessage((Message)localObject, localMessage2);
                }
              }
            }
          }
          if ((!GemsReqReplyMonitor.this.m_noLimit.isSelected()) && (GemsReqReplyMonitor.this.m_msgs >= GemsReqReplyMonitor.this.m_maxMsgs) && (localObject == null)) {
            GemsReqReplyMonitor.this.stop();
          }
        }
        catch (JMSException localJMSException)
        {
          System.err.println("Exception: " + localJMSException.getMessage());
          GemsReqReplyMonitor.this.stop();
        }
        catch (InterruptedException localInterruptedException)
        {
          Gems.debug("GemsReqReplyMonitor.Exception: " + localInterruptedException.toString());
        }
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsReqReplyMonitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */