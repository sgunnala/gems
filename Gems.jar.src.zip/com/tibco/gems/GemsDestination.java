package com.tibco.gems;

public class GemsDestination
{
  public String m_destName;
  public DEST_TYPE m_destType;
  
  public GemsDestination(String paramString, DEST_TYPE paramDEST_TYPE)
  {
    this.m_destName = paramString;
    this.m_destType = paramDEST_TYPE;
  }
  
  public String toString()
  {
    return "[" + this.m_destType + "]" + this.m_destName;
  }
  
  public static enum DEST_TYPE
  {
    Queue,  Topic;
    
    private DEST_TYPE() {}
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDestination.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */