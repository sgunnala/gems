package com.tibco.gems;

import com.tibco.tibjms.admin.BridgeInfo;
import com.tibco.tibjms.admin.DestinationBridgeInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;
import java.util.regex.Pattern;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;
import javax.swing.table.JTableHeader;

public class GemsManageBridgesDialog
  extends JDialog
{
  JFrame m_frame;
  JPanel m_panel;
  GemsConnectionNode m_cn;
  protected String m_destType;
  protected String m_bridgeType;
  protected JTextField m_conn;
  protected JTextField m_pattern;
  protected JTextField m_filter;
  Pattern m_filterPattern = null;
  protected JButton m_okButton;
  protected JButton m_cancelButton;
  protected JComboBox m_destTypeCombo;
  JTable m_table;
  protected GemsBridgeTableModel m_tableModel;
  TableSorter m_sorter;
  
  public GemsManageBridgesDialog(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, String paramString1, String paramString2, String paramString3)
  {
    super(paramJFrame, Gems.getGems().getTitlePrefix() + "Manage Bridges", true);
    setDefaultCloseOperation(2);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_destType = paramString1;
    this.m_bridgeType = paramString3;
    String str = "Target";
    if (paramString3.equals("Target")) {
      str = "Source";
    }
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("EMS Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    localJPanel2.add(new JLabel(str + " Destination Type:"));
    this.m_destTypeCombo = new JComboBox();
    this.m_destTypeCombo.addItem("Queue");
    this.m_destTypeCombo.addItem("Topic");
    this.m_destTypeCombo.setSelectedItem(this.m_destType);
    localJPanel2.add(this.m_destTypeCombo);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    JLabel localJLabel2 = new JLabel(str + " Destination Pattern:", 11);
    if ((paramString2 == null) || (paramString2.length() == 0)) {
      paramString2 = ">";
    }
    this.m_pattern = new JTextField(paramString2, 32);
    localJLabel2.setLabelFor(this.m_pattern);
    localJPanel2.add(localJLabel2);
    JButton localJButton1 = new JButton("  Lookup...");
    localJButton1.addActionListener(new DestinationWizardAction());
    localJPanel3.add(this.m_pattern);
    localJPanel3.add(localJButton1);
    localJPanel2.add(localJPanel3);
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    JLabel localJLabel3 = new JLabel("Target Destination Filter:", 11);
    this.m_filter = new JTextField("", 32);
    this.m_filter.setEnabled(false);
    localJLabel3.setLabelFor(this.m_filter);
    localJPanel2.add(localJLabel3);
    JButton localJButton2 = new JButton("Set Filter...");
    localJButton2.addActionListener(new FilterWizardAction());
    localJPanel4.add(this.m_filter);
    localJPanel4.add(localJButton2);
    localJPanel2.add(localJPanel4);
    this.m_tableModel = new GemsBridgeTableModel(false, true, this);
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setRowSelectionAllowed(false);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(735, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel5 = new JPanel(true);
    localJPanel5.setLayout(new BoxLayout(localJPanel5, 0));
    Component localComponent = Box.createRigidArea(new Dimension(275, 10));
    localJPanel5.add(localComponent);
    this.m_okButton = new JButton("Find Bridges");
    this.m_okButton.addActionListener(new OkPressed());
    this.m_cancelButton = new JButton("Close");
    this.m_cancelButton.addActionListener(new CancelPressed());
    localJPanel5.add(this.m_okButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel5.add(localComponent);
    localJPanel5.add(this.m_cancelButton);
    localJPanel1.add(localJPanel5, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 4, 2, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    pack();
    setLocationRelativeTo(paramJFrame);
    show();
  }
  
  public void start()
  {
    this.m_tableModel.buildColumnHeaders();
    this.m_sorter.setSortingStatus(1, 1);
    this.m_tableModel.populateBridgeInfo(getBridgeInfo(), this.m_filterPattern);
  }
  
  public void stop()
  {
    dispose();
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if ((paramAnonymousMouseEvent.getClickCount() == 2) && (GemsManageBridgesDialog.this.m_table.getSelectedColumn() > 0)) {
          GemsManageBridgesDialog.this.m_tableModel.toggleSelectedRow();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsManageBridgesDialog.this.dispose();
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuBar.add(localJMenu);
    localJMenuItem = new JMenuItem("Select All");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(65, 2));
    localJMenuItem.addActionListener(new SelectAllAction());
    localJMenu.add(localJMenuItem);
    if (!Gems.getGems().getViewOnlyMode())
    {
      localJMenu.addSeparator();
      localJMenuItem = new JMenuItem("Create New Target...");
      localJMenuItem.addActionListener(new CreateBridgeAction());
      localJMenu.add(localJMenuItem);
      localJMenuItem = new JMenuItem("Destroy Selected Bridges");
      localJMenuItem.addActionListener(new DeleteBridgesAction());
      localJMenu.add(localJMenuItem);
    }
    return localJMenuBar;
  }
  
  public BridgeInfo[] getBridgeInfo()
  {
    try
    {
      return this.m_cn.getJmsAdmin().getBridges(this.m_destTypeCombo.getSelectedItem().equals("Queue") ? 1 : 2, this.m_pattern.getText());
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
    }
    return null;
  }
  
  public void createBridge(String paramString)
  {
    if (!Gems.getGems().isStandbyOpsAllowed(this.m_cn)) {
      return;
    }
    GemsCreateBridgeDialog localGemsCreateBridgeDialog = new GemsCreateBridgeDialog(null, this.m_cn, this.m_destTypeCombo.getSelectedItem().equals("Queue"), paramString);
    if (localGemsCreateBridgeDialog.createBridge()) {
      start();
    }
  }
  
  public void deleteSelectedBridges()
  {
    if (!Gems.getGems().isStandbyOpsAllowed(this.m_cn)) {
      return;
    }
    Vector localVector = this.m_tableModel.getSelectedBridges();
    if (localVector.size() <= 0) {
      return;
    }
    int i = JOptionPane.showConfirmDialog(null, "Destroy All Selected Bridges?", "Destroy Bridge", 0);
    if ((i == 0) && (this.m_cn != null) && (this.m_cn.m_adminConn != null))
    {
      for (int j = 0; j < localVector.size(); j++) {
        try
        {
          DestinationBridgeInfo localDestinationBridgeInfo = (DestinationBridgeInfo)localVector.get(j);
          this.m_cn.m_adminConn.destroyDestinationBridge(localDestinationBridgeInfo.getSourceType(), localDestinationBridgeInfo.getSourceName(), localDestinationBridgeInfo.getTargetType(), localDestinationBridgeInfo.getTargetName());
        }
        catch (TibjmsAdminException localTibjmsAdminException)
        {
          JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
          return;
        }
      }
      start();
    }
  }
  
  public void deleteBridge(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (!Gems.getGems().isStandbyOpsAllowed(this.m_cn)) {
      return;
    }
    int i = JOptionPane.showConfirmDialog(null, "<html>Destroy Bridge:<p>Source " + paramString2 + ":" + paramString1 + "<p>Target " + paramString4 + ": " + paramString3 + "</html>", "Destroy Bridge", 0);
    if ((i == 0) && (this.m_cn != null) && (this.m_cn.m_adminConn != null))
    {
      try
      {
        this.m_cn.m_adminConn.destroyDestinationBridge(paramString2.equals("Queue") ? 1 : 2, paramString1, paramString4.equals("Queue") ? 1 : 2, paramString3);
      }
      catch (TibjmsAdminException localTibjmsAdminException)
      {
        JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
        return;
      }
      start();
    }
  }
  
  public void dispose()
  {
    super.dispose();
  }
  
  class FilterWizardAction
    implements ActionListener
  {
    FilterWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsBrowserFilterDialog localGemsBrowserFilterDialog = new GemsBrowserFilterDialog(GemsManageBridgesDialog.this.m_frame, "Target Filter Editor:");
      Pattern localPattern = localGemsBrowserFilterDialog.getFilter(GemsManageBridgesDialog.this.m_filterPattern, "destinations");
      if (!localGemsBrowserFilterDialog.m_cancelled) {
        GemsManageBridgesDialog.this.m_filterPattern = localPattern;
      }
      if ((GemsManageBridgesDialog.this.m_filterPattern != null) && (GemsManageBridgesDialog.this.m_filterPattern.pattern().length() > 0))
      {
        GemsManageBridgesDialog.this.m_filter.setText(GemsManageBridgesDialog.this.m_filterPattern.pattern());
      }
      else
      {
        GemsManageBridgesDialog.this.m_filter.setText("");
        GemsManageBridgesDialog.this.m_filterPattern = null;
      }
    }
  }
  
  class DestinationWizardAction
    implements ActionListener
  {
    DestinationWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsManageBridgesDialog.this.m_frame, GemsManageBridgesDialog.this.m_cn, GemsManageBridgesDialog.this.m_destTypeCombo.getSelectedItem().equals("Queue") ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null) {
        GemsManageBridgesDialog.this.m_pattern.setText(localGemsDestinationPicker.m_retDest.m_destName);
      }
    }
  }
  
  class DeleteBridgesAction
    implements ActionListener
  {
    DeleteBridgesAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsManageBridgesDialog.this.deleteSelectedBridges();
    }
  }
  
  class CreateBridgeAction
    implements ActionListener
  {
    CreateBridgeAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsManageBridgesDialog.this.createBridge(GemsManageBridgesDialog.this.m_pattern.getText());
    }
  }
  
  class SelectAllAction
    implements ActionListener
  {
    SelectAllAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsManageBridgesDialog.this.m_tableModel.selectAllRows();
    }
  }
  
  class LookupAction
    implements ActionListener
  {
    LookupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsManageBridgesDialog.this.start();
    }
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsManageBridgesDialog.this.dispose();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsManageBridgesDialog.this.start();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsManageBridgesDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */