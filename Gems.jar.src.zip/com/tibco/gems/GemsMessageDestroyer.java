package com.tibco.gems;

import com.tibco.tibjms.TibjmsQueueConnectionFactory;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.Vector;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.Timer;

public class GemsMessageDestroyer
  extends JDialog
{
  Frame m_frame;
  JPanel m_panel;
  boolean m_running = false;
  boolean m_started = false;
  GemsConnectionNode m_cn;
  Timer m_timer = new Timer(100, new RefreshTimerAction());
  protected JTextField m_conn;
  protected JTextArea m_results;
  protected JButton m_startButton;
  protected JButton m_stopButton;
  protected JRadioButton m_adminAPIButton;
  protected JRadioButton m_JMSReadButton;
  protected Vector m_msgs;
  protected String m_queue;
  protected boolean m_adminAPI = true;
  int m_msgsNum = 0;
  QueueSession m_session = null;
  QueueConnection m_connection = null;
  
  public GemsMessageDestroyer(Frame paramFrame, GemsConnectionNode paramGemsConnectionNode, Vector paramVector, String paramString)
  {
    super(paramFrame, "Destroy Selected Messages:", true);
    this.m_queue = paramString;
    setLocationRelativeTo(paramFrame);
    setDefaultCloseOperation(2);
    this.m_frame = paramFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_msgs = paramVector;
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel = new JLabel("EMS Server:", 11);
    this.m_conn = new JTextField(this.m_cn.getName(), 32);
    this.m_conn.setEditable(false);
    localJLabel.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel);
    localJPanel2.add(this.m_conn);
    this.m_adminAPIButton = new JRadioButton("Use Admin API (requires track msg ids)");
    this.m_adminAPIButton.addActionListener(new adminAPIPressed());
    this.m_adminAPIButton.setSelected(true);
    this.m_JMSReadButton = new JRadioButton("Use JMS Read");
    this.m_JMSReadButton.addActionListener(new JMSReadPressed());
    localJPanel2.add(this.m_JMSReadButton);
    localJPanel2.add(this.m_adminAPIButton);
    ButtonGroup localButtonGroup = new ButtonGroup();
    localButtonGroup.add(this.m_JMSReadButton);
    localButtonGroup.add(this.m_adminAPIButton);
    this.m_results = new JTextArea("");
    this.m_results.append("Press Start to destroy " + this.m_msgs.size() + " message(s) on EMS: " + this.m_cn.getName() + "\n");
    this.m_results.setEditable(false);
    JScrollPane localJScrollPane = new JScrollPane(this.m_results);
    localJScrollPane.setPreferredSize(new Dimension(430, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    Component localComponent = Box.createRigidArea(new Dimension(175, 10));
    localJPanel3.add(localComponent);
    this.m_startButton = new JButton("Start");
    this.m_startButton.addActionListener(new StartPressed());
    this.m_stopButton = new JButton("Close");
    this.m_stopButton.addActionListener(new StopPressed());
    localJPanel3.add(this.m_startButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel3.add(localComponent);
    localJPanel3.add(this.m_stopButton);
    localJPanel1.add(localJPanel3, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 2, 5, 5, 5, 5);
    pack();
    show();
  }
  
  public void start()
  {
    this.m_running = true;
    this.m_startButton.setEnabled(false);
    this.m_adminAPIButton.setEnabled(false);
    this.m_JMSReadButton.setEnabled(false);
    this.m_stopButton.setText("Stop");
    if (!this.m_started)
    {
      this.m_msgsNum = this.m_msgs.size();
      this.m_started = true;
    }
    if (this.m_adminAPI) {
      this.m_timer.start();
    } else {
      try
      {
        TibjmsQueueConnectionFactory localTibjmsQueueConnectionFactory = new TibjmsQueueConnectionFactory(this.m_cn.m_url, null, this.m_cn.m_sslParams);
        this.m_connection = localTibjmsQueueConnectionFactory.createQueueConnection(this.m_cn.m_user, this.m_cn.m_password);
        this.m_session = this.m_connection.createQueueSession(false, 1);
        this.m_connection.start();
        this.m_timer.start();
      }
      catch (JMSException localJMSException)
      {
        JOptionPane.showMessageDialog(this.m_frame, localJMSException.getMessage(), "Error", 1);
        stop(false);
      }
    }
  }
  
  public void stop(boolean paramBoolean)
  {
    this.m_timer.stop();
    this.m_running = false;
    try
    {
      if (this.m_session != null)
      {
        this.m_session.close();
        this.m_session = null;
      }
      if (this.m_connection != null)
      {
        this.m_connection.close();
        this.m_connection = null;
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("Exception: " + localJMSException.getMessage());
    }
    if (paramBoolean)
    {
      this.m_startButton.setEnabled(true);
      this.m_startButton.setText("Continue");
    }
    this.m_stopButton.setText("Close");
  }
  
  public void reset()
  {
    this.m_started = false;
    this.m_startButton.setText("Start");
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsMessageDestroyer.this.dispose();
      }
    });
    return localJMenuBar;
  }
  
  public void dispose()
  {
    stop(false);
    super.dispose();
  }
  
  class adminAPIPressed
    implements ActionListener
  {
    adminAPIPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageDestroyer.this.m_adminAPI = true;
    }
  }
  
  class JMSReadPressed
    implements ActionListener
  {
    JMSReadPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageDestroyer.this.m_adminAPI = false;
    }
  }
  
  class StopPressed
    implements ActionListener
  {
    StopPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsMessageDestroyer.this.m_stopButton.getText().equals("Close")) {
        GemsMessageDestroyer.this.dispose();
      } else {
        GemsMessageDestroyer.this.stop(true);
      }
    }
  }
  
  class StartPressed
    implements ActionListener
  {
    StartPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageDestroyer.this.start();
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsMessageDestroyer.this.m_running) {
        try
        {
          if (GemsMessageDestroyer.this.m_msgsNum <= 0)
          {
            GemsMessageDestroyer.this.m_results.append("Done\n");
            GemsMessageDestroyer.this.stop(false);
          }
          else
          {
            Message localMessage1 = (Message)GemsMessageDestroyer.this.m_msgs.elementAt(--GemsMessageDestroyer.this.m_msgsNum);
            if (localMessage1 != null)
            {
              GemsMessageDestroyer.this.m_results.append("Destroying message: " + localMessage1.getJMSMessageID() + "\n");
              String str = localMessage1.getJMSMessageID();
              if ((str == null) || (str.length() == 0) || (str.startsWith("tmpId")))
              {
                GemsMessageDestroyer.this.m_results.append("Error: Cannot destroy message. Message has no JMSMessageID\n");
                GemsMessageDestroyer.this.stop(true);
              }
              else if (GemsMessageDestroyer.this.m_adminAPI)
              {
                GemsMessageDestroyer.this.m_cn.removeMessage(localMessage1);
              }
              else
              {
                Queue localQueue = GemsMessageDestroyer.this.m_session.createQueue(GemsMessageDestroyer.this.m_queue);
                QueueReceiver localQueueReceiver = GemsMessageDestroyer.this.m_session.createReceiver(localQueue, "JMSMessageID='" + str + "'");
                Message localMessage2 = localQueueReceiver.receive(2000L);
                if (localMessage2 != null) {
                  GemsMessageDestroyer.this.m_results.append(str + " successfully read from queue " + GemsMessageDestroyer.this.m_queue + "\n");
                } else {
                  GemsMessageDestroyer.this.m_results.append(str + " time out from read after 2 seconds\n");
                }
                localQueueReceiver.close();
              }
            }
            else
            {
              GemsMessageDestroyer.this.m_results.append("Error: null message\n");
              GemsMessageDestroyer.this.stop(true);
            }
          }
        }
        catch (Exception localException)
        {
          GemsMessageDestroyer.this.m_results.append("Exception: " + localException.getMessage() + "\n");
          GemsMessageDestroyer.this.stop(true);
        }
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsMessageDestroyer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */