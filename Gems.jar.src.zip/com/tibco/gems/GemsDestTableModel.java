package com.tibco.gems;

import com.tibco.tibjms.admin.DestinationInfo;
import java.awt.Color;
import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class GemsDestTableModel
  extends DefaultTableModel
{
  JTable m_table;
  boolean m_isEditable;
  boolean m_showCheckbox = false;
  Object m_obj = new Object();
  MyRenderer m_renderer = new MyRenderer();
  MyCheckboxRenderer m_checkRenderer = new MyCheckboxRenderer();
  SimpleDateFormat dateFormatMillis = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
  
  public GemsDestTableModel(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.m_isEditable = paramBoolean1;
    this.m_showCheckbox = paramBoolean2;
  }
  
  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject != null) {
      return localObject.getClass();
    }
    return String.class;
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    if ((this.m_showCheckbox) && (paramInt2 < 1)) {
      return true;
    }
    return this.m_isEditable;
  }
  
  public Vector getSelectedDestinations()
  {
    Vector localVector = new Vector();
    if (this.m_showCheckbox) {
      for (int i = 0; i < getRowCount(); i++) {
        if (((Boolean)this.m_table.getValueAt(i, 0)).booleanValue()) {
          localVector.add((String)this.m_table.getValueAt(i, 1));
        }
      }
    }
    return localVector;
  }
  
  public void selectAllRows()
  {
    if (this.m_showCheckbox) {
      for (int i = 0; i < getRowCount(); i++) {
        this.m_table.setValueAt(new Boolean(true), i, 0);
      }
    }
  }
  
  public void toggleSelectedRow()
  {
    this.m_table.setValueAt(new Boolean(!((Boolean)this.m_table.getValueAt(this.m_table.getSelectedRow(), 0)).booleanValue()), this.m_table.getSelectedRow(), 0);
  }
  
  public void buildColumnHeaders()
  {
    setRowCount(0);
    setColumnCount(0);
    this.m_table.setAutoResizeMode(0);
    if (Gems.getGems().getColourPendingMsgs()) {
      this.m_table.setDefaultRenderer(Long.class, this.m_renderer);
    }
    this.m_table.setDefaultRenderer(String.class, this.m_renderer);
    this.m_table.setDefaultRenderer(Boolean.class, this.m_checkRenderer);
    String[] arrayOfString;
    if (this.m_showCheckbox) {
      arrayOfString = new String[] { "Sel", "Destination", "ConsumerCount", "PendingMsgCount", "PendingMsgSize" };
    } else {
      arrayOfString = new String[] { "Destination", "ConsumerCount", "PendingMsgCount", "PendingMsgSize" };
    }
    setColumnIdentifiers(arrayOfString);
    if (this.m_showCheckbox) {
      this.m_table.getColumn("Sel").setPreferredWidth(30);
    }
    this.m_table.getColumn("Destination").setPreferredWidth(250);
    this.m_table.getColumn("ConsumerCount").setPreferredWidth(110);
    this.m_table.getColumn("PendingMsgCount").setPreferredWidth(120);
    this.m_table.getColumn("PendingMsgSize").setPreferredWidth(120);
  }
  
  public void addDestination(DestinationInfo paramDestinationInfo)
  {
    if (paramDestinationInfo != null)
    {
      if (paramDestinationInfo.getName().equals(">")) {
        return;
      }
      if (paramDestinationInfo.getName().startsWith("$sys")) {
        return;
      }
      Object[] arrayOfObject;
      if (this.m_showCheckbox) {
        arrayOfObject = new Object[] { new Boolean(false), paramDestinationInfo.getName(), new Long(paramDestinationInfo.getConsumerCount()), new Long(paramDestinationInfo.getPendingMessageCount()), new Long(paramDestinationInfo.getPendingMessageSize()) };
      } else {
        arrayOfObject = new Object[] { paramDestinationInfo.getName(), new Long(paramDestinationInfo.getConsumerCount()), new Long(paramDestinationInfo.getPendingMessageCount()), new Long(paramDestinationInfo.getPendingMessageSize()) };
      }
      addRow(arrayOfObject);
    }
  }
  
  public void populateDestinationInfo(DestinationInfo[] paramArrayOfDestinationInfo)
  {
    setRowCount(0);
    if (paramArrayOfDestinationInfo == null) {
      return;
    }
    for (int i = 0; i < paramArrayOfDestinationInfo.length; i++) {
      addDestination(paramArrayOfDestinationInfo[i]);
    }
  }
  
  class MyRenderer
    extends DefaultTableCellRenderer
  {
    public MyRenderer()
    {
      setToolTipText("Select checkboxes of destinations to purge");
    }
    
    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      Component localComponent = super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
      if ((paramObject instanceof Long))
      {
        setHorizontalAlignment(4);
        if ((((Long)paramObject).longValue() > 0L) && (paramJTable.getColumnName(paramInt2).startsWith("Pending"))) {
          localComponent.setBackground(Color.orange);
        } else if (paramBoolean1) {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        } else {
          localComponent.setBackground(Color.white);
        }
      }
      else
      {
        setHorizontalAlignment(2);
        if (paramBoolean1) {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        } else {
          localComponent.setBackground(Color.white);
        }
      }
      return localComponent;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDestTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */