package com.tibco.gems;

import com.tibco.tibjms.Tibjms;
import com.tibco.tibjms.admin.RouteInfo;
import com.tibco.tibjms.admin.ServerInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import com.tibco.tibjms.version;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import javax.jms.Message;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.JViewport;
import javax.swing.KeyStroke;
import javax.swing.SpringLayout;
import javax.swing.Timer;
import javax.swing.UIDefaults;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.metal.MetalIconFactory;
import javax.swing.text.DefaultEditorKit.CopyAction;
import javax.swing.text.DefaultEditorKit.CutAction;
import javax.swing.text.DefaultEditorKit.PasteAction;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Gems
{
  static Gems m_gems;
  final String m_version = "Gems v3.4";
  String m_jreVersion = null;
  JFrame m_frame;
  JMenuBar m_menuBar;
  protected JTree m_tree;
  protected JTabbedPane m_tabPane;
  protected GemsTreeModel m_treeModel;
  public ImageIcon m_icon = null;
  public boolean m_useMetalIcons = true;
  protected GemsServerMonitorPanel m_servMonitorPanel;
  protected GemsServerInfoPanel m_servPanel;
  protected GemsConnectionPanel m_connPanel;
  protected GemsDetailsPanel m_detailsPanel;
  protected GemsMessagePanel m_messagePanel;
  protected int m_lastSelectedTab = 0;
  public int m_displayRefresh = 0;
  protected Properties m_props;
  final String p_maxMessageView = "MaxMessageView";
  final String p_viewOldMessagesFirst = "ViewOldMessagesFirst";
  final String p_queueNamePattern = "QueueNamePattern";
  final String p_topicNamePattern = "TopicNamePattern";
  final String p_showExtendedProperties = "ShowExtendedProperties";
  final String p_displayRefresh = "DisplayRefresh";
  final String p_showMonitorTopics = "ShowMonitorTopics";
  final String p_showRootNode = "ShowRootNode";
  final String p_screenWidth = "DisplayWidth";
  final String p_screenHeight = "DisplayHeight";
  final String p_msgReadDelay = "MsgReadDelay";
  final String p_requestReplyTimeout = "RequestReplyTimeout";
  final String p_colourPendingMsgs = "ColourPendingMsgs";
  final String p_serverConfigFile = "ServerConfigFile";
  final String p_viewOnlyMode = "ViewOnlyMode";
  final String p_lookAndFeel = "LookAndFeel";
  final String p_permType = "PermType";
  final String p_debug = "Debug";
  final String p_showTotals = "ShowTotals";
  final String p_maxDisplayBytes = "MaxDisplayBytes";
  final String p_showClientId = "ShowClientId";
  final String p_hideViews = "HideViews";
  final String p_connectTimeout = "ConnectTimeout";
  final String p_SSTimeout = "SSTimeout";
  final String p_allowStandbyOperations = "AllowStandbyOperations";
  final String p_adminTimeout = "AdminTimeout";
  final String p_useServerTimestamps = "UseServerTimestamps";
  final String p_showPathInTitleBar = "ShowPathInTitleBar";
  final String p_showRootInTitleBar = "ShowRootInTitleBar";
  final String p_detailPaneColWidths = "DetailPanelColWidths";
  final String p_logDateTimeFormat = "LogDateTimeFormat";
  final String p_CSVFileDelimiter = "CSVFileDelimiter";
  final String p_maxQueues = "MaxQueues";
  final String p_maxTopics = "MaxTopics";
  final String p_serverInfoColPositions = "ServerInfoColPositions";
  protected boolean m_lock = false;
  protected boolean m_serviceMenu = false;
  protected boolean m_substationMenu = false;
  protected boolean m_showEvents = false;
  protected JCheckBoxMenuItem m_autoRefresh = null;
  protected JCheckBoxMenuItem m_showTotals = null;
  protected Timer m_timer = null;
  protected Mutex m_xlock = new Mutex();
  
  public Gems(String[] paramArrayOfString)
  {
    if (paramArrayOfString.length > 0) {
      initProps(paramArrayOfString[0]);
    } else {
      initProps(null);
    }
  }
  
  public void start()
  {
    this.m_jreVersion = System.getProperty("java.version");
    debug("JRE Version = " + this.m_jreVersion);
    System.err.print("TIBCO Gems v3.4");
    version.main(null);
    debug("Default socketConnectionTimeout: " + String.valueOf(Tibjms.getSocketConnectTimeout()));
    Tibjms.setSocketConnectTimeout(getConnectTimeout());
    debug("Setting socketConnectionTimeout: " + String.valueOf(getConnectTimeout()));
    Toolkit.getDefaultToolkit().getSystemEventQueue().push(new TCPopupEventQueue());
    buildFrame();
    treeSelectionChange(getSelectedNode(), false);
    if (this.m_displayRefresh > 0)
    {
      this.m_timer = new Timer(this.m_displayRefresh * 1000 + 1000, new RefreshTimerAction());
      this.m_timer.start();
      this.m_timer.setInitialDelay(200);
    }
    long l = this.m_displayRefresh / 5;
    if (l < 1L) {
      l = 1L;
    }
    ConnectThread localConnectThread = new ConnectThread(this.m_displayRefresh);
    localConnectThread.start();
  }
  
  public void buildFrame()
  {
    try
    {
      String str1 = getLookAndFeel();
      if ((str1 == null) || (str1.length() == 0))
      {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
      }
      else
      {
        UIManager.setLookAndFeel(str1);
        if (str1.equals("com.sun.java.swing.plaf.windows.WindowsLookAndFeel")) {
          this.m_useMetalIcons = true;
        }
        UIDefaults localUIDefaults = UIManager.getDefaults();
        if (getDebug())
        {
          localObject1 = localUIDefaults.keys();
          while (((Enumeration)localObject1).hasMoreElements())
          {
            localObject2 = ((Enumeration)localObject1).nextElement();
            localObject3 = localUIDefaults.get(localObject2);
            System.out.println("[" + localObject2.toString() + "]:[" + (null != localObject3 ? localObject3.toString() : "(null)") + "]");
          }
        }
      }
    }
    catch (Exception localException1)
    {
      System.err.println("Error loading L&F: " + localException1);
      try
      {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
      }
      catch (Exception localException2) {}
    }
    JComponent localJComponent1 = buildTreeViewFromFile(getServerConfigFile());
    if (localJComponent1 == null) {
      localJComponent1 = buildTreeView();
    }
    JComponent localJComponent2 = buildTabbedView();
    this.m_menuBar = constructMenuBar();
    Object localObject1 = new JPanel(true);
    Object localObject2 = getTitlePrefix() + "Gems v3.4";
    if (getViewOnlyMode()) {
      localObject2 = (String)localObject2 + " (view only)";
    }
    this.m_frame = new JFrame((String)localObject2);
    this.m_frame.getContentPane().add("Center", (Component)localObject1);
    this.m_frame.setJMenuBar(this.m_menuBar);
    this.m_frame.setBackground(Color.lightGray);
    Object localObject3 = new JSplitPane(1, localJComponent1, localJComponent2);
    ((JSplitPane)localObject3).setOneTouchExpandable(true);
    ((JSplitPane)localObject3).setDividerLocation(200);
    localJComponent1.setMinimumSize(new Dimension(100, 50));
    localJComponent2.setMinimumSize(new Dimension(100, 50));
    ((JPanel)localObject1).setLayout(new BorderLayout());
    ((JPanel)localObject1).add("Center", (Component)localObject3);
    this.m_frame.addWindowListener(new WindowAdapter()
    {
      public void windowClosing(WindowEvent paramAnonymousWindowEvent)
      {
        System.exit(0);
      }
    });
    this.m_tree.addTreeSelectionListener(this.m_treeModel);
    this.m_frame.setSize(new Dimension(getScreenWidth(), getScreenHeight()));
    String str2 = "/images/gem.jpg";
    URL localURL = getClass().getResource(str2);
    if (localURL != null) {
      this.m_icon = new ImageIcon(localURL);
    } else {
      this.m_icon = new ImageIcon("gem.jpg");
    }
    if (this.m_icon != null) {
      this.m_frame.setIconImage(this.m_icon.getImage());
    }
    this.m_frame.setVisible(true);
  }
  
  public void setTitle()
  {
    String str = getTitlePrefix() + "Gems v3.4";
    if (getViewOnlyMode()) {
      str = str + " (view only)";
    }
    this.m_frame.setTitle(str);
  }
  
  public JComponent buildTreeView()
  {
    IconNode localIconNode = new IconNode("EMS-Servers");
    String str = "/images/gem16.gif";
    URL localURL = getClass().getResource(str);
    if (localURL != null)
    {
      localObject = new ImageIcon(localURL);
      if (((ImageIcon)localObject).getImageLoadStatus() == 8) {
        localIconNode.setIcon((Icon)localObject);
      }
    }
    else
    {
      localObject = new ImageIcon("gem16.jpg");
      if (((ImageIcon)localObject).getImageLoadStatus() == 8) {
        localIconNode.setIcon((Icon)localObject);
      }
    }
    this.m_treeModel = new GemsTreeModel(localIconNode);
    this.m_tree = new JTree(this.m_treeModel);
    this.m_treeModel.m_tree = this.m_tree;
    this.m_treeModel.m_gems = this;
    this.m_tree.setCellRenderer(new IconNodeRenderer());
    this.m_tree.putClientProperty("JTree.icons", makeIcons());
    this.m_tree.setRowHeight(-1);
    this.m_tree.getSelectionModel().setSelectionMode(1);
    this.m_tree.expandRow(0);
    this.m_treeModel.newJMSConnection("EMS Connection");
    Object localObject = new JScrollPane();
    ((JScrollPane)localObject).getViewport().add(this.m_tree);
    return (JComponent)localObject;
  }
  
  public JComponent buildTreeViewFromFile(String paramString)
  {
    DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
    DocumentBuilder localDocumentBuilder;
    try
    {
      localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
    }
    catch (ParserConfigurationException localParserConfigurationException)
    {
      System.err.println("Exception: " + localParserConfigurationException.getMessage());
      return null;
    }
    try
    {
      Document localDocument = localDocumentBuilder.parse(new File(paramString));
      Element localElement = localDocument.getDocumentElement();
      IconNode localIconNode = new IconNode(localElement.getNodeName());
      String str = localElement.getAttribute("icon");
      if ((str != null) && (str.length() > 0))
      {
        localObject1 = new ImageIcon(str);
        if (((ImageIcon)localObject1).getImageLoadStatus() == 8) {
          localIconNode.setIcon((Icon)localObject1);
        }
      }
      else
      {
        localObject1 = "/images/gem16.jpg";
        localObject2 = getClass().getResource((String)localObject1);
        if (localObject2 != null)
        {
          localObject3 = new ImageIcon((URL)localObject2);
          if (((ImageIcon)localObject3).getImageLoadStatus() == 8) {
            localIconNode.setIcon((Icon)localObject3);
          }
        }
        else
        {
          localObject3 = new ImageIcon("gem16.jpg");
          if (((ImageIcon)localObject3).getImageLoadStatus() == 8) {
            localIconNode.setIcon((Icon)localObject3);
          }
        }
      }
      this.m_treeModel = new GemsTreeModel(localIconNode);
      this.m_tree = new JTree(this.m_treeModel);
      this.m_treeModel.m_tree = this.m_tree;
      this.m_treeModel.m_gems = this;
      this.m_tree.setCellRenderer(new IconNodeRenderer());
      this.m_tree.putClientProperty("JTree.icons", makeIcons());
      this.m_tree.setRowHeight(-1);
      this.m_tree.getSelectionModel().setSelectionMode(1);
      this.m_tree.setRootVisible(getShowRootNode());
      Object localObject1 = buildNodes(localElement, localIconNode);
      this.m_tree.expandPath(new TreePath(localIconNode.getPath()));
      Object localObject2 = localIconNode.children();
      if (((Enumeration)localObject2).hasMoreElements())
      {
        localObject3 = (DefaultMutableTreeNode)((Enumeration)localObject2).nextElement();
        if (localObject3 != null) {
          this.m_tree.expandPath(new TreePath(((DefaultMutableTreeNode)localObject3).getPath()));
        }
      }
      this.m_tree.setSelectionPath(new TreePath(localIconNode.getPath()));
      Object localObject3 = new JScrollPane();
      ((JScrollPane)localObject3).getViewport().add(this.m_tree);
      return (JComponent)localObject3;
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return null;
  }
  
  public DefaultMutableTreeNode buildNodes(Node paramNode, DefaultMutableTreeNode paramDefaultMutableTreeNode)
  {
    Object localObject1 = null;
    try
    {
      NodeList localNodeList = paramNode.getChildNodes();
      if (localNodeList != null) {
        for (int i = 0; i < localNodeList.getLength(); i++)
        {
          Node localNode1 = localNodeList.item(i);
          if (localNode1.getNodeType() == 1)
          {
            Object localObject2;
            String str1;
            Object localObject3;
            if (localNode1.getNodeName().equals("ConnectionNode"))
            {
              localObject2 = ((Element)localNode1).getAttribute("alias");
              if ((localObject2 == null) || (((String)localObject2).length() == 0)) {
                localObject2 = ((Element)localNode1).getAttribute("name");
              }
              str1 = ((Element)localNode1).getAttribute("url");
              localObject3 = ((Element)localNode1).getAttribute("user");
              String str2 = ((Element)localNode1).getAttribute("password");
              String str3 = ((Element)localNode1).getAttribute("autoConnect");
              String str4 = ((Element)localNode1).getAttribute("logDir");
              String str5 = ((Element)localNode1).getAttribute("logServerInfo");
              GemsConnectionNode.LOG_TYPE localLOG_TYPE = null;
              if ((str5 != null) && (str5.length() > 0))
              {
                if (str5.equals(GemsConnectionNode.LOG_TYPE.Never.toString()))
                {
                  localLOG_TYPE = GemsConnectionNode.LOG_TYPE.Never;
                }
                else if (str5.equals(GemsConnectionNode.LOG_TYPE.WarnLimits.toString()))
                {
                  localLOG_TYPE = GemsConnectionNode.LOG_TYPE.WarnLimits;
                }
                else if (str5.equals(GemsConnectionNode.LOG_TYPE.ErrorLimits.toString()))
                {
                  localLOG_TYPE = GemsConnectionNode.LOG_TYPE.ErrorLimits;
                }
                else if (str5.equals(GemsConnectionNode.LOG_TYPE.Always.toString()))
                {
                  localLOG_TYPE = GemsConnectionNode.LOG_TYPE.Always;
                }
                else
                {
                  System.err.println("Error: Illegal logServerInfo attribute: " + str5 + " for " + (String)localObject2 + " must be one of: Never, WarnLimits, ErrorLimits, Always. Using WarnLimits");
                  localLOG_TYPE = GemsConnectionNode.LOG_TYPE.WarnLimits;
                }
              }
              else
              {
                System.err.println("Warning: No logServerInfo attribute specified for " + (String)localObject2 + " logging of ServerInfo will be disabled (see servers.xml for details)");
                localLOG_TYPE = GemsConnectionNode.LOG_TYPE.Never;
              }
              boolean bool1 = true;
              if ((str3 != null) && (str3.length() > 0)) {
                bool1 = Boolean.valueOf(str3).booleanValue();
              }
              if (localObject2 == null) {
                localObject2 = "EMS Connection";
              }
              if (str1 == null) {
                str1 = "tcp://localhost:7222";
              }
              if (localObject3 == null) {
                localObject2 = "admin";
              }
              if (str4 == null) {
                str4 = "./log";
              }
              GemsConnectionNode localGemsConnectionNode = new GemsConnectionNode((String)localObject2, str1, (String)localObject3, str2, 15L, bool1, localLOG_TYPE, str4);
              String str6 = ((Element)localNode1).getAttribute("icon");
              if (str6 != null)
              {
                localObject4 = new ImageIcon(str6);
                if (((ImageIcon)localObject4).getImageLoadStatus() == 8) {
                  localGemsConnectionNode.setIcon((Icon)localObject4);
                }
              }
              paramDefaultMutableTreeNode.add(localGemsConnectionNode);
              Object localObject4 = localNode1.getChildNodes();
              for (int j = 0; (localObject4 != null) && (j < ((NodeList)localObject4).getLength()); j++)
              {
                Node localNode2 = ((NodeList)localObject4).item(j);
                if (localNode2.getNodeName().equals("WarnLimits"))
                {
                  localGemsConnectionNode.addWarnLimits(localNode2);
                }
                else if (localNode2.getNodeName().equals("ErrorLimits"))
                {
                  localGemsConnectionNode.addErrorLimits(localNode2);
                }
                else if (localNode2.getNodeName().equals("SSLParam"))
                {
                  localGemsConnectionNode.addSSLParam(localNode2);
                }
                else
                {
                  String str7;
                  long l1;
                  Object localObject5;
                  int k;
                  Object localObject6;
                  if (localNode2.getNodeName().equals("EventMonitor"))
                  {
                    str7 = ((Element)localNode2).getAttribute("maxDisplayedEvents");
                    l1 = 100L;
                    try
                    {
                      l1 = Long.parseLong(str7);
                    }
                    catch (Exception localException2)
                    {
                      System.err.println("Exception: " + localException2.getMessage());
                    }
                    String str8 = ((Element)localNode2).getAttribute("enabled");
                    boolean bool2 = false;
                    if ((str8 != null) && (str8.length() > 0)) {
                      bool2 = Boolean.valueOf(str8).booleanValue();
                    }
                    localGemsConnectionNode.addEventMonitor(l1, bool2);
                    this.m_showEvents = true;
                    localObject5 = localNode2.getChildNodes();
                    for (k = 0; (localObject5 != null) && (k < ((NodeList)localObject5).getLength()); k++)
                    {
                      Node localNode3 = ((NodeList)localObject5).item(k);
                      if (localNode3.getNodeName().equals("EventSubscription"))
                      {
                        String str11 = ((Element)localNode3).getAttribute("monitorTopic");
                        localObject6 = ((Element)localNode3).getAttribute("selector");
                        if (str11 != null) {
                          localGemsConnectionNode.addEventSubscription(str11, (String)localObject6);
                        }
                      }
                    }
                  }
                  else if (localNode2.getNodeName().equals("ServiceMonitor"))
                  {
                    str7 = ((Element)localNode2).getAttribute("period");
                    l1 = 60L;
                    try
                    {
                      l1 = Long.parseLong(str7);
                    }
                    catch (Exception localException3)
                    {
                      System.err.println("Exception: " + localException3.getMessage());
                    }
                    String str9 = ((Element)localNode2).getAttribute("tmpQueueReplies");
                    String str10 = ((Element)localNode2).getAttribute("tmpTopicReplies");
                    localObject5 = ((Element)localNode2).getAttribute("enabled");
                    k = 0;
                    boolean bool4 = false;
                    boolean bool5 = false;
                    boolean bool3;
                    if ((str9 != null) && (str9.length() > 0)) {
                      bool3 = Boolean.valueOf(str9).booleanValue();
                    }
                    if ((str10 != null) && (str10.length() > 0)) {
                      bool4 = Boolean.valueOf(str10).booleanValue();
                    }
                    if ((localObject5 != null) && (((String)localObject5).length() > 0)) {
                      bool5 = Boolean.valueOf((String)localObject5).booleanValue();
                    }
                    localGemsConnectionNode.addServiceTable(l1, bool3, bool4, bool5);
                    this.m_serviceMenu = true;
                    localObject6 = localNode2.getChildNodes();
                    for (int m = 0; (localObject6 != null) && (m < ((NodeList)localObject6).getLength()); m++)
                    {
                      Node localNode4 = ((NodeList)localObject6).item(m);
                      if (localNode4.getNodeName().equals("Service"))
                      {
                        String str12 = ((Element)localNode4).getAttribute("name");
                        String str13 = ((Element)localNode4).getAttribute("requestQueue");
                        String str14 = ((Element)localNode4).getAttribute("requestTopic");
                        String str15 = ((Element)localNode4).getAttribute("replyQueue");
                        String str16 = ((Element)localNode4).getAttribute("replyTopic");
                        long l2 = 1000L;
                        String str17 = ((Element)localNode4).getAttribute("responseTimeLimit");
                        if ((str17 != null) && (str17.length() > 0)) {
                          try
                          {
                            l2 = Long.parseLong(str17);
                          }
                          catch (Exception localException4)
                          {
                            System.err.println("Exception: " + localException4.getMessage());
                          }
                        }
                        if ((str12 != null) && ((str13 != null) || (str14 != null))) {
                          localGemsConnectionNode.addService(str12, str13 != null ? str13 : str14, str13 != null, str15 != null ? str15 : str16, str15 != null, l2);
                        }
                      }
                    }
                  }
                  else if (localNode2.getNodeName().equals("SS-Node"))
                  {
                    localGemsConnectionNode.addSubStation(localNode2);
                    this.m_substationMenu = true;
                  }
                }
              }
              if (localObject1 == null) {
                localObject1 = localGemsConnectionNode;
              }
              if (bool1) {
                localGemsConnectionNode.connect();
              }
            }
            else
            {
              localObject2 = new IconNode(localNode1.getNodeName());
              str1 = ((Element)localNode1).getAttribute("icon");
              if (str1 != null)
              {
                localObject3 = new ImageIcon(str1);
                if (((ImageIcon)localObject3).getImageLoadStatus() == 8) {
                  ((IconNode)localObject2).setIcon((Icon)localObject3);
                }
              }
              paramDefaultMutableTreeNode.add((MutableTreeNode)localObject2);
              localObject3 = buildNodes(localNode1, (DefaultMutableTreeNode)localObject2);
              if (localObject1 == null) {
                localObject1 = localObject3;
              }
            }
          }
        }
      }
    }
    catch (Exception localException1)
    {
      System.err.println("Exception: " + localException1.getMessage());
      localException1.printStackTrace();
      return null;
    }
    return (DefaultMutableTreeNode)localObject1;
  }
  
  private Hashtable makeIcons()
  {
    Hashtable localHashtable = new Hashtable();
    localHashtable.put("floppyDrive", MetalIconFactory.getTreeFloppyDriveIcon());
    localHashtable.put("hardDrive", MetalIconFactory.getTreeHardDriveIcon());
    localHashtable.put("computer", MetalIconFactory.getTreeComputerIcon());
    localHashtable.put("queue", TextIcons.getIcon("queue"));
    localHashtable.put("routedqueue", TextIcons.getIcon("routedqueue"));
    localHashtable.put("topic", TextIcons.getIcon("topic"));
    return localHashtable;
  }
  
  public GemsTreeModel getTreeModel()
  {
    return this.m_treeModel;
  }
  
  public JComponent buildTabbedView()
  {
    this.m_tabPane = new JTabbedPane();
    this.m_connPanel = new GemsConnectionPanel(this.m_treeModel);
    this.m_servPanel = new GemsServerInfoPanel();
    this.m_servMonitorPanel = new GemsServerMonitorPanel();
    this.m_detailsPanel = new GemsDetailsPanel();
    this.m_messagePanel = new GemsMessagePanel();
    this.m_tabPane.addChangeListener(new ChangeListener()
    {
      public void stateChanged(ChangeEvent paramAnonymousChangeEvent)
      {
        JTabbedPane localJTabbedPane = (JTabbedPane)paramAnonymousChangeEvent.getSource();
        int i = localJTabbedPane.getSelectedIndex();
        if (i > 0) {
          Gems.this.m_lastSelectedTab = i;
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    });
    return this.m_tabPane;
  }
  
  public void treeSelectionChange(DefaultMutableTreeNode paramDefaultMutableTreeNode, boolean paramBoolean)
  {
    if ((paramDefaultMutableTreeNode != null) && (paramDefaultMutableTreeNode.isRoot())) {
      this.m_autoRefresh.setState(true);
    }
    treeSelectionChange1(paramDefaultMutableTreeNode, paramBoolean);
  }
  
  public synchronized void treeSelectionChange1(DefaultMutableTreeNode paramDefaultMutableTreeNode, boolean paramBoolean)
  {
    try
    {
      if (this.m_lock) {
        return;
      }
      this.m_lock = true;
      this.m_xlock.acquire();
      setTitle();
      int i = this.m_tabPane.getSelectedIndex();
      int j = 1;
      GemsConnectionNode localGemsConnectionNode = null;
      for (DefaultMutableTreeNode localDefaultMutableTreeNode = paramDefaultMutableTreeNode; localDefaultMutableTreeNode != null; localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent())
      {
        if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
        {
          localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
          break;
        }
        j++;
      }
      if (localGemsConnectionNode == null)
      {
        while (this.m_tabPane.getTabCount() > 1) {
          this.m_tabPane.removeTabAt(this.m_tabPane.getTabCount() - 1);
        }
        if (this.m_tabPane.getTabCount() == 1)
        {
          if (!this.m_tabPane.getTitleAt(0).equals("Server Monitor"))
          {
            this.m_tabPane.removeTabAt(0);
            this.m_tabPane.addTab("Server Monitor", this.m_servMonitorPanel);
          }
        }
        else {
          this.m_tabPane.addTab("Server Monitor", this.m_servMonitorPanel);
        }
        if ((paramDefaultMutableTreeNode != null) && (paramDefaultMutableTreeNode.getParent() == null) && (paramDefaultMutableTreeNode.getChildCount() == 0))
        {
          this.m_treeModel.reload();
          this.m_lock = false;
          this.m_xlock.release();
          return;
        }
        if (paramDefaultMutableTreeNode == null) {
          paramDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_treeModel.getRoot();
        }
        if (this.m_servMonitorPanel.getModel().populateTable(paramDefaultMutableTreeNode, paramBoolean, this.m_showEvents))
        {
          this.m_treeModel.reload();
          if (this.m_tabPane.getTabCount() == 1) {
            this.m_tabPane.removeTabAt(0);
          }
        }
        this.m_lock = false;
        this.m_xlock.release();
        return;
      }
      if (this.m_tabPane.getTabCount() == 0)
      {
        this.m_tabPane.addTab("Connection", this.m_connPanel);
        i = 0;
      }
      else if (!this.m_tabPane.getTitleAt(0).equals("Connection"))
      {
        this.m_tabPane.removeTabAt(0);
        this.m_tabPane.insertTab("Connection", null, this.m_connPanel, null, 0);
        i = 0;
      }
      if (!paramBoolean) {
        this.m_connPanel.setDetails((String)localGemsConnectionNode.getUserObject(), localGemsConnectionNode.m_url, localGemsConnectionNode.m_user, localGemsConnectionNode.isConnected());
      }
      if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == 1))
      {
        this.m_tabPane.addTab("Server Info", this.m_servPanel);
        i = 1;
        if (this.m_showEvents)
        {
          this.m_tabPane.addTab("Event Monitor", this.m_messagePanel);
          if (localGemsConnectionNode.showEvents()) {
            i = 2;
          }
        }
        this.m_tabPane.setSelectedIndex(i);
      }
      if (!localGemsConnectionNode.isConnected()) {
        while (this.m_tabPane.getTabCount() > 1) {
          this.m_tabPane.removeTabAt(this.m_tabPane.getTabCount() - 1);
        }
      }
      if ((i >= 1) && (this.m_tabPane.getTabCount() > 1)) {
        this.m_servPanel.getModel().populateTable(localGemsConnectionNode.getJmsServerInfoUserReq(!paramBoolean));
      }
      if ((i >= 2) && (this.m_tabPane.getTabCount() > 2) && (this.m_showEvents)) {
        this.m_messagePanel.getModel().populateEventMessageInfo(localGemsConnectionNode.getEventMessages());
      }
      if (paramDefaultMutableTreeNode == null)
      {
        this.m_lock = false;
        this.m_xlock.release();
        return;
      }
      String str1 = (String)paramDefaultMutableTreeNode.getUserObject();
      int k = 2;
      if (this.m_showEvents) {
        k = 3;
      }
      if (j == 1) {
        while (this.m_tabPane.getTabCount() > k) {
          this.m_tabPane.removeTabAt(this.m_tabPane.getTabCount() - 1);
        }
      }
      if (j == 2)
      {
        while (this.m_tabPane.getTabCount() > k + 1) {
          this.m_tabPane.removeTabAt(this.m_tabPane.getTabCount() - 1);
        }
        this.m_frame.setCursor(Cursor.getPredefinedCursor(3));
        if (str1.equals("Consumers"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Consumer Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Consumer Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateConsumerInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Producers"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Producer Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Producer Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateProducerInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Users"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("User Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "User Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateUserInfo(localGemsConnectionNode.getJmsAdmin());
          }
        }
        else if (str1.equals("Clients"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Client Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Client Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateClientsInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Connections(Client)"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Client Connection Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Client Connection Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateConnectionInfo(localGemsConnectionNode.getJmsAdmin());
          }
        }
        else if (str1.equals("Connections(System)"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("System Connection Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "System Connection Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateSystemConnectionInfo(localGemsConnectionNode.getJmsAdmin());
          }
        }
        else if (str1.startsWith("Topics"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Topics Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          try
          {
            this.m_tabPane.setTitleAt(k, "Topics Info");
            if (i >= k)
            {
              ServerInfo localServerInfo1 = localGemsConnectionNode.getJmsServerInfo(false);
              if (localServerInfo1 == null) {
                this.m_detailsPanel.getModel().populateErrorInfo("Not connected to EMS server");
              } else if ((localServerInfo1.getTopicCount() > getGems().getMaxTopics()) && (getGems().getTopicNamePattern().length() <= 1)) {
                this.m_detailsPanel.getModel().populateErrorInfo("Too many topics. Increase MaxTopics or set a TopicNamePattern filter in the gems.props property file");
              } else {
                try
                {
                  this.m_detailsPanel.getModel().populateTopicsInfo(localGemsConnectionNode.getJmsAdmin().getTopics(getTopicNamePattern(), getPermType()));
                }
                catch (Throwable localThrowable1)
                {
                  this.m_detailsPanel.getModel().populateTopicsInfo(localGemsConnectionNode.getJmsAdmin().getTopics(getTopicNamePattern()));
                }
              }
            }
          }
          catch (TibjmsAdminException localTibjmsAdminException1)
          {
            System.err.println("JMSException: " + localTibjmsAdminException1.getMessage());
            this.m_lock = false;
            this.m_frame.setCursor(Cursor.getDefaultCursor());
            this.m_xlock.release();
            return;
          }
        }
        else if (str1.startsWith("Queues"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Queues Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          try
          {
            this.m_tabPane.setTitleAt(k, "Queues Info");
            if (i >= k)
            {
              ServerInfo localServerInfo2 = localGemsConnectionNode.getJmsServerInfo(false);
              if (localServerInfo2 == null) {
                this.m_detailsPanel.getModel().populateErrorInfo("Not connected to EMS server");
              } else if ((localServerInfo2.getQueueCount() > getGems().getMaxQueues()) && (getGems().getQueueNamePattern().length() <= 1)) {
                this.m_detailsPanel.getModel().populateErrorInfo("Too many queues. Increase MaxQueues or set a QueueNamePattern filter in the gems.props property file");
              } else {
                try
                {
                  this.m_detailsPanel.getModel().populateQueuesInfo(localGemsConnectionNode.getJmsAdmin().getQueues(getQueueNamePattern(), getPermType()));
                }
                catch (Throwable localThrowable2)
                {
                  this.m_detailsPanel.getModel().populateQueuesInfo(localGemsConnectionNode.getJmsAdmin().getQueues(getQueueNamePattern()));
                }
              }
            }
          }
          catch (TibjmsAdminException localTibjmsAdminException2)
          {
            System.err.println("JMSException: " + localTibjmsAdminException2.getMessage());
            this.m_lock = false;
            this.m_frame.setCursor(Cursor.getDefaultCursor());
            this.m_xlock.release();
            return;
          }
        }
        else if (str1.equals("Bridges"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Bridge Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Bridge Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateBridgeInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Factories"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Factories Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Factories Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateFactoryInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Channels"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Channels Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Channels Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateChannelsInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Stores(File)"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Stores(File) Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Stores(File) Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateStoresFileInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Stores(DB)"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Stores(DB) Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Stores(DB) Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateStoresDbInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Stores(MStore)"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Stores(MStore) Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Stores(MStore) Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateStoresMStoreInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("Services"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Service Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Service Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateServiceInfo(localGemsConnectionNode.m_services);
          }
        }
        else if (str1.equals("Routes"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Route Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Route Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateRoutesInfo(localGemsConnectionNode.getJmsAdmin());
          }
        }
        else if (str1.equals("Transactions"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Transaction Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Transaction Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateTransactionInfo(localGemsConnectionNode.getJmsAdmin());
          }
        }
        else if (str1.equals("Transports"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Transport Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Transport Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateTransportInfo(localGemsConnectionNode.getJmsAdmin());
          }
        }
        else if (str1.equals("Durables"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Durable Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Durable Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateDurablesInfo(localGemsConnectionNode.getJmsAdmin());
          }
        }
        else if (str1.equals("Groups"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("Group Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "Group Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateGroupInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("ACLs"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("ACL Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "ACL Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateACLInfo(localGemsConnectionNode);
          }
        }
        else if (str1.equals("AdminACLs"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("AdminACL Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "AdminACL Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateAdminACLInfo(localGemsConnectionNode);
          }
        }
        else if (paramDefaultMutableTreeNode.getClass().getSimpleName().equals("GemsSSNode"))
        {
          if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
          {
            this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
            i = k;
            this.m_tabPane.setSelectedIndex(i);
          }
          this.m_tabPane.setTitleAt(k, "SubStation Info");
          if (i >= k) {
            this.m_detailsPanel.getModel().populateSSInfo(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode);
          }
        }
        else
        {
          this.m_lock = false;
          this.m_frame.setCursor(Cursor.getDefaultCursor());
          this.m_xlock.release();
        }
      }
      else
      {
        String str2;
        if (j == 3)
        {
          this.m_frame.setCursor(Cursor.getPredefinedCursor(3));
          str2 = (String)((DefaultMutableTreeNode)paramDefaultMutableTreeNode.getParent()).getUserObject();
          if (str2.startsWith("Topics"))
          {
            if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
            {
              this.m_tabPane.addTab("Topic Info", this.m_detailsPanel);
              i = k;
              this.m_tabPane.setSelectedIndex(i);
            }
            this.m_tabPane.setTitleAt(k, "Topic Info");
            if (i >= k) {
              this.m_detailsPanel.getModel().populateTopicInfo(localGemsConnectionNode.getJmsAdmin(), str1);
            }
          }
          else if (str2.startsWith("Queues"))
          {
            if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
            {
              this.m_tabPane.addTab("Queue Info", this.m_detailsPanel);
              i = k;
              this.m_tabPane.setSelectedIndex(i);
            }
            this.m_tabPane.setTitleAt(k, "Queue Info");
            if (i >= k) {
              this.m_detailsPanel.getModel().populateQueueInfo(localGemsConnectionNode.getJmsAdmin(), str1);
            }
          }
          else if (paramDefaultMutableTreeNode.getParent().getClass().getSimpleName().equals("GemsSSNode"))
          {
            if (str1.equals("Counters"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation Counters Info");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSCounters(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent());
              }
            }
            else if (str1.equals("Interfaces"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation Interfaces Info");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSInterface(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent());
              }
            }
            else if (str1.equals("Transports"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation Transports Info");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSTransport(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent());
              }
            }
            else if (str1.equals("IMS"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation IMS General");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSIMSGen(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent());
              }
            }
          }
        }
        else if (j == 4)
        {
          this.m_frame.setCursor(Cursor.getPredefinedCursor(3));
          str2 = (String)((DefaultMutableTreeNode)paramDefaultMutableTreeNode.getParent()).getUserObject();
          String str3 = "";
          if (!str2.equals("IMS")) {
            str3 = str2.substring(5);
          }
          if (paramDefaultMutableTreeNode.getParent().getParent().getClass().getSimpleName().equals("GemsSSNode")) {
            if (str1.equals("Listeners"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation Listeners Info");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSListeners(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent().getParent(), str3);
              }
            }
            else if (str1.equals("Active Recipes"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation Active Recipes Info");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSActive(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent().getParent(), "RID", str3);
              }
            }
            else if (str1.equals("Active Triggers"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation Active Triggers Info");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSActive(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent().getParent(), "TID", str3);
              }
            }
            else if (str1.equals("Disabled"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation Disabled Info");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSInActive(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent().getParent(), str3);
              }
            }
            else if (str1.equals("IMS Statistics"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation IMS Statistics");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSIMSStats(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent().getParent());
              }
            }
            else if (str1.equals("IMS Buffers"))
            {
              if ((localGemsConnectionNode.isConnected()) && (this.m_tabPane.getTabCount() == k))
              {
                this.m_tabPane.addTab("SubStation Info", this.m_detailsPanel);
                i = k;
                this.m_tabPane.setSelectedIndex(i);
              }
              this.m_tabPane.setTitleAt(k, "SubStation IMS Buffers");
              if (i >= k) {
                this.m_detailsPanel.getModel().populateSSIMSBuffers(localGemsConnectionNode, (GemsSSNode)paramDefaultMutableTreeNode.getParent().getParent());
              }
            }
          }
        }
      }
      this.m_frame.setCursor(Cursor.getDefaultCursor());
      this.m_lock = false;
      this.m_xlock.release();
    }
    catch (Exception localException)
    {
      debug(localException.toString());
      this.m_frame.setCursor(Cursor.getDefaultCursor());
      this.m_lock = false;
      this.m_xlock.release();
      return;
    }
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    String str = getGems().getHideViews();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        System.exit(0);
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CutAction());
    localJMenuItem.setText("Cut");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(88, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.CopyAction());
    localJMenuItem.setText("Copy");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(67, 2));
    localJMenu.add(localJMenuItem);
    localJMenuItem = new JMenuItem(new DefaultEditorKit.PasteAction());
    localJMenuItem.setText("Paste");
    localJMenuItem.setAccelerator(KeyStroke.getKeyStroke(86, 2));
    localJMenu.add(localJMenuItem);
    localJMenuBar.add(localJMenu);
    localJMenu = new JMenu("View");
    localJMenu.setMnemonic(86);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("Refresh"));
    localJMenuItem.addActionListener(new RefreshAction());
    this.m_autoRefresh = new JCheckBoxMenuItem("Auto Refresh");
    if (this.m_displayRefresh > 0)
    {
      this.m_autoRefresh.setState(true);
      localJMenuItem = localJMenu.add(this.m_autoRefresh);
    }
    this.m_showTotals = new JCheckBoxMenuItem("Show Server Totals");
    this.m_showTotals.setState(getShowTotals());
    this.m_showTotals.addActionListener(new ShowTotalsAction());
    localJMenuItem = localJMenu.add(this.m_showTotals);
    if (this.m_displayRefresh > 0)
    {
      localJMenu = new JMenu("Chart");
      localJMenu.setMnemonic(67);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Chart Server..."));
      localJMenuItem.addActionListener(new ChartAction());
    }
    localJMenu = new JMenu("Server");
    localJMenu.setMnemonic(83);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("New EMS Server Connection"));
    localJMenuItem.addActionListener(new AddConnectionAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Monitor Connections..."));
    localJMenuItem.addActionListener(new MonitorConnectionAction());
    if (!getViewOnlyMode())
    {
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Set Server Property..."));
      localJMenuItem.addActionListener(new SetServerPropertyAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Set Server Trace..."));
      localJMenuItem.addActionListener(new SetServerTraceAction());
    }
    if ((!getViewOnlyMode()) && (str.indexOf("Connections") < 0))
    {
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Destroy Client Connection"));
      localJMenuItem.addActionListener(new DisconnectClientAction());
    }
    if ((!getViewOnlyMode()) && (str.indexOf("Bridges") < 0))
    {
      localJMenu = new JMenu("Bridges");
      localJMenu.setMnemonic(66);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Create Bridge"));
      localJMenuItem.addActionListener(new CreateBridgeAction());
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Destroy Bridge"));
      localJMenuItem.addActionListener(new DestroyBridgeAction());
      localJMenu.addSeparator();
    }
    localJMenuItem = localJMenu.add(new JMenuItem("Manage Bridges..."));
    localJMenuItem.addActionListener(new FindBridgeTargetsAction());
    localJMenu = new JMenu("Queues");
    localJMenu.setMnemonic(81);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("Show Queues..."));
    localJMenuItem.addActionListener(new ShowQueuesAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Queue Browser..."));
    localJMenuItem.addActionListener(new BrowseQueueAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Queue Properties..."));
    localJMenuItem.addActionListener(new SetQueuePropertyAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Monitor Request/Reply Queue..."));
    localJMenuItem.addActionListener(new MonitorReqReplyQueueAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Monitor Queue..."));
    localJMenuItem.addActionListener(new MonitorQueueAction());
    if (!getViewOnlyMode())
    {
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Send TextMessage..."));
      localJMenuItem.addActionListener(new SendMessageAction(false));
      localJMenuItem = localJMenu.add(new JMenuItem("Send MapMessage..."));
      localJMenuItem.addActionListener(new SendMessageAction(true));
      localJMenuItem = localJMenu.add(new JMenuItem("Request/Reply Tester..."));
      localJMenuItem.addActionListener(new RequestReplyTesterAction(true));
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Create Queue"));
      localJMenuItem.addActionListener(new CreateQueueAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Set Queue Permissions..."));
      localJMenuItem.addActionListener(new SetQueuePermissionsAction());
      localJMenu.addSeparator();
      if (str.indexOf("Queues") < 0)
      {
        localJMenuItem = localJMenu.add(new JMenuItem("Purge Queue"));
        localJMenuItem.addActionListener(new PurgeQueueAction());
      }
      localJMenuItem = localJMenu.add(new JMenuItem("Purge Multiple Queues..."));
      localJMenuItem.addActionListener(new PurgeQueuesAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Purge $TMP Queues..."));
      localJMenuItem.addActionListener(new PurgeTMPQueuesAction());
      if (str.indexOf("Queues") < 0)
      {
        localJMenuItem = localJMenu.add(new JMenuItem("Destroy Queue"));
        localJMenuItem.addActionListener(new DeleteQueueAction());
      }
    }
    localJMenu = new JMenu("Topics");
    localJMenu.setMnemonic(84);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("Show Topics..."));
    localJMenuItem.addActionListener(new ShowTopicsAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Topic Subscriber..."));
    localJMenuItem.addActionListener(new SubscribeTopicAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Topic Properties..."));
    localJMenuItem.addActionListener(new SetTopicPropertyAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Monitor Request/Reply Topic..."));
    localJMenuItem.addActionListener(new MonitorReqReplyTopicAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Monitor Topic..."));
    localJMenuItem.addActionListener(new MonitorTopicAction());
    if (!getViewOnlyMode())
    {
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Publish TextMessage..."));
      localJMenuItem.addActionListener(new PublishMessageAction(false));
      localJMenuItem = localJMenu.add(new JMenuItem("Publish MapMessage..."));
      localJMenuItem.addActionListener(new PublishMessageAction(true));
      localJMenuItem = localJMenu.add(new JMenuItem("Request/Reply Tester..."));
      localJMenuItem.addActionListener(new RequestReplyTesterAction(false));
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Create Topic"));
      localJMenuItem.addActionListener(new CreateTopicAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Set Topic Permissions..."));
      localJMenuItem.addActionListener(new SetTopicPermissionsAction());
      localJMenu.addSeparator();
      if (str.indexOf("Topics") < 0)
      {
        localJMenuItem = localJMenu.add(new JMenuItem("Purge Topic"));
        localJMenuItem.addActionListener(new PurgeTopicAction());
      }
      localJMenuItem = localJMenu.add(new JMenuItem("Purge Multiple Topics..."));
      localJMenuItem.addActionListener(new PurgeTopicsAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Purge $TMP Topics..."));
      localJMenuItem.addActionListener(new PurgeTMPTopicsAction());
      if (str.indexOf("Topics") < 0)
      {
        localJMenuItem = localJMenu.add(new JMenuItem("Destroy Topic"));
        localJMenuItem.addActionListener(new DeleteTopicAction());
      }
    }
    if (str.indexOf("Durables") < 0)
    {
      localJMenu = new JMenu("Durables");
      localJMenu.setMnemonic(68);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Browse Durable..."));
      localJMenuItem.addActionListener(new BrowseDurableAction());
      if (!getViewOnlyMode())
      {
        localJMenuItem = localJMenu.add(new JMenuItem("Create Durable"));
        localJMenuItem.addActionListener(new CreateDurableAction());
        localJMenu.addSeparator();
        localJMenuItem = localJMenu.add(new JMenuItem("Destroy Durable"));
        localJMenuItem.addActionListener(new DestroyDurableAction());
        localJMenuItem = localJMenu.add(new JMenuItem("Purge Durable"));
        localJMenuItem.addActionListener(new PurgeDurableAction());
      }
    }
    if ((!getViewOnlyMode()) && (str.indexOf("Users") < 0))
    {
      localJMenu = new JMenu("Users");
      localJMenu.setMnemonic(85);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Create User"));
      localJMenuItem.addActionListener(new CreateUserAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Update User"));
      localJMenuItem.addActionListener(new UpdateUserAction());
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Create Group"));
      localJMenuItem.addActionListener(new CreateGroupAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Add User To Group"));
      localJMenuItem.addActionListener(new AddUserToGroupAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Remove User From Group"));
      localJMenuItem.addActionListener(new RemoveUserFromGroupAction());
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Set Admin Permissions..."));
      localJMenuItem.addActionListener(new SetAdminPermissionsAction());
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Destroy User"));
      localJMenuItem.addActionListener(new DestroyUserAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Destroy Group"));
      localJMenuItem.addActionListener(new DestroyGroupAction());
    }
    if ((!getViewOnlyMode()) && (str.indexOf("Routes") < 0))
    {
      localJMenu = new JMenu("Routes");
      localJMenu.setMnemonic(82);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Create Route"));
      localJMenuItem.addActionListener(new CreateRouteAction());
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Destroy Route"));
      localJMenuItem.addActionListener(new DestroyRouteAction());
      localJMenu.addSeparator();
      localJMenuItem = localJMenu.add(new JMenuItem("Monitor Routes..."));
      localJMenuItem.addActionListener(new MonitorRouteAction());
    }
    if (this.m_serviceMenu)
    {
      localJMenu = new JMenu("Services");
      localJMenu.setMnemonic(83);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Enable Service Monitoring"));
      localJMenuItem.addActionListener(new StartServiceMonitoringAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Disable Service Monitoring"));
      localJMenuItem.addActionListener(new StopServiceMonitoringAction());
    }
    if ((!getViewOnlyMode()) && (str.indexOf("Factories") < 0))
    {
      localJMenu = new JMenu("Factories");
      localJMenu.setMnemonic(65);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Create Connection Factory..."));
      localJMenuItem.addActionListener(new CreateFactoryAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Destroy Connection Factory"));
      localJMenuItem.addActionListener(new DestroyFactoryAction());
    }
    if ((!getViewOnlyMode()) && (this.m_substationMenu))
    {
      localJMenu = new JMenu("SubStation");
      localJMenu.setMnemonic(78);
      localJMenuBar.add(localJMenu);
      localJMenuItem = localJMenu.add(new JMenuItem("Refresh"));
      localJMenuItem.addActionListener(new RefreshSSAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Enable"));
      localJMenuItem.addActionListener(new EnableSSAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Disable"));
      localJMenuItem.addActionListener(new DisableSSAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Unload"));
      localJMenuItem.addActionListener(new UnloadSSAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Enable New Object"));
      localJMenuItem.addActionListener(new NewSSRecipeAction());
      localJMenuItem = localJMenu.add(new JMenuItem("Reset Counters"));
      localJMenuItem.addActionListener(new ResetSSAction());
    }
    localJMenu = new JMenu("Help");
    localJMenu.setMnemonic(72);
    localJMenuBar.add(localJMenu);
    if ((this.m_jreVersion != null) && (!this.m_jreVersion.startsWith("1.5")))
    {
      localJMenuItem = localJMenu.add(new JMenuItem("Help..."));
      localJMenuItem.addActionListener(new ShowHelp());
    }
    localJMenuItem = localJMenu.add(new JMenuItem("About Gems..."));
    localJMenuItem.addActionListener(new AboutAction());
    return localJMenuBar;
  }
  
  protected DefaultMutableTreeNode getSelectedNode()
  {
    TreePath localTreePath = this.m_tree.getSelectionPath();
    if (localTreePath != null) {
      return (DefaultMutableTreeNode)localTreePath.getLastPathComponent();
    }
    return null;
  }
  
  protected GemsConnectionNode getConnectionNode()
  {
    TreePath localTreePath = this.m_tree.getSelectionPath();
    if (localTreePath != null)
    {
      DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localTreePath.getLastPathComponent();
      if (localDefaultMutableTreeNode.isRoot()) {
        return null;
      }
      GemsConnectionNode localGemsConnectionNode = null;
      while (localDefaultMutableTreeNode.getLevel() > 0)
      {
        if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
        {
          localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
          break;
        }
        localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
      }
      return localGemsConnectionNode;
    }
    return null;
  }
  
  protected GemsSSNode getSSConnectionNode()
  {
    TreePath localTreePath = this.m_tree.getSelectionPath();
    if (localTreePath != null)
    {
      DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localTreePath.getLastPathComponent();
      if (localDefaultMutableTreeNode.isRoot()) {
        return null;
      }
      GemsSSNode localGemsSSNode = null;
      while (localDefaultMutableTreeNode.getLevel() > 0)
      {
        if ((localDefaultMutableTreeNode instanceof GemsSSNode))
        {
          localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode;
          break;
        }
        localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
      }
      return localGemsSSNode;
    }
    return null;
  }
  
  protected boolean checkConnected(String paramString)
  {
    GemsConnectionNode localGemsConnectionNode = getConnectionNode();
    if ((localGemsConnectionNode == null) || (!localGemsConnectionNode.isConnected()))
    {
      if (paramString != null) {
        JOptionPane.showMessageDialog(this.m_frame, "Select a " + paramString + " for an EMS server connection!", "Error", 1);
      } else {
        JOptionPane.showMessageDialog(this.m_frame, "Select an EMS server connection in the tree view", "Error", 1);
      }
      return false;
    }
    return true;
  }
  
  protected TreePath[] getSelectedPaths()
  {
    return this.m_tree.getSelectionPaths();
  }
  
  public static void main(String[] paramArrayOfString)
  {
    m_gems = new Gems(paramArrayOfString);
    m_gems.start();
  }
  
  public static Gems getGems()
  {
    return m_gems;
  }
  
  public void initProps(String paramString)
  {
    this.m_props = new Properties();
    this.m_props.setProperty("MaxMessageView", "100");
    this.m_props.setProperty("ViewOldMessagesFirst", "false");
    this.m_props.setProperty("QueueNamePattern", ">");
    this.m_props.setProperty("TopicNamePattern", ">");
    this.m_props.setProperty("ShowExtendedProperties", "false");
    this.m_props.setProperty("DisplayRefresh", "20");
    this.m_props.setProperty("ShowMonitorTopics", "false");
    this.m_props.setProperty("DisplayWidth", "1200");
    this.m_props.setProperty("DisplayHeight", "600");
    this.m_props.setProperty("ShowRootNode", "true");
    this.m_props.setProperty("ColourPendingMsgs", "true");
    this.m_props.setProperty("MsgReadDelay", "250");
    this.m_props.setProperty("RequestReplyTimeout", "10");
    this.m_props.setProperty("ServerConfigFile", "servers.xml");
    this.m_props.setProperty("ViewOnlyMode", "true");
    this.m_props.setProperty("Debug", "false");
    this.m_props.setProperty("LookAndFeel", "");
    this.m_props.setProperty("PermType", "3");
    this.m_props.setProperty("MaxDisplayBytes", "1024");
    this.m_props.setProperty("ShowClientId", "false");
    this.m_props.setProperty("HideViews", "Clients");
    this.m_props.setProperty("ShowTotals", "false");
    this.m_props.setProperty("ConnectTimeout", "500");
    this.m_props.setProperty("SSTimeout", "5000");
    this.m_props.setProperty("AdminTimeout", "5000");
    this.m_props.setProperty("AllowStandbyOperations", "false");
    this.m_props.setProperty("UseServerTimestamps", "false");
    this.m_props.setProperty("ShowRootInTitleBar", "false");
    this.m_props.setProperty("ShowPathInTitleBar", "true");
    this.m_props.setProperty("DetailPanelColWidths", "");
    this.m_props.setProperty("LogDateTimeFormat", "EEE MMM dd HH:mm:ss SSS zzz yyyy");
    this.m_props.setProperty("CSVFileDelimiter", ",");
    this.m_props.setProperty("MaxQueues", "1000");
    this.m_props.setProperty("MaxTopics", "1000");
    this.m_props.setProperty("ServerInfoColPositions", "");
    if (paramString != null) {
      try
      {
        FileInputStream localFileInputStream = new FileInputStream(paramString);
        this.m_props.load(localFileInputStream);
      }
      catch (Exception localException)
      {
        System.err.println("Exception: " + localException.getMessage());
        return;
      }
    }
    this.m_displayRefresh = getDisplayRefresh();
  }
  
  public String getProp(String paramString)
  {
    return this.m_props.getProperty(paramString);
  }
  
  public String getQueueNamePattern()
  {
    return this.m_props.getProperty("QueueNamePattern");
  }
  
  public String getTopicNamePattern()
  {
    return this.m_props.getProperty("TopicNamePattern");
  }
  
  public String getServerConfigFile()
  {
    return this.m_props.getProperty("ServerConfigFile");
  }
  
  public String getLookAndFeel()
  {
    return this.m_props.getProperty("LookAndFeel");
  }
  
  public String getHideViews()
  {
    return this.m_props.getProperty("HideViews");
  }
  
  public String getDetailPaneColWidths()
  {
    return this.m_props.getProperty("DetailPanelColWidths");
  }
  
  public String getLogDateTimeFormat()
  {
    return this.m_props.getProperty("LogDateTimeFormat");
  }
  
  public int getMaxDisplayBytes()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("MaxDisplayBytes"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 1024;
  }
  
  public int getScreenWidth()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("DisplayWidth"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 1200;
  }
  
  public int getPermType()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("PermType"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 3;
  }
  
  public int getScreenHeight()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("DisplayHeight"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 600;
  }
  
  public int getMaxMessageView()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("MaxMessageView"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 100;
  }
  
  public int getDisplayRefresh()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("DisplayRefresh"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 20;
  }
  
  public long getConnectTimeout()
  {
    try
    {
      return Long.parseLong(this.m_props.getProperty("ConnectTimeout"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 500L;
  }
  
  public long getSSTimeout()
  {
    try
    {
      return Long.parseLong(this.m_props.getProperty("SSTimeout"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 5000L;
  }
  
  public long getAdminTimeout()
  {
    try
    {
      return Long.parseLong(this.m_props.getProperty("AdminTimeout"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 5000L;
  }
  
  public boolean getShowPathInTitleBar()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ShowPathInTitleBar")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return true;
  }
  
  public boolean getShowRootInTitleBar()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ShowRootInTitleBar")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public boolean getViewOldMessagesFirst()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ViewOldMessagesFirst")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public void setViewOldMessagesFirst(boolean paramBoolean)
  {
    if (paramBoolean) {
      this.m_props.setProperty("ViewOldMessagesFirst", "true");
    } else {
      this.m_props.setProperty("ViewOldMessagesFirst", "false");
    }
  }
  
  public boolean getUseServerTimestamps()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("UseServerTimestamps")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public void setUseServerTimestamps(boolean paramBoolean)
  {
    if (paramBoolean) {
      this.m_props.setProperty("UseServerTimestamps", "true");
    } else {
      this.m_props.setProperty("UseServerTimestamps", "false");
    }
  }
  
  public boolean getViewOnlyMode()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ViewOnlyMode")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public boolean getAllowStandbyOperations()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("AllowStandbyOperations")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public void setShowTotals(boolean paramBoolean)
  {
    if (paramBoolean) {
      this.m_props.setProperty("ShowTotals", "true");
    } else {
      this.m_props.setProperty("ShowTotals", "false");
    }
    this.m_showTotals.setState(paramBoolean);
    treeSelectionChange(getSelectedNode(), false);
  }
  
  public boolean getShowTotals()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ShowTotals")).booleanValue();
    }
    catch (Exception localException) {}
    return false;
  }
  
  public boolean getDebug()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("Debug")).booleanValue();
    }
    catch (Exception localException) {}
    return false;
  }
  
  public boolean getShowRootNode()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ShowRootNode")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public boolean getShowMonitorTopics()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ShowMonitorTopics")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public boolean getColourPendingMsgs()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ColourPendingMsgs")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public boolean getShowExtendedProperties()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ShowExtendedProperties")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public boolean getShowClientId()
  {
    try
    {
      return Boolean.valueOf(this.m_props.getProperty("ShowClientId")).booleanValue();
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return false;
  }
  
  public int getMsgReadDelay()
  {
    try
    {
      int i = Integer.parseInt(this.m_props.getProperty("MsgReadDelay"));
      if (i < 10) {
        i = 10;
      }
      return i;
    }
    catch (Exception localException)
    {
      this.m_props.setProperty("MsgReadDelay", "250");
    }
    return 250;
  }
  
  public int getRequestReplyTimeout()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("RequestReplyTimeout"));
    }
    catch (Exception localException)
    {
      this.m_props.setProperty("RequestReplyTimeout", "10");
    }
    return 10;
  }
  
  public String getRequestReplyTimeoutStr()
  {
    return this.m_props.getProperty("RequestReplyTimeout");
  }
  
  public void setRequestReplyTimeout(String paramString)
  {
    this.m_props.setProperty("RequestReplyTimeout", paramString);
  }
  
  public String getMsgReadDelayStr()
  {
    return this.m_props.getProperty("MsgReadDelay");
  }
  
  public void setMsgReadDelay(String paramString)
  {
    this.m_props.setProperty("MsgReadDelay", paramString);
  }
  
  public String getCSVFileDelimiter()
  {
    return this.m_props.getProperty("CSVFileDelimiter");
  }
  
  public int getMaxTopics()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("MaxTopics"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 1000;
  }
  
  public int getMaxQueues()
  {
    try
    {
      return Integer.parseInt(this.m_props.getProperty("MaxQueues"));
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
    }
    return 1000;
  }
  
  public String getServerInfoColPositions()
  {
    return this.m_props.getProperty("ServerInfoColPositions");
  }
  
  public boolean isStandbyOpsAllowed(GemsConnectionNode paramGemsConnectionNode)
  {
    if ((!getAllowStandbyOperations()) && (paramGemsConnectionNode.isStandbyMode()))
    {
      JOptionPane.showMessageDialog(this.m_frame, "Admin operations on standby servers are disabled (see gems.props)", "Error", 1);
      return false;
    }
    return true;
  }
  
  public String getTitlePrefix()
  {
    if (!getShowPathInTitleBar()) {
      return "";
    }
    TreePath localTreePath = this.m_tree.getSelectionPath();
    Object[] arrayOfObject = null;
    int i = 0;
    if (!getShowRootInTitleBar()) {
      i = 1;
    }
    if (localTreePath != null)
    {
      DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localTreePath.getLastPathComponent();
      if (!localDefaultMutableTreeNode.isRoot()) {
        while (localDefaultMutableTreeNode.getLevel() > 0)
        {
          if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
          {
            arrayOfObject = localDefaultMutableTreeNode.getUserObjectPath();
            str = "";
            for (j = i; j < arrayOfObject.length; j++)
            {
              str = str + arrayOfObject[j].toString();
              if (j < arrayOfObject.length - 1) {
                str = str + ".";
              }
            }
            if (str.length() > 0) {
              str = str + ": ";
            }
            return str;
          }
          localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
        }
      }
      if (arrayOfObject == null) {
        arrayOfObject = localTreePath.getPath();
      }
      String str = "";
      for (int j = i; j < arrayOfObject.length; j++)
      {
        str = str + ((DefaultMutableTreeNode)arrayOfObject[j]).getUserObject().toString();
        if (j < arrayOfObject.length - 1) {
          str = str + ".";
        }
      }
      if (str.length() > 0) {
        str = str + ": ";
      }
      return str;
    }
    return ((DefaultMutableTreeNode)this.m_treeModel.getRoot()).getUserObject().toString() + ": ";
  }
  
  public void treeRepaint()
  {
    this.m_tree.repaint();
  }
  
  public void scheduleRepaint()
  {
    if (this.m_timer != null) {
      this.m_timer.restart();
    }
  }
  
  public static void debug(String paramString)
  {
    if (m_gems.getDebug()) {
      System.err.println("Debug: " + paramString);
    }
  }
  
  public GemsDetailsPanel getDetailsPanel()
  {
    return this.m_detailsPanel;
  }
  
  public void clearCurrentEventsDisplay()
  {
    GemsConnectionNode localGemsConnectionNode = getConnectionNode();
    if (localGemsConnectionNode != null)
    {
      localGemsConnectionNode.clearEventMessages();
      scheduleRepaint();
    }
  }
  
  class ConnectThread
    extends Thread
  {
    long m_delay;
    
    ConnectThread(long paramLong)
    {
      this.m_delay = (paramLong * 1000L);
    }
    
    public void run()
    {
      while (this.m_delay > 0L) {
        try
        {
          sleep(this.m_delay);
          DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
          localDefaultMutableTreeNode = (DefaultMutableTreeNode)Gems.this.m_treeModel.getRoot();
          if (Gems.this.m_servMonitorPanel.getModel().findServers(localDefaultMutableTreeNode, true, Gems.this.m_showEvents))
          {
            Gems.this.m_tree.repaint();
            if (Gems.this.m_timer != null) {
              Gems.this.m_timer.restart();
            }
          }
          else if (Gems.this.m_timer != null)
          {
            Gems.this.m_timer.restart();
          }
        }
        catch (Exception localException)
        {
          System.err.println("Exception: " + localException.getMessage());
        }
      }
    }
  }
  
  class RefreshTimerAction
    implements ActionListener
  {
    RefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      if (!Gems.this.m_autoRefresh.getState()) {
        return;
      }
      String str = null;
      int i = 0;
      if (Gems.this.m_detailsPanel.isShowing())
      {
        i = Gems.this.m_detailsPanel.getModel().getSelectedRow();
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      }
      Gems.getGems().treeSelectionChange(localDefaultMutableTreeNode, true);
      if ((Gems.this.m_detailsPanel.isShowing()) && (str != null)) {
        Gems.this.m_detailsPanel.getModel().maintainSelection(i, str);
      }
    }
  }
  
  class RefreshThread
    extends Thread
  {
    long m_delay;
    
    RefreshThread(long paramLong)
    {
      this.m_delay = (paramLong * 1000L);
    }
    
    public void run()
    {
      while (this.m_delay > 0L) {
        try
        {
          sleep(this.m_delay);
          Gems.getGems().treeSelectionChange(Gems.this.getSelectedNode(), true);
        }
        catch (Exception localException)
        {
          System.err.println("Exception: " + localException.getMessage());
        }
      }
    }
  }
  
  class OptionsDialog
    implements ActionListener
  {
    OptionsDialog() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      JPanel localJPanel = new JPanel(new SpringLayout());
      localJPanel.add(new JLabel("Only show Queues with name pattern:"));
      JTextField localJTextField1 = new JTextField(25);
      localJTextField1.setText(Gems.this.getQueueNamePattern());
      localJPanel.add(localJTextField1);
      localJPanel.add(new JLabel("Only show Topics with name pattern:"));
      JTextField localJTextField2 = new JTextField(25);
      localJTextField2.setText(Gems.this.getTopicNamePattern());
      localJPanel.add(localJTextField2);
      localJPanel.add(new JLabel("Target Type:"));
      JComboBox localJComboBox = new JComboBox();
      localJComboBox.addItem("Queue");
      localJComboBox.addItem("Topic");
      localJPanel.add(localJComboBox);
      localJPanel.add(new JLabel("Selector:"));
      JTextField localJTextField3 = new JTextField(25);
      localJPanel.add(localJTextField3);
      SpringUtilities.makeCompactGrid(localJPanel, 4, 2, 5, 5, 5, 5);
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, localJPanel, "Edit Options", 2);
      if (i == 0)
      {
        Gems.this.m_props.setProperty("QueueNamePattern", localJTextField1.getText());
        Gems.this.m_props.setProperty("TopicNamePattern", localJTextField2.getText());
        Gems.this.m_treeModel.reloadTree();
      }
    }
  }
  
  class ChartAction
    implements ActionListener
  {
    ChartAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionPicker localGemsConnectionPicker = new GemsConnectionPicker(Gems.this.m_frame, Gems.this.getConnectionNode(), "Chart");
      GemsConnectionNode localGemsConnectionNode = localGemsConnectionPicker.getConnection();
      if (localGemsConnectionNode != null)
      {
        Gems.this.m_frame.setCursor(Cursor.getPredefinedCursor(3));
        localGemsConnectionNode.startCharting();
        Gems.this.m_frame.setCursor(Cursor.getDefaultCursor());
      }
    }
  }
  
  class BrowseDurableAction
    implements ActionListener
  {
    BrowseDurableAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("durable")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Durables")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Durable to browse!", "Browse Durable", 1);
        return;
      }
      String str3 = Gems.this.m_detailsPanel.getModel().getSelectedCol(6);
      String str4 = Gems.this.m_detailsPanel.getModel().getSelectedCol(2);
      String str5 = Gems.this.m_detailsPanel.getModel().getSelectedCol(9);
      Boolean localBoolean = new Boolean(Gems.this.m_detailsPanel.getModel().getSelectedCol(10));
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsDurableBrowser(localGemsConnectionNode, str2, str3, str4, str5, localBoolean.booleanValue());
      }
    }
  }
  
  class StopServiceMonitoringAction
    implements ActionListener
  {
    StopServiceMonitoringAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null)
      {
        if (localGemsConnectionNode.m_services == null)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, "There are no services configured for " + localGemsConnectionNode.getName(), "Disable Service Monitoring", 1);
          return;
        }
        if (localGemsConnectionNode.m_services.m_running)
        {
          int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Disable service monitoring for " + localGemsConnectionNode.getName() + "?", "Disable Service Monitoring", 0);
          if (i == 0) {
            localGemsConnectionNode.m_services.userStop();
          }
        }
        else
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, "Service monitoring is currently disabled for " + localGemsConnectionNode.getName(), "Disable Service Monitoring", 1);
        }
      }
    }
  }
  
  class DestroyFactoryAction
    implements ActionListener
  {
    DestroyFactoryAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Factories")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Factory to destroy!", "Destroy Factory", 1);
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Connection Factory: " + str2, "Destroy Factory", 0);
      if (i == 0) {
        try
        {
          if ((localGemsConnectionNode != null) && (localGemsConnectionNode.m_adminConn != null)) {
            localGemsConnectionNode.m_adminConn.destroyConnectionFactory(str2);
          }
          Gems.this.scheduleRepaint();
        }
        catch (TibjmsAdminException localTibjmsAdminException)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
          return;
        }
      }
    }
  }
  
  class CreateFactoryAction
    implements ActionListener
  {
    CreateFactoryAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      if ((localGemsConnectionNode != null) && (localGemsConnectionNode.m_adminConn != null))
      {
        String str = "<html>Jndi Name is mandatory, other fields can be left blank for defaults.<br>Set Destination Type to 1 for Queue, 2 for Topic, or leave blank for generic. <br>For load balancing, set Metric to 1 for connections, 2 for byte rate, or leave blank for none.</html>";
        GemsDynamicPropertyDialog localGemsDynamicPropertyDialog = new GemsDynamicPropertyDialog(Gems.this.m_frame, "Create Connection Factory", "com.tibco.gems.GemsDummyConnectionFactoryInfo", str);
        GemsDummyConnectionFactoryInfo localGemsDummyConnectionFactoryInfo = null;
        try
        {
          localGemsDummyConnectionFactoryInfo = (GemsDummyConnectionFactoryInfo)localGemsDynamicPropertyDialog.getObject();
        }
        catch (Exception localException)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, localException.getMessage(), "Error", 1);
          return;
        }
        if (localGemsDummyConnectionFactoryInfo == null) {
          return;
        }
        try
        {
          localGemsConnectionNode.m_adminConn.createConnectionFactory(localGemsDummyConnectionFactoryInfo.getJndiName(), localGemsDummyConnectionFactoryInfo);
          Gems.this.scheduleRepaint();
        }
        catch (TibjmsAdminException localTibjmsAdminException)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
          return;
        }
      }
    }
  }
  
  class StartServiceMonitoringAction
    implements ActionListener
  {
    StartServiceMonitoringAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null)
      {
        if (localGemsConnectionNode.m_services == null)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, "There are no services configured for " + localGemsConnectionNode.getName(), "Enable Service Monitoring", 1);
          return;
        }
        int i;
        if (localGemsConnectionNode.m_services.m_running)
        {
          i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Service monitoring for " + localGemsConnectionNode.getName() + " is already enabled, do you want to reset stats?", "Enable Service Monitoring", 0);
          if (i == 0) {
            localGemsConnectionNode.m_services.reset();
          }
        }
        else
        {
          i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Enable service monitoring for " + localGemsConnectionNode.getName() + "?", "Enable Service Monitoring", 0);
          if (i == 0) {
            localGemsConnectionNode.m_services.userStart();
          }
        }
      }
    }
  }
  
  class PurgeDurableAction
    implements ActionListener
  {
    PurgeDurableAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("durable")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Durables")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Durable to purge!", "Purge Durable", 1);
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      String str3 = Gems.this.m_detailsPanel.getModel().getSelectedCol(6);
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Purge Durable: " + str2 + " clientID " + (str3 == null ? "" : str3), "Purge Durable", 0);
      if (i == 0)
      {
        if (localGemsConnectionNode != null) {
          localGemsConnectionNode.purgeDurable(str2, str3);
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class DestroyDurableAction
    implements ActionListener
  {
    DestroyDurableAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("durable")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Durables")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Durable to destroy!", "Destroy Durable", 1);
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      String str3 = Gems.this.m_detailsPanel.getModel().getSelectedCol(6);
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Durable: " + str2 + " clientID " + (str3 == null ? "" : str3), "Destroy Durable", 0);
      if (i == 0)
      {
        if (localGemsConnectionNode != null) {
          localGemsConnectionNode.destroyDurable(str2, str3);
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class DisconnectClientAction
    implements ActionListener
  {
    DisconnectClientAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("client connection")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || ((!str1.startsWith("Connections")) && (!str1.equals("Clients"))))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a client connection on the Connection Info display to destroy", "Destroy Connection", 1);
        return;
      }
      int i = 1;
      Object localObject;
      if (str1.equals("Clients"))
      {
        str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol(2);
        localObject = Gems.this.m_detailsPanel.getModel().getSelectedCol(1);
        i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Connection: ID " + str2 + " for " + (String)localObject, "Destroy Client Connection", 0);
      }
      else
      {
        localObject = Gems.this.m_detailsPanel.getModel().getSelectedCol(3);
        i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Connection: ID " + str2 + " on " + (String)localObject, "Destroy Connection", 0);
      }
      if (i == 0)
      {
        localObject = Gems.this.getConnectionNode();
        if (localObject != null) {
          ((GemsConnectionNode)localObject).destroyConnection(str2);
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class CreateDurableAction
    implements ActionListener
  {
    CreateDurableAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      JTextField localJTextField1 = new JTextField(20);
      JPanel localJPanel = new JPanel();
      localJPanel.setLayout(new BoxLayout(localJPanel, 1));
      localJPanel.add(new JLabel("Durable Name:"));
      JTextField localJTextField2 = new JTextField(20);
      localJPanel.add(localJTextField2);
      localJPanel.add(new JLabel("Topic Name:"));
      localJPanel.add(localJTextField1);
      localJPanel.add(new JLabel("Client Id:"));
      JTextField localJTextField3 = new JTextField(25);
      localJPanel.add(localJTextField3);
      localJPanel.add(new JLabel("Selector:"));
      JTextField localJTextField4 = new JTextField(25);
      localJPanel.add(localJTextField4);
      int i = JOptionPane.showConfirmDialog(null, localJPanel, "Create Durable", 2);
      if (i == 0)
      {
        localGemsConnectionNode.createDurable(localJTextField2.getText(), localJTextField1.getText(), localJTextField3.getText(), localJTextField4.getText());
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class RemoveUserFromGroupAction
    implements ActionListener
  {
    RemoveUserFromGroupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("user")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || ((!str1.equals("Users")) && (!str1.equals("Groups"))))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a User to remove or a Group to remove from!", "Remove User From Group", 1);
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      String str3;
      if (str1.equals("Users"))
      {
        str3 = JOptionPane.showInputDialog(Gems.this.m_frame, "Remove User  " + str2 + "  From Group:");
        if (str3 != null) {
          localGemsConnectionNode.removeUserFromGroup(str2, str3);
        }
      }
      else
      {
        str3 = JOptionPane.showInputDialog(Gems.this.m_frame, "Remove From Group  " + str2 + "  User:");
        if (str3 != null) {
          localGemsConnectionNode.removeUserFromGroup(str3, str2);
        }
      }
      Gems.this.scheduleRepaint();
    }
  }
  
  class AddUserToGroupAction
    implements ActionListener
  {
    AddUserToGroupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("user")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || ((!str1.equals("Users")) && (!str1.equals("Groups"))))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a User to add or a Group to add to!", "Add User To Group", 1);
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      String str3;
      if (str1.equals("Users"))
      {
        str3 = JOptionPane.showInputDialog(Gems.this.m_frame, "Add User  " + str2 + "  To Group:");
        if (str3 != null) {
          localGemsConnectionNode.addUserToGroup(str2, str3);
        }
      }
      else
      {
        str3 = JOptionPane.showInputDialog(Gems.this.m_frame, "Add To Group  " + str2 + "  User:");
        if (str3 != null) {
          localGemsConnectionNode.addUserToGroup(str3, str2);
        }
      }
      Gems.this.scheduleRepaint();
    }
  }
  
  class CreateGroupAction
    implements ActionListener
  {
    CreateGroupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      JPanel localJPanel = new JPanel();
      localJPanel.setLayout(new BoxLayout(localJPanel, 1));
      localJPanel.add(new JLabel("Groupname:"));
      JTextField localJTextField1 = new JTextField(20);
      localJPanel.add(localJTextField1);
      localJPanel.add(new JLabel("Description:"));
      JTextField localJTextField2 = new JTextField(25);
      localJPanel.add(localJTextField2);
      int i = JOptionPane.showConfirmDialog(null, localJPanel, "Create Group", 2);
      if (i == 0)
      {
        localGemsConnectionNode.createGroup(localJTextField1.getText(), localJTextField2.getText());
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class DestroyGroupAction
    implements ActionListener
  {
    DestroyGroupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("group")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Groups")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Group to destroy!", "Destroy Group", 1);
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Group: " + str2, "Destroy Group", 0);
      if (i == 0)
      {
        if ((localGemsConnectionNode != null) && (localGemsConnectionNode.m_adminConn != null)) {
          try
          {
            localGemsConnectionNode.m_adminConn.destroyGroup(str2);
          }
          catch (TibjmsAdminException localTibjmsAdminException)
          {
            System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
            return;
          }
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class DestroyUserAction
    implements ActionListener
  {
    DestroyUserAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("user")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Users")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a User to destroy!", "Destroy User", 1);
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy User: " + str2, "Destroy User", 0);
      if (i == 0)
      {
        if (localGemsConnectionNode != null) {
          localGemsConnectionNode.destroyUser(str2);
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class UpdateUserAction
    implements ActionListener
  {
    UpdateUserAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("user")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = new String();
      if ((localDefaultMutableTreeNode != null) && (str2 != null) && (str1.equals("Users"))) {
        str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      JPasswordField localJPasswordField = new JPasswordField(20);
      JPanel localJPanel = new JPanel();
      localJPanel.setLayout(new BoxLayout(localJPanel, 1));
      localJPanel.add(new JLabel("Username:"));
      JTextField localJTextField1 = new JTextField(20);
      localJTextField1.setText(str2);
      localJPanel.add(localJTextField1);
      localJPanel.add(new JLabel("Password:"));
      localJPanel.add(localJPasswordField);
      localJPanel.add(new JLabel("Description:"));
      JTextField localJTextField2 = new JTextField(25);
      localJPanel.add(localJTextField2);
      int i = JOptionPane.showConfirmDialog(null, localJPanel, "Update User", 2);
      if (i == 0)
      {
        localGemsConnectionNode.updateUser(localJTextField1.getText(), new String(localJPasswordField.getPassword()), localJTextField2.getText());
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class CreateUserAction
    implements ActionListener
  {
    CreateUserAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("user")) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null) {
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      JPasswordField localJPasswordField = new JPasswordField(20);
      JPanel localJPanel = new JPanel();
      localJPanel.setLayout(new BoxLayout(localJPanel, 1));
      localJPanel.add(new JLabel("Username:"));
      JTextField localJTextField1 = new JTextField(20);
      localJPanel.add(localJTextField1);
      localJPanel.add(new JLabel("Password:"));
      localJPanel.add(localJPasswordField);
      localJPanel.add(new JLabel("Description:"));
      JTextField localJTextField2 = new JTextField(25);
      localJPanel.add(localJTextField2);
      int i = JOptionPane.showConfirmDialog(null, localJPanel, "Create User", 2);
      if (i == 0)
      {
        localGemsConnectionNode.createUser(localJTextField1.getText(), new String(localJPasswordField.getPassword()), localJTextField2.getText());
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class DestroyRouteAction
    implements ActionListener
  {
    DestroyRouteAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("route")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol(1);
      String str3 = Gems.this.m_detailsPanel.getModel().getSelectedCol(2);
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Routes")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Route to destroy!", "Destroy Route", 1);
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Route to Server: " + str2 + " at " + str3, "Destroy Route", 0);
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      if ((i == 0) && (localGemsConnectionNode != null) && (localGemsConnectionNode.m_adminConn != null))
      {
        try
        {
          localGemsConnectionNode.m_adminConn.destroyRoute(str2);
        }
        catch (TibjmsAdminException localTibjmsAdminException)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
          return;
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class CreateRouteAction
    implements ActionListener
  {
    CreateRouteAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      Object localObject = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      JPanel localJPanel = new JPanel(new SpringLayout());
      localJPanel.add(new JLabel("Server Name"));
      JTextField localJTextField1 = new JTextField(25);
      localJPanel.add(localJTextField1);
      localJPanel.add(new JLabel("Server URL:"));
      JTextField localJTextField2 = new JTextField(25);
      localJPanel.add(localJTextField2);
      localJTextField2.setText("tcp://localhost:7222");
      localJPanel.add(new JLabel("Zone Name:"));
      JTextField localJTextField3 = new JTextField(25);
      localJTextField3.setText("default_mhop_zone");
      localJPanel.add(localJTextField3);
      localJPanel.add(new JLabel("Zone Type:"));
      JComboBox localJComboBox = new JComboBox();
      localJComboBox.addItem("MultiHop");
      localJComboBox.addItem("OneHop");
      localJPanel.add(localJComboBox);
      SpringUtilities.makeCompactGrid(localJPanel, 4, 2, 5, 5, 5, 5);
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, localJPanel, "Create Route to Server", 2);
      if ((i == 0) && (localGemsConnectionNode != null) && (localGemsConnectionNode.m_adminConn != null))
      {
        try
        {
          RouteInfo localRouteInfo = new RouteInfo(localJTextField1.getText(), localJTextField2.getText(), null, localJTextField3.getText(), (short)(localJComboBox.getSelectedItem().equals("MultiHop") ? 0 : 1));
          localGemsConnectionNode.m_adminConn.createRoute(localRouteInfo);
        }
        catch (TibjmsAdminException localTibjmsAdminException)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
          return;
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class FindBridgeTargetsAction
    implements ActionListener
  {
    FindBridgeTargetsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str1 = new String();
      String str2 = "Topic";
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics"))
      {
        str1 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        str2 = "Topic";
      }
      else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics")))
      {
        str1 = (String)localDefaultMutableTreeNode1.getUserObject();
        str2 = "Topic";
      }
      else if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues"))
      {
        str1 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        str2 = "Queue";
      }
      else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues")))
      {
        str1 = (String)localDefaultMutableTreeNode1.getUserObject();
        str2 = "Queue";
      }
      if ((str1 == null) || (str1.length() == 0)) {
        str1 = "";
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      GemsManageBridgesDialog localGemsManageBridgesDialog = new GemsManageBridgesDialog(Gems.this.m_frame, localGemsConnectionNode, str2, str1, "Target");
      Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
    }
  }
  
  class DestroyBridgeAction
    implements ActionListener
  {
    DestroyBridgeAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("bridge")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      String str1 = (String)localDefaultMutableTreeNode.getUserObject();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol(1);
      if ((localDefaultMutableTreeNode == null) || (str2 == null) || (!str1.equals("Bridges")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Bridge to destroy!", "Destroy Bridge", 1);
        return;
      }
      String str3 = Gems.this.m_detailsPanel.getModel().getSelectedCol(2);
      String str4 = Gems.this.m_detailsPanel.getModel().getSelectedCol(3);
      String str5 = Gems.this.m_detailsPanel.getModel().getSelectedCol(4);
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "<html>Destroy Bridge:<p>Source " + str3 + ":" + str2 + "<p>Target " + str5 + ": " + str4 + "</html>", "Destroy Bridge", 0);
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      if ((i == 0) && (localGemsConnectionNode != null) && (localGemsConnectionNode.m_adminConn != null))
      {
        try
        {
          localGemsConnectionNode.m_adminConn.destroyDestinationBridge(str3.equals("Queue") ? 1 : 2, str2, str5.equals("Queue") ? 1 : 2, str4);
        }
        catch (TibjmsAdminException localTibjmsAdminException)
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
          return;
        }
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class CreateBridgeAction
    implements ActionListener
  {
    CreateBridgeAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("destination")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if ((localDefaultMutableTreeNode1 == null) || (localGemsConnectionNode == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a source destination to create a bridge from!", "Create Bridge", 1);
        return;
      }
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str = new String();
      boolean bool = true;
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics"))
      {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        bool = false;
      }
      else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics")))
      {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
        bool = false;
      }
      else if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues"))
      {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      }
      else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues")))
      {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      if ((str == null) || (str.length() == 0))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a destination to create a bridge from!", "Create Bridge", 1);
        return;
      }
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      GemsCreateBridgeDialog localGemsCreateBridgeDialog = new GemsCreateBridgeDialog(Gems.this.m_frame, localGemsConnectionNode, bool, str);
      if (localGemsCreateBridgeDialog.createBridge()) {
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class DestroyMessageAction
    implements ActionListener
  {
    DestroyMessageAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("xxx")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      Message localMessage = Gems.this.m_messagePanel.getModel().getSelectedMessage();
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null) || (!((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues")) || (Gems.this.m_tabPane.getSelectedIndex() != 3) || (localMessage == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Message to destroy!", "Destroy Message", 1);
        return;
      }
      try
      {
        String str = (String)localDefaultMutableTreeNode1.getUserObject();
        int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Message: " + localMessage.getJMSMessageID(), "Destroy Message", 0);
        if (i == 0) {
          Gems.this.getConnectionNode().removeMessage(localMessage);
        }
      }
      catch (Exception localException)
      {
        System.err.println("JMSException: " + localException.getMessage());
        return;
      }
    }
  }
  
  class MonitorConnectionAction
    implements ActionListener
  {
    MonitorConnectionAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsTopicSubscriber(localGemsConnectionNode, "$sys.monitor.connection.*", "Connection Monitor");
      }
    }
  }
  
  class MonitorRouteAction
    implements ActionListener
  {
    MonitorRouteAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsTopicSubscriber(localGemsConnectionNode, "$sys.monitor.route.*", "Route Monitor");
      }
    }
  }
  
  class ShowTopicsAction
    implements ActionListener
  {
    ShowTopicsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsDestDisplay(localGemsConnectionNode, "Topic");
      }
    }
  }
  
  class ShowQueuesAction
    implements ActionListener
  {
    ShowQueuesAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsDestDisplay(localGemsConnectionNode, "Queue");
      }
    }
  }
  
  class MonitorQueueAction
    implements ActionListener
  {
    MonitorQueueAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("queue")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Queue to monitor!", "Monitor Queue", 1);
        return;
      }
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsTopicSubscriber(localGemsConnectionNode, "$sys.monitor.Q.*." + str, "Queue Monitor");
      }
    }
  }
  
  class MonitorReqReplyQueueAction
    implements ActionListener
  {
    MonitorReqReplyQueueAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("queue")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Request Queue to monitor!", "Monitor Request/Reply Queue", 1);
        return;
      }
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsReqReplyMonitor(localGemsConnectionNode, str, true, "Queue Request/Reply Monitor");
      }
    }
  }
  
  class ResetSSAction
    implements ActionListener
  {
    ResetSSAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("SubStation")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "A SubStation Node or an item below the node must be selected", "Enable New SS Object", 1);
        return;
      }
      GemsSSNode localGemsSSNode = null;
      String str1 = "";
      if (localDefaultMutableTreeNode2.getClass().getSimpleName().equals("GemsSSNode")) {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode2;
      } else if (localDefaultMutableTreeNode1.getClass().getSimpleName().equals("GemsSSNode")) {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode1;
      } else {
        return;
      }
      String str2 = "";
      str2 = localGemsSSNode.RunCommand("REFRESH,COUNTERS");
      JOptionPane.showMessageDialog(Gems.this.m_frame, str2, "Refresh SS Counters", 1);
    }
  }
  
  class UnloadSSAction
    implements ActionListener
  {
    UnloadSSAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("SubStation")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent().getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null) || ((!((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active")) && (!((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Disabled"))))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Recipe or Trigger to Unload!", "Unload SS Object", 1);
        return;
      }
      String str1 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol(2);
      GemsSSNode localGemsSSNode = null;
      String str3 = "";
      if (localDefaultMutableTreeNode2.getClass().getSimpleName().equals("GemsSSNode")) {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode2;
      } else {
        return;
      }
      String str4 = ((String)((DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent()).getUserObject()).substring(5);
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active R")) {
        str3 = localGemsSSNode.RunCommand("UNLOAD,RID=" + str1 + ",INTF=" + str4);
      }
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active T")) {
        str3 = localGemsSSNode.RunCommand("UNLOAD,TID=" + str1 + ",INTF=" + str4);
      }
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Disabled")) {
        if (str2.equals("Recipe")) {
          str3 = localGemsSSNode.RunCommand("UNLOAD,RID=" + str1 + ",INTF=" + str4);
        } else {
          str3 = localGemsSSNode.RunCommand("UNLOAD,TID=" + str1 + ",INTF=" + str4);
        }
      }
      JOptionPane.showMessageDialog(Gems.this.m_frame, str3, "Refresh SS Object", 1);
    }
  }
  
  class NewSSRecipeAction
    implements ActionListener
  {
    NewSSRecipeAction() {}
    
    private Object makeObj(final String paramString)
    {
      new Object()
      {
        public String toString()
        {
          return paramString;
        }
      };
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("SubStation")) {
        return;
      }
      JPanel localJPanel = new JPanel();
      localJPanel.setLayout(new BoxLayout(localJPanel, 1));
      JLabel localJLabel = new JLabel("Name:");
      localJPanel.add(localJLabel);
      JTextField localJTextField = new JTextField(10);
      localJLabel.setLabelFor(localJTextField);
      localJPanel.add(localJTextField);
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      JComboBox localJComboBox1 = new JComboBox();
      GemsSSNode localGemsSSNode;
      int k;
      Object localObject1;
      Object localObject2;
      DefaultMutableTreeNode localDefaultMutableTreeNode2;
      if (localDefaultMutableTreeNode1.getParent().getParent().getClass().getSimpleName().equals("GemsSSNode"))
      {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode1.getParent().getParent();
        j = localGemsSSNode.getChildCount();
        for (k = 0; k < j; k++)
        {
          localObject1 = (DefaultMutableTreeNode)localGemsSSNode.getChildAt(k);
          localObject2 = (String)((DefaultMutableTreeNode)localObject1).getUserObject();
          if (((String)localObject2).startsWith("Int:")) {
            localJComboBox1.addItem(makeObj(((String)localObject2).substring(5)));
          }
        }
      }
      else if (localDefaultMutableTreeNode1.getParent().getClass().getSimpleName().equals("GemsSSNode"))
      {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode1.getParent();
        j = localGemsSSNode.getChildCount();
        for (k = 0; k < j; k++)
        {
          localObject1 = (DefaultMutableTreeNode)localGemsSSNode.getChildAt(k);
          localObject2 = (String)((DefaultMutableTreeNode)localObject1).getUserObject();
          if (((String)localObject2).startsWith("Int:")) {
            localJComboBox1.addItem(makeObj(((String)localObject2).substring(5)));
          }
        }
      }
      else if (localDefaultMutableTreeNode1.getClass().getSimpleName().equals("GemsSSNode"))
      {
        int i = localDefaultMutableTreeNode1.getChildCount();
        for (j = 0; j < i; j++)
        {
          localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getChildAt(j);
          localObject1 = (String)localDefaultMutableTreeNode2.getUserObject();
          if (((String)localObject1).startsWith("Int:")) {
            localJComboBox1.addItem(makeObj(((String)localObject1).substring(5)));
          }
        }
      }
      else
      {
        return;
      }
      localJPanel.add(localJComboBox1);
      JComboBox localJComboBox2 = new JComboBox(new String[] { "Recipe", "Trigger" });
      localJPanel.add(localJComboBox2);
      int j = JOptionPane.showConfirmDialog(null, localJPanel, "Enable New SubStation Object", 2);
      if (j == 0)
      {
        localDefaultMutableTreeNode2 = Gems.this.getSelectedNode();
        localObject1 = null;
        if (localDefaultMutableTreeNode2 != null)
        {
          localObject1 = (DefaultMutableTreeNode)localDefaultMutableTreeNode2.getParent();
          if (((String)((DefaultMutableTreeNode)localObject1).getUserObject()).startsWith("Int")) {
            localObject1 = (DefaultMutableTreeNode)((DefaultMutableTreeNode)localObject1).getParent();
          }
        }
        if ((localDefaultMutableTreeNode2 == null) || (localObject1 == null))
        {
          JOptionPane.showMessageDialog(Gems.this.m_frame, "A SubStation Node or an item below the node must be selected", "Enable New SS Object", 1);
          return;
        }
        localObject2 = null;
        String str1 = "";
        if (localObject1.getClass().getSimpleName().equals("GemsSSNode")) {
          localObject2 = (GemsSSNode)localObject1;
        } else if (localDefaultMutableTreeNode2.getClass().getSimpleName().equals("GemsSSNode")) {
          localObject2 = (GemsSSNode)localDefaultMutableTreeNode2;
        } else {
          return;
        }
        String str2 = localJTextField.getText();
        String str3 = localJComboBox2.getSelectedItem().toString();
        String str4 = localJComboBox1.getSelectedItem().toString();
        if (str3.equals("Recipe")) {
          str1 = ((GemsSSNode)localObject2).RunCommand("REFRESH,RID=" + str2 + ",INTF=" + str4);
        } else {
          str1 = ((GemsSSNode)localObject2).RunCommand("REFRESH,TID=" + str2 + ",INTF=" + str4);
        }
        JOptionPane.showMessageDialog(Gems.this.m_frame, str1, "Enable New SS Object", 1);
      }
    }
  }
  
  class DisableSSAction
    implements ActionListener
  {
    DisableSSAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("SubStation")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent().getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null) || (!((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Recipe or Trigger to Disable!", "Enable SS Object", 1);
        return;
      }
      String str1 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      GemsSSNode localGemsSSNode = null;
      String str2 = "";
      if (localDefaultMutableTreeNode2.getClass().getSimpleName().equals("GemsSSNode")) {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode2;
      } else {
        return;
      }
      String str3 = ((String)((DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent()).getUserObject()).substring(5);
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active R")) {
        str2 = localGemsSSNode.RunCommand("DISABLE,RID=" + str1 + ",INTF=" + str3);
      }
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active T")) {
        str2 = localGemsSSNode.RunCommand("DISABLE,TID=" + str1 + ",INTF=" + str3);
      }
      JOptionPane.showMessageDialog(Gems.this.m_frame, str2, "Disable SS Object", 1);
    }
  }
  
  class EnableSSAction
    implements ActionListener
  {
    EnableSSAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("SubStation")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent().getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null) || (!((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Disabled")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Recipe or Trigger to Enable!", "Enable SS Object", 1);
        return;
      }
      String str1 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol(2);
      GemsSSNode localGemsSSNode = null;
      String str3 = "";
      if (localDefaultMutableTreeNode2.getClass().getSimpleName().equals("GemsSSNode")) {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode2;
      } else {
        return;
      }
      String str4 = ((String)((DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent()).getUserObject()).substring(5);
      if (str2.equals("Recipe")) {
        str3 = localGemsSSNode.RunCommand("ENABLE,RID=" + str1 + ",INTF=" + str4);
      } else {
        str3 = localGemsSSNode.RunCommand("ENABLE,TID=" + str1 + ",INTF=" + str4);
      }
      JOptionPane.showMessageDialog(Gems.this.m_frame, str3, "Enable SS Object", 1);
    }
  }
  
  class RefreshSSAction
    implements ActionListener
  {
    RefreshSSAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("SubStation")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent().getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null) || ((!((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active")) && (!((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Disabled"))))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Recipe or Trigger to refresh!", "Refresh SS Object", 1);
        return;
      }
      String str1 = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      String str2 = Gems.this.m_detailsPanel.getModel().getSelectedCol(2);
      GemsSSNode localGemsSSNode = null;
      String str3 = "";
      if (localDefaultMutableTreeNode2.getClass().getSimpleName().equals("GemsSSNode")) {
        localGemsSSNode = (GemsSSNode)localDefaultMutableTreeNode2;
      } else {
        return;
      }
      String str4 = ((String)((DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent()).getUserObject()).substring(5);
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active R")) {
        str3 = localGemsSSNode.RunCommand("REFRESH,RID=" + str1 + ",INTF=" + str4);
      }
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Active T")) {
        str3 = localGemsSSNode.RunCommand("REFRESH,TID=" + str1 + ",INTF=" + str4);
      }
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Disabled")) {
        if (str2.equals("Recipe")) {
          str3 = localGemsSSNode.RunCommand("REFRESH,RID=" + str1 + ",INTF=" + str4);
        } else {
          str3 = localGemsSSNode.RunCommand("REFRESH,TID=" + str1 + ",INTF=" + str4);
        }
      }
      JOptionPane.showMessageDialog(Gems.this.m_frame, str3, "Refresh SS Object", 1);
    }
  }
  
  class BrowseQueueAction
    implements ActionListener
  {
    BrowseQueueAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("queue")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Queue to browse!", "Browse Queue", 1);
        return;
      }
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsQueueBrowser(localGemsConnectionNode, str);
      }
    }
  }
  
  class DeleteTopicAction
    implements ActionListener
  {
    DeleteTopicAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      Object localObject = null;
      if (localDefaultMutableTreeNode1 != null)
      {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
        String str = (String)localDefaultMutableTreeNode1.getUserObject();
        if (str.startsWith("Topics")) {
          localObject = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
          localObject = str;
        }
      }
      if (localObject == null)
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Topic to destroy!", "Destroy Topic", 1);
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Topic: " + (String)localObject, "Destroy Topic", 0);
      if (i == 0) {
        Gems.this.m_treeModel.removeTopic((String)localObject);
      }
    }
  }
  
  class CreateTopicAction
    implements ActionListener
  {
    CreateTopicAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      String str = JOptionPane.showInputDialog(Gems.this.m_frame, "Create Topic:");
      if (str != null) {
        Gems.this.m_treeModel.createTopic(str, false);
      }
    }
  }
  
  class PurgeTopicAction
    implements ActionListener
  {
    PurgeTopicAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      Object localObject = null;
      if (localDefaultMutableTreeNode1 != null)
      {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
        String str = (String)localDefaultMutableTreeNode1.getUserObject();
        if (str.startsWith("Topics")) {
          localObject = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
          localObject = str;
        }
      }
      if (localObject == null)
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Topic to purge!", "Purge Topic", 1);
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Purge Topic: " + (String)localObject, "Purge Topic", 0);
      if (i == 0)
      {
        Gems.this.m_treeModel.purgeTopic((String)localObject);
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class SetQueuePermissionsAction
    implements ActionListener
  {
    SetQueuePermissionsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if ((localDefaultMutableTreeNode1 == null) || (localGemsConnectionNode == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Queue to set permissions!", "Set Permissions On Queue", 1);
        return;
      }
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      GemsPermissionDialog localGemsPermissionDialog = new GemsPermissionDialog(Gems.this.m_frame, "Set Queue Permissions", true, localGemsConnectionNode, str);
    }
  }
  
  class SetTopicPermissionsAction
    implements ActionListener
  {
    SetTopicPermissionsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if ((localDefaultMutableTreeNode1 == null) || (localGemsConnectionNode == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Topic to set permissions!", "Set Permissions On Topic", 1);
        return;
      }
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      GemsPermissionDialog localGemsPermissionDialog = new GemsPermissionDialog(Gems.this.m_frame, "Set Topic Permissions", false, localGemsConnectionNode, str);
    }
  }
  
  class SetAdminPermissionsAction
    implements ActionListener
  {
    SetAdminPermissionsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("user or group")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if ((localDefaultMutableTreeNode1 == null) || (localGemsConnectionNode == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a user or goup to set permissions!", "Set Admin Permissions", 1);
        return;
      }
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str = null;
      if (((String)localDefaultMutableTreeNode1.getUserObject()).equals("Users")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).equals("Users"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      Object localObject;
      if (str != null)
      {
        localObject = new GemsAdminPermissionDialog(Gems.this.m_frame, localGemsConnectionNode, str, "User", Gems.this.m_detailsPanel.getModel().getSelectedCol(3));
      }
      else
      {
        localObject = null;
        if (((String)localDefaultMutableTreeNode1.getUserObject()).equals("Groups")) {
          localObject = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).equals("Groups"))) {
          localObject = (String)localDefaultMutableTreeNode1.getUserObject();
        }
        GemsAdminPermissionDialog localGemsAdminPermissionDialog;
        if (localObject != null) {
          localGemsAdminPermissionDialog = new GemsAdminPermissionDialog(Gems.this.m_frame, localGemsConnectionNode, (String)localObject, "Group", Gems.this.m_detailsPanel.getModel().getSelectedCol(3));
        } else {
          localGemsAdminPermissionDialog = new GemsAdminPermissionDialog(Gems.this.m_frame, localGemsConnectionNode);
        }
      }
    }
  }
  
  class MonitorTopicAction
    implements ActionListener
  {
    MonitorTopicAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if ((localDefaultMutableTreeNode1 == null) || (localGemsConnectionNode == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Topic to monitor!", "Monitor Topic", 1);
        return;
      }
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      new GemsTopicSubscriber(localGemsConnectionNode, "$sys.monitor.T.*." + str, "Topic Monitor");
    }
  }
  
  class RequestReplyTesterAction
    implements ActionListener
  {
    boolean m_isQueue = true;
    
    public RequestReplyTesterAction(boolean paramBoolean)
    {
      this.m_isQueue = paramBoolean;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode == null)
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select an EMS server in the tree view!", "Request/Reply Tester", 1);
        return;
      }
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      String str;
      if (this.m_isQueue)
      {
        str = new String();
        if (localDefaultMutableTreeNode1 != null) {
          if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues")) {
            str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
          } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
            str = (String)localDefaultMutableTreeNode1.getUserObject();
          }
        }
        new GemsReqReplyTester(localGemsConnectionNode, str, true, "Queue Request/Reply Tester");
      }
      else
      {
        str = new String();
        if (localDefaultMutableTreeNode1 != null) {
          if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics")) {
            str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
          } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
            str = (String)localDefaultMutableTreeNode1.getUserObject();
          }
        }
        new GemsReqReplyTester(localGemsConnectionNode, str, false, "Topic Request/Reply Tester");
      }
    }
  }
  
  class MonitorReqReplyTopicAction
    implements ActionListener
  {
    MonitorReqReplyTopicAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if ((localDefaultMutableTreeNode1 == null) || (localGemsConnectionNode == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Request Topic to monitor!", "Monitor Request/Reply Topic", 1);
        return;
      }
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      new GemsReqReplyMonitor(localGemsConnectionNode, str, false, "Topic Request/Reply Monitor");
    }
  }
  
  class SubscribeTopicAction
    implements ActionListener
  {
    SubscribeTopicAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if ((localDefaultMutableTreeNode1 == null) || (localGemsConnectionNode == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Topic to subscribe to!", "Subscribe To Topic", 1);
        return;
      }
      localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      new GemsTopicSubscriber(localGemsConnectionNode, str, "Topic Subscriber");
    }
  }
  
  class PurgeTMPTopicsAction
    implements ActionListener
  {
    PurgeTMPTopicsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      Object localObject = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      GemsPurgeTopics localGemsPurgeTopics = new GemsPurgeTopics(Gems.this.m_frame, localGemsConnectionNode, "$TMP$.>");
    }
  }
  
  class PurgeTopicsAction
    implements ActionListener
  {
    PurgeTopicsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      Object localObject = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      GemsPurgeTopics localGemsPurgeTopics = new GemsPurgeTopics(Gems.this.m_frame, localGemsConnectionNode);
    }
  }
  
  class PurgeTMPQueuesAction
    implements ActionListener
  {
    PurgeTMPQueuesAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      Object localObject = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      GemsPurgeQueues localGemsPurgeQueues = new GemsPurgeQueues(Gems.this.m_frame, localGemsConnectionNode, "$TMP$.>");
    }
  }
  
  class PurgeQueuesAction
    implements ActionListener
  {
    PurgeQueuesAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.this.getSelectedNode();
      Object localObject = null;
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      GemsPurgeQueues localGemsPurgeQueues = new GemsPurgeQueues(Gems.this.m_frame, localGemsConnectionNode);
    }
  }
  
  class SetServerPropertyAction
    implements ActionListener
  {
    SetServerPropertyAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      GemsConnectionNode localGemsConnectionNode = Gems.this.getConnectionNode();
      if (localGemsConnectionNode != null)
      {
        if (!Gems.this.isStandbyOpsAllowed(localGemsConnectionNode)) {
          return;
        }
        localGemsConnectionNode.setServerProperty("");
      }
    }
  }
  
  class PurgeQueueAction
    implements ActionListener
  {
    PurgeQueueAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("queue")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      Object localObject = null;
      if (localDefaultMutableTreeNode1 != null)
      {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
        String str = (String)localDefaultMutableTreeNode1.getUserObject();
        if (str.startsWith("Queues")) {
          localObject = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
          localObject = str;
        }
      }
      if (localObject == null)
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Queue to purge!", "Purge Queue", 1);
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Purge Queue: " + (String)localObject, "Purge Queue", 0);
      if (i == 0)
      {
        Gems.this.m_treeModel.purgeQueue((String)localObject);
        Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
      }
    }
  }
  
  class SetTopicPropertyAction
    implements ActionListener
  {
    SetTopicPropertyAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      String str = null;
      GemsTopicNode localGemsTopicNode = null;
      if (localDefaultMutableTreeNode1 != null)
      {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
        localObject = (String)localDefaultMutableTreeNode1.getUserObject();
        if (((String)localObject).startsWith("Topics"))
        {
          str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
          if (str != null)
          {
            Enumeration localEnumeration = localDefaultMutableTreeNode1.children();
            while (localEnumeration.hasMoreElements())
            {
              DefaultMutableTreeNode localDefaultMutableTreeNode3 = (DefaultMutableTreeNode)localEnumeration.nextElement();
              if ((localDefaultMutableTreeNode3 != null) && (str.equals((String)localDefaultMutableTreeNode3.getUserObject())))
              {
                localGemsTopicNode = (GemsTopicNode)localDefaultMutableTreeNode3;
                break;
              }
            }
          }
        }
        else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics")))
        {
          localGemsTopicNode = (GemsTopicNode)localDefaultMutableTreeNode1;
          str = (String)localGemsTopicNode.getUserObject();
        }
      }
      Object localObject = new GemsDestPropEditor(Gems.this.m_frame, Gems.this.getConnectionNode(), "Topic", str);
    }
  }
  
  class SetQueuePropertyAction
    implements ActionListener
  {
    SetQueuePropertyAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("queue")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      String str = null;
      GemsQueueNode localGemsQueueNode = null;
      if (localDefaultMutableTreeNode1 != null)
      {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
        localObject = (String)localDefaultMutableTreeNode1.getUserObject();
        if (((String)localObject).startsWith("Queues"))
        {
          str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
          if (str != null)
          {
            Enumeration localEnumeration = localDefaultMutableTreeNode1.children();
            while (localEnumeration.hasMoreElements())
            {
              DefaultMutableTreeNode localDefaultMutableTreeNode3 = (DefaultMutableTreeNode)localEnumeration.nextElement();
              if ((localDefaultMutableTreeNode3 != null) && (str.equals((String)localDefaultMutableTreeNode3.getUserObject())))
              {
                localGemsQueueNode = (GemsQueueNode)localDefaultMutableTreeNode3;
                break;
              }
            }
          }
        }
        else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues")))
        {
          localGemsQueueNode = (GemsQueueNode)localDefaultMutableTreeNode1;
          str = (String)localGemsQueueNode.getUserObject();
        }
      }
      Object localObject = new GemsDestPropEditor(Gems.this.m_frame, Gems.this.getConnectionNode(), "Queue", str);
    }
  }
  
  class DeleteQueueAction
    implements ActionListener
  {
    DeleteQueueAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("queue")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      Object localObject = null;
      if (localDefaultMutableTreeNode1 != null)
      {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
        String str = (String)localDefaultMutableTreeNode1.getUserObject();
        if (str.startsWith("Queues")) {
          localObject = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
        } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
          localObject = str;
        }
      }
      if ((localObject == null) || (((String)localObject).startsWith("$")))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Queue to destroy!", "Destroy Queue", 1);
        return;
      }
      int i = JOptionPane.showConfirmDialog(Gems.this.m_frame, "Destroy Queue: " + (String)localObject, "Destroy Queue", 0);
      if (i == 0) {
        Gems.this.m_treeModel.removeQueue((String)localObject);
      }
    }
  }
  
  class CreateQueueAction
    implements ActionListener
  {
    CreateQueueAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      JPanel localJPanel = new JPanel();
      localJPanel.setLayout(new BoxLayout(localJPanel, 1));
      localJPanel.add(new JLabel("Queue Name:"));
      JTextField localJTextField = new JTextField(10);
      localJPanel.add(localJTextField);
      localJPanel.add(new JLabel("For routed queue use queueName@serverName"));
      int i = JOptionPane.showConfirmDialog(null, localJPanel, "Create Queue", 2);
      if (i == 0)
      {
        String str = localJTextField.getText();
        if ((str != null) && (str.length() > 0)) {
          Gems.this.m_treeModel.createQueue(str, false);
        }
      }
    }
  }
  
  class SetServerTraceAction
    implements ActionListener
  {
    SetServerTraceAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected(null)) {
        return;
      }
      Gems.this.m_treeModel.setServerTrace();
    }
  }
  
  class AboutAction
    implements ActionListener
  {
    AboutAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      JOptionPane.showMessageDialog(Gems.this.m_frame, "<html><font size=\"5\">Gems v3.4</font><p><font size =\"4\">Graphical EMS Administration and Monitoring Tool</font><p><p>This software comes with no warranties of any kind. <p>See Terms of Use at: <a href=\"http://www.tibcommunity.com\">http://www.tibcommunity.com</a></html>", "About Gems", 1, Gems.this.m_icon);
    }
  }
  
  class ShowLicense
    implements ActionListener
  {
    ShowLicense() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsLicenseDialog localGemsLicenseDialog = new GemsLicenseDialog(Gems.this.m_frame);
      localGemsLicenseDialog.show();
    }
  }
  
  class ShowHelp
    implements ActionListener
  {
    ShowHelp() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsBrowser localGemsBrowser = new GemsBrowser("file:doc/index.htm");
    }
  }
  
  class PublishMessageAction
    implements ActionListener
  {
    boolean m_isMap = false;
    
    public PublishMessageAction(boolean paramBoolean)
    {
      this.m_isMap = paramBoolean;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("topic")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Topic to publish to!", "Publish Message", 1);
        return;
      }
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Topics")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(Gems.this.getConnectionNode(), true, str, false, Gems.this.m_frame, false, this.m_isMap);
    }
  }
  
  class SendMessageAction
    implements ActionListener
  {
    boolean m_isMap = false;
    
    public SendMessageAction(boolean paramBoolean)
    {
      this.m_isMap = paramBoolean;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (!Gems.this.checkConnected("queue")) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.this.getSelectedNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = null;
      if (localDefaultMutableTreeNode1 != null) {
        localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
      }
      if ((localDefaultMutableTreeNode1 == null) || (localDefaultMutableTreeNode2 == null))
      {
        JOptionPane.showMessageDialog(Gems.this.m_frame, "Select a Queue to send to!", "Send Message", 1);
        return;
      }
      String str = new String();
      if (((String)localDefaultMutableTreeNode1.getUserObject()).startsWith("Queues")) {
        str = Gems.this.m_detailsPanel.getModel().getSelectedCol1();
      } else if ((localDefaultMutableTreeNode2 != null) && (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues"))) {
        str = (String)localDefaultMutableTreeNode1.getUserObject();
      }
      GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(Gems.this.getConnectionNode(), true, str, true, Gems.this.m_frame, false, this.m_isMap);
    }
  }
  
  class RefreshTreeViewAction
    implements ActionListener
  {
    RefreshTreeViewAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Gems.this.m_treeModel.reloadTree();
    }
  }
  
  class RefreshAction
    implements ActionListener
  {
    RefreshAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Gems.this.treeSelectionChange(Gems.this.getSelectedNode(), false);
    }
  }
  
  class AddConnectionAction
    implements ActionListener
  {
    AddConnectionAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.this.m_treeModel.newJMSConnection("EMS Connection");
    }
  }
  
  class ShowTotalsAction
    implements ActionListener
  {
    ShowTotalsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      Gems.this.setShowTotals(!Gems.this.getShowTotals());
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\Gems.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */