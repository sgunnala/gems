package com.tibco.gems;

import com.tibco.tibjms.admin.BridgeInfo;
import com.tibco.tibjms.admin.BridgeTarget;
import com.tibco.tibjms.admin.DestinationBridgeInfo;
import java.awt.Color;
import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class GemsBridgeTableModel
  extends DefaultTableModel
  implements GetPopupHandler
{
  JTable m_table;
  boolean m_isEditable;
  boolean m_showCheckbox = false;
  PopupHandler m_popup = null;
  Object m_obj = new Object();
  MyRenderer m_renderer = new MyRenderer();
  MyCheckboxRenderer m_checkRenderer = new MyCheckboxRenderer();
  SimpleDateFormat dateFormatMillis = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
  GemsManageBridgesDialog m_manager = null;
  
  public GemsBridgeTableModel(boolean paramBoolean1, boolean paramBoolean2, GemsManageBridgesDialog paramGemsManageBridgesDialog)
  {
    this.m_isEditable = paramBoolean1;
    this.m_showCheckbox = paramBoolean2;
    this.m_manager = paramGemsManageBridgesDialog;
  }
  
  public PopupHandler getPopupHandler()
  {
    if (this.m_popup == null) {
      this.m_popup = new PopupBridgeTableHandler(this.m_table, this, this.m_manager);
    }
    return this.m_popup;
  }
  
  public Class getColumnClass(int paramInt)
  {
    Object localObject = getValueAt(0, paramInt);
    if (localObject != null) {
      return localObject.getClass();
    }
    return String.class;
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    if ((this.m_showCheckbox) && (paramInt2 < 1)) {
      return true;
    }
    return this.m_isEditable;
  }
  
  public Vector getSelectedBridges()
  {
    Vector localVector = new Vector();
    if (this.m_showCheckbox) {
      for (int i = 0; i < getRowCount(); i++) {
        if (((Boolean)this.m_table.getValueAt(i, 0)).booleanValue()) {
          localVector.add(new DestinationBridgeInfo(this.m_table.getValueAt(i, 2).equals("Queue") ? 1 : 2, (String)this.m_table.getValueAt(i, 1), this.m_table.getValueAt(i, 4).equals("Queue") ? 1 : 2, (String)this.m_table.getValueAt(i, 3), ""));
        }
      }
    }
    return localVector;
  }
  
  public void selectAllRows()
  {
    if (this.m_showCheckbox) {
      for (int i = 0; i < getRowCount(); i++) {
        this.m_table.setValueAt(new Boolean(true), i, 0);
      }
    }
  }
  
  public void toggleSelectedRow()
  {
    this.m_table.setValueAt(new Boolean(!((Boolean)this.m_table.getValueAt(this.m_table.getSelectedRow(), 0)).booleanValue()), this.m_table.getSelectedRow(), 0);
  }
  
  public void buildColumnHeaders()
  {
    setRowCount(0);
    setColumnCount(0);
    this.m_table.setAutoResizeMode(0);
    this.m_table.setDefaultRenderer(Boolean.class, this.m_checkRenderer);
    String[] arrayOfString;
    if (this.m_showCheckbox) {
      arrayOfString = new String[] { "Sel", "Source Destination", "Source Type", "Target Destination", "Target Type", "Selector" };
    } else {
      arrayOfString = new String[] { "Source Destination", "Source Type", "Target Destination", "Target Type", "Selector" };
    }
    setColumnIdentifiers(arrayOfString);
    if (this.m_showCheckbox) {
      this.m_table.getColumn("Sel").setPreferredWidth(30);
    }
    this.m_table.getColumn("Source Destination").setPreferredWidth(250);
    this.m_table.getColumn("Target Destination").setPreferredWidth(250);
    this.m_table.getColumn("Source Type").setPreferredWidth(80);
    this.m_table.getColumn("Target Type").setPreferredWidth(80);
    this.m_table.getColumn("Selector").setPreferredWidth(250);
  }
  
  public void addBridge(BridgeInfo paramBridgeInfo, Pattern paramPattern)
  {
    if (paramBridgeInfo != null)
    {
      BridgeTarget[] arrayOfBridgeTarget = paramBridgeInfo.getTargets();
      for (int i = 0; i < arrayOfBridgeTarget.length; i++) {
        if ((paramPattern == null) || (paramPattern.matcher(arrayOfBridgeTarget[i].getName()).matches()))
        {
          Object[] arrayOfObject;
          if (this.m_showCheckbox) {
            arrayOfObject = new Object[] { new Boolean(false), paramBridgeInfo.getName(), new String(paramBridgeInfo.getType() == 1 ? "Queue" : "Topic"), arrayOfBridgeTarget[i].getName(), new String(arrayOfBridgeTarget[i].getType() == 1 ? "Queue" : "Topic"), arrayOfBridgeTarget[i].getSelector() };
          } else {
            arrayOfObject = new Object[] { paramBridgeInfo.getName(), new String(paramBridgeInfo.getType() == 1 ? "Queue" : "Topic"), arrayOfBridgeTarget[i].getName(), new String(arrayOfBridgeTarget[i].getType() == 1 ? "Queue" : "Topic"), arrayOfBridgeTarget[i].getSelector() };
          }
          addRow(arrayOfObject);
        }
      }
    }
  }
  
  public void populateBridgeInfo(BridgeInfo[] paramArrayOfBridgeInfo, Pattern paramPattern)
  {
    setRowCount(0);
    if (paramArrayOfBridgeInfo == null) {
      return;
    }
    for (int i = 0; i < paramArrayOfBridgeInfo.length; i++) {
      addBridge(paramArrayOfBridgeInfo[i], paramPattern);
    }
  }
  
  class MyRenderer
    extends DefaultTableCellRenderer
  {
    public MyRenderer()
    {
      setToolTipText("Select checkboxes of destinations to purge");
    }
    
    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      Component localComponent = super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
      if ((paramObject instanceof Long))
      {
        setHorizontalAlignment(4);
        if ((((Long)paramObject).longValue() > 0L) && (paramJTable.getColumnName(paramInt2).startsWith("Pending"))) {
          localComponent.setBackground(Color.orange);
        } else if (paramBoolean1) {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        } else {
          localComponent.setBackground(Color.white);
        }
      }
      else
      {
        setHorizontalAlignment(2);
        if (paramBoolean1) {
          localComponent.setBackground(paramJTable.getSelectionBackground());
        } else {
          localComponent.setBackground(Color.white);
        }
      }
      return localComponent;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsBridgeTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */