package com.tibco.gems;

import com.tibco.gems.chart.GemsChartFrame;
import com.tibco.gems.chart.GemsSubscriber;
import com.tibco.tibjms.admin.ConnectionInfo;
import com.tibco.tibjms.admin.GroupInfo;
import com.tibco.tibjms.admin.QueueInfo;
import com.tibco.tibjms.admin.ServerInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import com.tibco.tibjms.admin.TopicInfo;
import com.tibco.tibjms.admin.TraceInfo;
import com.tibco.tibjms.admin.UserInfo;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;
import javax.jms.Message;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class GemsConnectionNode
  extends IconNode
  implements Runnable
{
  String m_url;
  String m_user;
  String m_password;
  String m_logDir = "./log";
  LOG_TYPE m_logServerInfo = LOG_TYPE.Never;
  Vector m_logColumnNames = null;
  File m_logFile = null;
  FileOutputStream m_fileOut = null;
  PrintStream m_filePrint = null;
  SimpleDateFormat m_fileDateFormat = new SimpleDateFormat("ddMMMyyyy");
  SimpleDateFormat dateFormatMillis = null;
  TibjmsAdmin m_adminConn = null;
  ServerInfo m_serverInfo = null;
  DefaultMutableTreeNode m_topicsNode = null;
  DefaultMutableTreeNode m_queuesNode = null;
  DefaultMutableTreeNode m_usersNode = null;
  DefaultMutableTreeNode m_consumersNode = null;
  DefaultMutableTreeNode m_channelsNode = null;
  DefaultMutableTreeNode m_producersNode = null;
  DefaultMutableTreeNode m_connectionsNode = null;
  DefaultMutableTreeNode m_sysConnectionsNode = null;
  DefaultMutableTreeNode m_clientsNode = null;
  DefaultMutableTreeNode m_routesNode = null;
  DefaultMutableTreeNode m_bridgesNode = null;
  DefaultMutableTreeNode m_transactionsNode = null;
  DefaultMutableTreeNode m_transportsNode = null;
  DefaultMutableTreeNode m_durablesNode = null;
  DefaultMutableTreeNode m_groupsNode = null;
  DefaultMutableTreeNode m_aclsNode = null;
  DefaultMutableTreeNode m_adminAclsNode = null;
  DefaultMutableTreeNode m_factoriesNode = null;
  DefaultMutableTreeNode m_storesFileNode = null;
  DefaultMutableTreeNode m_storesDbNode = null;
  DefaultMutableTreeNode m_mstoresNode = null;
  DefaultMutableTreeNode m_serviceNode = null;
  Vector m_ssNodes = null;
  DefaultMutableTreeNode m_ssTriggerNode = null;
  DefaultMutableTreeNode m_ssRecipeNode = null;
  DefaultMutableTreeNode m_ssInterfaceNode = null;
  Hashtable m_warnLimits = null;
  Hashtable m_errorLimits = null;
  Hashtable m_clientIDs = null;
  Properties m_SSSystems = new Properties();
  long m_delay = 0L;
  Thread m_thread = null;
  static Hashtable props = null;
  boolean m_isAutoConnect = false;
  boolean m_isInError = false;
  boolean m_isInWarning = false;
  Map m_sslParams = new Hashtable();
  GemsServiceTable m_services = null;
  GemsEventMonitor m_eventMonitor = null;
  protected GemsSubscriber m_sub = null;
  protected GemsChartFrame m_chart = null;
  protected Timer m_chartUpdateTimer = null;
  static Hashtable connections = new Hashtable();
  
  static Hashtable getConnections()
  {
    return connections;
  }
  
  public synchronized void init()
  {
    if (props == null) {
      try
      {
        props = new Hashtable();
        props.put("isAuthorizationEnabled", new GemsProperty("AuthorizationEnabled", Boolean.TYPE, "<html>Enable or disable Authorization mode<br> for subsequent requests</html>"));
        props.put("DetailedStatistics", new GemsProperty("DetailedStatistics", Integer.TYPE, "<html>0 = None, or a combination of<br>2 = Producers, 4 = Consumers, 8 = Routes</html>"));
        props.put("MaxMsgMemory", new GemsProperty("MaxMsgMemory", Long.TYPE, "<html>Maximum number of bytes the<br>server can use for messages</html>"));
        props.put("MaxStatisticsMemory", new GemsProperty("MaxStatisticsMemory", Long.TYPE, "<html>Maximum amount of memory (bytes)<br>to use for detailed statistic gathering</html>"));
        props.put("isMessageSwappingEnabled", new GemsProperty("MessageSwappingEnabled", Boolean.TYPE, "<html>Enables or disables the ability to swap<br>messages to disk</html>"));
        props.put("RateInterval", new GemsProperty("RateInterval", Long.TYPE, "<html>The statistics interval(millisecs) for routes<br>destinations, producers, and consumers</html>"));
        props.put("ServerRateInterval", new GemsProperty("ServerRateInterval", Long.TYPE, "<html>The interval(millisecs) over which server<br>statistics are averaged</html>"));
        props.put("StatisticsCleanupInterval", new GemsProperty("StatisticsCleanupInterval", Long.TYPE, "<html>How long (in millisecs) the server keeps detailed<br>statistics if the destination has no activity</html>"));
        props.put("isStatisticsEnabled", new GemsProperty("StatisticsEnabled", Boolean.TYPE, "<html>Enables or disables statistic gathering for<br>producers, consumers, destinations, and routes</html>"));
        props.put("isTrackCorrelationIds", new GemsProperty("TrackCorrelationIds", Boolean.TYPE, "<html>Enables or disables tracking messages<br>by CorrelationID</html>"));
        props.put("isTrackMsgIds", new GemsProperty("TrackMsgIds", Boolean.TYPE, "<html>Enables or disables tracking<br>messages by MessageID</html>"));
        props.put("MulticastStatisticsInterval", new GemsProperty("MulticastStatisticsInterval", Long.TYPE, "<html>Multicast statistics interval in milliseconds<br>0 disables multicast statistics collection</html>"));
      }
      catch (Throwable localThrowable1)
      {
        System.err.println(localThrowable1);
      }
    }
    try
    {
      this.dateFormatMillis = new SimpleDateFormat(Gems.getGems().getLogDateTimeFormat());
    }
    catch (Throwable localThrowable2)
    {
      System.err.println("Bad LogDateTimeFormat in gems.props file: " + localThrowable2);
      this.dateFormatMillis = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
    }
  }
  
  public GemsConnectionNode(String paramString)
  {
    super(paramString, true);
    this.m_url = "tcp://localhost:7222";
    this.m_user = "admin";
    setIconName("computer");
    init();
  }
  
  public GemsConnectionNode(String paramString1, String paramString2, String paramString3, String paramString4, long paramLong, boolean paramBoolean, LOG_TYPE paramLOG_TYPE, String paramString5)
  {
    super(paramString1, true);
    this.m_url = paramString2;
    this.m_user = paramString3;
    this.m_password = paramString4;
    this.m_delay = (paramLong * 1000L);
    this.m_logDir = paramString5;
    this.m_logServerInfo = paramLOG_TYPE;
    setIconName("computer");
    init();
    this.m_isAutoConnect = paramBoolean;
  }
  
  public boolean showError()
  {
    if (this.m_adminConn == null) {
      return true;
    }
    if ((this.m_eventMonitor != null) && (this.m_eventMonitor.m_messages.size() > 0)) {
      return true;
    }
    return this.m_isInError;
  }
  
  public boolean showWarning()
  {
    return this.m_isInWarning;
  }
  
  public boolean showEvents()
  {
    return this.m_eventMonitor != null;
  }
  
  public boolean isAutoConnect()
  {
    return this.m_isAutoConnect;
  }
  
  public boolean isSSL()
  {
    return this.m_url.startsWith("ssl");
  }
  
  public void addEventMonitor(long paramLong, boolean paramBoolean)
  {
    this.m_eventMonitor = new GemsEventMonitor(this, paramLong, paramBoolean);
  }
  
  public void addEventSubscription(String paramString1, String paramString2)
  {
    this.m_eventMonitor.addSubscription(paramString1, paramString2);
  }
  
  public void clearEventMessages()
  {
    if (this.m_eventMonitor != null) {
      this.m_eventMonitor.reset();
    }
  }
  
  public Vector getEventMessages()
  {
    if (this.m_eventMonitor != null) {
      return this.m_eventMonitor.getMessages();
    }
    return null;
  }
  
  public int getEventCount()
  {
    if (this.m_eventMonitor != null) {
      return this.m_eventMonitor.getMessageCount();
    }
    return 0;
  }
  
  public void addServiceTable(long paramLong, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    this.m_services = new GemsServiceTable(this, paramLong, paramBoolean1, paramBoolean2, paramBoolean3);
  }
  
  public void addService(String paramString1, String paramString2, boolean paramBoolean1, String paramString3, boolean paramBoolean2, long paramLong)
  {
    this.m_services.addService(paramString1, paramString2, paramBoolean1, paramString3, paramBoolean2, paramLong);
  }
  
  public TraceInfo getServerTrace(boolean paramBoolean)
  {
    if (this.m_adminConn == null) {
      return null;
    }
    try
    {
      ServerInfo localServerInfo = this.m_adminConn.getInfo();
      if (localServerInfo != null)
      {
        if (paramBoolean) {
          return localServerInfo.getLogTraceInfo();
        }
        return localServerInfo.getConsoleTraceInfo();
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
    }
    return null;
  }
  
  public void setServerTrace(TraceInfo paramTraceInfo, boolean paramBoolean)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      ServerInfo localServerInfo = this.m_adminConn.getInfo();
      if (localServerInfo != null)
      {
        if (paramBoolean) {
          localServerInfo.setLogTraceInfo(paramTraceInfo);
        } else {
          localServerInfo.setTraceBufferTraceInfo(paramTraceInfo);
        }
        this.m_adminConn.updateServer(localServerInfo);
        Gems.getGems().scheduleRepaint();
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void setServerProperty(String paramString)
  {
    if ((this.m_adminConn == null) || (paramString == null)) {
      return;
    }
    try
    {
      GemsProperty localGemsProperty = (GemsProperty)props.get(paramString);
      String str1 = null;
      ServerInfo localServerInfo = this.m_adminConn.getInfo();
      if (localServerInfo == null) {
        return;
      }
      if (paramString != null)
      {
        localGemsProperty = (GemsProperty)props.get(paramString);
        if (localGemsProperty != null) {
          str1 = localGemsProperty.getValue(localServerInfo);
        }
      }
      GemsSetPropDialog localGemsSetPropDialog = new GemsSetPropDialog(Gems.getGems().m_frame, "Set server Property for " + (String)getUserObject());
      String str2 = localGemsSetPropDialog.getValue(props, paramString, str1);
      if (str2 != null)
      {
        localGemsProperty = (GemsProperty)props.get(localGemsSetPropDialog.getSelectedProp());
        localGemsProperty.setValue(localServerInfo, str2);
        this.m_adminConn.updateServer(localServerInfo);
        Gems.getGems().scheduleRepaint();
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(Gems.getGems().m_frame, localTibjmsAdminException.getMessage(), "Set Server Property", 0);
      return;
    }
  }
  
  public void disconnect()
  {
    if (this.m_ssNodes != null)
    {
      for (int i = 0; i < this.m_ssNodes.size(); i++)
      {
        GemsSSNode localGemsSSNode = (GemsSSNode)this.m_ssNodes.get(i);
        localGemsSSNode.destroy();
      }
      this.m_ssNodes.removeAllElements();
    }
    if (this.m_eventMonitor != null) {
      this.m_eventMonitor.systemStop();
    }
    if (this.m_services != null) {
      this.m_services.systemStop();
    }
    removeAllChildren();
    String str = (String)getUserObject();
    str = str + "(" + this.m_url + ")";
    connections.remove(str);
    if (this.m_services != null) {
      this.m_services.stopServices();
    }
    try
    {
      if (this.m_adminConn != null) {
        this.m_adminConn.close();
      }
      this.m_adminConn = null;
      this.m_serverInfo = null;
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void connect(String paramString1, String paramString2, String paramString3, String paramString4, Map paramMap)
  {
    setUserObject(paramString1);
    this.m_url = paramString2;
    this.m_user = paramString3;
    this.m_password = paramString4;
    this.m_sslParams = paramMap;
    connect();
  }
  
  public void connect(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    setUserObject(paramString1);
    this.m_url = paramString2;
    this.m_user = paramString3;
    this.m_password = paramString4;
    connect();
  }
  
  public void setSSLParams(Map paramMap)
  {
    this.m_sslParams = paramMap;
  }
  
  public String getName()
  {
    return (String)getUserObject();
  }
  
  public synchronized void connect()
  {
    removeAllChildren();
    try
    {
      System.err.println("Connecting to: " + this.m_url);
      if ((isSSL()) && (this.m_sslParams != null)) {
        this.m_adminConn = new TibjmsAdmin(this.m_url, this.m_user, this.m_password, this.m_sslParams);
      } else {
        this.m_adminConn = new TibjmsAdmin(this.m_url, this.m_user, this.m_password);
      }
      this.m_adminConn.setAutoSave(true);
      this.m_adminConn.setCommandTimeout(Gems.getGems().getAdminTimeout());
      String str1 = (String)getUserObject();
      str1 = str1 + "(" + this.m_url + ")";
      connections.put(str1, this);
      Gems.debug("Got connection");
      this.m_serverInfo = this.m_adminConn.getInfo();
      Gems.debug("Got serverInfo");
      updateErrorWarningFlags();
      this.m_logColumnNames = ReflectionUtils.getGetterMethodNames(this.m_serverInfo.getClass());
    }
    catch (TibjmsAdminException localTibjmsAdminException1)
    {
      System.err.println(localTibjmsAdminException1.toString());
      return;
    }
    String str2 = Gems.getGems().getHideViews();
    if (str2.indexOf("ACLs") < 0)
    {
      this.m_aclsNode = new DefaultMutableTreeNode("ACLs", true);
      add(this.m_aclsNode);
      this.m_adminAclsNode = new DefaultMutableTreeNode("AdminACLs", true);
      add(this.m_adminAclsNode);
    }
    if (str2.indexOf("Bridges") < 0)
    {
      this.m_bridgesNode = new DefaultMutableTreeNode("Bridges", true);
      add(this.m_bridgesNode);
    }
    if (str2.indexOf("Channels") < 0)
    {
      this.m_channelsNode = new DefaultMutableTreeNode("Channels", true);
      add(this.m_channelsNode);
    }
    if (str2.indexOf("Clients") < 0)
    {
      this.m_clientsNode = new DefaultMutableTreeNode("Clients", true);
      add(this.m_clientsNode);
    }
    if (str2.indexOf("Connections") < 0)
    {
      this.m_connectionsNode = new DefaultMutableTreeNode("Connections(Client)", true);
      add(this.m_connectionsNode);
      this.m_sysConnectionsNode = new DefaultMutableTreeNode("Connections(System)", true);
      add(this.m_sysConnectionsNode);
    }
    if (str2.indexOf("Consumers") < 0)
    {
      this.m_consumersNode = new DefaultMutableTreeNode("Consumers", true);
      add(this.m_consumersNode);
    }
    if (str2.indexOf("Durables") < 0)
    {
      this.m_durablesNode = new DefaultMutableTreeNode("Durables", true);
      add(this.m_durablesNode);
    }
    if (str2.indexOf("Factories") < 0)
    {
      this.m_factoriesNode = new DefaultMutableTreeNode("Factories", true);
      add(this.m_factoriesNode);
    }
    if (str2.indexOf("Groups") < 0)
    {
      this.m_groupsNode = new DefaultMutableTreeNode("Groups", true);
      add(this.m_groupsNode);
    }
    if (str2.indexOf("Producers") < 0)
    {
      this.m_producersNode = new DefaultMutableTreeNode("Producers", true);
      add(this.m_producersNode);
    }
    if (str2.indexOf("Queues") < 0)
    {
      String str3 = Gems.getGems().getQueueNamePattern();
      if (str3.equals(">")) {
        this.m_queuesNode = new DefaultMutableTreeNode("Queues", true);
      } else {
        this.m_queuesNode = new DefaultMutableTreeNode("Queues(" + str3 + ")", true);
      }
      add(this.m_queuesNode);
    }
    if (str2.indexOf("Routes") < 0)
    {
      this.m_routesNode = new DefaultMutableTreeNode("Routes", true);
      add(this.m_routesNode);
    }
    if (this.m_services != null)
    {
      this.m_serviceNode = new DefaultMutableTreeNode("Services", true);
      add(this.m_serviceNode);
    }
    if (str2.indexOf("Stores") < 0)
    {
      this.m_storesFileNode = new DefaultMutableTreeNode("Stores(File)", true);
      add(this.m_storesFileNode);
      this.m_storesDbNode = new DefaultMutableTreeNode("Stores(DB)", true);
      add(this.m_storesDbNode);
      try
      {
        if (Class.forName("com.tibco.tibjms.admin.MStoreInfo") != null)
        {
          this.m_mstoresNode = new DefaultMutableTreeNode("Stores(MStore)", true);
          add(this.m_mstoresNode);
        }
      }
      catch (Exception localException) {}
    }
    if (str2.indexOf("Topics") < 0)
    {
      localObject = Gems.getGems().getTopicNamePattern();
      if (((String)localObject).equals(">")) {
        this.m_topicsNode = new DefaultMutableTreeNode("Topics", true);
      } else {
        this.m_topicsNode = new DefaultMutableTreeNode("Topics(" + (String)localObject + ")", true);
      }
      add(this.m_topicsNode);
    }
    if (str2.indexOf("Transactions") < 0)
    {
      this.m_transactionsNode = new DefaultMutableTreeNode("Transactions", true);
      add(this.m_transactionsNode);
    }
    if (str2.indexOf("Transports") < 0)
    {
      this.m_transportsNode = new DefaultMutableTreeNode("Transports", true);
      add(this.m_transportsNode);
    }
    if (str2.indexOf("Users") < 0)
    {
      this.m_usersNode = new DefaultMutableTreeNode("Users", true);
      add(this.m_usersNode);
    }
    Object localObject = this.m_SSSystems.propertyNames();
    while (((Enumeration)localObject).hasMoreElements())
    {
      String str4 = (String)((Enumeration)localObject).nextElement();
      if (this.m_ssNodes == null) {
        this.m_ssNodes = new Vector();
      }
      Properties localProperties = (Properties)this.m_SSSystems.get(str4);
      GemsSSNode localGemsSSNode = new GemsSSNode(str4, localProperties.getProperty("QUEUE"), localProperties.getProperty("VERSION"), this);
      add(localGemsSSNode);
      this.m_ssTriggerNode = new DefaultMutableTreeNode("Counters", true);
      localGemsSSNode.add(this.m_ssTriggerNode);
      this.m_ssTriggerNode = new DefaultMutableTreeNode("Interfaces", true);
      localGemsSSNode.add(this.m_ssTriggerNode);
      this.m_ssTriggerNode = new DefaultMutableTreeNode("Transports", true);
      localGemsSSNode.add(this.m_ssTriggerNode);
      Enumeration localEnumeration = localProperties.propertyNames();
      while (localEnumeration.hasMoreElements())
      {
        String str5 = (String)localEnumeration.nextElement();
        if ((str5 != "QUEUE") && (str5 != "VERSION"))
        {
          if (localProperties.getProperty(str5) == "INT")
          {
            this.m_ssInterfaceNode = new DefaultMutableTreeNode("Int: " + str5, true);
            localGemsSSNode.add(this.m_ssInterfaceNode);
            this.m_ssRecipeNode = new DefaultMutableTreeNode("Active Recipes", true);
            this.m_ssInterfaceNode.add(this.m_ssRecipeNode);
            this.m_ssRecipeNode = new DefaultMutableTreeNode("Active Triggers", true);
            this.m_ssInterfaceNode.add(this.m_ssRecipeNode);
            this.m_ssTriggerNode = new DefaultMutableTreeNode("Disabled", true);
            this.m_ssInterfaceNode.add(this.m_ssTriggerNode);
            this.m_ssTriggerNode = new DefaultMutableTreeNode("Listeners", true);
            this.m_ssInterfaceNode.add(this.m_ssTriggerNode);
          }
          if (localProperties.getProperty(str5) == "IMS")
          {
            this.m_ssInterfaceNode = new DefaultMutableTreeNode("IMS", true);
            localGemsSSNode.add(this.m_ssInterfaceNode);
            this.m_ssRecipeNode = new DefaultMutableTreeNode("IMS Statistics", true);
            this.m_ssInterfaceNode.add(this.m_ssRecipeNode);
            this.m_ssRecipeNode = new DefaultMutableTreeNode("IMS Buffers", true);
            this.m_ssInterfaceNode.add(this.m_ssRecipeNode);
          }
        }
      }
      this.m_ssNodes.add(localGemsSSNode);
    }
    try
    {
      if (this.m_topicsNode != null) {
        if ((this.m_serverInfo.getTopicCount() > Gems.getGems().getMaxTopics()) && (Gems.getGems().getTopicNamePattern().length() <= 1))
        {
          System.err.println("Warning: Over " + Gems.getGems().getMaxTopics() + " topics, main topics display disabled. Increase MaxTopics or configure a TopicNamePattern in the gems.props property file");
        }
        else
        {
          try
          {
            localObject = this.m_adminConn.getTopics(Gems.getGems().getTopicNamePattern(), Gems.getGems().getPermType());
          }
          catch (Throwable localThrowable1)
          {
            localObject = this.m_adminConn.getTopics(Gems.getGems().getTopicNamePattern());
          }
          for (int i = 0; i < localObject.length; i++) {
            if (!localObject[i].getName().startsWith("$sys")) {
              this.m_topicsNode.add(new GemsTopicNode(localObject[i].getName()));
            }
          }
        }
      }
      if (this.m_queuesNode != null) {
        if ((this.m_serverInfo.getQueueCount() > Gems.getGems().getMaxQueues()) && (Gems.getGems().getQueueNamePattern().length() <= 1))
        {
          System.err.println("Warning: Over " + Gems.getGems().getMaxQueues() + " queues, main queues display disabled. Increase MaxQueues or configure a QueueNamePattern in the gems.props property file");
        }
        else
        {
          try
          {
            localObject = this.m_adminConn.getQueues(Gems.getGems().getQueueNamePattern(), Gems.getGems().getPermType());
          }
          catch (Throwable localThrowable2)
          {
            localObject = this.m_adminConn.getQueues(Gems.getGems().getQueueNamePattern());
          }
          for (int j = 0; j < localObject.length; j++) {
            try
            {
              boolean bool = localObject[j].isRouted();
              this.m_queuesNode.add(new GemsQueueNode(localObject[j].getName(), bool));
            }
            catch (Throwable localThrowable3)
            {
              this.m_queuesNode.add(new GemsQueueNode(localObject[j].getName()));
            }
          }
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException2)
    {
      System.err.println("JMSException: " + localTibjmsAdminException2.getMessage());
      return;
    }
    if ((this.m_serverInfo != null) && (this.m_serverInfo.getState() == 4))
    {
      if (this.m_eventMonitor != null) {
        this.m_eventMonitor.systemStart();
      }
      if (this.m_services != null) {
        this.m_services.systemStart();
      }
    }
  }
  
  public boolean isFtUrl()
  {
    return (this.m_url != null) && (this.m_url.indexOf(',') > 0);
  }
  
  public synchronized boolean isStandbyMode()
  {
    return (this.m_serverInfo != null) && (this.m_serverInfo.getState() == 3);
  }
  
  public synchronized ServerInfo getJmsServerInfo(boolean paramBoolean)
  {
    if (!paramBoolean) {
      return this.m_serverInfo;
    }
    if (this.m_adminConn != null) {
      try
      {
        this.m_serverInfo = this.m_adminConn.getInfo();
        if (this.m_chartUpdateTimer != null) {
          this.m_chartUpdateTimer.start();
        }
        updateErrorWarningFlags();
        doLogging();
      }
      catch (TibjmsAdminException localTibjmsAdminException)
      {
        System.err.println("JMSException: " + localTibjmsAdminException.toString());
        System.err.println("Disconnecting from " + this.m_url);
        disconnect();
      }
      catch (Exception localException)
      {
        System.err.println("Exception: " + localException.toString());
        System.err.println("Disconnecting from " + this.m_url);
        disconnect();
      }
    }
    return this.m_serverInfo;
  }
  
  public synchronized ServerInfo getJmsServerInfoUserReq(boolean paramBoolean)
  {
    if (!paramBoolean) {
      return this.m_serverInfo;
    }
    if (this.m_adminConn != null) {
      try
      {
        this.m_serverInfo = this.m_adminConn.getInfo();
        updateErrorWarningFlags();
      }
      catch (TibjmsAdminException localTibjmsAdminException)
      {
        System.err.println("JMSException: " + localTibjmsAdminException.toString());
        System.err.println("Disconnecting from " + this.m_url);
        disconnect();
      }
    }
    return this.m_serverInfo;
  }
  
  public TibjmsAdmin getJmsAdmin()
  {
    return this.m_adminConn;
  }
  
  public boolean isConnected()
  {
    return this.m_adminConn != null;
  }
  
  public DefaultMutableTreeNode createQueue(String paramString, boolean paramBoolean)
  {
    if (this.m_adminConn == null) {
      return null;
    }
    try
    {
      if (!paramBoolean)
      {
        localObject1 = new QueueInfo(paramString);
        this.m_adminConn.createQueue((QueueInfo)localObject1);
      }
      Object localObject1 = null;
      Object localObject2 = null;
      int i = paramString.indexOf('@');
      if (i > 0) {
        paramString = paramString.substring(0, i);
      }
      if (this.m_queuesNode == null) {
        return null;
      }
      if ((this.m_serverInfo.getQueueCount() <= Gems.getGems().getMaxQueues()) || (Gems.getGems().getQueueNamePattern().length() > 1))
      {
        this.m_queuesNode.removeAllChildren();
        QueueInfo[] arrayOfQueueInfo;
        try
        {
          arrayOfQueueInfo = this.m_adminConn.getQueues(Gems.getGems().getQueueNamePattern(), Gems.getGems().getPermType());
        }
        catch (Throwable localThrowable1)
        {
          arrayOfQueueInfo = this.m_adminConn.getQueues(Gems.getGems().getQueueNamePattern());
        }
        for (int j = 0; j < arrayOfQueueInfo.length; j++)
        {
          try
          {
            boolean bool2 = arrayOfQueueInfo[j].isRouted();
            localObject1 = new GemsQueueNode(arrayOfQueueInfo[j].getName(), bool2);
          }
          catch (Throwable localThrowable2)
          {
            localObject1 = new GemsQueueNode(arrayOfQueueInfo[j].getName());
          }
          if (paramString.equals(arrayOfQueueInfo[j].getName())) {
            localObject2 = localObject1;
          }
          this.m_queuesNode.add((MutableTreeNode)localObject1);
        }
      }
      else
      {
        boolean bool1 = paramString.indexOf('@') > 0;
        localObject2 = new GemsQueueNode(paramString, bool1);
        this.m_queuesNode.add((MutableTreeNode)localObject2);
      }
      return (DefaultMutableTreeNode)localObject2;
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
    }
    return null;
  }
  
  public DefaultMutableTreeNode removeQueue(String paramString)
  {
    if (this.m_adminConn == null) {
      return null;
    }
    try
    {
      if (this.m_queuesNode == null) {
        return null;
      }
      this.m_adminConn.destroyQueue(paramString);
      Enumeration localEnumeration = this.m_queuesNode.children();
      while (localEnumeration.hasMoreElements())
      {
        DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localEnumeration.nextElement();
        if ((localDefaultMutableTreeNode != null) && (paramString.equals((String)localDefaultMutableTreeNode.getUserObject())))
        {
          localDefaultMutableTreeNode.removeFromParent();
          return this.m_queuesNode;
        }
      }
      return this.m_queuesNode;
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
    }
    return null;
  }
  
  public void purgeQueue(String paramString)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      this.m_adminConn.purgeQueue(paramString);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void purgeTopic(String paramString)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      this.m_adminConn.purgeTopic(paramString);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void createUser(String paramString1, String paramString2, String paramString3)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      UserInfo localUserInfo = new UserInfo(paramString1, paramString3);
      localUserInfo.setPassword(paramString2);
      this.m_adminConn.createUser(localUserInfo);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void updateUser(String paramString1, String paramString2, String paramString3)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      UserInfo localUserInfo = new UserInfo(paramString1, paramString3);
      localUserInfo.setPassword(paramString2);
      this.m_adminConn.updateUser(localUserInfo);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void destroyUser(String paramString)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      this.m_adminConn.destroyUser(paramString);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void createGroup(String paramString1, String paramString2)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      GroupInfo localGroupInfo = new GroupInfo(paramString1, paramString2);
      this.m_adminConn.createGroup(localGroupInfo);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void addUserToGroup(String paramString1, String paramString2)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      this.m_adminConn.addUserToGroup(paramString2, paramString1);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void removeUserFromGroup(String paramString1, String paramString2)
  {
    if (this.m_adminConn == null) {
      return;
    }
    try
    {
      this.m_adminConn.removeUserFromGroup(paramString2, paramString1);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void createDurable(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    if (this.m_adminConn == null) {
      return;
    }
    if ((paramString3 != null) && (paramString3.length() == 0)) {
      paramString3 = null;
    }
    try
    {
      this.m_adminConn.createDurable(paramString2, paramString1, paramString3, paramString4, false, false);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void destroyDurable(String paramString1, String paramString2)
  {
    if (this.m_adminConn == null) {
      return;
    }
    if ((paramString2 != null) && (paramString2.length() == 0)) {
      paramString2 = null;
    }
    try
    {
      this.m_adminConn.destroyDurable(paramString1, paramString2);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void purgeDurable(String paramString1, String paramString2)
  {
    if (this.m_adminConn == null) {
      return;
    }
    if ((paramString2 != null) && (paramString2.length() == 0)) {
      paramString2 = null;
    }
    try
    {
      this.m_adminConn.purgeDurable(paramString1, paramString2);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public void destroyConnection(String paramString)
  {
    if (this.m_adminConn == null) {
      return;
    }
    long l;
    try
    {
      l = Long.parseLong(paramString);
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
      return;
    }
    try
    {
      this.m_adminConn.destroyConnection(l);
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
      return;
    }
  }
  
  public DefaultMutableTreeNode createTopic(String paramString, boolean paramBoolean)
  {
    if (this.m_adminConn == null) {
      return null;
    }
    try
    {
      if (!paramBoolean)
      {
        localObject1 = new TopicInfo(paramString);
        this.m_adminConn.createTopic((TopicInfo)localObject1);
      }
      Object localObject1 = null;
      Object localObject2 = null;
      if (this.m_topicsNode == null) {
        return null;
      }
      if ((this.m_serverInfo.getTopicCount() <= Gems.getGems().getMaxTopics()) || (Gems.getGems().getTopicNamePattern().length() > 1))
      {
        this.m_topicsNode.removeAllChildren();
        TopicInfo[] arrayOfTopicInfo;
        try
        {
          arrayOfTopicInfo = this.m_adminConn.getTopics(Gems.getGems().getTopicNamePattern(), Gems.getGems().getPermType());
        }
        catch (Throwable localThrowable)
        {
          arrayOfTopicInfo = this.m_adminConn.getTopics(Gems.getGems().getTopicNamePattern());
        }
        for (int i = 0; i < arrayOfTopicInfo.length; i++) {
          if (!arrayOfTopicInfo[i].getName().startsWith("$sys"))
          {
            localObject1 = new GemsTopicNode(arrayOfTopicInfo[i].getName());
            if (paramString.equals(arrayOfTopicInfo[i].getName())) {
              localObject2 = localObject1;
            }
            this.m_topicsNode.add((MutableTreeNode)localObject1);
          }
        }
      }
      else
      {
        localObject2 = new GemsTopicNode(paramString);
        this.m_topicsNode.add((MutableTreeNode)localObject2);
      }
      return (DefaultMutableTreeNode)localObject2;
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
    }
    return null;
  }
  
  public DefaultMutableTreeNode removeTopic(String paramString)
  {
    if (this.m_adminConn == null) {
      return null;
    }
    try
    {
      if (this.m_topicsNode == null) {
        return null;
      }
      this.m_adminConn.destroyTopic(paramString);
      Enumeration localEnumeration = this.m_topicsNode.children();
      while (localEnumeration.hasMoreElements())
      {
        DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localEnumeration.nextElement();
        if ((localDefaultMutableTreeNode != null) && (paramString.equals((String)localDefaultMutableTreeNode.getUserObject())))
        {
          localDefaultMutableTreeNode.removeFromParent();
          return this.m_topicsNode;
        }
      }
      return this.m_topicsNode;
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
    }
    return null;
  }
  
  public void removeMessage(Message paramMessage)
    throws Exception
  {
    if (this.m_adminConn == null) {
      return;
    }
    this.m_adminConn.destroyMessage(paramMessage.getJMSMessageID());
  }
  
  public void addWarnLimits(Node paramNode)
  {
    this.m_warnLimits = new Hashtable();
    NamedNodeMap localNamedNodeMap = paramNode.getAttributes();
    for (int i = 0; i < localNamedNodeMap.getLength(); i++)
    {
      Node localNode = localNamedNodeMap.item(i);
      this.m_warnLimits.put(localNode.getNodeName(), new Long(localNode.getNodeValue()));
    }
  }
  
  public Long getWarnLimit(String paramString)
  {
    if (this.m_warnLimits != null) {
      return (Long)this.m_warnLimits.get(paramString);
    }
    return null;
  }
  
  public void addErrorLimits(Node paramNode)
  {
    this.m_errorLimits = new Hashtable();
    NamedNodeMap localNamedNodeMap = paramNode.getAttributes();
    for (int i = 0; i < localNamedNodeMap.getLength(); i++)
    {
      Node localNode = localNamedNodeMap.item(i);
      this.m_errorLimits.put(localNode.getNodeName(), new Long(localNode.getNodeValue()));
    }
  }
  
  public Long getErrorLimit(String paramString)
  {
    if (this.m_errorLimits != null) {
      return (Long)this.m_errorLimits.get(paramString);
    }
    return null;
  }
  
  public void updateErrorWarningFlags()
  {
    this.m_isInError = false;
    this.m_isInWarning = false;
    if ((isFtUrl()) && (this.m_serverInfo.getState() == 4) && (this.m_serverInfo.getBackupName() == null))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    Long localLong = getErrorLimit("Connections");
    if ((localLong != null) && (this.m_serverInfo.getConnectionCount() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("Sessions");
    try
    {
      if ((localLong != null) && (this.m_serverInfo.getSessionCount() > localLong.longValue()))
      {
        this.m_isInError = true;
        Gems.getGems().treeRepaint();
        return;
      }
    }
    catch (Throwable localThrowable1) {}
    localLong = getErrorLimit("Queues");
    if ((localLong != null) && (this.m_serverInfo.getQueueCount() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("Topics");
    if ((localLong != null) && (this.m_serverInfo.getTopicCount() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("Durables");
    if ((localLong != null) && (this.m_serverInfo.getDurableCount() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("PendingMsgs");
    if ((localLong != null) && (this.m_serverInfo.getPendingMessageCount() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("PendingMsgsSize");
    if ((localLong != null) && (this.m_serverInfo.getPendingMessageSize() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("MsgMem");
    if ((localLong != null) && (this.m_serverInfo.getMsgMem() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("InMsgCount");
    if ((localLong != null) && (this.m_serverInfo.getInboundMessageCount() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("InMsgRate");
    if ((localLong != null) && (this.m_serverInfo.getInboundMessageRate() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("OutMsgCount");
    if ((localLong != null) && (this.m_serverInfo.getOutboundMessageCount() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getErrorLimit("OutMsgRate");
    if ((localLong != null) && (this.m_serverInfo.getOutboundMessageRate() > localLong.longValue()))
    {
      this.m_isInError = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("Connections");
    if ((localLong != null) && (this.m_serverInfo.getConnectionCount() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("Sessions");
    try
    {
      if ((localLong != null) && (this.m_serverInfo.getSessionCount() > localLong.longValue()))
      {
        this.m_isInWarning = true;
        Gems.getGems().treeRepaint();
        return;
      }
    }
    catch (Throwable localThrowable2) {}
    localLong = getWarnLimit("Queues");
    if ((localLong != null) && (this.m_serverInfo.getQueueCount() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("Topics");
    if ((localLong != null) && (this.m_serverInfo.getTopicCount() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("Durables");
    if ((localLong != null) && (this.m_serverInfo.getDurableCount() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("PendingMsgs");
    if ((localLong != null) && (this.m_serverInfo.getPendingMessageCount() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("PendingMsgsSize");
    if ((localLong != null) && (this.m_serverInfo.getPendingMessageSize() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("MsgMem");
    if ((localLong != null) && (this.m_serverInfo.getMsgMem() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("InMsgCount");
    if ((localLong != null) && (this.m_serverInfo.getInboundMessageCount() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("InMsgRate");
    if ((localLong != null) && (this.m_serverInfo.getInboundMessageRate() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("OutMsgCount");
    if ((localLong != null) && (this.m_serverInfo.getOutboundMessageCount() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    localLong = getWarnLimit("OutMsgRate");
    if ((localLong != null) && (this.m_serverInfo.getOutboundMessageRate() > localLong.longValue()))
    {
      this.m_isInWarning = true;
      Gems.getGems().treeRepaint();
      return;
    }
    Gems.getGems().treeRepaint();
  }
  
  public String getClientID(long paramLong)
  {
    if (paramLong == 0L) {
      return "";
    }
    if (this.m_adminConn == null) {
      return "";
    }
    if (this.m_clientIDs == null) {
      this.m_clientIDs = new Hashtable();
    }
    String str = (String)this.m_clientIDs.get(String.valueOf(paramLong));
    if (str == null)
    {
      this.m_clientIDs.clear();
      try
      {
        ConnectionInfo[] arrayOfConnectionInfo = this.m_adminConn.getConnections();
        for (int i = 0; (arrayOfConnectionInfo != null) && (i < arrayOfConnectionInfo.length); i++) {
          if (arrayOfConnectionInfo[i].getClientID() != null) {
            this.m_clientIDs.put(String.valueOf(arrayOfConnectionInfo[i].getID()), arrayOfConnectionInfo[i].getClientID());
          }
        }
      }
      catch (TibjmsAdminException localTibjmsAdminException)
      {
        System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
        return "";
      }
      str = (String)this.m_clientIDs.get(String.valueOf(paramLong));
    }
    if (str != null) {
      return str;
    }
    return "";
  }
  
  public void run()
  {
    while (this.m_delay > 0L)
    {
      try
      {
        Thread.sleep(this.m_delay);
      }
      catch (Exception localException) {}
      if (!isConnected())
      {
        connect();
        if (isConnected()) {
          Gems.getGems().scheduleRepaint();
        }
      }
      else
      {
        getJmsServerInfo(true);
        if (this.m_sub != null) {
          this.m_sub.onData(this.m_serverInfo);
        }
        if (!isConnected()) {
          Gems.getGems().scheduleRepaint();
        }
      }
    }
  }
  
  public void startCharting()
  {
    if (this.m_sub == null)
    {
      Vector localVector = ReflectionUtils.getGetterMethodNames(this.m_serverInfo.getClass());
      this.m_sub = new GemsSubscriber(localVector, "hello");
      this.m_chart = new GemsChartFrame(Gems.getGems().getTitlePrefix() + "Real Time Chart for " + getName() + " (" + this.m_url + ")", localVector, this.m_sub, this);
      this.m_sub.addChart(this.m_chart);
      this.m_chartUpdateTimer = new Timer(0, new ChartRefreshTimerAction());
      this.m_chartUpdateTimer.setRepeats(false);
    }
    else
    {
      this.m_chart.bringToFront();
    }
  }
  
  public void stopCharting()
  {
    this.m_sub = null;
    this.m_chart = null;
  }
  
  public void addSSLParam(Node paramNode)
  {
    NamedNodeMap localNamedNodeMap = paramNode.getAttributes();
    Node localNode1 = localNamedNodeMap.getNamedItem("type");
    if (localNode1 == null) {
      localNode1 = localNamedNodeMap.getNamedItem("Type");
    }
    Node localNode2 = localNamedNodeMap.getNamedItem("name");
    if (localNode2 == null) {
      localNode2 = localNamedNodeMap.getNamedItem("Name");
    }
    Node localNode3 = localNamedNodeMap.getNamedItem("value");
    if (localNode3 == null) {
      localNode3 = localNamedNodeMap.getNamedItem("Value");
    }
    if ((localNode1 == null) || (localNode2 == null) || (localNode3 == null)) {
      return;
    }
    Gems.debug("SSLParam: " + localNode2.getNodeValue() + "=" + localNode3.getNodeValue());
    if (localNode1.getNodeValue().equalsIgnoreCase("string")) {
      this.m_sslParams.put(localNode2.getNodeValue(), localNode3.getNodeValue());
    } else if (localNode1.getNodeValue().equalsIgnoreCase("boolean")) {
      this.m_sslParams.put(localNode2.getNodeValue(), new Boolean(localNode3.getNodeValue()));
    } else if (localNode1.getNodeValue().equalsIgnoreCase("long")) {
      this.m_sslParams.put(localNode2.getNodeValue(), new Long(localNode3.getNodeValue()));
    } else if ((localNode1.getNodeValue().equalsIgnoreCase("integer")) || (localNode1.getNodeValue().equalsIgnoreCase("int"))) {
      this.m_sslParams.put(localNode2.getNodeValue(), new Integer(localNode3.getNodeValue()));
    }
  }
  
  public void addSubStation(Node paramNode)
  {
    NamedNodeMap localNamedNodeMap1 = paramNode.getAttributes();
    Node localNode1 = localNamedNodeMap1.getNamedItem("alias");
    if (localNode1 == null) {
      localNode1 = localNamedNodeMap1.getNamedItem("Alias");
    }
    Node localNode2 = localNamedNodeMap1.getNamedItem("adminqueue");
    if (localNode2 == null) {
      localNode2 = localNamedNodeMap1.getNamedItem("Queue");
    }
    if ((localNode1 == null) || (localNode2 == null)) {
      return;
    }
    Properties localProperties = new Properties();
    localProperties.put("QUEUE", localNode2.getNodeValue());
    Node localNode3 = localNamedNodeMap1.getNamedItem("version");
    if (localNode3 == null) {
      localNode3 = localNamedNodeMap1.getNamedItem("Version");
    }
    if (localNode3 == null) {
      localProperties.put("VERSION", "2.4");
    } else {
      localProperties.put("VERSION", localNode3.getNodeValue().substring(0, 3));
    }
    NodeList localNodeList = paramNode.getChildNodes();
    for (int i = 0; (localNodeList != null) && (i < localNodeList.getLength()); i++)
    {
      Node localNode4 = localNodeList.item(i);
      if (localNode4.getNodeName().equals("Interface"))
      {
        NamedNodeMap localNamedNodeMap2 = localNode4.getAttributes();
        Node localNode5 = localNamedNodeMap2.getNamedItem("name");
        if (localNode5 == null) {
          localNode5 = localNamedNodeMap2.getNamedItem("Name");
        }
        Node localNode6 = localNamedNodeMap2.getNamedItem("type");
        if (localNode6 == null) {
          localNode6 = localNamedNodeMap2.getNamedItem("Type");
        }
        if (localNode6 == null) {
          localProperties.put(localNode5.getNodeValue(), "INT");
        } else if (localNode6.getNodeValue().equals("IMS")) {
          localProperties.put(localNode5.getNodeValue(), "IMS");
        } else {
          localProperties.put(localNode5.getNodeValue(), "INT");
        }
      }
    }
    this.m_SSSystems.put(localNode1.getNodeValue(), localProperties);
  }
  
  public void doLogging()
  {
    if ((this.m_adminConn != null) && (this.m_logServerInfo != LOG_TYPE.Never) && ((this.m_logServerInfo == LOG_TYPE.Always) || ((this.m_isInWarning) && (this.m_logServerInfo == LOG_TYPE.WarnLimits)) || ((this.m_isInError) && ((this.m_logServerInfo == LOG_TYPE.ErrorLimits) || (this.m_logServerInfo == LOG_TYPE.WarnLimits)))))
    {
      Date localDate = new Date();
      Object localObject;
      int i;
      try
      {
        String str = this.m_fileDateFormat.format(localDate).toString() + ".csv";
        if ((this.m_logFile == null) || (!this.m_logFile.getName().endsWith(str)))
        {
          if (this.m_filePrint != null) {
            this.m_filePrint.close();
          }
          if (this.m_fileOut != null) {
            this.m_fileOut.close();
          }
          localObject = new File(this.m_logDir);
          ((File)localObject).mkdirs();
          this.m_logFile = new File((File)localObject, StringUtilities.stripSpaces(getName()) + "-" + str);
          i = this.m_logFile.exists();
          this.m_fileOut = new FileOutputStream(this.m_logFile, true);
          this.m_filePrint = new PrintStream(this.m_fileOut);
          if (i == 0)
          {
            StringBuffer localStringBuffer = new StringBuffer("timestamp");
            localStringBuffer.append(",");
            for (int j = 0; j < this.m_logColumnNames.size(); j++)
            {
              localStringBuffer.append(this.m_logColumnNames.get(j));
              if (j + 1 < this.m_logColumnNames.size()) {
                localStringBuffer.append(",");
              }
            }
            this.m_filePrint.println(localStringBuffer.toString());
          }
        }
      }
      catch (IOException localIOException)
      {
        System.err.println("Error: Failed to create ServerInfo logfile: JavaIOException: " + localIOException.getMessage());
        this.m_logServerInfo = LOG_TYPE.Never;
        this.m_logFile = null;
        this.m_fileOut = null;
        this.m_filePrint = null;
        return;
      }
      if (this.m_filePrint != null)
      {
        Hashtable localHashtable = ReflectionUtils.getGetterMethodValues(this.m_serverInfo);
        localObject = new StringBuffer(this.dateFormatMillis.format(localDate).toString());
        ((StringBuffer)localObject).append(",");
        for (i = 0; i < this.m_logColumnNames.size(); i++)
        {
          ((StringBuffer)localObject).append(localHashtable.get(this.m_logColumnNames.get(i)));
          if (i + 1 < this.m_logColumnNames.size()) {
            ((StringBuffer)localObject).append(",");
          }
        }
        this.m_filePrint.println(((StringBuffer)localObject).toString());
      }
    }
  }
  
  class ChartRefreshTimerAction
    implements ActionListener
  {
    ChartRefreshTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsConnectionNode.this.m_sub != null) {
        GemsConnectionNode.this.m_sub.onData(GemsConnectionNode.this.m_serverInfo);
      }
    }
  }
  
  public static enum LOG_TYPE
  {
    Never,  WarnLimits,  ErrorLimits,  Always;
    
    private LOG_TYPE() {}
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsConnectionNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */