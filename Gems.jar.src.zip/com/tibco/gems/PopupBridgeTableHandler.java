package com.tibco.gems;

import java.awt.Point;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.TableModel;

public class PopupBridgeTableHandler
  extends PopupTableHandler
{
  public AbstractAction selAll = null;
  public AbstractAction createTar = null;
  public AbstractAction delBridge = null;
  public AbstractAction delSelBridges = null;
  public GemsBridgeTableModel m_model;
  GemsManageBridgesDialog m_manager = null;
  
  public PopupBridgeTableHandler(JTable paramJTable, GemsBridgeTableModel paramGemsBridgeTableModel, GemsManageBridgesDialog paramGemsManageBridgesDialog)
  {
    super(paramJTable);
    this.m_model = paramGemsBridgeTableModel;
    this.m_manager = paramGemsManageBridgesDialog;
  }
  
  public JPopupMenu createPopup(Point paramPoint)
  {
    JPopupMenu localJPopupMenu = super.createPopup(paramPoint);
    if (this.m_model.m_showCheckbox)
    {
      if (this.selAll == null) {
        this.selAll = new TableSelectAllAction("Select All", null);
      }
      localJPopupMenu.insert(this.selAll, 1);
    }
    if (!Gems.getGems().getViewOnlyMode())
    {
      if (this.createTar == null) {
        this.createTar = new CreateTargetAction("Create New Target...", null);
      }
      if (this.delBridge == null) {
        this.delBridge = new DeleteBridgeAction("Destroy Bridge", null);
      }
      if (this.delSelBridges == null) {
        this.delSelBridges = new DeleteSelectedBridgesAction("Destroy Selected Bridges", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.createTar);
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.delBridge);
      localJPopupMenu.add(this.delSelBridges);
    }
    return localJPopupMenu;
  }
  
  public class DeleteSelectedBridgesAction
    extends AbstractAction
  {
    public DeleteSelectedBridgesAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupBridgeTableHandler.this.m_manager.deleteSelectedBridges();
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class DeleteBridgeAction
    extends AbstractAction
  {
    public DeleteBridgeAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      String str1 = PopupBridgeTableHandler.this.m_table.getModel().getValueAt(PopupBridgeTableHandler.this.m_row, 1).toString();
      String str2 = PopupBridgeTableHandler.this.m_table.getModel().getValueAt(PopupBridgeTableHandler.this.m_row, 2).toString();
      String str3 = PopupBridgeTableHandler.this.m_table.getModel().getValueAt(PopupBridgeTableHandler.this.m_row, 3).toString();
      String str4 = PopupBridgeTableHandler.this.m_table.getModel().getValueAt(PopupBridgeTableHandler.this.m_row, 4).toString();
      PopupBridgeTableHandler.this.m_manager.deleteBridge(str1, str2, str3, str4);
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class CreateTargetAction
    extends AbstractAction
  {
    public CreateTargetAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      String str = PopupBridgeTableHandler.this.m_table.getModel().getValueAt(PopupBridgeTableHandler.this.m_row, 1).toString();
      PopupBridgeTableHandler.this.m_manager.createBridge(str);
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class TableSelectAllAction
    extends AbstractAction
  {
    public TableSelectAllAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupBridgeTableHandler.this.m_model.selectAllRows();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\PopupBridgeTableHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */