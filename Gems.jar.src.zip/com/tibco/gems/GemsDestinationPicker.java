package com.tibco.gems;

import com.tibco.tibjms.admin.DestinationInfo;
import com.tibco.tibjms.admin.ServerInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class GemsDestinationPicker
  extends JDialog
{
  JFrame m_frame;
  JPanel m_panel;
  GemsConnectionNode m_cn;
  GemsDestination m_retDest = null;
  protected JComboBox m_type;
  protected JTextField m_pattern;
  protected JButton m_okButton;
  protected JButton m_cancelButton;
  protected JButton m_lookup;
  JTable m_table;
  protected MyTableModel m_tableModel;
  TableSorter m_sorter;
  
  public GemsDestinationPicker(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode)
  {
    super(paramJFrame, "Destination Picker (" + paramGemsConnectionNode.getName() + ")", true);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    init();
    pack();
    show();
  }
  
  public GemsDestinationPicker(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, GemsDestination.DEST_TYPE paramDEST_TYPE)
  {
    super(paramJFrame, "Destination Picker (" + paramGemsConnectionNode.getName() + ")", true);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    init();
    this.m_type.setSelectedItem(paramDEST_TYPE);
    this.m_type.setEnabled(false);
    pack();
    show();
  }
  
  public void init()
  {
    setLocationRelativeTo(this.m_frame);
    setDefaultCloseOperation(2);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Destination Type:", 11);
    this.m_type = new JComboBox();
    for (localObject2 : GemsDestination.DEST_TYPE.values()) {
      this.m_type.addItem(localObject2);
    }
    this.m_type.addItemListener(new DestTypeSelectAction());
    localJLabel1.setLabelFor(this.m_type);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_type);
    ??? = new JPanel(true);
    ((JPanel)???).setLayout(new BoxLayout((Container)???, 0));
    ((JPanel)???).setMinimumSize(new Dimension(200, 24));
    JLabel localJLabel2 = new JLabel(" Pattern:", 11);
    this.m_pattern = new JTextField(">", 30);
    this.m_pattern.addKeyListener(new SubmitListener());
    localJLabel2.setLabelFor(this.m_pattern);
    localJPanel2.add(localJLabel2);
    ((JPanel)???).add(this.m_pattern);
    this.m_lookup = new JButton("LookUp");
    this.m_lookup.addActionListener(new LookupAction());
    ((JPanel)???).add(this.m_lookup);
    localJPanel2.add((Component)???);
    this.m_tableModel = new MyTableModel();
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setSelectionMode(0);
    addMouseListenerToTable(this.m_table);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(330, 300));
    localJPanel1.add(localJScrollPane, "Center");
    Object localObject2 = new JPanel(true);
    ((JPanel)localObject2).setLayout(new BoxLayout((Container)localObject2, 0));
    Component localComponent = Box.createRigidArea(new Dimension(175, 10));
    ((JPanel)localObject2).add(localComponent);
    this.m_okButton = new JButton("Ok");
    this.m_okButton.addActionListener(new OkPressed());
    this.m_cancelButton = new JButton("Cancel");
    this.m_cancelButton.addActionListener(new CancelPressed());
    ((JPanel)localObject2).add(this.m_okButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    ((JPanel)localObject2).add(localComponent);
    ((JPanel)localObject2).add(this.m_cancelButton);
    localJPanel1.add((Component)localObject2, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 2, 5, 5, 5, 5);
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          GemsDestinationPicker.this.ok();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  public DestinationInfo[] getDestinationInfo()
  {
    try
    {
      ServerInfo localServerInfo = this.m_cn.getJmsServerInfo(false);
      if (this.m_type.getSelectedItem() == GemsDestination.DEST_TYPE.Queue)
      {
        if ((localServerInfo != null) && (localServerInfo.getQueueCount() > Gems.getGems().getMaxQueues()) && (this.m_pattern.getText().equals(">")))
        {
          int i = JOptionPane.showConfirmDialog(this, "There are " + localServerInfo.getQueueCount() + " queues, set a pattern to filter the number of queues. \nAre you sure you want to continue?", "Lookup Queues", 0);
          if (i != 0) {
            return null;
          }
        }
        try
        {
          return this.m_cn.getJmsAdmin().getQueues(this.m_pattern.getText(), this.m_pattern.getText().startsWith("$TMP$") ? 4 : 3);
        }
        catch (Throwable localThrowable1)
        {
          return this.m_cn.getJmsAdmin().getQueues(this.m_pattern.getText());
        }
      }
      if ((localServerInfo != null) && (localServerInfo.getTopicCount() > Gems.getGems().getMaxTopics()) && (this.m_pattern.getText().equals(">")))
      {
        int j = JOptionPane.showConfirmDialog(this, "There are " + localServerInfo.getTopicCount() + " topics, set a pattern to filter the number of queues. \nAre you sure you want to continue?", "Lookup Topics", 0);
        if (j != 0) {
          return null;
        }
      }
      try
      {
        return this.m_cn.getJmsAdmin().getTopics(this.m_pattern.getText(), this.m_pattern.getText().startsWith("$TMP$") ? 4 : 3);
      }
      catch (Throwable localThrowable2)
      {
        return this.m_cn.getJmsAdmin().getTopics(this.m_pattern.getText());
      }
      return null;
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this, localTibjmsAdminException.getMessage(), "Error", 1);
    }
  }
  
  public void ok()
  {
    int i = this.m_table.getSelectedRow();
    if (i < 0)
    {
      JOptionPane.showMessageDialog(this, "No destination selected", "Error", 1);
    }
    else
    {
      String str = (String)this.m_table.getValueAt(i, 0);
      this.m_retDest = new GemsDestination(str, (GemsDestination.DEST_TYPE)this.m_type.getSelectedItem());
      dispose();
    }
  }
  
  public void cancel()
  {
    dispose();
  }
  
  public void populateDestinationInfo(DestinationInfo[] paramArrayOfDestinationInfo)
  {
    this.m_tableModel.setRowCount(0);
    if (paramArrayOfDestinationInfo == null) {
      return;
    }
    for (int i = 0; i < paramArrayOfDestinationInfo.length; i++) {
      addDestination(paramArrayOfDestinationInfo[i]);
    }
  }
  
  public void addDestination(DestinationInfo paramDestinationInfo)
  {
    if (paramDestinationInfo != null)
    {
      if (paramDestinationInfo.getName().equals(">")) {
        return;
      }
      if ((!this.m_pattern.getText().startsWith("$sys.")) && (paramDestinationInfo.getName().startsWith("$sys."))) {
        return;
      }
      Object[] arrayOfObject = { paramDestinationInfo.getName() };
      this.m_tableModel.addRow(arrayOfObject);
    }
  }
  
  public void dispose()
  {
    super.dispose();
  }
  
  class MyTableModel
    extends DefaultTableModel
  {
    MyTableModel() {}
    
    public boolean isCellEditable(int paramInt1, int paramInt2)
    {
      return false;
    }
  }
  
  class DestTypeSelectAction
    implements ItemListener
  {
    DestTypeSelectAction() {}
    
    public void itemStateChanged(ItemEvent paramItemEvent)
    {
      if (paramItemEvent.getStateChange() == 1) {}
    }
  }
  
  class LookupAction
    implements ActionListener
  {
    LookupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker.this.m_tableModel.setRowCount(0);
      GemsDestinationPicker.this.m_tableModel.setColumnCount(0);
      String[] arrayOfString = { "Destination Name" };
      GemsDestinationPicker.this.m_tableModel.setColumnIdentifiers(arrayOfString);
      GemsDestinationPicker.this.populateDestinationInfo(GemsDestinationPicker.this.getDestinationInfo());
    }
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker.this.cancel();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker.this.ok();
    }
  }
  
  public class SubmitListener
    implements KeyListener
  {
    public SubmitListener() {}
    
    public void keyPressed(KeyEvent paramKeyEvent)
    {
      if (paramKeyEvent.getKeyCode() == 10)
      {
        GemsDestinationPicker.this.m_tableModel.setRowCount(0);
        GemsDestinationPicker.this.m_tableModel.setColumnCount(0);
        String[] arrayOfString = { "Destination Name" };
        GemsDestinationPicker.this.m_tableModel.setColumnIdentifiers(arrayOfString);
        GemsDestinationPicker.this.populateDestinationInfo(GemsDestinationPicker.this.getDestinationInfo());
      }
    }
    
    public void keyReleased(KeyEvent paramKeyEvent) {}
    
    public void keyTyped(KeyEvent paramKeyEvent) {}
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDestinationPicker.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */