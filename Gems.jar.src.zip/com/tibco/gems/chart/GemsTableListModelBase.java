package com.tibco.gems.chart;

import java.util.Vector;

public abstract interface GemsTableListModelBase
{
  public abstract int getColumnCount();
  
  public abstract int getRowCount();
  
  public abstract Vector getDataVector();
  
  public abstract Object getValueAt(int paramInt1, int paramInt2);
  
  public abstract Class getColumnClass(int paramInt);
  
  public abstract int[] getColumnSizes();
  
  public abstract String[] getColumnHeadings();
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsTableListModelBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */