package com.tibco.gems.chart;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.Vector;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.border.SoftBevelBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableCellEditor;

public class GemsTableListPanel
  extends JPanel
{
  private ChangeListener _changetListener;
  protected int iLastSelected = -1;
  protected JLabel _headerLabel;
  protected Vector _listElements;
  protected GemsTableListModelBase _tableListModel;
  protected TableListControl _tableListControl;
  
  public void onMouseClick()
  {
    this.iLastSelected = getSelectedIndex();
  }
  
  public void onDoubleClick()
  {
    this.iLastSelected = getSelectedIndex();
  }
  
  public void resizeAndRepaint()
  {
    if (this._tableListControl == null) {
      return;
    }
    this._tableListControl.resizeAndRepaint();
  }
  
  public void setAutoResizeMode(int paramInt)
  {
    if (this._tableListControl == null) {
      return;
    }
    this._tableListControl.setAutoResizeMode(paramInt);
  }
  
  public int getSelectedColumn()
  {
    return this._tableListControl.getSelectedColumn();
  }
  
  public int getSelectedIndex()
  {
    return this._tableListControl.getSelectedRow();
  }
  
  public void setSelectedIndex(int paramInt)
  {
    this.iLastSelected = paramInt;
    if (paramInt == -1)
    {
      this._tableListControl.clearSelection();
      return;
    }
    this._tableListControl.setRowSelectionInterval(paramInt, paramInt);
  }
  
  public void addChangetListener(ChangeListener paramChangeListener)
  {
    this._changetListener = paramChangeListener;
  }
  
  public boolean onSelectionChanged(Object paramObject)
  {
    if (this._changetListener != null) {
      this._changetListener.stateChanged(new ChangeEvent(paramObject));
    }
    return true;
  }
  
  protected void editObject(Object paramObject, int paramInt)
  {
    if (paramObject != null) {
      editObject(this._listElements.indexOf(paramObject), paramInt);
    }
  }
  
  protected void editObject(int paramInt1, int paramInt2)
  {
    if (paramInt1 != -1)
    {
      setSelectedIndex(paramInt1);
      if (paramInt2 < 0) {
        paramInt2 = 0;
      }
      getTable().editCellAt(getSelectedIndex(), paramInt2);
      this._tableListControl.editCellAt(paramInt1, 0);
    }
  }
  
  public void onBottom(int paramInt)
  {
    stopEditing();
    if (paramInt == this._listElements.size() - 1) {
      return;
    }
    Object localObject = this._listElements.elementAt(paramInt);
    this._listElements.removeElementAt(paramInt);
    this._listElements.addElement(localObject);
    setSelectedIndex(this._listElements.size() - 1);
  }
  
  public void onUp(int paramInt)
  {
    if ((paramInt < 1) || (paramInt >= this._listElements.size())) {
      return;
    }
    Object localObject = this._listElements.elementAt(paramInt);
    this._listElements.removeElementAt(paramInt);
    this._listElements.insertElementAt(localObject, paramInt - 1);
    setSelectedIndex(paramInt - 1);
  }
  
  public void onDown(int paramInt)
  {
    stopEditing();
    if (paramInt == this._listElements.size() - 1) {
      return;
    }
    Object localObject = this._listElements.elementAt(paramInt);
    this._listElements.removeElementAt(paramInt);
    this._listElements.insertElementAt(localObject, paramInt + 1);
    setSelectedIndex(paramInt + 1);
  }
  
  public void onTop(int paramInt)
  {
    stopEditing();
    if ((paramInt < 0) || (paramInt >= this._listElements.size())) {
      return;
    }
    Object localObject = this._listElements.elementAt(paramInt);
    this._listElements.removeElementAt(paramInt);
    this._listElements.insertElementAt(localObject, 0);
    setSelectedIndex(0);
  }
  
  public void stopEditing()
  {
    TableCellEditor localTableCellEditor = this._tableListControl.getCellEditor();
    if (localTableCellEditor != null) {
      localTableCellEditor.stopCellEditing();
    }
    this._tableListControl.requestFocus();
  }
  
  public void addExtraButtons(JPanel paramJPanel) {}
  
  public JPanel constructHeaderPanel(String paramString)
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BorderLayout());
    localJPanel.setBackground(Color.lightGray);
    localJPanel.setPreferredSize(new Dimension(250, 20));
    localJPanel.setMinimumSize(new Dimension(250, 20));
    this._headerLabel = new JLabel(paramString, 2);
    localJPanel.add("Center", this._headerLabel);
    return localJPanel;
  }
  
  public JComponent constructListPanel(TableListControl paramTableListControl)
  {
    this._tableListControl = paramTableListControl;
    this._tableListControl.setBackground(Color.white);
    this._tableListControl.clearSelection();
    this._tableListControl.getSelectionModel().setSelectionMode(0);
    JScrollPane localJScrollPane = new JScrollPane();
    localJScrollPane.setBorder(new SoftBevelBorder(1));
    localJScrollPane.getViewport().add(this._tableListControl);
    localJScrollPane.setBackground(Color.white);
    return localJScrollPane;
  }
  
  public JComponent constructListPanel()
  {
    return constructListPanel(new TableListControl(this._tableListModel));
  }
  
  public Object getSelectedObject()
  {
    int i = getSelectedIndex();
    if (i < 0) {
      return null;
    }
    return this._listElements.elementAt(i);
  }
  
  public void resetSelection()
  {
    if (this._listElements.size() != 0)
    {
      int i = getSelectedIndex();
      this._tableListControl.clearSelection();
      this._tableListControl.validate();
      this._tableListControl.repaint();
      if (i >= 0) {
        setSelectedIndex(i);
      }
    }
  }
  
  public Vector getListElements()
  {
    return this._listElements;
  }
  
  public Object elementAt(int paramInt)
  {
    return this._listElements.elementAt(paramInt);
  }
  
  public void insertElementAt(Object paramObject, int paramInt)
  {
    this._listElements.insertElementAt(paramObject, paramInt);
  }
  
  public void addElement(Object paramObject)
  {
    this._listElements.addElement(paramObject);
    resizeAndRepaint();
  }
  
  public void setListElements(Vector paramVector)
  {
    this._listElements = paramVector;
    if (this._listElements.size() != 0) {
      this.iLastSelected = 0;
    }
    resizeAndRepaint();
  }
  
  public void setDescription(String paramString)
  {
    this._headerLabel.setText(paramString);
    doLayout();
    repaint();
  }
  
  public JTable getTable()
  {
    return this._tableListControl;
  }
  
  public void setPanels(JComponent paramJComponent1, JComponent paramJComponent2)
  {
    if (paramJComponent1 != null) {
      add(paramJComponent1, "North");
    }
    add(paramJComponent2, "Center");
  }
  
  public void setTableModel(GemsTableListModelBase paramGemsTableListModelBase)
  {
    this._tableListModel = paramGemsTableListModelBase;
    this._listElements = this._tableListModel.getDataVector();
    if (this._listElements == null) {
      this._listElements = new Vector();
    }
  }
  
  public GemsTableListPanel(String paramString1, String paramString2, GemsTableListModelBase paramGemsTableListModelBase)
  {
    this(paramGemsTableListModelBase);
    JPanel localJPanel = constructHeaderPanel(paramString2);
    setPanels(localJPanel, constructListPanel());
  }
  
  public GemsTableListPanel(String paramString, GemsTableListModelBase paramGemsTableListModelBase)
  {
    this(null, paramString, paramGemsTableListModelBase);
  }
  
  public GemsTableListPanel(GemsTableListModelBase paramGemsTableListModelBase)
  {
    this();
    setTableModel(paramGemsTableListModelBase);
  }
  
  public GemsTableListPanel()
  {
    setLayout(new BorderLayout());
    setBackground(Color.lightGray);
  }
  
  private class TableListControl
    extends GemsTableListTable
  {
    boolean resizing = false;
    
    protected void resizeAndRepaint()
    {
      this.resizing = true;
      super.resizeAndRepaint();
      this.resizing = false;
    }
    
    public void onMouseClick()
    {
      GemsTableListPanel.this.onMouseClick();
    }
    
    public void onDoubleClick()
    {
      GemsTableListPanel.this.onDoubleClick();
    }
    
    public void onSelectionChanged()
    {
      if (this.resizing) {
        return;
      }
      GemsTableListPanel.this.iLastSelected = GemsTableListPanel.this.getSelectedIndex();
    }
    
    public TableListControl(GemsTableListModel paramGemsTableListModel)
    {
      super();
    }
    
    public TableListControl(GemsTableListModelBase paramGemsTableListModelBase)
    {
      super();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsTableListPanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */