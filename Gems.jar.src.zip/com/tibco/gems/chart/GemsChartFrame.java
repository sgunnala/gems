package com.tibco.gems.chart;

import com.tibco.gems.Gems;
import com.tibco.gems.GemsConnectionNode;
import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.event.RendererChangeEvent;
import org.jfree.chart.event.RendererChangeListener;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.time.Second;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class GemsChartFrame
  extends JFrame
{
  private long _timeLimit;
  private JFrame _frame;
  private JComponent _tablePane;
  private JComponent _chartPane;
  private GemsSubscriber _subscriber;
  private GemsSubscriptionData _subscriptionData;
  private JComboBox _retainDataCombo;
  private JTable _table;
  private String m_title;
  private JTabbedPane _tabbedPane;
  private GemsConnectionNode _cn;
  private JFreeChart m_chart;
  private ChartPanel m_chartPanel = null;
  private Vector m_chartableFields;
  private Vector m_series = new Vector();
  private GemsChartFieldList m_fieldList = null;
  protected JCheckBoxMenuItem m_showLegends = null;
  protected JCheckBoxMenuItem m_showTitle = null;
  protected JCheckBoxMenuItem m_showShapes = null;
  public static final SimpleDateFormat dateFormat = new SimpleDateFormat("EEE d MMM yyyy");
  
  public boolean checkRetainDataPeriod()
  {
    Object localObject = this._retainDataCombo.getSelectedItem();
    Integer localInteger;
    try
    {
      localInteger = new Integer(localObject.toString());
    }
    catch (NumberFormatException localNumberFormatException)
    {
      JOptionPane.showMessageDialog(this._frame, "Input numeric data only !", "Warning", 2);
      return false;
    }
    if (localInteger.intValue() <= 0)
    {
      JOptionPane.showMessageDialog(this._frame, "Input a value greater than 0 !", "Warning", 2);
      return false;
    }
    this._timeLimit = (localInteger.intValue() * 60 * 1000);
    return true;
  }
  
  public void clickedOKInOptionsEditor(long paramLong)
  {
    if (this._subscriptionData.getTimeLimit() != paramLong)
    {
      this._subscriptionData.setTimeLimit(paramLong);
      updateRetentionPeriod();
    }
  }
  
  public void done()
  {
    this._frame.dispose();
    this._subscriber.doneSelectedInTabbedPane(this);
    this._cn.stopCharting();
  }
  
  public void bringToFront()
  {
    this._frame.setAlwaysOnTop(true);
    this._frame.setAlwaysOnTop(false);
  }
  
  public void newDataAvailable(Date paramDate, Hashtable paramHashtable)
  {
    if ((paramHashtable != null) && (paramHashtable.size() > 0))
    {
      this._subscriptionData.addRow(paramDate, paramHashtable);
      for (int i = 0; i < this.m_series.size(); i++)
      {
        Second localSecond = new Second();
        ((TimeSeries)this.m_series.get(i)).add(localSecond, (Number)paramHashtable.get((String)this.m_chartableFields.get(i)));
      }
    }
    this.m_fieldList.refreshChartableFieldColors();
  }
  
  public void updateRetentionPeriod()
  {
    for (int i = 0; i < this.m_series.size(); i++) {
      ((TimeSeries)this.m_series.get(i)).setMaximumItemAge(this._timeLimit / 1000L);
    }
  }
  
  public JPanel constructListPanel()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BorderLayout());
    _cls3 local_cls3 = new _cls3();
    this._retainDataCombo = new _cls4();
    this._retainDataCombo.setEditable(true);
    TitledBorder localTitledBorder = new TitledBorder(LineBorder.createBlackLineBorder(), "Retention Period (min)");
    localTitledBorder.setTitleColor(Color.black);
    this._retainDataCombo.setBorder(localTitledBorder);
    this._retainDataCombo.setPreferredSize(new Dimension(50, 45));
    this._retainDataCombo.addItem("5");
    this._retainDataCombo.addItem("10");
    this._retainDataCombo.addItem("15");
    this._retainDataCombo.addItem("30");
    this._retainDataCombo.addItem("60");
    this._retainDataCombo.addItem("120");
    this._retainDataCombo.addItem("180");
    this._retainDataCombo.setSelectedIndex(0);
    this._retainDataCombo.addActionListener(local_cls3);
    this.m_fieldList = new GemsChartFieldList(this, "Chartable Fields", this.m_chartableFields, this._subscriptionData);
    localJPanel.add("North", this._retainDataCombo);
    localJPanel.add("Center", this.m_fieldList);
    return localJPanel;
  }
  
  public JPanel createTablePane()
  {
    Vector localVector = this._subscriptionData.getColumnHeaders();
    this._table = new GemsTableChartData(this._subscriptionData, localVector);
    this._table.setAutoCreateColumnsFromModel(false);
    this._table.setDefaultRenderer(Number.class, null);
    JPanel localJPanel1 = ((GemsTableChartData)this._table).createView(new Dimension(700, 300));
    JPanel localJPanel2 = new JPanel();
    localJPanel2.setLayout(new BorderLayout());
    localJPanel2.setBorder(new SoftBevelBorder(1));
    TitledBorder localTitledBorder = new TitledBorder(LineBorder.createBlackLineBorder(), "Table");
    localTitledBorder.setTitleColor(Color.black);
    localJPanel2.setBorder(localTitledBorder);
    localJPanel2.add("Center", localJPanel1);
    return localJPanel2;
  }
  
  public JPanel createChartPane()
  {
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BorderLayout());
    TitledBorder localTitledBorder = new TitledBorder(LineBorder.createBlackLineBorder(), "Time Series Chart");
    localTitledBorder.setTitleColor(Color.black);
    localJPanel.setBorder(localTitledBorder);
    long l = this._subscriptionData.getTimeLimit() / 60000L;
    TimeSeriesCollection localTimeSeriesCollection = new TimeSeriesCollection();
    for (int i = 0; i < this.m_chartableFields.size(); i++)
    {
      localObject = new TimeSeries((String)this.m_chartableFields.get(i), Second.class);
      ((TimeSeries)localObject).setMaximumItemAge(this._timeLimit / 1000L);
      localTimeSeriesCollection.addSeries((TimeSeries)localObject);
      this.m_series.addElement(localObject);
    }
    this.m_chart = ChartFactory.createTimeSeriesChart("", null, null, localTimeSeriesCollection, true, false, false);
    Font localFont = new Font("Tahoma", 1, 16);
    Object localObject = new TextTitle(this.m_title, localFont);
    this.m_chart.setTitle((TextTitle)localObject);
    XYPlot localXYPlot = this.m_chart.getXYPlot();
    ValueAxis localValueAxis = localXYPlot.getDomainAxis();
    localValueAxis = localXYPlot.getRangeAxis();
    localXYPlot.setRenderer(new XYLineAndShapeRenderer());
    localValueAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
    XYLineAndShapeRenderer localXYLineAndShapeRenderer = (XYLineAndShapeRenderer)localXYPlot.getRenderer();
    for (int j = 0; j < this.m_series.size(); j++)
    {
      localXYLineAndShapeRenderer.setSeriesStroke(j, new BasicStroke(2.0F, 1, 1));
      localXYLineAndShapeRenderer.setSeriesVisible(j, Boolean.valueOf(false));
      localXYLineAndShapeRenderer.setSeriesShapesVisible(j, false);
    }
    this.m_chartPanel = new ChartPanel(this.m_chart);
    localJPanel.add("West", constructListPanel());
    localJPanel.add("Center", this.m_chartPanel);
    return localJPanel;
  }
  
  public void removeChartableField(int paramInt)
  {
    XYPlot localXYPlot = this.m_chart.getXYPlot();
    XYItemRenderer localXYItemRenderer = localXYPlot.getRenderer();
    localXYItemRenderer.setSeriesVisible(paramInt, Boolean.valueOf(false));
  }
  
  public void showChartableField(int paramInt)
  {
    XYPlot localXYPlot = this.m_chart.getXYPlot();
    XYItemRenderer localXYItemRenderer = localXYPlot.getRenderer();
    localXYItemRenderer.setSeriesVisible(paramInt, Boolean.valueOf(true));
  }
  
  public Color getSeriesColor(int paramInt)
  {
    XYPlot localXYPlot = this.m_chart.getXYPlot();
    XYItemRenderer localXYItemRenderer = localXYPlot.getRenderer();
    return (Color)localXYItemRenderer.getSeriesPaint(paramInt);
  }
  
  public void createTabListener()
  {
    _cls2 local_cls2 = new _cls2();
    this._tabbedPane.addChangeListener(local_cls2);
  }
  
  public GemsChartFrame(String paramString, Vector paramVector, GemsSubscriber paramGemsSubscriber, GemsConnectionNode paramGemsConnectionNode)
  {
    super(paramString);
    Date localDate = new Date();
    this.m_title = ("Time Series Chart for " + paramGemsConnectionNode.getName() + " (" + dateFormat.format(localDate) + ")");
    this._cn = paramGemsConnectionNode;
    this._frame = this;
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    this.m_chartableFields = paramVector;
    this._table = null;
    this._retainDataCombo = null;
    this._chartPane = null;
    this._tablePane = null;
    this._timeLimit = 300000L;
    this._subscriber = paramGemsSubscriber;
    this._subscriptionData = new GemsSubscriptionData(paramVector);
    this._subscriptionData.setChart(this);
    this._frame.setIconImage(Gems.getGems().m_icon.getImage());
    this._frame.addWindowListener(new _cls1());
    this._tabbedPane = new JTabbedPane();
    this._tabbedPane.setFont(new Font("Dialog", 1, 12));
    if (this._subscriber.anyChartableField())
    {
      this._chartPane = createChartPane();
      this._tabbedPane.addTab("Chart View", this._chartPane);
    }
    this._tablePane = createTablePane();
    this._tabbedPane.addTab("Tabular View", this._tablePane);
    createTabListener();
    this._tabbedPane.setSelectedIndex(0);
    JPanel localJPanel = new JPanel();
    localJPanel.setLayout(new BorderLayout());
    localJPanel.setBorder(new SoftBevelBorder(1));
    localJPanel.add("Center", this._tabbedPane);
    this._frame.getContentPane().add(localJPanel);
    this._frame.setLocation(200, 100);
    this._frame.pack();
    this._frame.setVisible(true);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Save Chart As..."));
    localJMenuItem.addActionListener(new ChartSaveAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Print Chart..."));
    localJMenuItem.addActionListener(new ChartPrintAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsChartFrame.this.done();
      }
    });
    localJMenu = new JMenu("Edit");
    localJMenu.setMnemonic(69);
    localJMenuBar.add(localJMenu);
    localJMenuItem = localJMenu.add(new JMenuItem("Copy Chart"));
    localJMenuItem.addActionListener(new ChartCopyAction());
    localJMenuItem = localJMenu.add(new JMenuItem("Chart Properties..."));
    localJMenuItem.addActionListener(new ChartPropertiesAction());
    localJMenu = new JMenu("View");
    localJMenu.setMnemonic(86);
    localJMenuBar.add(localJMenu);
    this.m_showLegends = new JCheckBoxMenuItem("Legends");
    this.m_showLegends.addActionListener(new ChartShowLegendsAction());
    this.m_showLegends.setSelected(true);
    this.m_showTitle = new JCheckBoxMenuItem("Chart Title");
    this.m_showTitle.setSelected(true);
    this.m_showTitle.addActionListener(new ChartShowTitleAction());
    localJMenu.add(this.m_showTitle);
    this.m_showShapes = new JCheckBoxMenuItem("Series Shapes");
    this.m_showShapes.setSelected(false);
    this.m_showShapes.addActionListener(new ShowShapesAction());
    localJMenu.add(this.m_showShapes);
    return localJMenuBar;
  }
  
  private class _cls1
    extends WindowAdapter
  {
    public void windowClosing(WindowEvent paramWindowEvent)
    {
      GemsChartFrame.this.done();
    }
    
    _cls1() {}
  }
  
  private class _cls2
    implements ChangeListener
  {
    public void stateChanged(ChangeEvent paramChangeEvent)
    {
      JTabbedPane localJTabbedPane = (JTabbedPane)paramChangeEvent.getSource();
      int i = localJTabbedPane.getSelectedIndex();
      Component localComponent = localJTabbedPane.getComponentAt(i);
    }
    
    _cls2() {}
  }
  
  private class _cls4
    extends JComboBox
  {
    public void processKeyEvent(KeyEvent paramKeyEvent)
    {
      if ((paramKeyEvent.getKeyCode() == 10) && (GemsChartFrame.this.checkRetainDataPeriod())) {
        GemsChartFrame.this.clickedOKInOptionsEditor(GemsChartFrame.this._timeLimit);
      }
    }
    
    _cls4() {}
  }
  
  private class _cls3
    implements ActionListener
  {
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsChartFrame.this.checkRetainDataPeriod()) {
        GemsChartFrame.this.clickedOKInOptionsEditor(GemsChartFrame.this._timeLimit);
      }
    }
    
    _cls3() {}
  }
  
  private class _cls5
    implements ActionListener
  {
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsChartFrame.this.done();
    }
    
    _cls5() {}
  }
  
  private class RendererChanged
    implements RendererChangeListener
  {
    private RendererChanged() {}
    
    public void rendererChanged(RendererChangeEvent paramRendererChangeEvent)
    {
      if (paramRendererChangeEvent.getSeriesVisibilityChanged()) {
        GemsChartFrame.this.m_fieldList.refreshChartableFieldColors();
      }
    }
  }
  
  class ChartPropertiesAction
    implements ActionListener
  {
    ChartPropertiesAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsChartFrame.this.m_chartPanel.doEditChartProperties();
    }
  }
  
  class ChartPrintAction
    implements ActionListener
  {
    ChartPrintAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsChartFrame.this.m_chartPanel.createChartPrintJob();
    }
  }
  
  class ChartCopyAction
    implements ActionListener
  {
    ChartCopyAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsChartFrame.this.m_chartPanel.doCopy();
    }
  }
  
  class ChartSaveAction
    implements ActionListener
  {
    ChartSaveAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        GemsChartFrame.this.m_chartPanel.doSaveAs();
      }
      catch (IOException localIOException)
      {
        System.err.println(localIOException.toString());
      }
    }
  }
  
  class ShowShapesAction
    implements ActionListener
  {
    ShowShapesAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      XYPlot localXYPlot = GemsChartFrame.this.m_chart.getXYPlot();
      XYLineAndShapeRenderer localXYLineAndShapeRenderer = (XYLineAndShapeRenderer)localXYPlot.getRenderer();
      for (int i = 0; i < GemsChartFrame.this.m_series.size(); i++) {
        localXYLineAndShapeRenderer.setSeriesShapesVisible(i, GemsChartFrame.this.m_showShapes.isSelected());
      }
    }
  }
  
  class ChartShowTitleAction
    implements ActionListener
  {
    ChartShowTitleAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsChartFrame.this.m_showTitle.isSelected()) {
        GemsChartFrame.this.m_chart.setTitle(GemsChartFrame.this.m_title);
      } else {
        GemsChartFrame.this.m_chart.setTitle((String)null);
      }
    }
  }
  
  class ChartShowLegendsAction
    implements ActionListener
  {
    ChartShowLegendsAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      XYPlot localXYPlot = GemsChartFrame.this.m_chart.getXYPlot();
      XYItemRenderer localXYItemRenderer = localXYPlot.getRenderer();
      localXYItemRenderer.setBaseSeriesVisibleInLegend(GemsChartFrame.this.m_showLegends.isSelected());
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsChartFrame.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */