package com.tibco.gems;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.util.Enumeration;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;

public class PopupDetailsTableHandler
  extends PopupTableHandler
{
  public AbstractAction bq = null;
  public AbstractAction qp = null;
  public AbstractAction stm = null;
  public AbstractAction smm = null;
  public AbstractAction ts = null;
  public AbstractAction tp = null;
  public AbstractAction ptm = null;
  public AbstractAction pmm = null;
  public AbstractAction sp = null;
  public AbstractAction rss = null;
  public AbstractAction dss = null;
  public AbstractAction ess = null;
  public GemsDetailsTableModel m_model;
  
  public PopupDetailsTableHandler(JTable paramJTable, GemsDetailsTableModel paramGemsDetailsTableModel)
  {
    super(paramJTable);
    this.m_model = paramGemsDetailsTableModel;
  }
  
  public JPopupMenu createPopup(Point paramPoint)
  {
    JPopupMenu localJPopupMenu = super.createPopup(paramPoint);
    if (this.m_model.getColumnName(0).equals("QueueName"))
    {
      if (this.bq == null) {
        this.bq = new BrowseQueueAction("Browse Queue...", null);
      }
      if (this.qp == null) {
        this.qp = new SetPropertyAction("Queue Properties...", null);
      }
      if (this.stm == null) {
        this.stm = new SendTextMessageAction("Send TextMessage...", null);
      }
      if (this.smm == null) {
        this.smm = new SendMapMessageAction("Send MapMessage...", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.bq);
      localJPopupMenu.add(this.qp);
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.stm);
      localJPopupMenu.add(this.smm);
    }
    else if (this.m_model.getColumnName(0).equals("TopicName"))
    {
      if (this.ts == null) {
        this.ts = new TopicSubscriberAction("Topic Subscriber...", null);
      }
      if (this.tp == null) {
        this.tp = new SetPropertyAction("Topic Properties...", null);
      }
      if (this.ptm == null) {
        this.ptm = new PublishTextMessageAction("Publish TextMessage...", null);
      }
      if (this.pmm == null) {
        this.pmm = new PublishMapMessageAction("Publish MapMessage...", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.ts);
      localJPopupMenu.add(this.tp);
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.ptm);
      localJPopupMenu.add(this.pmm);
    }
    else if (this.m_model.getColumnName(0).equals("Identifier"))
    {
      if (this.rss == null) {
        this.rss = new SSRefreshAction("Refresh", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.rss);
      localJPopupMenu.addSeparator();
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.getGems().getSelectedNode();
      if (((String)localDefaultMutableTreeNode.getUserObject()).startsWith("Disabled"))
      {
        if (this.ess == null) {
          this.ess = new SSEnableAction("Enable", null);
        }
        localJPopupMenu.add(this.ess);
      }
      else
      {
        if (this.dss == null) {
          this.dss = new SSDisableAction("Disable", null);
        }
        localJPopupMenu.add(this.dss);
      }
    }
    else if ((this.m_model.getColumnCount() == 2) && ((this.m_model.getColumnName(0).equals("QueueProperty")) || (this.m_model.getColumnName(0).equals("TopicProperty"))))
    {
      if (this.sp == null) {
        this.sp = new SetPropertyAction("Set Property...", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.sp);
    }
    return localJPopupMenu;
  }
  
  public class SSDisableAction
    extends AbstractAction
  {
    public SSDisableAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      GemsSSNode localGemsSSNode = Gems.getGems().getSSConnectionNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.getGems().getSelectedNode();
      if (localGemsConnectionNode != null)
      {
        String str1 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
        String str2 = ((String)((DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent()).getUserObject()).substring(5);
        String str3 = "";
        if (((String)localDefaultMutableTreeNode.getUserObject()).startsWith("Active R")) {
          str3 = localGemsSSNode.RunCommand("DISABLE,RID=" + str1 + ",INTF=" + str2);
        }
        if (((String)localDefaultMutableTreeNode.getUserObject()).startsWith("Active T")) {
          str3 = localGemsSSNode.RunCommand("DISABLE,TID=" + str1 + ",INTF=" + str2);
        }
        JOptionPane.showMessageDialog(Gems.getGems().m_frame, str3, "Disable SS Object", 1);
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class SSEnableAction
    extends AbstractAction
  {
    public SSEnableAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      GemsSSNode localGemsSSNode = Gems.getGems().getSSConnectionNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.getGems().getSelectedNode();
      if (localGemsConnectionNode != null)
      {
        String str1 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
        String str2 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 1);
        String str3 = ((String)((DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent()).getUserObject()).substring(5);
        String str4 = "";
        if (str2.equals("Recipe")) {
          str4 = localGemsSSNode.RunCommand("ENABLE,RID=" + str1 + ",INTF=" + str3);
        } else {
          str4 = localGemsSSNode.RunCommand("ENABLE,TID=" + str1 + ",INTF=" + str3);
        }
        JOptionPane.showMessageDialog(Gems.getGems().m_frame, str4, "Enable SS Object", 1);
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class SSRefreshAction
    extends AbstractAction
  {
    public SSRefreshAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      GemsSSNode localGemsSSNode = Gems.getGems().getSSConnectionNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode = Gems.getGems().getSelectedNode();
      if (localGemsConnectionNode != null)
      {
        String str1 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
        String str2 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 1);
        String str3 = ((String)((DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent()).getUserObject()).substring(5);
        String str4 = "";
        if (((String)localDefaultMutableTreeNode.getUserObject()).startsWith("Active R")) {
          str4 = localGemsSSNode.RunCommand("REFRESH,RID=" + str1 + ",INTF=" + str3);
        }
        if (((String)localDefaultMutableTreeNode.getUserObject()).startsWith("Active T")) {
          str4 = localGemsSSNode.RunCommand("REFRESH,TID=" + str1 + ",INTF=" + str3);
        }
        if (((String)localDefaultMutableTreeNode.getUserObject()).startsWith("Disabled")) {
          if (str2.equals("Recipe")) {
            str4 = localGemsSSNode.RunCommand("REFRESH,RID=" + str1 + ",INTF=" + str3);
          } else {
            str4 = localGemsSSNode.RunCommand("REFRESH,TID=" + str1 + ",INTF=" + str3);
          }
        }
        JOptionPane.showMessageDialog(Gems.getGems().m_frame, str4, "Refresh SS Object", 1);
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class BrowseQueueAction
    extends AbstractAction
  {
    public BrowseQueueAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsQueueBrowser(localGemsConnectionNode, (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0));
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class SendTextMessageAction
    extends AbstractAction
  {
    public SendTextMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsMessageFrame(localGemsConnectionNode, true, (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0), true, Gems.getGems().m_frame, false);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class SendMapMessageAction
    extends AbstractAction
  {
    public SendMapMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsMessageFrame(localGemsConnectionNode, true, (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0), true, Gems.getGems().m_frame, false, true);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class TopicSubscriberAction
    extends AbstractAction
  {
    public TopicSubscriberAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsTopicSubscriber(localGemsConnectionNode, (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0), "Topic Subscriber");
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
  
  public class PublishMapMessageAction
    extends AbstractAction
  {
    public PublishMapMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsMessageFrame(localGemsConnectionNode, true, (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0), false, Gems.getGems().m_frame, false, true);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class PublishTextMessageAction
    extends AbstractAction
  {
    public PublishTextMessageAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      if (localGemsConnectionNode != null) {
        new GemsMessageFrame(localGemsConnectionNode, true, (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0), false, Gems.getGems().m_frame, false);
      }
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
  
  public class SetPropertyAction
    extends AbstractAction
  {
    public SetPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformedNEW(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      String str1 = null;
      String str2 = null;
      if (localGemsConnectionNode != null)
      {
        GemsDestPropEditor localGemsDestPropEditor;
        if (PopupDetailsTableHandler.this.m_model.getColumnName(0).equals("TopicName"))
        {
          str1 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
          localGemsDestPropEditor = new GemsDestPropEditor(Gems.getGems().m_frame, localGemsConnectionNode, "Topic", str1);
        }
        else if (PopupDetailsTableHandler.this.m_model.getColumnName(0).equals("QueueName"))
        {
          str1 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
          localGemsDestPropEditor = new GemsDestPropEditor(Gems.getGems().m_frame, localGemsConnectionNode, "Queue", str1);
        }
        else
        {
          DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.getGems().getSelectedNode();
          if (localDefaultMutableTreeNode1 != null)
          {
            DefaultMutableTreeNode localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
            if (localDefaultMutableTreeNode2 != null)
            {
              str2 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
              if (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics")) {
                ((GemsTopicNode)localDefaultMutableTreeNode1).setProperty(localGemsConnectionNode, str2);
              } else if (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Queues")) {
                ((GemsQueueNode)localDefaultMutableTreeNode1).setProperty(localGemsConnectionNode, str2);
              }
            }
          }
        }
      }
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsConnectionNode localGemsConnectionNode = Gems.getGems().getConnectionNode();
      DefaultMutableTreeNode localDefaultMutableTreeNode1 = Gems.getGems().getSelectedNode();
      String str1 = null;
      String str2 = null;
      if ((localGemsConnectionNode != null) && (localDefaultMutableTreeNode1 != null))
      {
        DefaultMutableTreeNode localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
        String str3 = (String)localDefaultMutableTreeNode1.getUserObject();
        if ((str3.startsWith("Topics")) || (str3.startsWith("Queues")))
        {
          str1 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
          if (str1 != null)
          {
            Enumeration localEnumeration = localDefaultMutableTreeNode1.children();
            while (localEnumeration.hasMoreElements())
            {
              DefaultMutableTreeNode localDefaultMutableTreeNode3 = (DefaultMutableTreeNode)localEnumeration.nextElement();
              if ((localDefaultMutableTreeNode3 != null) && (str1.equals((String)localDefaultMutableTreeNode3.getUserObject())))
              {
                String str4 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
                GemsDestPropEditor localGemsDestPropEditor;
                if (PopupDetailsTableHandler.this.m_model.getColumnName(0).equals("TopicName")) {
                  localGemsDestPropEditor = new GemsDestPropEditor(Gems.getGems().m_frame, localGemsConnectionNode, "Topic", str4);
                } else {
                  localGemsDestPropEditor = new GemsDestPropEditor(Gems.getGems().m_frame, localGemsConnectionNode, "Queue", str4);
                }
                return;
              }
            }
          }
        }
        else if (localDefaultMutableTreeNode2 != null)
        {
          str2 = (String)PopupDetailsTableHandler.this.m_table.getModel().getValueAt(PopupDetailsTableHandler.this.m_row, 0);
          if (((String)localDefaultMutableTreeNode2.getUserObject()).startsWith("Topics")) {
            ((GemsTopicNode)localDefaultMutableTreeNode1).setProperty(localGemsConnectionNode, str2);
          } else {
            ((GemsQueueNode)localDefaultMutableTreeNode1).setProperty(localGemsConnectionNode, str2);
          }
        }
      }
    }
    
    public boolean isEnabled()
    {
      return true;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\PopupDetailsTableHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */