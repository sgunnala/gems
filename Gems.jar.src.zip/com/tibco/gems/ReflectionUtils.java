package com.tibco.gems;

import java.io.PrintStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

public class ReflectionUtils
{
  private static Set primitiveTypes = new HashSet();
  private static Set excludedProperties;
  private static Map classProperties = new TreeMap();
  
  public static boolean isPrimitiveType(String paramString)
  {
    return primitiveTypes.contains(paramString);
  }
  
  public static boolean isCollection(Class paramClass)
    throws RXMLException
  {
    return (containsInterface(paramClass, "java.util.Collection")) || (isSet(paramClass)) || (isList(paramClass));
  }
  
  public static boolean isSet(Class paramClass)
    throws RXMLException
  {
    return containsInterface(paramClass, "java.util.Set");
  }
  
  public static boolean isList(Class paramClass)
    throws RXMLException
  {
    return containsInterface(paramClass, "java.util.List");
  }
  
  public static boolean isMap(Class paramClass)
    throws RXMLException
  {
    return containsInterface(paramClass, "java.util.Map");
  }
  
  public static boolean containsInterface(Class paramClass, String paramString)
    throws RXMLException
  {
    try
    {
      if (paramClass.getName().equals(paramString)) {
        return true;
      }
      Class[] arrayOfClass = paramClass.getInterfaces();
      for (int i = 0; i < arrayOfClass.length; i++)
      {
        String str = arrayOfClass[i].getName();
        if (str.equals(paramString)) {
          return true;
        }
      }
      return false;
    }
    catch (Exception localException)
    {
      System.err.println(localException.getClass() + ": " + localException.getMessage());
      throw new RXMLException(localException);
    }
  }
  
  public static Class getClassFromName(String paramString)
  {
    try
    {
      return Class.forName(paramString);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      System.err.println(localClassNotFoundException.getClass() + ": " + localClassNotFoundException.getMessage());
    }
    return null;
  }
  
  public static Map getClassProperties(String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramString);
      return getClassProperties(localClass);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      System.err.println(localClassNotFoundException.getClass() + ": " + localClassNotFoundException.getMessage());
    }
    return null;
  }
  
  public static Map getClassProperties(Class paramClass)
  {
    String str1 = paramClass.getName();
    if (classProperties.containsKey(str1)) {
      return (Map)classProperties.get(str1);
    }
    TreeMap localTreeMap = new TreeMap();
    Method[] arrayOfMethod = paramClass.getMethods();
    for (int i = 0; i < arrayOfMethod.length; i++)
    {
      String str2 = arrayOfMethod[i].getName();
      Object localObject1;
      Object localObject2;
      Object localObject3;
      Property localProperty;
      if ((str2.startsWith("get")) || (str2.startsWith("is")))
      {
        localObject1 = arrayOfMethod[i].getParameterTypes();
        if (localObject1.length <= 0)
        {
          int j = arrayOfMethod[i].getModifiers();
          if (!Modifier.isTransient(j))
          {
            localObject2 = null;
            if (str2.startsWith("get")) {
              localObject2 = Character.toLowerCase(str2.charAt(3)) + str2.substring(4);
            } else {
              localObject2 = Character.toLowerCase(str2.charAt(2)) + str2.substring(3);
            }
            if (localTreeMap.containsKey(localObject2))
            {
              localObject3 = (Property)localTreeMap.get(localObject2);
              ((Property)localObject3).setGetter(arrayOfMethod[i]);
            }
            else
            {
              localObject3 = arrayOfMethod[i].getReturnType().getName();
              if (!excludedProperties.contains(localObject2))
              {
                localProperty = new Property((String)localObject2, (String)localObject3, null, arrayOfMethod[i]);
                localTreeMap.put(localObject2, localProperty);
              }
            }
          }
        }
      }
      else if (str2.startsWith("set"))
      {
        localObject1 = Character.toLowerCase(str2.charAt(3)) + str2.substring(4);
        String str3 = arrayOfMethod[i].getReturnType().getName();
        if (str3.equals("void"))
        {
          localObject2 = arrayOfMethod[i].getParameterTypes();
          if (localObject2.length == 1) {
            if (localTreeMap.containsKey(localObject1))
            {
              localObject3 = (Property)localTreeMap.get(localObject1);
              ((Property)localObject3).setSetter(arrayOfMethod[i]);
            }
            else
            {
              localObject3 = localObject2[0].getName();
              localProperty = new Property((String)localObject1, (String)localObject3, arrayOfMethod[i], null);
              localTreeMap.put(localObject1, localProperty);
            }
          }
        }
      }
    }
    classProperties.put(str1, localTreeMap);
    return localTreeMap;
  }
  
  public static Property getProperty(Class paramClass, String paramString)
  {
    Map localMap = getClassProperties(paramClass);
    if (!localMap.containsKey(paramString)) {
      return null;
    }
    return (Property)localMap.get(paramString);
  }
  
  public static Object getPropertyValue(Object paramObject, String paramString)
  {
    Property localProperty = getProperty(paramObject.getClass(), paramString);
    if (localProperty.isReadable()) {
      try
      {
        return localProperty.getGetter().invoke(paramObject, new Object[0]);
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        System.err.println(localIllegalAccessException.getClass() + ": " + localIllegalAccessException.getMessage());
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        System.err.println(localInvocationTargetException.getClass() + ": " + localInvocationTargetException.getMessage());
      }
    }
    return null;
  }
  
  public static Method getSetterMethod(String paramString1, String paramString2)
  {
    Class localClass = getClassFromName(paramString1);
    if (localClass == null) {
      return null;
    }
    return getSetterMethod(localClass, paramString2);
  }
  
  public static Method getSetterMethod(Class paramClass, String paramString)
  {
    Property localProperty = getProperty(paramClass, paramString);
    if (localProperty == null) {
      return null;
    }
    return localProperty.getSetter();
  }
  
  public static Method getGetterMethod(String paramString1, String paramString2)
  {
    Class localClass = getClassFromName(paramString1);
    if (localClass == null) {
      return null;
    }
    return getGetterMethod(localClass, paramString2);
  }
  
  public static Method getGetterMethod(Class paramClass, String paramString)
  {
    Property localProperty = getProperty(paramClass, paramString);
    if (localProperty == null) {
      return null;
    }
    return localProperty.getGetter();
  }
  
  public static Annotation[] getGetterAnnotations(String paramString1, String paramString2)
  {
    Class localClass = getClassFromName(paramString1);
    if (localClass == null) {
      return null;
    }
    return getGetterAnnotations(localClass, paramString2);
  }
  
  public static Annotation[] getGetterAnnotations(Class paramClass, String paramString)
  {
    Method localMethod = getGetterMethod(paramClass, paramString);
    if (localMethod == null) {
      return null;
    }
    return localMethod.getDeclaredAnnotations();
  }
  
  public static Annotation[] getSetterAnnotations(String paramString1, String paramString2)
  {
    Class localClass = getClassFromName(paramString1);
    if (localClass == null) {
      return null;
    }
    return getSetterAnnotations(localClass, paramString2);
  }
  
  public static Annotation[] getSetterAnnotations(Class paramClass, String paramString)
  {
    Method localMethod = getSetterMethod(paramClass, paramString);
    if (localMethod == null) {
      return null;
    }
    return localMethod.getAnnotations();
  }
  
  public static Object getSetterAnnotationPropertyValue(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    try
    {
      Class localClass = Class.forName(paramString1);
      return getSetterAnnotationPropertyValue(localClass, paramString2, paramString3, paramString4);
    }
    catch (Exception localException)
    {
      System.err.println(localException.getClass() + ": " + localException.getMessage());
    }
    return null;
  }
  
  public static Object getSetterAnnotationPropertyValue(Class paramClass, String paramString1, String paramString2, String paramString3)
  {
    Annotation[] arrayOfAnnotation = getSetterAnnotations(paramClass, paramString1);
    for (int i = 0; i < arrayOfAnnotation.length; i++) {
      if (arrayOfAnnotation[i].annotationType().getName().equals(paramString2)) {
        return getAnnotationPropertyValue(arrayOfAnnotation[i], paramString3);
      }
    }
    return null;
  }
  
  public static Object getAnnotationPropertyValue(Annotation paramAnnotation, String paramString)
  {
    try
    {
      Method[] arrayOfMethod = paramAnnotation.annotationType().getMethods();
      for (int i = 0; i < arrayOfMethod.length; i++) {
        if (arrayOfMethod[i].getName().equals(paramString)) {
          return arrayOfMethod[i].invoke(paramAnnotation, new Object[0]);
        }
      }
    }
    catch (Exception localException)
    {
      System.err.println(localException.getClass() + ": " + localException.getMessage());
    }
    return null;
  }
  
  public static Annotation[] getPropertyAnnotations(String paramString1, String paramString2)
  {
    return getGetterAnnotations(paramString1, paramString2);
  }
  
  public static Annotation[] getPropertyAnnotations(Class paramClass, String paramString)
  {
    return getGetterAnnotations(paramClass, paramString);
  }
  
  public static Map getReadableProperties(Class paramClass)
  {
    Map localMap = getClassProperties(paramClass);
    TreeMap localTreeMap = new TreeMap();
    Iterator localIterator = localMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Property localProperty = (Property)localMap.get(str);
      if (localProperty.isReadable()) {
        localTreeMap.put(str, localProperty.getClassType());
      }
    }
    return localTreeMap;
  }
  
  public static Map getReadableProperties(String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramString);
      return getReadableProperties(localClass);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      System.err.println(localClassNotFoundException.getClass() + ": " + localClassNotFoundException.getMessage());
    }
    return null;
  }
  
  public static Vector getGetterMethodNames(Class paramClass)
  {
    Vector localVector = new Vector();
    Method[] arrayOfMethod = paramClass.getMethods();
    for (int i = 0; i < arrayOfMethod.length; i++)
    {
      String str1 = arrayOfMethod[i].getName();
      if (str1.startsWith("get"))
      {
        Class[] arrayOfClass = arrayOfMethod[i].getParameterTypes();
        if (arrayOfClass.length <= 0)
        {
          int j = arrayOfMethod[i].getModifiers();
          if ((!Modifier.isTransient(j)) && ((arrayOfMethod[i].getReturnType().getName().equals("long")) || (arrayOfMethod[i].getReturnType().getName().equals("int"))) && ((str1.contains("MsgMem")) || (str1.contains("Size")) || (str1.contains("Count")) || (str1.contains("Rate"))))
          {
            String str2;
            if (Character.isLowerCase(str1.charAt(4))) {
              str2 = Character.toLowerCase(str1.charAt(3)) + str1.substring(4);
            } else {
              str2 = str1.substring(3);
            }
            localVector.add(str2);
          }
        }
      }
    }
    return localVector;
  }
  
  public static Hashtable getGetterMethodValues(Object paramObject)
  {
    Hashtable localHashtable = new Hashtable();
    Class localClass = paramObject.getClass();
    Method[] arrayOfMethod = localClass.getMethods();
    for (int i = 0; i < arrayOfMethod.length; i++)
    {
      String str1 = arrayOfMethod[i].getName();
      if (str1.startsWith("get"))
      {
        Class[] arrayOfClass = arrayOfMethod[i].getParameterTypes();
        if (arrayOfClass.length <= 0)
        {
          int j = arrayOfMethod[i].getModifiers();
          if (!Modifier.isTransient(j)) {
            try
            {
              if (((arrayOfMethod[i].getReturnType().getName().equals("long")) || (arrayOfMethod[i].getReturnType().getName().equals("int"))) && ((str1.contains("MsgMem")) || (str1.contains("Size")) || (str1.contains("Count")) || (str1.contains("Rate"))))
              {
                String str2;
                if (Character.isLowerCase(str1.charAt(4))) {
                  str2 = Character.toLowerCase(str1.charAt(3)) + str1.substring(4);
                } else {
                  str2 = str1.substring(3);
                }
                Object localObject = arrayOfMethod[i].invoke(paramObject, (Object[])null);
                localHashtable.put(str2, localObject);
              }
            }
            catch (Throwable localThrowable)
            {
              System.err.println(localThrowable.getClass() + ": " + localThrowable.getMessage());
            }
          }
        }
      }
    }
    return localHashtable;
  }
  
  public static Map getWriteableProperties(Class paramClass)
  {
    Map localMap = getClassProperties(paramClass);
    TreeMap localTreeMap = new TreeMap();
    Iterator localIterator = localMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Property localProperty = (Property)localMap.get(str);
      if (localProperty.isWriteable()) {
        localTreeMap.put(str, localProperty.getClassType());
      }
    }
    return localTreeMap;
  }
  
  public static Map getWriteableProperties(String paramString)
  {
    try
    {
      Class localClass = Class.forName(paramString);
      return getWriteableProperties(localClass);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      System.err.println(localClassNotFoundException.getClass() + ": " + localClassNotFoundException.getMessage());
    }
    return null;
  }
  
  public static Object buildObject(String paramString, Map paramMap)
  {
    try
    {
      Class localClass = Class.forName(paramString);
      Object localObject = localClass.newInstance();
      Method[] arrayOfMethod = localClass.getMethods();
      for (int i = 0; i < arrayOfMethod.length; i++)
      {
        String str1 = arrayOfMethod[i].getName();
        if (str1.startsWith("set"))
        {
          String str2 = Character.toLowerCase(str1.charAt(3)) + str1.substring(4);
          String str3 = arrayOfMethod[i].getReturnType().getName();
          if (str3.equals("void"))
          {
            Class[] arrayOfClass = arrayOfMethod[i].getParameterTypes();
            if ((arrayOfClass.length == 1) && (paramMap.containsKey(str2)))
            {
              String str4 = arrayOfClass[0].getName();
              if (primitiveTypes.contains(str4))
              {
                String str5 = (String)paramMap.get(str2);
                if ((str5 != null) && (str5.length() > 0))
                {
                  Object[] arrayOfObject = new Object[1];
                  arrayOfObject[0] = convertStringToObjectWrapper(str4, str5);
                  arrayOfMethod[i].invoke(localObject, arrayOfObject);
                }
              }
            }
          }
        }
      }
      return localObject;
    }
    catch (Exception localException)
    {
      System.err.println(localException.getClass() + ": " + localException.getMessage());
    }
    return null;
  }
  
  private static Object convertStringToObjectWrapper(String paramString1, String paramString2)
  {
    Object localObject = null;
    if ((paramString1.equals("java.lang.Integer")) || (paramString1.equals("int"))) {
      localObject = new Integer(paramString2);
    } else if ((paramString1.equals("java.lang.Long")) || (paramString1.equals("long"))) {
      localObject = new Long(paramString2);
    } else if ((paramString1.equals("java.lang.Short")) || (paramString1.equals("short"))) {
      localObject = new Short(paramString2);
    } else if ((paramString1.equals("java.lang.Byte")) || (paramString1.equals("byte"))) {
      localObject = new Byte(paramString2);
    } else if ((paramString1.equals("java.lang.Float")) || (paramString1.equals("float"))) {
      localObject = new Float(paramString2);
    } else if ((paramString1.equals("java.lang.Double")) || (paramString1.equals("double"))) {
      localObject = new Double(paramString2);
    } else if (paramString1.equals("java.lang.String")) {
      localObject = paramString2;
    } else if ((paramString1.equals("java.lang.Boolean")) || (paramString1.equals("boolean"))) {
      localObject = new Boolean(paramString2);
    }
    return localObject;
  }
  
  static
  {
    primitiveTypes.add("byte");
    primitiveTypes.add("short");
    primitiveTypes.add("int");
    primitiveTypes.add("long");
    primitiveTypes.add("float");
    primitiveTypes.add("double");
    primitiveTypes.add("boolean");
    primitiveTypes.add("java.lang.String");
    primitiveTypes.add("java.lang.Byte");
    primitiveTypes.add("java.lang.Short");
    primitiveTypes.add("java.lang.Integer");
    primitiveTypes.add("java.lang.Long");
    primitiveTypes.add("java.lang.Float");
    primitiveTypes.add("java.lang.Double");
    primitiveTypes.add("java.lang.Boolean");
    excludedProperties = new HashSet();
    excludedProperties.add("class");
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\ReflectionUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */