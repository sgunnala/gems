package com.tibco.gems;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class GemsBrowserOptionsDialog
  extends JDialog
{
  protected JTextField m_delay = null;
  protected JTextField m_timeout = null;
  protected JCheckBox m_oldFirst;
  protected JCheckBox m_useServerTimestamps = null;
  protected boolean m_cancelled = false;
  
  public GemsBrowserOptionsDialog(Frame paramFrame, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    super(paramFrame, paramString, true);
    init(paramFrame, paramString, paramBoolean1, paramBoolean2, paramBoolean3);
  }
  
  public GemsBrowserOptionsDialog(Frame paramFrame, String paramString, boolean paramBoolean)
  {
    super(paramFrame, paramString, true);
    init(paramFrame, paramString, paramBoolean, true, true);
  }
  
  public GemsBrowserOptionsDialog(Frame paramFrame, String paramString)
  {
    super(paramFrame, paramString, true);
    init(paramFrame, paramString, false, false, true);
  }
  
  public void init(Frame paramFrame, String paramString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3)
  {
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 1));
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2);
    int i = 0;
    if (paramBoolean3)
    {
      localJLabel = new JLabel("Message read delay (millisecs):", 11);
      this.m_delay = new JTextField(Gems.getGems().getMsgReadDelayStr(), 20);
      this.m_delay.setMaximumSize(new Dimension(50, 0));
      localJLabel.setLabelFor(this.m_delay);
      localJPanel2.add(localJLabel);
      localJPanel2.add(this.m_delay);
      i++;
    }
    JLabel localJLabel = new JLabel("View oldest messages first:", 11);
    this.m_oldFirst = new JCheckBox();
    this.m_oldFirst.setSelected(Gems.getGems().getViewOldMessagesFirst());
    localJLabel.setLabelFor(this.m_oldFirst);
    localJPanel2.add(localJLabel);
    localJPanel2.add(this.m_oldFirst);
    i++;
    if (paramBoolean1)
    {
      localObject = new JLabel("Use Server based timestamps:", 11);
      this.m_useServerTimestamps = new JCheckBox();
      this.m_useServerTimestamps.setSelected(Gems.getGems().getUseServerTimestamps());
      ((JLabel)localObject).setLabelFor(this.m_useServerTimestamps);
      localJPanel2.add((Component)localObject);
      localJPanel2.add(this.m_useServerTimestamps);
      i++;
    }
    if (paramBoolean2)
    {
      localObject = new JLabel("Request/reply timeout (secs):", 11);
      this.m_timeout = new JTextField(Gems.getGems().getRequestReplyTimeoutStr(), 20);
      this.m_timeout.setMaximumSize(new Dimension(50, 0));
      ((JLabel)localObject).setLabelFor(this.m_timeout);
      localJPanel2.add((Component)localObject);
      localJPanel2.add(this.m_timeout);
      i++;
    }
    SpringUtilities.makeCompactGrid(localJPanel2, i, 2, 5, 5, 8, 8);
    Object localObject = new JPanel();
    ((JPanel)localObject).setLayout(new FlowLayout());
    JButton localJButton1 = new JButton("OK ");
    JButton localJButton2 = new JButton("Cancel ");
    ((JPanel)localObject).add(localJButton1);
    ((JPanel)localObject).add(localJButton2);
    localJButton1.addActionListener(new OkPressed());
    localJButton2.addActionListener(new CancelPressed());
    localJPanel1.add((Component)localObject);
    setContentPane(localJPanel1);
    setLocationRelativeTo(paramFrame);
    pack();
    show();
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsBrowserOptionsDialog.this.m_cancelled = true;
      GemsBrowserOptionsDialog.this.dispose();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsBrowserOptionsDialog.this.m_delay != null) {
        Gems.getGems().setMsgReadDelay(GemsBrowserOptionsDialog.this.m_delay.getText());
      }
      Gems.getGems().setViewOldMessagesFirst(GemsBrowserOptionsDialog.this.m_oldFirst.isSelected());
      if (GemsBrowserOptionsDialog.this.m_useServerTimestamps != null) {
        Gems.getGems().setUseServerTimestamps(GemsBrowserOptionsDialog.this.m_useServerTimestamps.isSelected());
      }
      if ((GemsBrowserOptionsDialog.this.m_timeout != null) && (GemsBrowserOptionsDialog.this.m_timeout.getText() != null)) {
        Gems.getGems().setRequestReplyTimeout(GemsBrowserOptionsDialog.this.m_timeout.getText());
      }
      GemsBrowserOptionsDialog.this.dispose();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsBrowserOptionsDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */