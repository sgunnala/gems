package com.tibco.gems;

import com.tibco.tibjms.admin.DestinationBridgeInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class GemsCreateBridgeDialog
  extends JPanel
{
  JFrame m_frame;
  GemsConnectionNode m_cn;
  boolean m_isQueue;
  String m_dest;
  JTextField m_sel;
  JTextField m_tar;
  JComboBox m_tartype;
  
  public GemsCreateBridgeDialog(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, boolean paramBoolean, String paramString)
  {
    super(new SpringLayout());
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_isQueue = paramBoolean;
    this.m_dest = paramString;
    init();
  }
  
  public void init()
  {
    add(new JLabel("Source " + (this.m_isQueue ? "Queue:" : "Topic")));
    JTextField localJTextField = new JTextField(25);
    localJTextField.setText(this.m_dest);
    localJTextField.setEditable(false);
    add(localJTextField);
    JPanel localJPanel = new JPanel(true);
    localJPanel.setLayout(new BoxLayout(localJPanel, 0));
    add(new JLabel("Target Type:"));
    this.m_tartype = new JComboBox();
    this.m_tartype.addItem("Queue");
    this.m_tartype.addItem("Topic");
    add(this.m_tartype);
    add(new JLabel("Target Destination:"));
    this.m_tar = new JTextField(25);
    localJPanel.add(this.m_tar);
    JButton localJButton = new JButton("...");
    localJButton.setPreferredSize(new Dimension(18, 16));
    localJButton.addActionListener(new DestinationWizardAction());
    localJPanel.add(localJButton);
    add(localJPanel);
    add(new JLabel("Selector:"));
    this.m_sel = new JTextField(25);
    add(this.m_sel);
    SpringUtilities.makeCompactGrid(this, 4, 2, 5, 5, 5, 5);
  }
  
  public boolean createBridge()
  {
    int i = JOptionPane.showConfirmDialog(this.m_frame, this, "Create Bridge", 2);
    if ((i == 0) && (this.m_cn != null) && (this.m_cn.m_adminConn != null))
    {
      try
      {
        DestinationBridgeInfo localDestinationBridgeInfo = new DestinationBridgeInfo(this.m_isQueue ? 1 : 2, this.m_dest, this.m_tartype.getSelectedItem().equals("Queue") ? 1 : 2, this.m_tar.getText(), this.m_sel.getText().length() > 0 ? this.m_sel.getText() : null);
        this.m_cn.m_adminConn.createDestinationBridge(localDestinationBridgeInfo);
      }
      catch (TibjmsAdminException localTibjmsAdminException)
      {
        JOptionPane.showMessageDialog(this.m_frame, localTibjmsAdminException.getMessage(), "Error", 1);
        return false;
      }
      return true;
    }
    return false;
  }
  
  class DestinationWizardAction
    implements ActionListener
  {
    DestinationWizardAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsCreateBridgeDialog.this.m_frame, GemsCreateBridgeDialog.this.m_cn, GemsCreateBridgeDialog.this.m_tartype.getSelectedItem().equals("Queue") ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null) {
        GemsCreateBridgeDialog.this.m_tar.setText(localGemsDestinationPicker.m_retDest.m_destName);
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsCreateBridgeDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */