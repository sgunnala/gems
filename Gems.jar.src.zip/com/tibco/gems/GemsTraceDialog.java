package com.tibco.gems;

import com.tibco.tibjms.admin.TraceInfo;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.Vector;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.border.EtchedBorder;

public class GemsTraceDialog
  extends JDialog
{
  JFrame m_frame;
  JPanel m_panel;
  GemsConnectionNode m_cn;
  TraceInfo m_ti;
  protected JTextField m_traceText;
  protected JButton m_setButton;
  protected JButton m_addButton;
  protected JButton m_removeButton;
  protected JButton m_clearButton;
  protected JButton m_applyButton;
  protected JButton m_closeButton;
  protected JRadioButton m_consoleButton;
  protected JRadioButton m_logfileButton;
  boolean m_isLogTrace = true;
  
  public GemsTraceDialog(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode)
  {
    super(paramJFrame, "Configure Server Trace: (" + paramGemsConnectionNode.getName() + ")", true);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    init();
    reset();
    pack();
    show();
  }
  
  public void init()
  {
    setLocationRelativeTo(this.m_frame);
    setDefaultCloseOperation(2);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel2.setBorder(new EtchedBorder());
    localJPanel1.add(localJPanel2, "North");
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    localJPanel2.add(localJPanel3);
    this.m_consoleButton = new JRadioButton("Console Trace");
    this.m_consoleButton.addActionListener(new consolePressed());
    this.m_logfileButton = new JRadioButton("Log Trace");
    this.m_logfileButton.setSelected(true);
    this.m_logfileButton.addActionListener(new logPressed());
    Component localComponent = Box.createRigidArea(new Dimension(100, 10));
    localJPanel3.add(localComponent);
    localJPanel3.add(this.m_consoleButton);
    localComponent = Box.createRigidArea(new Dimension(70, 10));
    localJPanel3.add(localComponent);
    localJPanel3.add(this.m_logfileButton);
    ButtonGroup localButtonGroup = new ButtonGroup();
    localButtonGroup.add(this.m_consoleButton);
    localButtonGroup.add(this.m_logfileButton);
    JLabel localJLabel1 = new JLabel("Current Trace Setting:");
    localJPanel2.add(localJLabel1);
    this.m_traceText = new JTextField("", 30);
    this.m_traceText.setEditable(false);
    localJPanel2.add(this.m_traceText);
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    localJPanel2.add(localJPanel4);
    localComponent = Box.createRigidArea(new Dimension(70, 10));
    localJPanel4.add(localComponent);
    this.m_setButton = new JButton("Set...");
    this.m_setButton.addActionListener(new setPressed());
    localJPanel4.add(this.m_setButton);
    localComponent = Box.createRigidArea(new Dimension(30, 10));
    localJPanel4.add(localComponent);
    this.m_addButton = new JButton("Add...");
    this.m_addButton.addActionListener(new addPressed());
    localJPanel4.add(this.m_addButton);
    localComponent = Box.createRigidArea(new Dimension(30, 10));
    localJPanel4.add(localComponent);
    this.m_removeButton = new JButton("Remove...");
    this.m_removeButton.addActionListener(new removePressed());
    localJPanel4.add(this.m_removeButton);
    localComponent = Box.createRigidArea(new Dimension(30, 10));
    localJPanel4.add(localComponent);
    this.m_clearButton = new JButton("Clear");
    this.m_clearButton.addActionListener(new clearPressed());
    localJPanel4.add(this.m_clearButton);
    localComponent = Box.createRigidArea(new Dimension(30, 10));
    localJPanel4.add(localComponent);
    Font localFont = new Font("Serif", 0, 11);
    JLabel localJLabel2 = new JLabel("DEFAULT includes ACL, ADMIN, CONFIG, CONNECT_ERROR, INFO, LIMITS, MSG, ROUTE, RVADV, WARNING");
    localJLabel2.setFont(localFont);
    localJPanel2.add(localJLabel2);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel2.add(localComponent);
    JPanel localJPanel5 = new JPanel(true);
    localJPanel5.setLayout(new BoxLayout(localJPanel5, 0));
    localComponent = Box.createRigidArea(new Dimension(190, 10));
    localJPanel5.add(localComponent);
    this.m_applyButton = new JButton("Apply");
    this.m_applyButton.addActionListener(new applyPressed());
    this.m_closeButton = new JButton("Close");
    this.m_closeButton.addActionListener(new closePressed());
    localJPanel5.add(this.m_applyButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel5.add(localComponent);
    localJPanel5.add(this.m_closeButton);
    localJPanel1.add(localJPanel5, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 6, 1, 10, 10, 10, 10);
  }
  
  public void update()
  {
    this.m_traceText.setText(TraceInfoToString(this.m_ti));
  }
  
  public void reset()
  {
    this.m_ti = this.m_cn.getServerTrace(this.m_isLogTrace);
    update();
  }
  
  public void cancel()
  {
    dispose();
  }
  
  public void doSetTrace()
  {
    GemsTracePopup localGemsTracePopup = new GemsTracePopup(this, this.m_setButton);
    Vector localVector = localGemsTracePopup.getSelectedTraceItems();
    if (localVector != null)
    {
      long l = 0L;
      for (int i = 0; i < localVector.size(); i++) {
        l |= ((Trace)localVector.get(i)).id;
      }
      this.m_ti.setTraceItems(l);
      update();
    }
  }
  
  public void doAddTrace()
  {
    GemsTracePopup localGemsTracePopup = new GemsTracePopup(this, this.m_addButton);
    Vector localVector = localGemsTracePopup.getSelectedTraceItems();
    if (localVector != null)
    {
      long l = 0L;
      for (int i = 0; i < localVector.size(); i++) {
        l |= ((Trace)localVector.get(i)).id;
      }
      this.m_ti.clearAddTraceItems();
      this.m_ti.addTraceItems(l);
      update();
    }
  }
  
  public void doRemoveTrace()
  {
    GemsTracePopup localGemsTracePopup = new GemsTracePopup(this, this.m_removeButton);
    Vector localVector = localGemsTracePopup.getSelectedTraceItems();
    if (localVector != null)
    {
      long l = 0L;
      for (int i = 0; i < localVector.size(); i++) {
        l |= ((Trace)localVector.get(i)).id;
      }
      this.m_ti.clearRemoveTraceItems();
      this.m_ti.removeTraceItems(l);
      update();
    }
  }
  
  public void dispose()
  {
    super.dispose();
  }
  
  public static String TraceInfoToString(TraceInfo paramTraceInfo)
  {
    String str = "set=";
    long l = paramTraceInfo.getTraceSetItems();
    str = str + TraceItemsToString(l, "");
    str = str + ";add=";
    l = paramTraceInfo.getTraceAddItems();
    str = str + TraceItemsToString(l, "+");
    str = str + ";remove=";
    l = paramTraceInfo.getTraceRemoveItems();
    str = str + TraceItemsToString(l, "-");
    return str;
  }
  
  void debugDump()
  {
    System.out.println("TRACE_MEMORY 2097152");
    System.out.println("TRACE_MEMORY_DEBUG 4194304");
    System.out.println("TRACE_JAAS 536870912");
    System.out.println("TRACE_JVM 268435456");
    System.out.println("TRACE_JVMERR 4294967296");
    System.out.println("TRACE_DBSTORE 2147483648");
    System.out.println("TRACE_MULTICAST 1073741824");
    System.out.println("TRACE_SS 1048576");
    System.out.println("TRACE_MSTORE 8589934592");
    System.out.println("TRACE_LOADER 17179869184");
    System.out.println("TRACE_CONFIG_DETAIL 34359738368");
  }
  
  public static String TraceItemsToString(long paramLong, String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    if ((paramLong & Trace.DEFAULT.id) == Trace.DEFAULT.id)
    {
      i = 1;
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.DEFAULT);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.MEMORY.id) == Trace.MEMORY.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.MEMORY);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.MEMORY_DEBUG.id) == Trace.MEMORY_DEBUG.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.MEMORY_DEBUG);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.JAAS.id) == Trace.JAAS.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.JAAS);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.JVM.id) == Trace.JVM.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.JVM);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.JVMERR.id) == Trace.JVMERR.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.JVMERR);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.DBSTORE.id) == Trace.DBSTORE.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.DBSTORE);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.LOAD.id) == Trace.LOAD.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.LOAD);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.MULTICAST.id) == Trace.MULTICAST.id)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.MULTICAST);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.ACL.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.ACL);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.ADMIN.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.ADMIN);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.AUTH.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.AUTH);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.CONFIG.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.CONFIG);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.CONFIG_DETAIL.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.CONFIG_DETAIL);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.CONNECT.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.CONNECT);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.CONNECT_ERROR.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.CONNECT_ERROR);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.DEST.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.DEST);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.FLOW.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.FLOW);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.INFO.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.INFO);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.LDAP_DEBUG.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.LDAP_DEBUG);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.LIMITS.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.LIMITS);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.MSG.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.MSG);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.PRODCONS.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.PRODCONS);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.ROUTE.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.ROUTE);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.ROUTE_DEBUG.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.ROUTE_DEBUG);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.RVADV.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.RVADV);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.SS.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.SS);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.SSL.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.SSL);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.SSL_DEBUG.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.SSL_DEBUG);
      localStringBuffer.append(',');
    }
    if ((paramLong & Trace.TX.id) != 0L)
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.TX);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.WARNING.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.WARNING);
      localStringBuffer.append(',');
    }
    if ((i == 0) && ((paramLong & Trace.MSTORE.id) != 0L))
    {
      localStringBuffer.append(paramString);
      localStringBuffer.append(Trace.MSTORE);
      localStringBuffer.append(',');
    }
    if (localStringBuffer.length() > 0) {
      localStringBuffer.setLength(localStringBuffer.length() - 1);
    }
    return localStringBuffer.toString();
  }
  
  public static enum Trace
  {
    DEFAULT(67204336L),  ACL(64L),  ADMIN(4096L),  AUTH(33554432L),  CONFIG(8192L),  CONFIG_DETAIL(34359738368L),  CONNECT(32768L),  CONNECT_ERROR(65536L),  DBSTORE(2147483648L),  DEST(262144L),  FLOW(134217728L),  INFO(16L),  JAAS(536870912L),  JVM(268435456L),  JVMERR(4294967296L),  LDAP_DEBUG(16777216L),  LIMITS(128L),  LOAD(17179869184L),  MEMORY(2097152L),  MEMORY_DEBUG(4194304L),  MSG(67108864L),  MSTORE(8589934592L),  MULTICAST(1073741824L),  PRODCONS(131072L),  ROUTE(1024L),  ROUTE_DEBUG(2048L),  RVADV(16384L),  SS(1048576L),  SSL(256L),  SSL_DEBUG(512L),  TX(524288L),  WARNING(32L);
    
    public final long id;
    
    private Trace(long paramLong)
    {
      this.id = paramLong;
    }
  }
  
  class logPressed
    implements ActionListener
  {
    logPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.m_isLogTrace = true;
      GemsTraceDialog.this.reset();
    }
  }
  
  class consolePressed
    implements ActionListener
  {
    consolePressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.m_isLogTrace = false;
      GemsTraceDialog.this.reset();
    }
  }
  
  class clearPressed
    implements ActionListener
  {
    clearPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.m_ti.clearAllTraceItems();
      GemsTraceDialog.this.update();
    }
  }
  
  class removePressed
    implements ActionListener
  {
    removePressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.doRemoveTrace();
    }
  }
  
  class addPressed
    implements ActionListener
  {
    addPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.doAddTrace();
    }
  }
  
  class setPressed
    implements ActionListener
  {
    setPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.doSetTrace();
    }
  }
  
  class closePressed
    implements ActionListener
  {
    closePressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.cancel();
    }
  }
  
  class applyPressed
    implements ActionListener
  {
    applyPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsTraceDialog.this.m_cn.setServerTrace(GemsTraceDialog.this.m_ti, GemsTraceDialog.this.m_isLogTrace);
      GemsTraceDialog.this.reset();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsTraceDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */