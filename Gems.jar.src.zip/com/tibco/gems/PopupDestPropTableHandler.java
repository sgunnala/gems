package com.tibco.gems;

import java.awt.Point;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JPopupMenu;
import javax.swing.JTable;

public class PopupDestPropTableHandler
  extends PopupTableHandler
{
  public AbstractAction sp = null;
  public GemsDestPropEditor m_editor;
  public GemsDetailsTableModel m_model;
  
  public PopupDestPropTableHandler(JTable paramJTable, GemsDetailsTableModel paramGemsDetailsTableModel, GemsDestPropEditor paramGemsDestPropEditor)
  {
    super(paramJTable);
    this.m_editor = paramGemsDestPropEditor;
    this.m_model = paramGemsDetailsTableModel;
  }
  
  public JPopupMenu createPopup(Point paramPoint)
  {
    JPopupMenu localJPopupMenu = super.createPopup(paramPoint);
    if ((this.m_model.getColumnCount() == 2) && ((this.m_model.getColumnName(0).equals("QueueProperty")) || (this.m_model.getColumnName(0).equals("TopicProperty"))))
    {
      if (this.sp == null) {
        this.sp = new SetPropertyAction("Set Property...", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.sp);
    }
    return localJPopupMenu;
  }
  
  public class SetPropertyAction
    extends AbstractAction
  {
    public SetPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupDestPropTableHandler.this.m_editor.editRowProperty(PopupDestPropTableHandler.this.m_row);
    }
    
    public boolean isEnabled()
    {
      return !Gems.getGems().getViewOnlyMode();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\PopupDestPropTableHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */