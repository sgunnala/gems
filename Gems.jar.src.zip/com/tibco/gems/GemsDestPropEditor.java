package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.table.JTableHeader;

public class GemsDestPropEditor
  extends JDialog
{
  JFrame m_frame;
  JPanel m_panel;
  GemsConnectionNode m_cn;
  protected String m_type;
  protected JTextField m_conn;
  protected JTextField m_dest;
  protected JButton m_closeButton;
  protected JButton m_refreshButton;
  protected JButton m_lookup;
  JTable m_table;
  protected GemsDetailsTableModel m_tableModel;
  TableSorter m_sorter;
  
  public GemsDestPropEditor(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, String paramString1, String paramString2)
  {
    super(paramJFrame, Gems.getGems().getTitlePrefix() + paramString1 + " Property Editor", true);
    setLocationRelativeTo(paramJFrame);
    setDefaultCloseOperation(2);
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_type = paramString1;
    JMenuBar localJMenuBar = constructMenuBar();
    setJMenuBar(localJMenuBar);
    JPanel localJPanel1 = new JPanel(true);
    localJPanel1.setLayout(new BorderLayout());
    getContentPane().add("Center", localJPanel1);
    JPanel localJPanel2 = new JPanel(new SpringLayout(), true);
    localJPanel1.add(localJPanel2, "North");
    JLabel localJLabel1 = new JLabel("Server:", 11);
    this.m_conn = new JTextField(paramGemsConnectionNode.getName(), 20);
    this.m_conn.setEditable(false);
    this.m_conn.setMaximumSize(new Dimension(0, 24));
    localJLabel1.setLabelFor(this.m_conn);
    localJPanel2.add(localJLabel1);
    localJPanel2.add(this.m_conn);
    JPanel localJPanel3 = new JPanel(true);
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 0));
    localJPanel3.setMinimumSize(new Dimension(300, 24));
    JLabel localJLabel2 = new JLabel(paramString1 + ":", 11);
    this.m_dest = new JTextField(paramString2, 32);
    this.m_dest.addKeyListener(new SubmitListener());
    localJLabel2.setLabelFor(this.m_dest);
    localJPanel2.add(localJLabel2);
    localJPanel3.add(this.m_dest);
    this.m_lookup = new JButton("...");
    this.m_lookup.addActionListener(new LookupAction());
    localJPanel3.add(this.m_lookup);
    localJPanel2.add(localJPanel3);
    this.m_tableModel = new GemsDetailsTableModel();
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_tableModel.setPopupHandler(new PopupDestPropTableHandler(this.m_table, this.m_tableModel, this));
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_tableModel.setTable(this.m_table);
    this.m_table.setSelectionMode(0);
    if (!Gems.getGems().getViewOnlyMode()) {
      addMouseListenerToTable(this.m_table);
    }
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    localJScrollPane.setPreferredSize(new Dimension(635, 300));
    localJPanel1.add(localJScrollPane, "Center");
    JPanel localJPanel4 = new JPanel(true);
    localJPanel4.setLayout(new BoxLayout(localJPanel4, 0));
    Component localComponent = Box.createRigidArea(new Dimension(225, 10));
    localJPanel4.add(localComponent);
    this.m_refreshButton = new JButton("Refresh");
    this.m_refreshButton.addActionListener(new RefreshPressed());
    localJPanel4.add(this.m_refreshButton);
    localComponent = Box.createRigidArea(new Dimension(20, 10));
    localJPanel4.add(localComponent);
    this.m_closeButton = new JButton("Close");
    this.m_closeButton.addActionListener(new ClosePressed());
    localJPanel4.add(this.m_closeButton);
    localJPanel1.add(localJPanel4, "South");
    SpringUtilities.makeCompactGrid(localJPanel2, 2, 2, 5, 5, 5, 5);
    this.m_frame.setIconImage(Gems.getGems().m_icon.getImage());
    getProperties();
    pack();
    show();
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2) {
          GemsDestPropEditor.this.editSelectedProperty();
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
  
  private JMenuBar constructMenuBar()
  {
    JMenuBar localJMenuBar = new JMenuBar();
    JMenu localJMenu = new JMenu("File");
    localJMenu.setMnemonic(70);
    localJMenuBar.add(localJMenu);
    JMenuItem localJMenuItem = localJMenu.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsDestPropEditor.this.dispose();
      }
    });
    if (!Gems.getGems().getViewOnlyMode())
    {
      localJMenu = new JMenu("Edit");
      localJMenu.setMnemonic(69);
      localJMenuBar.add(localJMenu);
      localJMenuItem = new JMenuItem("Edit Property...");
      localJMenuItem.addActionListener(new EditPropAction());
      localJMenu.add(localJMenuItem);
    }
    return localJMenuBar;
  }
  
  public void editSelectedProperty()
  {
    editProperty(this.m_tableModel.getSelectedCol1());
  }
  
  public void editRowProperty(int paramInt)
  {
    String str = (String)this.m_table.getValueAt(paramInt, 0);
    editProperty(str);
  }
  
  public void editProperty(String paramString)
  {
    if (this.m_type.equals("Queue")) {
      GemsQueueNode.setProperty(this.m_frame, this.m_cn, paramString, this.m_dest.getText());
    } else {
      GemsTopicNode.setProperty(this.m_frame, this.m_cn, paramString, this.m_dest.getText());
    }
    getProperties();
  }
  
  public void getProperties()
  {
    if (this.m_dest.getText().length() == 0) {
      return;
    }
    if (this.m_type.equals("Queue")) {
      this.m_tableModel.populateQueueInfo(this.m_cn.m_adminConn, this.m_dest.getText());
    } else {
      this.m_tableModel.populateTopicInfo(this.m_cn.m_adminConn, this.m_dest.getText());
    }
  }
  
  public void dispose()
  {
    super.dispose();
  }
  
  class EditPropAction
    implements ActionListener
  {
    EditPropAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestPropEditor.this.editSelectedProperty();
    }
  }
  
  class LookupAction
    implements ActionListener
  {
    LookupAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsDestPropEditor.this.m_frame, GemsDestPropEditor.this.m_cn, GemsDestPropEditor.this.m_type.equals("Queue") ? GemsDestination.DEST_TYPE.Queue : GemsDestination.DEST_TYPE.Topic);
      if (localGemsDestinationPicker.m_retDest != null)
      {
        GemsDestPropEditor.this.m_dest.setText(localGemsDestinationPicker.m_retDest.m_destName);
        GemsDestPropEditor.this.getProperties();
      }
    }
  }
  
  public class SubmitListener
    implements KeyListener
  {
    public SubmitListener() {}
    
    public void keyPressed(KeyEvent paramKeyEvent)
    {
      if (paramKeyEvent.getKeyCode() == 10) {
        GemsDestPropEditor.this.getProperties();
      }
    }
    
    public void keyReleased(KeyEvent paramKeyEvent) {}
    
    public void keyTyped(KeyEvent paramKeyEvent) {}
  }
  
  class RefreshPressed
    implements ActionListener
  {
    RefreshPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestPropEditor.this.getProperties();
    }
  }
  
  class ClosePressed
    implements ActionListener
  {
    ClosePressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestPropEditor.this.dispose();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDestPropEditor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */