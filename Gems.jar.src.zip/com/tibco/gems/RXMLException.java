package com.tibco.gems;

public class RXMLException
  extends Exception
{
  public RXMLException() {}
  
  public RXMLException(String paramString)
  {
    super(paramString);
  }
  
  public RXMLException(String paramString, Throwable paramThrowable)
  {
    super(paramString, paramThrowable);
  }
  
  public RXMLException(Throwable paramThrowable)
  {
    super(paramThrowable);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\RXMLException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */