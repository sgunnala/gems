package com.tibco.gems;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.ActionMapUIResource;

public class TristateCheckBox
  extends JCheckBox
{
  public static final State NOT_SELECTED = new State(null);
  public static final State SELECTED = new State(null);
  public static final State DONT_CARE = new State(null);
  private final TristateDecorator model;
  
  public TristateCheckBox(String paramString, Icon paramIcon, State paramState)
  {
    super(paramString, paramIcon);
    super.addMouseListener(new MouseAdapter()
    {
      public void mousePressed(MouseEvent paramAnonymousMouseEvent)
      {
        TristateCheckBox.this.grabFocus();
        TristateCheckBox.this.model.nextState();
      }
    });
    ActionMapUIResource localActionMapUIResource = new ActionMapUIResource();
    localActionMapUIResource.put("pressed", new AbstractAction()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        TristateCheckBox.this.grabFocus();
        TristateCheckBox.this.model.nextState();
      }
    });
    localActionMapUIResource.put("released", null);
    SwingUtilities.replaceUIActionMap(this, localActionMapUIResource);
    this.model = new TristateDecorator(getModel(), null);
    setModel(this.model);
    setState(paramState);
  }
  
  public TristateCheckBox(String paramString, State paramState)
  {
    this(paramString, null, paramState);
  }
  
  public TristateCheckBox(String paramString)
  {
    this(paramString, DONT_CARE);
  }
  
  public TristateCheckBox()
  {
    this(null);
  }
  
  public void addMouseListener(MouseListener paramMouseListener) {}
  
  public void setState(State paramState)
  {
    this.model.setState(paramState);
  }
  
  public State getState()
  {
    return this.model.getState();
  }
  
  public void setSelected(boolean paramBoolean)
  {
    if (paramBoolean) {
      setState(SELECTED);
    } else {
      setState(NOT_SELECTED);
    }
  }
  
  private class TristateDecorator
    implements ButtonModel
  {
    private final ButtonModel other;
    
    private TristateDecorator(ButtonModel paramButtonModel)
    {
      this.other = paramButtonModel;
    }
    
    private void setState(TristateCheckBox.State paramState)
    {
      if (paramState == TristateCheckBox.NOT_SELECTED)
      {
        this.other.setArmed(false);
        setPressed(false);
        setSelected(false);
      }
      else if (paramState == TristateCheckBox.SELECTED)
      {
        this.other.setArmed(false);
        setPressed(false);
        setSelected(true);
      }
      else
      {
        this.other.setArmed(true);
        setPressed(true);
        setSelected(true);
      }
    }
    
    private TristateCheckBox.State getState()
    {
      if ((isSelected()) && (!isArmed())) {
        return TristateCheckBox.SELECTED;
      }
      if ((isSelected()) && (isArmed())) {
        return TristateCheckBox.DONT_CARE;
      }
      return TristateCheckBox.NOT_SELECTED;
    }
    
    private void nextState()
    {
      TristateCheckBox.State localState = getState();
      if (localState == TristateCheckBox.NOT_SELECTED) {
        setState(TristateCheckBox.SELECTED);
      } else if (localState == TristateCheckBox.SELECTED) {
        setState(TristateCheckBox.DONT_CARE);
      } else if (localState == TristateCheckBox.DONT_CARE) {
        setState(TristateCheckBox.NOT_SELECTED);
      }
    }
    
    public void setArmed(boolean paramBoolean) {}
    
    public void setEnabled(boolean paramBoolean)
    {
      TristateCheckBox.this.setFocusable(paramBoolean);
      this.other.setEnabled(paramBoolean);
    }
    
    public boolean isArmed()
    {
      return this.other.isArmed();
    }
    
    public boolean isSelected()
    {
      return this.other.isSelected();
    }
    
    public boolean isEnabled()
    {
      return this.other.isEnabled();
    }
    
    public boolean isPressed()
    {
      return this.other.isPressed();
    }
    
    public boolean isRollover()
    {
      return this.other.isRollover();
    }
    
    public void setSelected(boolean paramBoolean)
    {
      this.other.setSelected(paramBoolean);
    }
    
    public void setPressed(boolean paramBoolean)
    {
      this.other.setPressed(paramBoolean);
    }
    
    public void setRollover(boolean paramBoolean)
    {
      this.other.setRollover(paramBoolean);
    }
    
    public void setMnemonic(int paramInt)
    {
      this.other.setMnemonic(paramInt);
    }
    
    public int getMnemonic()
    {
      return this.other.getMnemonic();
    }
    
    public void setActionCommand(String paramString)
    {
      this.other.setActionCommand(paramString);
    }
    
    public String getActionCommand()
    {
      return this.other.getActionCommand();
    }
    
    public void setGroup(ButtonGroup paramButtonGroup)
    {
      this.other.setGroup(paramButtonGroup);
    }
    
    public void addActionListener(ActionListener paramActionListener)
    {
      this.other.addActionListener(paramActionListener);
    }
    
    public void removeActionListener(ActionListener paramActionListener)
    {
      this.other.removeActionListener(paramActionListener);
    }
    
    public void addItemListener(ItemListener paramItemListener)
    {
      this.other.addItemListener(paramItemListener);
    }
    
    public void removeItemListener(ItemListener paramItemListener)
    {
      this.other.removeItemListener(paramItemListener);
    }
    
    public void addChangeListener(ChangeListener paramChangeListener)
    {
      this.other.addChangeListener(paramChangeListener);
    }
    
    public void removeChangeListener(ChangeListener paramChangeListener)
    {
      this.other.removeChangeListener(paramChangeListener);
    }
    
    public Object[] getSelectedObjects()
    {
      return this.other.getSelectedObjects();
    }
  }
  
  public static class State {}
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\TristateCheckBox.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */