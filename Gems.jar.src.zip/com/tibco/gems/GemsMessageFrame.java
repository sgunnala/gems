package com.tibco.gems;

import com.tibco.tibjms.Tibjms;
import com.tibco.tibjms.TibjmsConnectionFactory;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import javax.jms.BytesMessage;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;

public class GemsMessageFrame
  extends JDialog
{
  GemsMsgPropTableModel m_tableModel = null;
  GemsMsgPropTableModel m_mapTableModel = null;
  JMenuBar m_menuBar = new JMenuBar();
  JMenu m_mapmenu = null;
  JFrame m_frame;
  JTable m_table;
  JPanel m_panel;
  JPanel m_headPanel;
  JPanel m_textPanel;
  JPanel m_mapPanel = null;
  JPanel m_bytesPanel = null;
  JTextArea m_bytesTextArea;
  GemsMessageText m_text;
  JButton m_sendButt;
  boolean m_send;
  JTabbedPane m_tabPane;
  String m_destination;
  String m_destprop;
  boolean m_isQueue;
  Message m_msg = null;
  TibjmsAdmin m_admin = null;
  Connection m_connection = null;
  Session m_session = null;
  GemsConnectionNode m_cn = null;
  SimpleDateFormat dateFormatMillis = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
  boolean m_isMonitorMsg;
  boolean m_isEditor = false;
  JDialog m_this;
  
  public GemsMessageFrame(GemsConnectionNode paramGemsConnectionNode, boolean paramBoolean1, String paramString, boolean paramBoolean2, JFrame paramJFrame, boolean paramBoolean3)
  {
    super(paramJFrame, Gems.getGems().getTitlePrefix() + "Message: ", false);
    this.m_isMonitorMsg = paramBoolean3;
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_send = paramBoolean1;
    this.m_isQueue = paramBoolean2;
    this.m_destination = paramString;
    this.m_this = this;
    init();
    setLocationRelativeTo(paramJFrame);
    setLocation(getX(), getY() - 175);
    pack();
    show();
  }
  
  public GemsMessageFrame(GemsConnectionNode paramGemsConnectionNode, boolean paramBoolean1, String paramString, boolean paramBoolean2, JFrame paramJFrame, boolean paramBoolean3, boolean paramBoolean4)
  {
    super(paramJFrame, Gems.getGems().getTitlePrefix() + "Message: ", false);
    this.m_isMonitorMsg = paramBoolean3;
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_send = paramBoolean1;
    this.m_isQueue = paramBoolean2;
    this.m_destination = paramString;
    this.m_this = this;
    init();
    if (paramBoolean4)
    {
      createMapUI();
      this.m_mapTableModel.populateEmptyPropertyInfo(0);
    }
    setLocationRelativeTo(paramJFrame);
    setLocation(getX(), getY() - 165);
    pack();
    show();
  }
  
  public GemsMessageFrame(GemsConnectionNode paramGemsConnectionNode, boolean paramBoolean1, String paramString, boolean paramBoolean2, JFrame paramJFrame, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5)
  {
    super(paramJFrame, Gems.getGems().getTitlePrefix() + "Message: ", true);
    this.m_isMonitorMsg = paramBoolean3;
    this.m_frame = paramJFrame;
    this.m_cn = paramGemsConnectionNode;
    this.m_send = paramBoolean1;
    this.m_isQueue = paramBoolean2;
    this.m_destination = paramString;
    this.m_isEditor = paramBoolean5;
    this.m_this = this;
    init();
    if (paramBoolean4)
    {
      createMapUI();
      this.m_mapTableModel.populateEmptyPropertyInfo(0);
    }
    setLocationRelativeTo(paramJFrame);
    setLocation(getX(), getY() - 165);
    pack();
  }
  
  public void init()
  {
    setDefaultCloseOperation(2);
    if (this.m_cn != null) {
      this.m_admin = this.m_cn.m_adminConn;
    }
    if (this.m_send)
    {
      if (this.m_isQueue) {
        setTitle(Gems.getGems().getTitlePrefix() + "Send TextMessage To Queue");
      } else {
        setTitle(Gems.getGems().getTitlePrefix() + "Publish TextMessage To Topic");
      }
      this.m_destprop = this.m_destination;
    }
    else
    {
      if (this.m_isQueue) {
        this.m_destprop = new String("Queue[");
      } else {
        this.m_destprop = new String("Topic[");
      }
      this.m_destprop = (this.m_destprop + this.m_destination + ']');
    }
    JMenuBar localJMenuBar = constructMenuBar(this.m_send);
    setJMenuBar(localJMenuBar);
    this.m_panel = new JPanel(true);
    this.m_panel.setLayout(new BorderLayout());
    this.m_tabPane = new JTabbedPane();
    this.m_panel.add(this.m_tabPane, "Center");
    getContentPane().add("Center", this.m_panel);
    this.m_headPanel = new JPanel(new BorderLayout());
    this.m_tableModel = new GemsMsgPropTableModel(this.m_send);
    this.m_table = new JTable(this.m_tableModel);
    this.m_table.getTableHeader().setReorderingAllowed(false);
    this.m_tableModel.m_table = this.m_table;
    JScrollPane localJScrollPane1 = new JScrollPane(this.m_table);
    this.m_headPanel.add(localJScrollPane1, "Center");
    this.m_tabPane.addTab("Header", this.m_headPanel);
    this.m_textPanel = new JPanel(new BorderLayout());
    this.m_text = new GemsMessageText();
    this.m_text.setLineWrap(true);
    if (!this.m_send) {
      this.m_text.setEditable(false);
    }
    JScrollPane localJScrollPane2 = new JScrollPane(this.m_text);
    this.m_textPanel.add(localJScrollPane2, "Center");
    this.m_tabPane.addTab("Text Body", this.m_textPanel);
    if (this.m_send)
    {
      if (this.m_isEditor) {
        this.m_sendButt = new JButton("OK");
      } else if (this.m_isQueue) {
        this.m_sendButt = new JButton("Send Message");
      } else {
        this.m_sendButt = new JButton("Publish Message");
      }
      this.m_sendButt.addActionListener(new SendPressed());
      this.m_panel.add(this.m_sendButt, "South");
      if (this.m_isEditor) {
        this.m_tableModel.emptyEditorPropertyInfo(this.m_destprop);
      } else {
        this.m_tableModel.emptyPropertyInfo(this.m_destprop);
      }
      this.m_text.setText("<Message text>");
    }
  }
  
  public void createMapUI()
  {
    Object localObject1;
    Object localObject2;
    if (this.m_mapPanel == null)
    {
      this.m_mapPanel = new JPanel(new BorderLayout());
      this.m_mapTableModel = new GemsMsgPropTableModel(this.m_send, true);
      localObject1 = new JTable(this.m_mapTableModel);
      ((JTable)localObject1).getTableHeader().setReorderingAllowed(false);
      this.m_mapTableModel.m_table = ((JTable)localObject1);
      localObject2 = new JScrollPane((Component)localObject1);
      this.m_mapPanel.add((Component)localObject2, "Center");
      this.m_tabPane.addTab("Map Body", this.m_mapPanel);
      this.m_tabPane.remove(this.m_textPanel);
    }
    this.m_mapTableModel.setRowCount(0);
    if (this.m_send)
    {
      if (this.m_isQueue) {
        setTitle(Gems.getGems().getTitlePrefix() + "Send MapMessage To Queue");
      } else {
        setTitle(Gems.getGems().getTitlePrefix() + "Publish MapMessage To Topic");
      }
      if (this.m_mapmenu == null)
      {
        this.m_mapmenu = new JMenu("Map");
        this.m_mapmenu.setMnemonic(77);
        this.m_menuBar.add(this.m_mapmenu);
        localObject1 = new JMenu("Add Field");
        this.m_mapmenu.add((JMenuItem)localObject1);
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("String"));
        ((JMenuItem)localObject2).addActionListener(new AddStringField());
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("Boolean"));
        ((JMenuItem)localObject2).addActionListener(new AddBooleanField());
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("Integer"));
        ((JMenuItem)localObject2).addActionListener(new AddIntegerField());
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("Byte"));
        ((JMenuItem)localObject2).addActionListener(new AddByteField());
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("Short"));
        ((JMenuItem)localObject2).addActionListener(new AddShortField());
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("Long"));
        ((JMenuItem)localObject2).addActionListener(new AddLongField());
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("Float"));
        ((JMenuItem)localObject2).addActionListener(new AddFloatField());
        localObject2 = ((JMenu)localObject1).add(new JMenuItem("Double"));
        ((JMenuItem)localObject2).addActionListener(new AddDoubleField());
      }
    }
  }
  
  public void createBytesFieldUI(String paramString, boolean paramBoolean)
  {
    if (this.m_bytesPanel == null)
    {
      this.m_bytesPanel = new JPanel(new BorderLayout());
      this.m_bytesTextArea = new JTextArea();
      this.m_bytesTextArea.setLineWrap(true);
      this.m_bytesTextArea.setEditable(false);
      JScrollPane localJScrollPane = new JScrollPane(this.m_bytesTextArea);
      this.m_bytesPanel.add(localJScrollPane, "Center");
      this.m_tabPane.addTab(paramString + " Field", this.m_bytesPanel);
    }
    else
    {
      this.m_tabPane.setTitleAt(2, paramString + " Field");
    }
    if ((this.m_msg != null) && ((this.m_msg instanceof MapMessage))) {
      try
      {
        if (paramBoolean) {
          this.m_bytesTextArea.setText(new String(((MapMessage)this.m_msg).getBytes(paramString)));
        } else {
          this.m_bytesTextArea.setText(StringUtilities.dumpBytes(((MapMessage)this.m_msg).getBytes(paramString)));
        }
        this.m_tabPane.setSelectedIndex(2);
      }
      catch (Exception localException)
      {
        System.err.println("Exception: " + localException.getMessage());
        return;
      }
    }
  }
  
  public void createTextUI()
  {
    if (this.m_mapPanel != null)
    {
      this.m_tabPane.remove(this.m_mapPanel);
      this.m_mapPanel = null;
      this.m_mapTableModel = null;
      this.m_tabPane.addTab("Text Body", this.m_textPanel);
    }
    if (this.m_send) {
      if (this.m_isQueue) {
        setTitle(Gems.getGems().getTitlePrefix() + "Send TextMessage To Queue");
      } else {
        setTitle(Gems.getGems().getTitlePrefix() + "Publish TextMessage To Topic");
      }
    }
  }
  
  public void createSimpleUI()
  {
    if (this.m_tabPane.getTabCount() > 1) {
      this.m_tabPane.remove(this.m_textPanel);
    }
    if (this.m_send) {
      if (this.m_isQueue) {
        setTitle(Gems.getGems().getTitlePrefix() + "Send SimpleMessage To Queue");
      } else {
        setTitle(Gems.getGems().getTitlePrefix() + "Publish SimpleMessage To Topic");
      }
    }
  }
  
  public void populate(Message paramMessage)
  {
    this.m_msg = paramMessage;
    try
    {
      String str1 = paramMessage.getClass().getName();
      int i = str1.lastIndexOf("Tibjms");
      String str2 = new String();
      if (paramMessage.getJMSMessageID() != null) {
        str2 = paramMessage.getJMSMessageID();
      }
      if (i > 0) {
        setTitle(Gems.getGems().getTitlePrefix() + str1.substring(i + 6) + " " + str2);
      }
      this.m_tableModel.populatePropertyInfo(paramMessage);
      this.m_text.setMessageText(paramMessage);
      if ((paramMessage instanceof TextMessage))
      {
        if (this.m_tabPane.getTabCount() > 1) {
          this.m_tabPane.setTitleAt(1, "Text Body");
        }
      }
      else if ((paramMessage instanceof MapMessage))
      {
        createMapUI();
        MapMessage localMapMessage = (MapMessage)paramMessage;
        this.m_mapTableModel.populateMapMsg(localMapMessage);
      }
      else if ((paramMessage instanceof BytesMessage))
      {
        if (this.m_tabPane.getTabCount() > 1) {
          this.m_tabPane.setTitleAt(1, "Bytes Body (" + ((BytesMessage)paramMessage).getBodyLength() + " bytes)");
        }
      }
      else if ((paramMessage instanceof StreamMessage))
      {
        if (this.m_tabPane.getTabCount() > 1) {
          this.m_tabPane.setTitleAt(1, "Body");
        }
      }
      else if ((paramMessage instanceof ObjectMessage))
      {
        if (this.m_tabPane.getTabCount() > 1) {
          this.m_tabPane.setTitleAt(1, "Body");
        }
      }
      else
      {
        createSimpleUI();
      }
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
      return;
    }
  }
  
  public void openSubMapMsg(String paramString)
  {
    if ((this.m_msg != null) && ((this.m_msg instanceof MapMessage))) {
      try
      {
        MapMessage localMapMessage = (MapMessage)this.m_msg;
        Object localObject1 = localMapMessage.getObject(paramString);
        Object localObject2;
        if ((localObject1 != null) && ((localObject1 instanceof MapMessage)))
        {
          localObject2 = new GemsMessageFrame(this.m_cn, false, this.m_destination, this.m_isQueue, this.m_frame, false);
          ((GemsMessageFrame)localObject2).populate((MapMessage)localObject1);
        }
        else if (localMapMessage.itemExists("message_bytes"))
        {
          localObject2 = Tibjms.createFromBytes(localMapMessage.getBytes("message_bytes"));
          GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(this.m_cn, false, this.m_destination, this.m_isQueue, this.m_frame, false);
          localGemsMessageFrame.populate((Message)localObject2);
        }
      }
      catch (Exception localException)
      {
        Gems.debug(localException.getMessage());
        return;
      }
    }
  }
  
  public GemsMsgPropTableModel getModel()
  {
    return this.m_tableModel;
  }
  
  Message createMessage(Session paramSession)
    throws JMSException
  {
    Object localObject1 = null;
    if (this.m_mapPanel != null) {
      localObject1 = paramSession.createMapMessage();
    } else {
      localObject1 = paramSession.createTextMessage();
    }
    ((Message)localObject1).setJMSCorrelationID(this.m_tableModel.getJMSCorrelationID());
    ((Message)localObject1).setJMSDeliveryMode(this.m_tableModel.getJMSDeliveryMode());
    ((Message)localObject1).setJMSExpiration(this.m_tableModel.getJMSExpiration());
    ((Message)localObject1).setJMSPriority(this.m_tableModel.getJMSPriority());
    ((Message)localObject1).setJMSType(this.m_tableModel.getJMSType());
    GemsDestination localGemsDestination = this.m_tableModel.getJMSReplyTo();
    if (localGemsDestination != null) {
      if (localGemsDestination.m_destType == GemsDestination.DEST_TYPE.Queue) {
        ((Message)localObject1).setJMSReplyTo(paramSession.createQueue(localGemsDestination.m_destName));
      } else {
        ((Message)localObject1).setJMSReplyTo(paramSession.createTopic(localGemsDestination.m_destName));
      }
    }
    Object localObject2;
    for (int i = this.m_tableModel.getHeaderRows(); i < this.m_tableModel.getRowCount(); i++)
    {
      String str = (String)this.m_tableModel.getValueAt(i, 0);
      if ((str != null) && (str.length() > 0))
      {
        localObject2 = this.m_tableModel.getValueAt(i, 1);
        if ((localObject2 instanceof String)) {
          ((Message)localObject1).setStringProperty(str, (String)localObject2);
        } else if ((localObject2 instanceof Boolean)) {
          ((Message)localObject1).setBooleanProperty(str, ((Boolean)localObject2).booleanValue());
        } else if ((localObject2 instanceof Integer)) {
          ((Message)localObject1).setIntProperty(str, ((Integer)localObject2).intValue());
        } else if ((localObject2 instanceof Long)) {
          ((Message)localObject1).setLongProperty(str, ((Long)localObject2).longValue());
        } else if ((localObject2 instanceof Short)) {
          ((Message)localObject1).setShortProperty(str, ((Short)localObject2).shortValue());
        } else if ((localObject2 instanceof Byte)) {
          ((Message)localObject1).setByteProperty(str, ((Byte)localObject2).byteValue());
        } else if ((localObject2 instanceof Float)) {
          ((Message)localObject1).setFloatProperty(str, ((Float)localObject2).floatValue());
        } else if ((localObject2 instanceof Double)) {
          ((Message)localObject1).setDoubleProperty(str, ((Double)localObject2).doubleValue());
        }
      }
    }
    if ((localObject1 instanceof TextMessage))
    {
      ((TextMessage)localObject1).setText(this.m_text.getText());
    }
    else if ((localObject1 instanceof MapMessage))
    {
      MapMessage localMapMessage = (MapMessage)localObject1;
      for (int j = this.m_mapTableModel.getHeaderRows(); j < this.m_mapTableModel.getRowCount(); j++)
      {
        localObject2 = (String)this.m_mapTableModel.getValueAt(j, 0);
        if ((localObject2 != null) && (((String)localObject2).length() > 0))
        {
          Object localObject3 = this.m_mapTableModel.getValueAt(j, 1);
          if ((localObject3 instanceof String)) {
            localMapMessage.setString((String)localObject2, (String)localObject3);
          } else if ((localObject3 instanceof Boolean)) {
            localMapMessage.setBoolean((String)localObject2, ((Boolean)localObject3).booleanValue());
          } else if ((localObject3 instanceof Integer)) {
            localMapMessage.setInt((String)localObject2, ((Integer)localObject3).intValue());
          } else if ((localObject3 instanceof Long)) {
            localMapMessage.setLong((String)localObject2, ((Long)localObject3).longValue());
          } else if ((localObject3 instanceof Short)) {
            localMapMessage.setShort((String)localObject2, ((Short)localObject3).shortValue());
          } else if ((localObject3 instanceof Byte)) {
            localMapMessage.setByte((String)localObject2, ((Byte)localObject3).byteValue());
          } else if ((localObject3 instanceof Float)) {
            localMapMessage.setFloat((String)localObject2, ((Float)localObject3).floatValue());
          } else if ((localObject3 instanceof Double)) {
            localMapMessage.setDouble((String)localObject2, ((Double)localObject3).doubleValue());
          }
        }
      }
    }
    return (Message)localObject1;
  }
  
  private JMenuBar constructMenuBar(boolean paramBoolean)
  {
    JMenu localJMenu1 = new JMenu("File");
    localJMenu1.setMnemonic(70);
    this.m_menuBar.add(localJMenu1);
    if (paramBoolean)
    {
      localJMenuItem = localJMenu1.add(new JMenuItem("Load..."));
      localJMenuItem.addActionListener(new LoadMessage());
      JMenu localJMenu2 = new JMenu("Property");
      localJMenu2.setMnemonic(80);
      this.m_menuBar.add(localJMenu2);
      if (!this.m_isEditor)
      {
        localJMenu3 = new JMenu("Add JMS Property");
        localJMenu2.add(localJMenu3);
        localJMenuItem = localJMenu3.add(new JMenuItem("JMSReplyTo..."));
        localJMenuItem.addActionListener(new AddJMSReplyToProperty());
      }
      JMenu localJMenu3 = new JMenu("Add Tibco Property");
      localJMenu2.add(localJMenu3);
      localJMenuItem = localJMenu3.add(new JMenuItem("JMS_TIBCO_COMPRESS"));
      localJMenuItem.addActionListener(new AddCompressProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("JMS_TIBCO_PRESERVE_UNDELIVERED"));
      localJMenuItem.addActionListener(new AddPreserveProperty());
      localJMenu3 = new JMenu("Add Custom Property");
      localJMenu2.add(localJMenu3);
      localJMenuItem = localJMenu3.add(new JMenuItem("String"));
      localJMenuItem.addActionListener(new AddStringProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("Boolean"));
      localJMenuItem.addActionListener(new AddBooleanProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("Integer"));
      localJMenuItem.addActionListener(new AddIntegerProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("Byte"));
      localJMenuItem.addActionListener(new AddByteProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("Short"));
      localJMenuItem.addActionListener(new AddShortProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("Long"));
      localJMenuItem.addActionListener(new AddLongProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("Float"));
      localJMenuItem.addActionListener(new AddFloatProperty());
      localJMenuItem = localJMenu3.add(new JMenuItem("Double"));
      localJMenuItem.addActionListener(new AddDoubleProperty());
    }
    else
    {
      localJMenuItem = localJMenu1.add(new JMenuItem("Save..."));
      localJMenuItem.addActionListener(new SaveMessage());
    }
    JMenuItem localJMenuItem = localJMenu1.add(new JMenuItem("Exit"));
    localJMenuItem.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent paramAnonymousActionEvent)
      {
        GemsMessageFrame.this.dispose();
      }
    });
    if (this.m_isMonitorMsg)
    {
      localJMenu1 = new JMenu("Message");
      localJMenu1.setMnemonic(77);
      this.m_menuBar.add(localJMenu1);
      localJMenuItem = localJMenu1.add(new JMenuItem("View Original Message..."));
      localJMenuItem.addActionListener(new ViewOrigMsg(this));
    }
    return this.m_menuBar;
  }
  
  public void close()
  {
    try
    {
      if (this.m_session != null)
      {
        this.m_session.close();
        this.m_session = null;
      }
      if (this.m_connection != null)
      {
        this.m_connection.close();
        this.m_connection = null;
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("Exception: " + localJMSException.getMessage());
    }
  }
  
  public void dispose()
  {
    close();
    super.dispose();
  }
  
  class ViewOrigMsg
    implements ActionListener
  {
    Component parent;
    
    public ViewOrigMsg(Component paramComponent)
    {
      this.parent = paramComponent;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if ((GemsMessageFrame.this.m_isMonitorMsg) && (GemsMessageFrame.this.m_msg != null)) {
        try
        {
          MapMessage localMapMessage = (MapMessage)GemsMessageFrame.this.m_msg;
          if (localMapMessage.itemExists("message_bytes"))
          {
            Message localMessage = Tibjms.createFromBytes(localMapMessage.getBytes("message_bytes"));
            GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(GemsMessageFrame.this.m_cn, false, GemsMessageFrame.this.m_destination, GemsMessageFrame.this.m_isQueue, GemsMessageFrame.this.m_frame, false);
            localGemsMessageFrame.populate(localMessage);
          }
        }
        catch (Exception localException)
        {
          Gems.debug(localException.getMessage());
          return;
        }
      }
    }
  }
  
  class AddJMSReplyToProperty
    implements ActionListener
  {
    AddJMSReplyToProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker(GemsMessageFrame.this.m_frame, GemsMessageFrame.this.m_cn);
      if (localGemsDestinationPicker.m_retDest != null)
      {
        GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
        GemsMessageFrame.this.m_tableModel.addJMSReplyToProperty(localGemsDestinationPicker.m_retDest);
      }
    }
  }
  
  class AddDoubleField
    implements ActionListener
  {
    AddDoubleField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addDoubleProperty();
    }
  }
  
  class AddFloatField
    implements ActionListener
  {
    AddFloatField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addFloatProperty();
    }
  }
  
  class AddBooleanField
    implements ActionListener
  {
    AddBooleanField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addBooleanProperty();
    }
  }
  
  class AddByteField
    implements ActionListener
  {
    AddByteField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addByteProperty();
    }
  }
  
  class AddShortField
    implements ActionListener
  {
    AddShortField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addShortProperty();
    }
  }
  
  class AddLongField
    implements ActionListener
  {
    AddLongField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addLongProperty();
    }
  }
  
  class AddIntegerField
    implements ActionListener
  {
    AddIntegerField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addIntProperty();
    }
  }
  
  class AddStringField
    implements ActionListener
  {
    AddStringField() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(1);
      GemsMessageFrame.this.m_mapTableModel.addStringProperty();
    }
  }
  
  class AddPreserveProperty
    implements ActionListener
  {
    AddPreserveProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addPreserveProperty();
    }
  }
  
  class AddCompressProperty
    implements ActionListener
  {
    AddCompressProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addCompressProperty();
    }
  }
  
  class AddDoubleProperty
    implements ActionListener
  {
    AddDoubleProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addDoubleProperty();
    }
  }
  
  class AddFloatProperty
    implements ActionListener
  {
    AddFloatProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addFloatProperty();
    }
  }
  
  class AddBooleanProperty
    implements ActionListener
  {
    AddBooleanProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addBooleanProperty();
    }
  }
  
  class AddByteProperty
    implements ActionListener
  {
    AddByteProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addByteProperty();
    }
  }
  
  class AddShortProperty
    implements ActionListener
  {
    AddShortProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addShortProperty();
    }
  }
  
  class AddLongProperty
    implements ActionListener
  {
    AddLongProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addLongProperty();
    }
  }
  
  class AddIntegerProperty
    implements ActionListener
  {
    AddIntegerProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addIntProperty();
    }
  }
  
  class AddStringProperty
    implements ActionListener
  {
    AddStringProperty() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame.this.m_tabPane.setSelectedIndex(0);
      GemsMessageFrame.this.m_tableModel.addStringProperty();
    }
  }
  
  class LoadMessage
    implements ActionListener
  {
    LoadMessage() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        JFileChooser localJFileChooser = new JFileChooser();
        localJFileChooser.setDialogTitle("Load Message From File");
        int i = localJFileChooser.showOpenDialog(GemsMessageFrame.this.m_frame);
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          BufferedReader localBufferedReader = new BufferedReader(new FileReader(localFile));
          GemsMessageFrame.this.m_text.setText("");
          GemsMessageFrame.this.m_tableModel.emptyPropertyInfo(GemsMessageFrame.this.m_destprop);
          StringBuffer localStringBuffer1 = new StringBuffer();
          StringBuffer localStringBuffer2 = new StringBuffer();
          int j = 1;
          int k = 1;
          int m = 0;
          String str;
          label349:
          while ((str = localBufferedReader.readLine()) != null)
          {
            if (k == 0) {
              localStringBuffer2.append('\n');
            }
            localStringBuffer2.append(str);
            k = 0;
            if (str.startsWith("$Properties:"))
            {
              m = 1;
              for (;;)
              {
                if ((str = localBufferedReader.readLine()) == null) {
                  break label349;
                }
                if ((str.startsWith("$Body:")) || (str.startsWith("$TextBody:")))
                {
                  while ((str = localBufferedReader.readLine()) != null)
                  {
                    if (j == 0) {
                      localStringBuffer1.append('\n');
                    }
                    localStringBuffer1.append(str);
                    j = 0;
                  }
                  GemsMessageFrame.this.createTextUI();
                  GemsMessageFrame.this.m_text.setText(localStringBuffer1.toString());
                  break;
                }
                if (str.startsWith("$MapBody:"))
                {
                  GemsMessageFrame.this.createMapUI();
                  GemsMessageFrame.this.m_mapTableModel.populateEmptyPropertyInfo(0);
                  while ((str = localBufferedReader.readLine()) != null) {
                    if (GemsMessageFrame.this.m_mapTableModel != null) {
                      GemsMessageFrame.this.m_mapTableModel.addPropertyInfo(str);
                    }
                  }
                  break;
                }
                if ((str.startsWith("JMS_")) || (!str.startsWith("JMS"))) {
                  GemsMessageFrame.this.m_tableModel.addPropertyInfo(str);
                }
              }
            }
          }
          if (m == 0) {
            GemsMessageFrame.this.m_text.setText(localStringBuffer2.toString());
          }
          localBufferedReader.close();
        }
      }
      catch (IOException localIOException)
      {
        System.err.println("JavaIOException: " + localIOException.getMessage());
        return;
      }
    }
  }
  
  class SaveMessage
    implements ActionListener
  {
    SaveMessage() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsMessageFrame.this.m_msg == null) {
        return;
      }
      try
      {
        JFileChooser localJFileChooser = new JFileChooser();
        localJFileChooser.setApproveButtonText("Save");
        localJFileChooser.setDialogTitle("Save Message To File");
        int i = localJFileChooser.showOpenDialog(GemsMessageFrame.this.m_frame);
        if (i == 0)
        {
          File localFile = localJFileChooser.getSelectedFile();
          localFile.createNewFile();
          FileOutputStream localFileOutputStream = new FileOutputStream(localFile);
          PrintStream localPrintStream = new PrintStream(localFileOutputStream);
          localPrintStream.println("$Header:");
          localPrintStream.println("JMSMessageID=" + GemsMessageFrame.this.m_msg.getJMSMessageID());
          Date localDate = new Date();
          localDate.setTime(GemsMessageFrame.this.m_msg.getJMSTimestamp());
          localPrintStream.println("JMSTimestamp=" + GemsMessageFrame.this.dateFormatMillis.format(localDate).toString());
          localPrintStream.println("JMSDestination=" + GemsMessageFrame.this.m_msg.getJMSDestination());
          String str1 = GemsMessageFrame.this.m_msg.getJMSDeliveryMode() == 1 ? "NON_PERSISTENT" : GemsMessageFrame.this.m_msg.getJMSDeliveryMode() == 2 ? "PERSISTENT" : "RELIABLE";
          localPrintStream.println("JMSDeliveryMode=" + str1);
          if (GemsMessageFrame.this.m_msg.getJMSCorrelationID() != null) {
            localPrintStream.println("JMSCorrelationID=" + GemsMessageFrame.this.m_msg.getJMSCorrelationID());
          }
          if (GemsMessageFrame.this.m_msg.getJMSType() != null) {
            localPrintStream.println("JMSType=" + GemsMessageFrame.this.m_msg.getJMSType());
          }
          if (GemsMessageFrame.this.m_msg.getJMSReplyTo() != null) {
            localPrintStream.println("JMSReplyTo=" + GemsMessageFrame.this.m_msg.getJMSReplyTo());
          }
          if (GemsMessageFrame.this.m_msg.getJMSExpiration() != 0L)
          {
            localDate.setTime(GemsMessageFrame.this.m_msg.getJMSExpiration());
            localPrintStream.println("JMSExpiration=" + GemsMessageFrame.this.dateFormatMillis.format(localDate).toString());
          }
          localPrintStream.println("JMSPriority=" + String.valueOf(GemsMessageFrame.this.m_msg.getJMSPriority()));
          localPrintStream.println("$Properties:");
          Enumeration localEnumeration1 = GemsMessageFrame.this.m_msg.getPropertyNames();
          while (localEnumeration1.hasMoreElements())
          {
            String str2 = (String)localEnumeration1.nextElement();
            localPrintStream.println(str2 + "=" + GemsMsgPropTableModel.toTypedString(null, GemsMessageFrame.this.m_msg.getObjectProperty(str2)));
          }
          Object localObject;
          if ((GemsMessageFrame.this.m_msg instanceof TextMessage))
          {
            localObject = (TextMessage)GemsMessageFrame.this.m_msg;
            localPrintStream.println("$TextBody:");
            localPrintStream.println(((TextMessage)localObject).getText());
          }
          else if ((GemsMessageFrame.this.m_msg instanceof MapMessage))
          {
            localObject = (MapMessage)GemsMessageFrame.this.m_msg;
            localPrintStream.println("$MapBody:");
            Enumeration localEnumeration2 = ((MapMessage)localObject).getMapNames();
            while (localEnumeration2.hasMoreElements())
            {
              String str3 = (String)localEnumeration2.nextElement();
              localPrintStream.println(str3 + "=" + GemsMsgPropTableModel.toTypedString(null, ((MapMessage)localObject).getObject(str3)));
            }
          }
          else if ((GemsMessageFrame.this.m_msg instanceof BytesMessage))
          {
            localObject = (BytesMessage)GemsMessageFrame.this.m_msg;
            localPrintStream.println("$BytesBody:");
            ((BytesMessage)localObject).reset();
            long l = ((BytesMessage)localObject).getBodyLength();
            byte[] arrayOfByte = new byte[(int)l];
            ((BytesMessage)localObject).readBytes(arrayOfByte, (int)l);
            localPrintStream.println(StringUtilities.dumpBytes(arrayOfByte));
          }
          else if ((GemsMessageFrame.this.m_msg instanceof StreamMessage))
          {
            localObject = (StreamMessage)GemsMessageFrame.this.m_msg;
            localPrintStream.println("$StreamBody:");
            localPrintStream.println(localObject.toString());
          }
          else if ((GemsMessageFrame.this.m_msg instanceof ObjectMessage))
          {
            localObject = (ObjectMessage)GemsMessageFrame.this.m_msg;
            localPrintStream.println("$ObjectBody:");
            localPrintStream.println(localObject.toString());
          }
          localPrintStream.close();
        }
      }
      catch (JMSException localJMSException)
      {
        System.err.println("JMSException: " + localJMSException.getMessage());
        return;
      }
      catch (IOException localIOException)
      {
        System.err.println("JavaIOException: " + localIOException.getMessage());
        return;
      }
    }
  }
  
  class SendPressed
    implements ActionListener
  {
    SendPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      if (GemsMessageFrame.this.m_table.getCellEditor() != null) {
        GemsMessageFrame.this.m_table.getCellEditor().stopCellEditing();
      }
      if ((GemsMessageFrame.this.m_mapTableModel != null) && (GemsMessageFrame.this.m_mapTableModel.m_table != null) && (GemsMessageFrame.this.m_mapTableModel.m_table.getCellEditor() != null)) {
        GemsMessageFrame.this.m_mapTableModel.m_table.getCellEditor().stopCellEditing();
      }
      if (GemsMessageFrame.this.m_isEditor)
      {
        GemsMessageFrame.this.dispose();
        return;
      }
      String str = GemsMessageFrame.this.m_tableModel.getJMSDestination();
      try
      {
        if (GemsMessageFrame.this.m_isQueue)
        {
          if (GemsMessageFrame.this.m_admin.getQueue(str) == null) {
            JOptionPane.showMessageDialog(GemsMessageFrame.this.m_this, "The destination queue does not exist!", "Error", 1);
          }
        }
        else if (GemsMessageFrame.this.m_admin.getTopic(str) == null)
        {
          JOptionPane.showMessageDialog(GemsMessageFrame.this.m_this, "The destination topic does not exist!", "Error", 1);
          return;
        }
      }
      catch (TibjmsAdminException localTibjmsAdminException)
      {
        JOptionPane.showMessageDialog(GemsMessageFrame.this.m_this, localTibjmsAdminException.getMessage(), "Error", 1);
        return;
      }
      catch (Exception localException1)
      {
        JOptionPane.showMessageDialog(GemsMessageFrame.this.m_this, "Connection Error, please close send message window and retry", "Error", 1);
        return;
      }
      MessageProducer localMessageProducer = null;
      try
      {
        Object localObject;
        if (GemsMessageFrame.this.m_connection == null)
        {
          localObject = new TibjmsConnectionFactory(GemsMessageFrame.this.m_cn.m_url, null, GemsMessageFrame.this.m_cn.m_sslParams);
          GemsMessageFrame.this.m_connection = ((ConnectionFactory)localObject).createConnection(GemsMessageFrame.this.m_cn.m_user, GemsMessageFrame.this.m_cn.m_password);
          GemsMessageFrame.this.m_connection.start();
        }
        if (GemsMessageFrame.this.m_session == null) {
          GemsMessageFrame.this.m_session = GemsMessageFrame.this.m_connection.createSession(false, 1);
        }
        if (GemsMessageFrame.this.m_isQueue) {
          localObject = GemsMessageFrame.this.m_session.createQueue(str);
        } else {
          localObject = GemsMessageFrame.this.m_session.createTopic(str);
        }
        localMessageProducer = GemsMessageFrame.this.m_session.createProducer(null);
        Message localMessage = GemsMessageFrame.this.createMessage(GemsMessageFrame.this.m_session);
        localMessageProducer.send((Destination)localObject, localMessage, GemsMessageFrame.this.m_tableModel.getJMSDeliveryMode(), GemsMessageFrame.this.m_tableModel.getJMSPriority(), GemsMessageFrame.this.m_tableModel.getJMSExpiration());
        if (GemsMessageFrame.this.m_isQueue) {
          GemsMessageFrame.this.m_sendButt.setText("Send Again");
        } else {
          GemsMessageFrame.this.m_sendButt.setText("Publish Again");
        }
        localMessageProducer.close();
      }
      catch (JMSException localJMSException)
      {
        JOptionPane.showMessageDialog(GemsMessageFrame.this.m_this, localJMSException.getMessage(), "Error", 1);
        System.err.println("Exception: " + localJMSException.getMessage());
        GemsMessageFrame.this.close();
        return;
      }
      catch (Exception localException2)
      {
        JOptionPane.showMessageDialog(GemsMessageFrame.this.m_this, localException2.getMessage(), "Error", 1);
        System.err.println("Exception: " + localException2.getMessage());
        return;
      }
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsMessageFrame.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */