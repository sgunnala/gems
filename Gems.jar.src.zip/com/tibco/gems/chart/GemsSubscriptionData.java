package com.tibco.gems.chart;

import com.tibco.gems.Gems;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Hashtable;
import java.util.TimeZone;
import java.util.Vector;
import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;

public class GemsSubscriptionData
  extends AbstractTableModel
{
  private GemsChartFrame m_chart;
  private long _timeLimit = 300000L;
  public static final SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm:ss");
  private Vector _chartingColumns = null;
  private Vector _subscriptionDataHeaders = null;
  private Vector[] _subscriptionDataVector = null;
  
  public synchronized void purgeOldData(long paramLong)
  {
    long l = paramLong;
    Vector localVector = this._subscriptionDataVector[0];
    int i = localVector.size();
    if (i <= 1) {
      return;
    }
    if (l == 0L)
    {
      Long localLong1 = (Long)localVector.elementAt(0);
      l = localLong1.longValue() - this._timeLimit;
    }
    for (int j = i - 1; j >= 0; j--)
    {
      Long localLong2 = (Long)localVector.elementAt(0);
      if (l <= localLong2.longValue() + this._timeLimit) {
        break;
      }
      for (int k = 0; k < this._subscriptionDataHeaders.size(); k++) {
        this._subscriptionDataVector[k].removeElementAt(0);
      }
    }
  }
  
  public void setTimeLimit(long paramLong)
  {
    this._timeLimit = paramLong;
    purgeOldData(0L);
    setXAxisMinMax();
  }
  
  public long getTimeLimit()
  {
    return this._timeLimit;
  }
  
  public void setXAxisMinMax() {}
  
  public synchronized String[] getPointLabels()
  {
    Vector localVector = this._subscriptionDataVector[0];
    if (localVector == null) {
      return null;
    }
    int i = localVector.size();
    String[] arrayOfString = new String[i];
    for (int j = 0; j < i; j++)
    {
      long l = ((Long)localVector.elementAt(j)).longValue();
      Date localDate = new Date(l);
      arrayOfString[j] = new String(timeFormat.format(localDate));
    }
    return arrayOfString;
  }
  
  public String getSeriesLabel(int paramInt)
  {
    return null;
  }
  
  public String getSeriesName(int paramInt)
  {
    return null;
  }
  
  public String getName()
  {
    return "Real-time Data";
  }
  
  public void setChart(GemsChartFrame paramGemsChartFrame)
  {
    this.m_chart = paramGemsChartFrame;
  }
  
  public synchronized Object getDataItem(int paramInt1, int paramInt2)
  {
    Vector localVector1 = this._subscriptionDataVector[0];
    Vector localVector2 = this._subscriptionDataVector[1];
    switch (paramInt1)
    {
    case 0: 
      return localVector1.elementAt(paramInt2);
    case 1: 
      return localVector2.elementAt(paramInt2);
    }
    return null;
  }
  
  public synchronized int getDataInterpretation()
  {
    return 0;
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    return false;
  }
  
  public Object getValueAt(int paramInt1, int paramInt2)
  {
    int i = getRowCount();
    int j = i != 0 ? i - 1 : i;
    if (paramInt2 == 0)
    {
      long l = ((Long)this._subscriptionDataVector[0].elementAt(j - paramInt1)).longValue();
      Date localDate = new Date(l);
      return localDate.toString();
    }
    return this._subscriptionDataVector[paramInt2].elementAt(j - paramInt1);
  }
  
  public int getColumnCount()
  {
    return this._subscriptionDataHeaders != null ? this._subscriptionDataHeaders.size() : 0;
  }
  
  public String getColumnName(int paramInt)
  {
    return (String)this._subscriptionDataHeaders.elementAt(paramInt);
  }
  
  public int getRowCount()
  {
    if ((this._subscriptionDataVector == null) || (this._subscriptionDataVector[0] == null)) {
      return 0;
    }
    return this._subscriptionDataVector[0].size();
  }
  
  public Vector getColumnHeaders()
  {
    return this._subscriptionDataHeaders;
  }
  
  public Vector getTimeSlices()
  {
    return this._subscriptionDataVector[0];
  }
  
  public synchronized Vector getDataPoints(String paramString)
  {
    for (int i = 0; i < this._subscriptionDataHeaders.size(); i++) {
      if (this._subscriptionDataHeaders.elementAt(i).equals(paramString)) {
        return this._subscriptionDataVector[i];
      }
    }
    return new Vector();
  }
  
  public int getChartableFieldIndex(String paramString)
  {
    for (int i = 0; i < this._chartingColumns.size(); i++)
    {
      int j = ((Long)this._chartingColumns.elementAt(i)).intValue();
      if (this._subscriptionDataHeaders.elementAt(j).equals(paramString)) {
        return i;
      }
    }
    return -1;
  }
  
  public void showChartableField(int paramInt)
  {
    try
    {
      this.m_chart.showChartableField(paramInt);
    }
    catch (Exception localException)
    {
      Gems.getGems();
      Gems.debug(localException.toString());
    }
  }
  
  public void removeChartableField(String paramString, int paramInt)
  {
    this.m_chart.removeChartableField(paramInt);
  }
  
  public synchronized void addRow(Date paramDate, Hashtable paramHashtable)
  {
    purgeOldData(paramDate.getTime());
    this._subscriptionDataVector[0].addElement(new Long(paramDate.getTime()));
    for (int i = 1; i < this._subscriptionDataHeaders.size(); i++)
    {
      String str = (String)this._subscriptionDataHeaders.elementAt(i);
      this._subscriptionDataVector[i].addElement(paramHashtable.get(str));
    }
    fireTableChanged(new TableModelEvent(this));
  }
  
  public void setColumnIdentifiers(Vector paramVector)
  {
    this._subscriptionDataVector = new Vector[paramVector.size() + 1];
    this._subscriptionDataHeaders = new Vector(paramVector.size() + 1);
    this._subscriptionDataHeaders.insertElementAt("     ", 0);
    for (int i = 0; i < paramVector.size(); i++) {
      this._subscriptionDataHeaders.addElement((String)paramVector.elementAt(i));
    }
    for (i = 0; i < this._subscriptionDataHeaders.size(); i++) {
      this._subscriptionDataVector[i] = new Vector(50);
    }
  }
  
  public GemsSubscriptionData(Vector paramVector)
  {
    setColumnIdentifiers(paramVector);
    this._chartingColumns = new Vector();
    timeFormat.setTimeZone(TimeZone.getDefault());
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsSubscriptionData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */