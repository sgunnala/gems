package com.tibco.gems;

import java.awt.Component;
import java.awt.Container;
import java.awt.Point;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

public class PopupMsgPropTableHandler
  extends PopupTableHandler
{
  public AbstractAction openMsg = null;
  public AbstractAction remProp = null;
  public AbstractAction compProp = null;
  public AbstractAction presvProp = null;
  public AbstractAction viewBytes = null;
  public AbstractAction viewBytesText = null;
  public AbstractAction replytoProp = null;
  public AbstractAction addint = null;
  public AbstractAction addbool = null;
  public AbstractAction addstring = null;
  public AbstractAction addbyte = null;
  public AbstractAction addshort = null;
  public AbstractAction addlong = null;
  public AbstractAction adddouble = null;
  public AbstractAction addfloat = null;
  public JMenu addprop = null;
  public JMenu addfield = null;
  public GemsMsgPropTableModel m_model;
  
  public PopupMsgPropTableHandler(JTable paramJTable)
  {
    super(paramJTable);
    this.m_model = ((GemsMsgPropTableModel)paramJTable.getModel());
  }
  
  public JPopupMenu createPopup(Point paramPoint)
  {
    JPopupMenu localJPopupMenu = super.createPopup(paramPoint);
    if (this.addint == null) {
      this.addint = new AddIntPropertyAction("Integer", null);
    }
    if (this.addlong == null) {
      this.addlong = new AddLongPropertyAction("Long", null);
    }
    if (this.addshort == null) {
      this.addshort = new AddShortPropertyAction("Short", null);
    }
    if (this.addbyte == null) {
      this.addbyte = new AddBytePropertyAction("Byte", null);
    }
    if (this.addfloat == null) {
      this.addfloat = new AddFloatPropertyAction("Float", null);
    }
    if (this.adddouble == null) {
      this.adddouble = new AddDoublePropertyAction("Double", null);
    }
    if (this.addbool == null) {
      this.addbool = new AddBooleanPropertyAction("Boolean", null);
    }
    if (this.addstring == null) {
      this.addstring = new AddStringPropertyAction("String", null);
    }
    if (this.m_model.isMapMsg())
    {
      if (this.openMsg == null) {
        this.openMsg = new OpenMsgAction("Open Sub Message...", null);
      }
      if (this.viewBytes == null) {
        this.viewBytes = new ViewBytesAction("View Bytes Field", null);
      }
      if (this.viewBytesText == null) {
        this.viewBytesText = new ViewBytesTextAction("View Bytes Field As Text", null);
      }
      this.addfield = new JMenu("Add Field");
      if (this.remProp == null) {
        this.remProp = new RemovePropertyAction("Remove Field", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.addfield);
      this.addfield.add(this.addstring);
      this.addfield.add(this.addbool);
      this.addfield.add(this.addint);
      this.addfield.add(this.addbyte);
      this.addfield.add(this.addshort);
      this.addfield.add(this.addlong);
      this.addfield.add(this.addfloat);
      this.addfield.add(this.adddouble);
      localJPopupMenu.add(this.remProp);
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(this.openMsg);
      localJPopupMenu.add(this.viewBytes);
      localJPopupMenu.add(this.viewBytesText);
    }
    else
    {
      this.addprop = new JMenu("Add Custom Property");
      JMenu localJMenu1 = new JMenu("Add Tibco Property");
      JMenu localJMenu2 = new JMenu("Add JMS Property");
      if (this.remProp == null) {
        this.remProp = new RemovePropertyAction("Remove Property", null);
      }
      if (this.compProp == null) {
        this.compProp = new AddCompressPropertyAction("JMS_TIBCO_COMPRESS", null);
      }
      if (this.presvProp == null) {
        this.presvProp = new AddPreservePropertyAction("JMS_TIBCO_PRESERVE_UNDELIVERED", null);
      }
      if (this.replytoProp == null) {
        this.replytoProp = new AddJMSReplyToPropertyAction("JMSReplyTo...", null);
      }
      localJPopupMenu.addSeparator();
      localJPopupMenu.add(localJMenu2);
      localJMenu2.add(this.replytoProp);
      localJPopupMenu.add(localJMenu1);
      localJMenu1.add(this.compProp);
      localJMenu1.add(this.presvProp);
      localJPopupMenu.add(this.addprop);
      this.addprop.add(this.addstring);
      this.addprop.add(this.addbool);
      this.addprop.add(this.addint);
      this.addprop.add(this.addbyte);
      this.addprop.add(this.addshort);
      this.addprop.add(this.addlong);
      this.addprop.add(this.addfloat);
      this.addprop.add(this.adddouble);
      localJPopupMenu.add(this.remProp);
    }
    return localJPopupMenu;
  }
  
  public class RemovePropertyAction
    extends AbstractAction
  {
    public RemovePropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.removeRow(PopupMsgPropTableHandler.this.m_row);
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isCellEditable(PopupMsgPropTableHandler.this.m_row, 0);
    }
  }
  
  public class AddJMSReplyToPropertyAction
    extends AbstractAction
  {
    public AddJMSReplyToPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      for (Container localContainer = PopupMsgPropTableHandler.this.m_model.m_table.getParent(); localContainer != null; localContainer = localContainer.getParent()) {
        if ((localContainer instanceof GemsMessageFrame))
        {
          GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker((JFrame)localContainer, ((GemsMessageFrame)localContainer).m_cn);
          if (localGemsDestinationPicker.m_retDest != null) {
            PopupMsgPropTableHandler.this.m_model.addJMSReplyToProperty(localGemsDestinationPicker.m_retDest);
          }
          return;
        }
      }
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddPreservePropertyAction
    extends AbstractAction
  {
    public AddPreservePropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addPreserveProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddCompressPropertyAction
    extends AbstractAction
  {
    public AddCompressPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addCompressProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddPropertyAction
    extends AbstractAction
  {
    public AddPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addIntegerProperty("intf", Integer.valueOf(123));
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddStringPropertyAction
    extends AbstractAction
  {
    public AddStringPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addStringProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddBooleanPropertyAction
    extends AbstractAction
  {
    public AddBooleanPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addBooleanProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddBytePropertyAction
    extends AbstractAction
  {
    public AddBytePropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addByteProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddDoublePropertyAction
    extends AbstractAction
  {
    public AddDoublePropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addDoubleProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddFloatPropertyAction
    extends AbstractAction
  {
    public AddFloatPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addFloatProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddLongPropertyAction
    extends AbstractAction
  {
    public AddLongPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addLongProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddShortPropertyAction
    extends AbstractAction
  {
    public AddShortPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addShortProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class AddIntPropertyAction
    extends AbstractAction
  {
    public AddIntPropertyAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      PopupMsgPropTableHandler.this.m_model.addIntProperty();
    }
    
    public boolean isEnabled()
    {
      return PopupMsgPropTableHandler.this.m_model.isEditable();
    }
  }
  
  public class OpenMsgAction
    extends AbstractAction
  {
    public OpenMsgAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame localGemsMessageFrame = (GemsMessageFrame)SwingUtilities.getWindowAncestor(PopupMsgPropTableHandler.this.m_table);
      localGemsMessageFrame.openSubMapMsg((String)PopupMsgPropTableHandler.this.m_model.getValueAt(PopupMsgPropTableHandler.this.m_row, 0));
    }
    
    public boolean isEnabled()
    {
      String str1 = PopupMsgPropTableHandler.this.m_model.getValueAt(PopupMsgPropTableHandler.this.m_row, 1).toString();
      String str2 = (String)PopupMsgPropTableHandler.this.m_model.getValueAt(PopupMsgPropTableHandler.this.m_row, 0);
      return (str1.startsWith("MapMsg:{")) || (str2.equals("message_bytes"));
    }
  }
  
  public class ViewBytesAction
    extends AbstractAction
  {
    public ViewBytesAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame localGemsMessageFrame = (GemsMessageFrame)SwingUtilities.getWindowAncestor(PopupMsgPropTableHandler.this.m_table);
      localGemsMessageFrame.createBytesFieldUI((String)PopupMsgPropTableHandler.this.m_model.getValueAt(PopupMsgPropTableHandler.this.m_row, 0), false);
    }
    
    public boolean isEnabled()
    {
      String str = PopupMsgPropTableHandler.this.m_model.getValueAt(PopupMsgPropTableHandler.this.m_row, 1).toString();
      return str.startsWith("byte[]");
    }
  }
  
  public class ViewBytesTextAction
    extends AbstractAction
  {
    public ViewBytesTextAction(String paramString, Icon paramIcon)
    {
      super(paramIcon);
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsMessageFrame localGemsMessageFrame = (GemsMessageFrame)SwingUtilities.getWindowAncestor(PopupMsgPropTableHandler.this.m_table);
      localGemsMessageFrame.createBytesFieldUI((String)PopupMsgPropTableHandler.this.m_model.getValueAt(PopupMsgPropTableHandler.this.m_row, 0), true);
    }
    
    public boolean isEnabled()
    {
      String str = PopupMsgPropTableHandler.this.m_model.getValueAt(PopupMsgPropTableHandler.this.m_row, 1).toString();
      return str.startsWith("byte[]");
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\PopupMsgPropTableHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */