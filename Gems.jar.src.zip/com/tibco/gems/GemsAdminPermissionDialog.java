package com.tibco.gems;

import com.tibco.tibjms.admin.AdminACLEntry;
import com.tibco.tibjms.admin.AdminPermissions;
import com.tibco.tibjms.admin.GroupInfo;
import com.tibco.tibjms.admin.PrincipalInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import com.tibco.tibjms.admin.UserInfo;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.PrintStream;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SpringLayout;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.metal.MetalTreeUI;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

public class GemsAdminPermissionDialog
  extends JDialog
{
  protected JTree m_perms;
  protected JCheckBox m_isAdmin;
  protected JComboBox m_principal;
  protected boolean m_cancelled = false;
  protected String m_selected;
  protected CheckNode[] m_px;
  protected GemsConnectionNode m_cn;
  
  public GemsAdminPermissionDialog(Frame paramFrame, GemsConnectionNode paramGemsConnectionNode)
  {
    super(paramFrame, "Set Global Administrator Permissions", true);
    this.m_cn = paramGemsConnectionNode;
    buildFrame(paramFrame);
    updatePermissions(false);
    pack();
    setVisible(true);
  }
  
  public GemsAdminPermissionDialog(Frame paramFrame, GemsConnectionNode paramGemsConnectionNode, String paramString1, String paramString2, String paramString3)
  {
    super(paramFrame, "Set Global Administrator Permissions", true);
    this.m_cn = paramGemsConnectionNode;
    String str = paramString1;
    if (paramString2.equals("User")) {
      str = str + " (user";
    } else {
      str = str + " (group";
    }
    if (paramString3.equals("true")) {
      str = str + ", external)";
    } else {
      str = str + ")";
    }
    buildFrame(paramFrame);
    this.m_principal.setSelectedItem(str);
    this.m_selected = ((String)this.m_principal.getSelectedItem());
    updatePermissions(true);
    pack();
    setVisible(true);
  }
  
  public void buildFrame(Frame paramFrame)
  {
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 1));
    JPanel localJPanel2 = new JPanel(new SpringLayout());
    localJPanel1.add(localJPanel2);
    JLabel localJLabel = new JLabel("Principal:", 11);
    this.m_principal = new JComboBox();
    populatePrincipals();
    this.m_principal.addActionListener(new PrincipalSelected());
    localJPanel2.add(localJLabel);
    localJPanel2.add(this.m_principal);
    SpringUtilities.makeCompactGrid(localJPanel2, 1, 2, 5, 5, 5, 5);
    this.m_px = new CheckNode[] { new CheckNode("Global Permissions:"), new CheckNode("All Admin Permissions:"), new CheckNode("View Permissions:"), new CheckNode("View ACL"), new CheckNode("View Admin ACL"), new CheckNode("View Connection"), new CheckNode("View Destination"), new CheckNode("View Durable"), new CheckNode("View Factory"), new CheckNode("View Group"), new CheckNode("View Message"), new CheckNode("View Route"), new CheckNode("View Server"), new CheckNode("View User"), new CheckNode("Modify Permissions:"), new CheckNode("Change ACL"), new CheckNode("Change Admin ACL"), new CheckNode("Change Connection"), new CheckNode("Change Durable"), new CheckNode("Change Factory"), new CheckNode("Change Group"), new CheckNode("Change Message"), new CheckNode("Change Route"), new CheckNode("Change Server"), new CheckNode("Change User"), new CheckNode("Create Destination"), new CheckNode("Delete Destination"), new CheckNode("Modify Destination"), new CheckNode("Purge Permissions:"), new CheckNode("Purge Destination"), new CheckNode("Purge Durable"), new CheckNode("Shutdown Permissions:"), new CheckNode("Shutdown Server"), new CheckNode("Protect Permissions:"), new CheckNode("Protect1"), new CheckNode("Protect2"), new CheckNode("Protect3"), new CheckNode("Protect4") };
    this.m_perms = new JTree(this.m_px[0]);
    this.m_perms.setUI(new MetalTreeUI());
    this.m_perms.setBorder(new EtchedBorder());
    this.m_perms.setCellRenderer(new CheckRenderer());
    this.m_perms.getSelectionModel().setSelectionMode(1);
    this.m_perms.putClientProperty("JTree.lineStyle", "Angled");
    this.m_perms.addMouseListener(new NodeSelectionListener(this.m_perms));
    int i = 0;
    for (int j = 1; j < this.m_px.length; j++)
    {
      if (((String)this.m_px[j].getUserObject()).equals("Protect Permissions:")) {
        i = 0;
      } else if ((((String)this.m_px[j].getUserObject()).endsWith(":")) && (i > 1)) {
        i = 1;
      }
      this.m_px[i].add(this.m_px[j]);
      if (((String)this.m_px[j].getUserObject()).endsWith(":")) {
        i = j;
      }
    }
    this.m_perms.expandRow(0);
    this.m_perms.expandRow(1);
    JScrollPane localJScrollPane = new JScrollPane(this.m_perms);
    localJScrollPane.setPreferredSize(new Dimension(375, 450));
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setBorder(new TitledBorder("Global Admin Permissions"));
    localJPanel3.setLayout(new BoxLayout(localJPanel3, 1));
    JPanel localJPanel4 = new JPanel(new FlowLayout());
    JButton localJButton1 = new JButton("Apply");
    localJButton1.addActionListener(new ApplyPressed());
    localJPanel4.add(localJButton1);
    JButton localJButton2 = new JButton("Reset");
    localJButton2.addActionListener(new ResetPressed());
    localJPanel4.add(localJButton2);
    localJPanel3.add(localJScrollPane);
    JPanel localJPanel5 = new JPanel(new FlowLayout());
    JButton localJButton3 = new JButton("Permit All");
    JButton localJButton4 = new JButton("Restrict All");
    localJPanel5.add(localJButton3);
    localJPanel5.add(localJButton4);
    localJPanel3.add(localJPanel4);
    localJPanel1.add(localJPanel3);
    JPanel localJPanel6 = new JPanel();
    localJPanel6.setLayout(new FlowLayout());
    JButton localJButton5 = new JButton("OK");
    JButton localJButton6 = new JButton("Cancel");
    localJPanel6.add(localJButton5);
    localJPanel6.add(localJButton6);
    localJButton5.addActionListener(new OkPressed());
    localJButton6.addActionListener(new CancelPressed());
    localJPanel1.add(localJPanel6);
    setContentPane(localJPanel1);
    setLocationRelativeTo(paramFrame);
  }
  
  public String getSelectedProp()
  {
    return this.m_selected;
  }
  
  public void populatePrincipals()
  {
    try
    {
      UserInfo[] arrayOfUserInfo = this.m_cn.m_adminConn.getUsers();
      for (int i = 0; i < arrayOfUserInfo.length; i++) {
        if (!arrayOfUserInfo[i].getName().equals("admin"))
        {
          String str1 = arrayOfUserInfo[i].getName() + " (user";
          if (arrayOfUserInfo[i].isExternal()) {
            str1 = str1 + ", external)";
          } else {
            str1 = str1 + ")";
          }
          this.m_principal.addItem(str1);
        }
      }
      GroupInfo[] arrayOfGroupInfo = this.m_cn.m_adminConn.getGroups();
      for (int j = 0; j < arrayOfGroupInfo.length; j++) {
        if (!arrayOfGroupInfo[j].getName().equals("$admin"))
        {
          String str2 = arrayOfGroupInfo[j].getName() + " (group";
          if (arrayOfGroupInfo[j].isExternal()) {
            str2 = str2 + ", external)";
          } else {
            str2 = str2 + ")";
          }
          this.m_principal.addItem(str2);
        }
      }
      this.m_selected = ((String)this.m_principal.getSelectedItem());
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      System.err.println("JMSException: " + localTibjmsAdminException.getMessage());
    }
  }
  
  public void updatePermissions(boolean paramBoolean)
  {
    if (paramBoolean) {
      return;
    }
    try
    {
      for (int i = 0; i < this.m_px.length; i++) {
        this.m_px[i].setSelected(false);
      }
      Object[] arrayOfObject = this.m_cn.m_adminConn.getPermissions();
      for (int j = 0; j < arrayOfObject.length; j++) {
        if ((arrayOfObject[j] instanceof AdminACLEntry))
        {
          AdminACLEntry localAdminACLEntry = (AdminACLEntry)arrayOfObject[j];
          String str = localAdminACLEntry.getPrincipal().getName();
          if ((localAdminACLEntry.getPrincipal() instanceof UserInfo)) {
            str = str + " (user";
          } else {
            str = str + " (group";
          }
          if (this.m_selected.startsWith(str))
          {
            AdminPermissions localAdminPermissions = localAdminACLEntry.getPermissions();
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(8192L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(8192L))) {
              this.m_px[3].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(67108864L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(67108864L))) {
              this.m_px[4].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(16L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(16L))) {
              this.m_px[5].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(65536L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(65536L))) {
              this.m_px[6].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(64L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(64L))) {
              this.m_px[7].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(1L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(1L))) {
              this.m_px[8].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(2048L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(2048L))) {
              this.m_px[9].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(2097152L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(2097152L))) {
              this.m_px[10].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(4L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(4L))) {
              this.m_px[11].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(8388608L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(8388608L))) {
              this.m_px[12].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(2305843009213693952L)) || (localAdminPermissions.hasPositivePermission(512L)) || (localAdminPermissions.hasPositivePermission(4611686018427387904L))) && (!localAdminPermissions.hasNegativePermission(512L))) {
              this.m_px[13].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(16384L))) && (!localAdminPermissions.hasNegativePermission(16384L))) {
              this.m_px[15].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(134217728L))) && (!localAdminPermissions.hasNegativePermission(134217728L))) {
              this.m_px[16].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(32L))) && (!localAdminPermissions.hasNegativePermission(32L))) {
              this.m_px[17].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(128L))) && (!localAdminPermissions.hasNegativePermission(128L))) {
              this.m_px[18].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(2L))) && (!localAdminPermissions.hasNegativePermission(2L))) {
              this.m_px[19].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(4096L))) && (!localAdminPermissions.hasNegativePermission(4096L))) {
              this.m_px[20].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(4194304L))) && (!localAdminPermissions.hasNegativePermission(4194304L))) {
              this.m_px[21].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(8L))) && (!localAdminPermissions.hasNegativePermission(8L))) {
              this.m_px[22].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(16777216L))) && (!localAdminPermissions.hasNegativePermission(16777216L))) {
              this.m_px[23].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(1024L))) && (!localAdminPermissions.hasNegativePermission(1024L))) {
              this.m_px[24].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(131072L))) && (!localAdminPermissions.hasNegativePermission(131072L))) {
              this.m_px[25].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(262144L))) && (!localAdminPermissions.hasNegativePermission(262144L))) {
              this.m_px[26].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(524288L))) && (!localAdminPermissions.hasNegativePermission(524288L))) {
              this.m_px[27].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(1048576L))) && (!localAdminPermissions.hasNegativePermission(1048576L))) {
              this.m_px[29].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(256L))) && (!localAdminPermissions.hasNegativePermission(256L))) {
              this.m_px[30].setSelected(true);
            }
            if (((localAdminPermissions.hasPositivePermission(4611686018427387904L)) || (localAdminPermissions.hasPositivePermission(33554432L))) && (!localAdminPermissions.hasNegativePermission(33554432L))) {
              this.m_px[32].setSelected(true);
            }
            if ((localAdminPermissions.hasPositivePermission(36028797018963968L)) && (!localAdminPermissions.hasNegativePermission(36028797018963968L))) {
              this.m_px[34].setSelected(true);
            }
            if ((localAdminPermissions.hasPositivePermission(72057594037927936L)) && (!localAdminPermissions.hasNegativePermission(72057594037927936L))) {
              this.m_px[35].setSelected(true);
            }
            if ((localAdminPermissions.hasPositivePermission(144115188075855872L)) && (!localAdminPermissions.hasNegativePermission(144115188075855872L))) {
              this.m_px[36].setSelected(true);
            }
            if ((!localAdminPermissions.hasPositivePermission(288230376151711744L)) || (localAdminPermissions.hasNegativePermission(288230376151711744L))) {
              break;
            }
            this.m_px[37].setSelected(true);
            break;
          }
        }
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this, localTibjmsAdminException.getMessage(), "Error", 1);
    }
    this.m_perms.repaint();
  }
  
  public void setPermissions()
  {
    try
    {
      AdminPermissions localAdminPermissions1 = new AdminPermissions();
      AdminPermissions localAdminPermissions2 = new AdminPermissions();
      if (this.m_px[1].areAllChildrenSelected())
      {
        localAdminPermissions1.setPermission(4611686018427387904L, true);
      }
      else if (!this.m_px[1].isSelected())
      {
        localAdminPermissions2.setPermission(4611686018427387904L, true);
      }
      else
      {
        if (this.m_px[2].areAllChildrenSelected())
        {
          localAdminPermissions1.setPermission(2305843009213693952L, true);
        }
        else if (!this.m_px[2].isSelected())
        {
          localAdminPermissions2.setPermission(2305843009213693952L, true);
        }
        else
        {
          if (this.m_px[3].isSelected()) {
            localAdminPermissions1.setPermission(8192L, true);
          } else {
            localAdminPermissions2.setPermission(8192L, true);
          }
          if (this.m_px[4].isSelected()) {
            localAdminPermissions1.setPermission(67108864L, true);
          } else {
            localAdminPermissions2.setPermission(67108864L, true);
          }
          if (this.m_px[5].isSelected()) {
            localAdminPermissions1.setPermission(16L, true);
          } else {
            localAdminPermissions2.setPermission(16L, true);
          }
          if (this.m_px[6].isSelected()) {
            localAdminPermissions1.setPermission(65536L, true);
          } else {
            localAdminPermissions2.setPermission(65536L, true);
          }
          if (this.m_px[7].isSelected()) {
            localAdminPermissions1.setPermission(64L, true);
          } else {
            localAdminPermissions2.setPermission(64L, true);
          }
          if (this.m_px[8].isSelected()) {
            localAdminPermissions1.setPermission(1L, true);
          } else {
            localAdminPermissions2.setPermission(1L, true);
          }
          if (this.m_px[9].isSelected()) {
            localAdminPermissions1.setPermission(2048L, true);
          } else {
            localAdminPermissions2.setPermission(2048L, true);
          }
          if (this.m_px[10].isSelected()) {
            localAdminPermissions1.setPermission(2097152L, true);
          } else {
            localAdminPermissions2.setPermission(2097152L, true);
          }
          if (this.m_px[11].isSelected()) {
            localAdminPermissions1.setPermission(4L, true);
          } else {
            localAdminPermissions2.setPermission(4L, true);
          }
          if (this.m_px[12].isSelected()) {
            localAdminPermissions1.setPermission(8388608L, true);
          } else {
            localAdminPermissions2.setPermission(8388608L, true);
          }
          if (this.m_px[13].isSelected()) {
            localAdminPermissions1.setPermission(512L, true);
          } else {
            localAdminPermissions2.setPermission(512L, true);
          }
        }
        if (this.m_px[15].isSelected()) {
          localAdminPermissions1.setPermission(16384L, true);
        } else {
          localAdminPermissions2.setPermission(16384L, true);
        }
        if (this.m_px[16].isSelected()) {
          localAdminPermissions1.setPermission(134217728L, true);
        } else {
          localAdminPermissions2.setPermission(134217728L, true);
        }
        if (this.m_px[17].isSelected()) {
          localAdminPermissions1.setPermission(32L, true);
        } else {
          localAdminPermissions2.setPermission(32L, true);
        }
        if (this.m_px[18].isSelected()) {
          localAdminPermissions1.setPermission(128L, true);
        } else {
          localAdminPermissions2.setPermission(128L, true);
        }
        if (this.m_px[19].isSelected()) {
          localAdminPermissions1.setPermission(2L, true);
        } else {
          localAdminPermissions2.setPermission(2L, true);
        }
        if (this.m_px[20].isSelected()) {
          localAdminPermissions1.setPermission(4096L, true);
        } else {
          localAdminPermissions2.setPermission(4096L, true);
        }
        if (this.m_px[21].isSelected()) {
          localAdminPermissions1.setPermission(4194304L, true);
        } else {
          localAdminPermissions2.setPermission(4194304L, true);
        }
        if (this.m_px[22].isSelected()) {
          localAdminPermissions1.setPermission(8L, true);
        } else {
          localAdminPermissions2.setPermission(8L, true);
        }
        if (this.m_px[23].isSelected()) {
          localAdminPermissions1.setPermission(16777216L, true);
        } else {
          localAdminPermissions2.setPermission(16777216L, true);
        }
        if (this.m_px[24].isSelected()) {
          localAdminPermissions1.setPermission(1024L, true);
        } else {
          localAdminPermissions2.setPermission(1024L, true);
        }
        if (this.m_px[25].isSelected()) {
          localAdminPermissions1.setPermission(131072L, true);
        } else {
          localAdminPermissions2.setPermission(131072L, true);
        }
        if (this.m_px[26].isSelected()) {
          localAdminPermissions1.setPermission(262144L, true);
        } else {
          localAdminPermissions2.setPermission(262144L, true);
        }
        if (this.m_px[27].isSelected()) {
          localAdminPermissions1.setPermission(524288L, true);
        } else {
          localAdminPermissions2.setPermission(524288L, true);
        }
        if (this.m_px[29].isSelected()) {
          localAdminPermissions1.setPermission(1048576L, true);
        } else {
          localAdminPermissions2.setPermission(1048576L, true);
        }
        if (this.m_px[30].isSelected()) {
          localAdminPermissions1.setPermission(256L, true);
        } else {
          localAdminPermissions2.setPermission(256L, true);
        }
        if (this.m_px[32].isSelected()) {
          localAdminPermissions1.setPermission(33554432L, true);
        } else {
          localAdminPermissions2.setPermission(33554432L, true);
        }
      }
      if (this.m_px[34].isSelected()) {
        localAdminPermissions1.setPermission(36028797018963968L, true);
      } else {
        localAdminPermissions2.setPermission(36028797018963968L, true);
      }
      if (this.m_px[35].isSelected()) {
        localAdminPermissions1.setPermission(72057594037927936L, true);
      } else {
        localAdminPermissions2.setPermission(72057594037927936L, true);
      }
      if (this.m_px[36].isSelected()) {
        localAdminPermissions1.setPermission(144115188075855872L, true);
      } else {
        localAdminPermissions2.setPermission(144115188075855872L, true);
      }
      if (this.m_px[37].isSelected()) {
        localAdminPermissions1.setPermission(288230376151711744L, true);
      } else {
        localAdminPermissions2.setPermission(288230376151711744L, true);
      }
      int i;
      Object localObject;
      if ((i = this.m_selected.lastIndexOf(" (user")) > 0)
      {
        localObject = new UserInfo(this.m_selected.substring(0, i));
      }
      else
      {
        i = this.m_selected.lastIndexOf(" (group");
        localObject = new GroupInfo(this.m_selected.substring(0, i));
      }
      if (!localAdminPermissions2.isEmpty()) {
        this.m_cn.m_adminConn.revoke(new AdminACLEntry((PrincipalInfo)localObject, localAdminPermissions2));
      }
      if (!localAdminPermissions1.isEmpty()) {
        this.m_cn.m_adminConn.grant(new AdminACLEntry((PrincipalInfo)localObject, localAdminPermissions1));
      }
      if (localAdminPermissions2.hasPositivePermission(4611686018427387904L)) {
        updatePermissions(false);
      }
      Gems.getGems().scheduleRepaint();
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(this, localTibjmsAdminException.getMessage(), "Error", 1);
      updatePermissions(false);
    }
  }
  
  class NodeSelectionListener
    extends MouseAdapter
  {
    JTree tree;
    
    NodeSelectionListener(JTree paramJTree)
    {
      this.tree = paramJTree;
    }
    
    public void mouseClicked(MouseEvent paramMouseEvent)
    {
      int i = paramMouseEvent.getX();
      int j = paramMouseEvent.getY();
      int k = this.tree.getRowForLocation(i, j);
      TreePath localTreePath = this.tree.getPathForRow(k);
      if (localTreePath != null)
      {
        CheckNode localCheckNode = (CheckNode)localTreePath.getLastPathComponent();
        boolean bool = !localCheckNode.isSelected();
        localCheckNode.setSelected(bool);
        if (localCheckNode.getSelectionMode() == 4) {
          this.tree.expandPath(localTreePath);
        }
        ((DefaultTreeModel)this.tree.getModel()).nodeChanged(localCheckNode);
        if (k >= 0)
        {
          this.tree.revalidate();
          this.tree.repaint();
        }
      }
    }
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsAdminPermissionDialog.this.m_cancelled = true;
      GemsAdminPermissionDialog.this.dispose();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsAdminPermissionDialog.this.setPermissions();
      GemsAdminPermissionDialog.this.dispose();
    }
  }
  
  class ApplyPressed
    implements ActionListener
  {
    ApplyPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsAdminPermissionDialog.this.setPermissions();
    }
  }
  
  class PrincipalSelected
    implements ActionListener
  {
    PrincipalSelected() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsAdminPermissionDialog.this.m_selected = ((String)GemsAdminPermissionDialog.this.m_principal.getSelectedItem());
      GemsAdminPermissionDialog.this.updatePermissions(false);
    }
  }
  
  class ResetPressed
    implements ActionListener
  {
    ResetPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsAdminPermissionDialog.this.updatePermissions(false);
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsAdminPermissionDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */