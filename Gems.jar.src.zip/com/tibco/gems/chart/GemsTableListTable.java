package com.tibco.gems.chart;

import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.PrintStream;
import javax.swing.AbstractAction;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableColumn;

public abstract class GemsTableListTable
  extends JTable
{
  final int m_nCols = 4;
  GemsTableListModel m_dataModel;
  
  public void setColumns()
  {
    String[] arrayOfString = this.m_dataModel.getColumnHeadings();
    int[] arrayOfInt = this.m_dataModel.getColumnSizes();
    int i = arrayOfString.length <= getColumnCount() ? arrayOfInt.length : getColumnCount();
    for (int j = 0; j < i; j++)
    {
      TableColumn localTableColumn = new TableColumn(j);
      localTableColumn.setHeaderValue(arrayOfString[j]);
      addColumn(localTableColumn);
    }
  }
  
  public GemsTableListTable(GemsTableListModel paramGemsTableListModel)
  {
    super(paramGemsTableListModel);
    this.m_dataModel = paramGemsTableListModel;
    this.m_dataModel.setTable(this);
    ListSelectionModel localListSelectionModel = getSelectionModel();
    localListSelectionModel.addListSelectionListener(new TableListTableSelectionListener());
    setRequestFocusEnabled(true);
    KeyStroke localKeyStroke = KeyStroke.getKeyStroke(10, 0);
    registerKeyboardAction(new TableListTableAction(), localKeyStroke, 2);
    addMouseListener(new TableListTableMouseListener());
    setRowSelectionAllowed(true);
    setColumnSelectionAllowed(false);
    setAutoResizeMode(0);
    this.m_dataModel.setColumnHeadings();
    this.m_dataModel.setColumnSizes();
  }
  
  public GemsTableListTable(GemsTableListModelBase paramGemsTableListModelBase)
  {
    this(new GemsTableListModel(paramGemsTableListModelBase));
  }
  
  public abstract void onMouseClick();
  
  public abstract void onDoubleClick();
  
  public abstract void onSelectionChanged();
  
  private class TableListTableMouseListener
    extends MouseAdapter
  {
    public void mousePressed(MouseEvent paramMouseEvent)
    {
      GemsTableListTable.this.onMouseClick();
      if (paramMouseEvent.getClickCount() == 2) {
        GemsTableListTable.this.onDoubleClick();
      }
    }
    
    TableListTableMouseListener() {}
  }
  
  private class TableListTableAction
    extends AbstractAction
  {
    public boolean isEnabled()
    {
      return true;
    }
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      System.out.println("RowSelectionAction:actionPerformed - " + paramActionEvent);
      GemsTableListTable.this.onDoubleClick();
    }
    
    TableListTableAction() {}
  }
  
  private class TableListTableSelectionListener
    implements ListSelectionListener
  {
    public void valueChanged(ListSelectionEvent paramListSelectionEvent)
    {
      GemsTableListTable.this.onSelectionChanged();
    }
    
    TableListTableSelectionListener() {}
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsTableListTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */