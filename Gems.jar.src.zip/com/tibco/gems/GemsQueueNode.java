package com.tibco.gems;

import com.tibco.tibjms.admin.QueueInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class GemsQueueNode
  extends IconNode
{
  static Hashtable props = null;
  
  public static synchronized void init()
  {
    if (props == null) {
      try
      {
        props = new Hashtable();
        props.put("isGlobal", new GemsProperty("Global", Boolean.TYPE, "<html>Enables or disables global routing of messages<br>on this destination</html>"));
        props.put("isFailsafe", new GemsProperty("Failsafe", Boolean.TYPE, "<html>Whether the server writes persistent messages<br>to disk synchronously (pre EMS5.0 only)</html>"));
        props.put("isSecure", new GemsProperty("Secure", Boolean.TYPE, "<html>Whether the server checks user permissions<br> on the destination</html>"));
        props.put("FlowControl", new GemsProperty("FlowControlMaxBytes", Long.TYPE, "<html>The target maximum size (bytes) the server<br>can use to store pending messages</html>"));
        props.put("MaxBytes", new GemsProperty("MaxBytes", Long.TYPE, "<html>The maximum size (in bytes) that the destination<br>can store, summed over all messages</html>"));
        props.put("isSenderName", new GemsProperty("SenderName", Boolean.TYPE, "<html>Whether the server may include the senderís<br>username for messages sent to this destination</html>"));
        props.put("isSenderNameEnforced", new GemsProperty("SenderNameEnforced", Boolean.TYPE, "<html>Whether the server must include the senderís<br>username for messages sent to this destination</html>"));
        props.put("MsgTrace", new GemsProperty("MsgTrace", Byte.TYPE, "<html>Set the level of message tracing<br>0 = none, 1 = basic, 3 = detail</html>"));
        props.put("Prefetch", new GemsProperty("Prefetch", Integer.TYPE, "<html>Number of messages prefetched by consumers<br>of this destination (0 = default, -1 = none)</html>"));
        props.put("MaxRedelivery", new GemsProperty("MaxRedelivery", Integer.TYPE, "<html>The number of attempts the server should make<br>to redeliver a message (0 = no limit)</html>"));
        props.put("isExclusive", new GemsProperty("Exclusive", Boolean.TYPE, "<html>Whether the server sends all messages on<br>the queue to one consumer</html>"));
        props.put("ExpiryOverride", new GemsProperty("ExpiryOverride", Long.TYPE, "<html>The expiry override for this destination<br>in millisecs (0 = disable override)</html>"));
        props.put("OverflowPolicy", new GemsProperty("OverflowPolicy", Integer.TYPE, "<html>Behaviour when message capacity is exceeded<br>0 = default, 1 = discardOld, 2 = rejectIncoming</html>"));
        props.put("MaxMsgs", new GemsProperty("MaxMsgs", Long.TYPE, "<html>The maximum number of messages that can be<br>waiting on a destination</html>"));
        props.put("Store", new GemsProperty("Store", Class.forName("java.lang.String"), "<html>Where messages on this destination are stored<br>First stop the flow of incoming messages!</html>"));
        props.put("RedeliveryDelay", new GemsProperty("RedeliveryDelay", Long.TYPE, "<html>The interval (msecs) before returning an unacknowledged<br>message to the queue. 0 = no redelivery delay</html>"));
      }
      catch (Throwable localThrowable)
      {
        System.err.println(localThrowable);
      }
    }
  }
  
  public GemsQueueNode(String paramString)
  {
    super(paramString, false);
    init();
    if (Gems.getGems().m_useMetalIcons) {
      setIconName("queue");
    }
  }
  
  public GemsQueueNode(String paramString, boolean paramBoolean)
  {
    super(paramString, false);
    init();
    if (Gems.getGems().m_useMetalIcons) {
      if (paramBoolean) {
        setIconName("routedqueue");
      } else {
        setIconName("queue");
      }
    }
  }
  
  public boolean hasMessages()
  {
    return false;
  }
  
  public Vector getMessages()
  {
    return null;
  }
  
  public static void setProperty(JFrame paramJFrame, GemsConnectionNode paramGemsConnectionNode, String paramString1, String paramString2)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    init();
    try
    {
      GemsProperty localGemsProperty = null;
      String str1 = null;
      QueueInfo localQueueInfo = paramGemsConnectionNode.m_adminConn.getQueue(paramString2);
      if (localQueueInfo == null) {
        return;
      }
      if (paramString1 != null)
      {
        localGemsProperty = (GemsProperty)props.get(paramString1);
        if (localGemsProperty != null) {
          str1 = localGemsProperty.getValue(localQueueInfo);
        }
      }
      GemsSetPropDialog localGemsSetPropDialog = new GemsSetPropDialog(paramJFrame, "Set Property on Queue " + paramString2);
      String str2 = localGemsSetPropDialog.getValue(props, paramString1, str1);
      if (str2 != null)
      {
        localGemsProperty = (GemsProperty)props.get(localGemsSetPropDialog.getSelectedProp());
        localGemsProperty.setValue(localQueueInfo, str2);
        paramGemsConnectionNode.m_adminConn.updateQueue(localQueueInfo);
        Gems.getGems().scheduleRepaint();
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(paramJFrame, localTibjmsAdminException.getMessage(), "Set Queue Property", 0);
      return;
    }
  }
  
  public void setProperty(GemsConnectionNode paramGemsConnectionNode, String paramString)
  {
    if ((paramGemsConnectionNode == null) || (paramGemsConnectionNode.m_adminConn == null)) {
      return;
    }
    try
    {
      GemsProperty localGemsProperty = null;
      String str1 = null;
      QueueInfo localQueueInfo = paramGemsConnectionNode.m_adminConn.getQueue((String)getUserObject());
      if (localQueueInfo == null) {
        return;
      }
      if (paramString != null)
      {
        localGemsProperty = (GemsProperty)props.get(paramString);
        if (localGemsProperty != null) {
          str1 = localGemsProperty.getValue(localQueueInfo);
        }
      }
      GemsSetPropDialog localGemsSetPropDialog = new GemsSetPropDialog(Gems.getGems().m_frame, "Set Property on Queue " + (String)getUserObject());
      String str2 = localGemsSetPropDialog.getValue(props, paramString, str1);
      if (str2 != null)
      {
        localGemsProperty = (GemsProperty)props.get(localGemsSetPropDialog.getSelectedProp());
        localGemsProperty.setValue(localQueueInfo, str2);
        paramGemsConnectionNode.m_adminConn.updateQueue(localQueueInfo);
        Gems.getGems().scheduleRepaint();
      }
    }
    catch (TibjmsAdminException localTibjmsAdminException)
    {
      JOptionPane.showMessageDialog(Gems.getGems().m_frame, localTibjmsAdminException.getMessage(), "Set Queue Property", 0);
      return;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsQueueNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */