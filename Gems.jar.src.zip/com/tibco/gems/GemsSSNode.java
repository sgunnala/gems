package com.tibco.gems;

import com.tibco.tibjms.TibjmsQueueConnectionFactory;
import java.io.PrintStream;
import java.util.Hashtable;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;

public class GemsSSNode
  extends IconNode
{
  static Hashtable props = null;
  public String m_name = null;
  public String m_queueName = null;
  public String m_ver = null;
  QueueConnection m_connection = null;
  public QueueSession m_session = null;
  Queue m_queue = null;
  Queue m_replyQueue = null;
  QueueSender m_sender = null;
  QueueReceiver m_receiver = null;
  int m_seqno = 0;
  long TIMEOUT = Gems.getGems().getSSTimeout();
  GemsConnectionNode m_cn = null;
  
  public synchronized void init(GemsConnectionNode paramGemsConnectionNode)
  {
    try
    {
      TibjmsQueueConnectionFactory localTibjmsQueueConnectionFactory = new TibjmsQueueConnectionFactory(paramGemsConnectionNode.m_url, null, paramGemsConnectionNode.m_sslParams);
      this.m_connection = localTibjmsQueueConnectionFactory.createQueueConnection(paramGemsConnectionNode.m_user, paramGemsConnectionNode.m_password);
      this.m_session = this.m_connection.createQueueSession(false, 22);
      this.m_queue = this.m_session.createQueue(this.m_queueName);
      this.m_sender = this.m_session.createSender(this.m_queue);
      this.m_sender.setDeliveryMode(22);
      this.m_replyQueue = this.m_session.createTemporaryQueue();
      this.m_receiver = this.m_session.createReceiver(this.m_replyQueue);
      this.m_connection.start();
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      this.m_receiver = null;
      this.m_sender = null;
      this.m_session = null;
      this.m_connection = null;
      return;
    }
  }
  
  public synchronized void destroy()
  {
    try
    {
      if (this.m_receiver != null) {
        this.m_receiver.close();
      }
      if (this.m_sender != null) {
        this.m_sender.close();
      }
      if (this.m_session != null) {
        this.m_session.close();
      }
      if (this.m_connection != null) {
        this.m_connection.close();
      }
      this.m_receiver = null;
      this.m_sender = null;
      this.m_session = null;
      this.m_connection = null;
    }
    catch (JMSException localJMSException)
    {
      this.m_receiver = null;
      this.m_sender = null;
      this.m_session = null;
      this.m_connection = null;
      return;
    }
  }
  
  public GemsSSNode(String paramString1, String paramString2, String paramString3, GemsConnectionNode paramGemsConnectionNode)
  {
    super(paramString1, true);
    this.m_name = paramString1;
    this.m_queueName = paramString2;
    this.m_cn = paramGemsConnectionNode;
    this.m_ver = paramString3;
    if (Gems.getGems().m_useMetalIcons) {
      setIconName("substation");
    }
  }
  
  public synchronized String RunCommand(String paramString)
  {
    if (this.m_connection == null) {
      init(this.m_cn);
    }
    if (this.m_connection == null) {
      return "Error: EMS server connection error";
    }
    try
    {
      MapMessage localMapMessage1 = this.m_session.createMapMessage();
      String str = paramString;
      localMapMessage1.setString("SXS-COMMAND", str);
      localMapMessage1.setJMSReplyTo(this.m_replyQueue);
      int i = ++this.m_seqno;
      localMapMessage1.setJMSCorrelationID(String.valueOf(i));
      this.m_sender.send(localMapMessage1, 22, 4, 4L * this.TIMEOUT);
      MapMessage localMapMessage2 = receiveReply(i);
      if (localMapMessage2 != null)
      {
        Gems.debug("SubStation returned: " + localMapMessage2.getString("SXS-RESULT"));
        return localMapMessage2.getString("SXS-RESULT");
      }
      System.err.println("Error: Timeout waiting for SubStation response");
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      destroy();
    }
    return "Error: Timeout waiting for SubStation reply (timeout value may be set in gems.props file)";
  }
  
  synchronized MapMessage receiveReply(int paramInt)
    throws JMSException
  {
    MapMessage localMapMessage = null;
    long l1 = this.TIMEOUT;
    do
    {
      long l2 = System.currentTimeMillis();
      localMapMessage = (MapMessage)this.m_receiver.receive(l1);
      if (localMapMessage == null) {
        return localMapMessage;
      }
      String str = localMapMessage.getJMSCorrelationID();
      try
      {
        if ((str != null) && (Integer.valueOf(str).intValue() == paramInt)) {
          break;
        }
      }
      catch (NumberFormatException localNumberFormatException)
      {
        System.err.println("Error: " + localNumberFormatException.getMessage());
      }
      long l3 = System.currentTimeMillis();
      long l4 = l3 - l2;
      if (l4 > 200L) {
        l1 -= l4;
      }
    } while (l1 > 10L);
    return localMapMessage;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsSSNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */