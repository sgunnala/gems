package com.tibco.gems;

import java.awt.Component;
import java.awt.Container;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.EventObject;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.StreamMessage;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.CellEditorListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;

public class GemsMsgPropTableModel
  extends DefaultTableModel
  implements GetPopupHandler
{
  JTable m_table;
  boolean m_isEditable;
  boolean m_isMapMsg = false;
  boolean m_hasSubMapMsg = false;
  int s_headerRows = 6;
  PopupHandler m_popup = null;
  SimpleDateFormat dateFormatMillis = new SimpleDateFormat("EEE MMM dd HH:mm:ss SSS zzz yyyy");
  
  public GemsMsgPropTableModel(boolean paramBoolean)
  {
    this.m_isEditable = paramBoolean;
    if (!Gems.getGems().getShowExtendedProperties()) {
      this.s_headerRows -= 3;
    }
  }
  
  public GemsMsgPropTableModel(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.m_isEditable = paramBoolean1;
    this.s_headerRows = 0;
    this.m_isMapMsg = paramBoolean2;
  }
  
  public PopupHandler getPopupHandler()
  {
    if (this.m_popup == null) {
      this.m_popup = new PopupMsgPropTableHandler(this.m_table);
    }
    return this.m_popup;
  }
  
  public int getHeaderRows()
  {
    return this.s_headerRows;
  }
  
  public boolean isCellEditable(int paramInt1, int paramInt2)
  {
    if (this.m_isEditable) {
      return (paramInt1 >= this.s_headerRows) || (paramInt2 != 0);
    }
    return false;
  }
  
  public boolean hasSubMapMsg()
  {
    return this.m_hasSubMapMsg;
  }
  
  public boolean isMapMsg()
  {
    return this.m_isMapMsg;
  }
  
  public boolean isEditable()
  {
    return this.m_isEditable;
  }
  
  public void populateMapMsg(MapMessage paramMapMessage)
  {
    this.m_isMapMsg = true;
    setRowCount(0);
    setColumnCount(0);
    if (paramMapMessage == null) {
      return;
    }
    addColumn("Field");
    addColumn("Value");
    try
    {
      Enumeration localEnumeration = paramMapMessage.getMapNames();
      while (localEnumeration.hasMoreElements())
      {
        String str = (String)localEnumeration.nextElement();
        String[] arrayOfString = { str, toTypedString(this, paramMapMessage.getObject(str)) };
        addRow(arrayOfString);
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  static int getTypeFromString(String paramString)
  {
    if (paramString.equals("String")) {
      return 9;
    }
    if (paramString.equals("Integer")) {
      return 5;
    }
    if (paramString.equals("Long")) {
      return 6;
    }
    if (paramString.equals("Boolean")) {
      return 1;
    }
    if (paramString.equals("Short")) {
      return 4;
    }
    if (paramString.equals("Byte")) {
      return 2;
    }
    if (paramString.equals("Double")) {
      return 8;
    }
    if (paramString.equals("Float")) {
      return 7;
    }
    if (paramString.equals("byte[]")) {
      return 10;
    }
    if (paramString.equals("MapMag")) {
      return 11;
    }
    if (paramString.equals("StreamMsg")) {
      return 18;
    }
    if (paramString.equals("short-array")) {
      return 12;
    }
    if (paramString.equals("int-array")) {
      return 13;
    }
    if (paramString.equals("long-array")) {
      return 14;
    }
    if (paramString.equals("float-array")) {
      return 15;
    }
    if (paramString.equals("double-array")) {
      return 16;
    }
    return 255;
  }
  
  static int getPropType(Object paramObject)
  {
    if (paramObject == null) {
      return 0;
    }
    if ((paramObject instanceof String)) {
      return 9;
    }
    if ((paramObject instanceof Integer)) {
      return 5;
    }
    if ((paramObject instanceof Long)) {
      return 6;
    }
    if ((paramObject instanceof Boolean)) {
      return 1;
    }
    if ((paramObject instanceof Short)) {
      return 4;
    }
    if ((paramObject instanceof Byte)) {
      return 2;
    }
    if ((paramObject instanceof Double)) {
      return 8;
    }
    return !(paramObject instanceof Float) ? 255 : 7;
  }
  
  static int getFieldType(Object paramObject)
  {
    if (paramObject == null) {
      return 0;
    }
    if ((paramObject instanceof String)) {
      return 9;
    }
    if ((paramObject instanceof Integer)) {
      return 5;
    }
    if ((paramObject instanceof Long)) {
      return 6;
    }
    if ((paramObject instanceof Boolean)) {
      return 1;
    }
    if ((paramObject instanceof Short)) {
      return 4;
    }
    if ((paramObject instanceof Double)) {
      return 8;
    }
    if ((paramObject instanceof byte[])) {
      return 10;
    }
    if ((paramObject instanceof Byte)) {
      return 2;
    }
    if ((paramObject instanceof Float)) {
      return 7;
    }
    return !(paramObject instanceof Character) ? 255 : 3;
  }
  
  static int getExtendedType(Object paramObject)
  {
    if (paramObject == null) {
      return 255;
    }
    if ((paramObject instanceof MapMessage)) {
      return 11;
    }
    if ((paramObject instanceof StreamMessage)) {
      return 18;
    }
    if ((paramObject instanceof short[])) {
      return 12;
    }
    if ((paramObject instanceof int[])) {
      return 13;
    }
    if ((paramObject instanceof long[])) {
      return 14;
    }
    if ((paramObject instanceof float[])) {
      return 15;
    }
    return !(paramObject instanceof double[]) ? 255 : 16;
  }
  
  static String getTypeName(Object paramObject)
  {
    if (paramObject == null) {
      return "null";
    }
    if ((paramObject instanceof byte[])) {
      return "byte[]";
    }
    String str = paramObject.getClass().getName();
    if (str.length() < 1) {
      return str;
    }
    int i = str.lastIndexOf('.', str.length() - 1);
    if ((i >= 0) && (i < str.length() - 1)) {
      str = str.substring(i + 1, str.length());
    }
    return str;
  }
  
  static String toTypedString(GemsMsgPropTableModel paramGemsMsgPropTableModel, Object paramObject)
  {
    if (paramObject == null) {
      return null;
    }
    String str1 = "";
    String str2 = "";
    int i = getFieldType(paramObject);
    if (i != 255) {
      str2 = getTypeName(paramObject);
    } else {
      i = getExtendedType(paramObject);
    }
    switch (i)
    {
    case 10: 
      byte[] arrayOfByte = (byte[])(byte[])paramObject;
      String str3 = String.valueOf(arrayOfByte.length) + " bytes";
      return str2 + ":" + str3;
    case 11: 
      if (paramGemsMsgPropTableModel != null) {
        paramGemsMsgPropTableModel.m_hasSubMapMsg = true;
      }
      return "MapMsg:{" + ((MapMessage)paramObject).toString() + " }";
    case 18: 
      return "StreamMsg:{" + ((StreamMessage)paramObject).toString() + " }";
    case 12: 
      return "short-array:[" + ((short[])(short[])paramObject).length + " elements]";
    case 13: 
      return "int-array:[" + ((int[])(int[])paramObject).length + " elements]";
    case 14: 
      return "long-array:[" + ((long[])(long[])paramObject).length + " elements]";
    case 15: 
      return "float-array:[" + ((float[])(float[])paramObject).length + " elements]";
    case 16: 
      return "double-array:[" + ((double[])(double[])paramObject).length + " elements]";
    case 255: 
      return "<unknown type>";
    }
    return str2 + ":" + paramObject.toString();
  }
  
  public void populatePropertyInfo(Message paramMessage)
  {
    setRowCount(0);
    setColumnCount(0);
    if (paramMessage == null) {
      return;
    }
    addColumn("Property");
    addColumn("Value");
    try
    {
      Date localDate = new Date();
      String str1 = paramMessage.getJMSMessageID();
      if ((str1 != null) && (str1.length() > 0))
      {
        localObject = new String[] { "JMSMessageID", str1 };
        addRow((Object[])localObject);
      }
      localDate.setTime(paramMessage.getJMSTimestamp());
      Gems.debug("JMSTimestamp: " + paramMessage.getJMSTimestamp());
      Object localObject = { "JMSTimestamp", this.dateFormatMillis.format(localDate).toString() };
      addRow((Object[])localObject);
      String str2 = paramMessage.getJMSDeliveryMode() == 1 ? "NON_PERSISTENT" : paramMessage.getJMSDeliveryMode() == 2 ? "PERSISTENT" : "RELIABLE";
      localObject = new String[] { "JMSDeliveryMode", str2 };
      addRow((Object[])localObject);
      Destination localDestination = paramMessage.getJMSDestination();
      if (localDestination != null)
      {
        localObject = new String[] { "JMSDestination", localDestination.toString() };
        addRow((Object[])localObject);
      }
      String str3 = paramMessage.getJMSCorrelationID();
      if ((str3 != null) && (str3.length() > 0))
      {
        localObject = new String[] { "JMSCorrelationID", str3 };
        addRow((Object[])localObject);
      }
      String str4 = paramMessage.getJMSType();
      if ((str4 != null) && (str4.length() > 0))
      {
        localObject = new String[] { "JMSType", str4 };
        addRow((Object[])localObject);
      }
      if (Gems.getGems().getShowExtendedProperties())
      {
        if (paramMessage.getJMSExpiration() != 0L)
        {
          localDate.setTime(paramMessage.getJMSExpiration());
          localObject = new String[] { "JMSExpiration", this.dateFormatMillis.format(localDate).toString() };
          addRow((Object[])localObject);
        }
        localObject = new String[] { "JMSPriority", String.valueOf(paramMessage.getJMSPriority()) };
        addRow((Object[])localObject);
        if (paramMessage.getJMSReplyTo() != null)
        {
          localObject = new String[] { "JMSReplyTo", paramMessage.getJMSReplyTo().toString() };
          addRow((Object[])localObject);
        }
      }
      Enumeration localEnumeration = paramMessage.getPropertyNames();
      while (localEnumeration.hasMoreElements())
      {
        String str5 = (String)localEnumeration.nextElement();
        if (str5.equals("msg_timestamp"))
        {
          localDate.setTime(paramMessage.getLongProperty("msg_timestamp"));
          localObject = new String[] { "msg_timestamp", this.dateFormatMillis.format(localDate).toString() };
          Gems.debug("msg_timestamp: " + paramMessage.getLongProperty("msg_timestamp"));
        }
        else
        {
          localObject = new Object[] { str5, paramMessage.getObjectProperty(str5) };
        }
        addRow((Object[])localObject);
      }
    }
    catch (JMSException localJMSException)
    {
      System.err.println("JMSException: " + localJMSException.getMessage());
      return;
    }
  }
  
  public void populateEmptyPropertyInfo(int paramInt)
  {
    setRowCount(0);
    setColumnCount(0);
    if (this.m_isMapMsg) {
      addColumn("Field");
    } else {
      addColumn("Property");
    }
    addColumn("Value");
    TableColumn localTableColumn = this.m_table.getColumn("Value");
    localTableColumn.setCellEditor(new MultiEditor());
    localTableColumn.setCellRenderer(new MultiRenderer());
    for (int i = 0; i < paramInt; i++)
    {
      String[] arrayOfString = { new String(), new String() };
      addRow(arrayOfString);
    }
  }
  
  public void emptyEditorPropertyInfo(String paramString)
  {
    setRowCount(0);
    setColumnCount(0);
    addColumn("Property");
    addColumn("Value");
    TableColumn localTableColumn = this.m_table.getColumn("Value");
    localTableColumn.setCellEditor(new MultiEditor());
    localTableColumn.setCellRenderer(new MultiRenderer());
    Object localObject = { "JMSDeliveryMode", DELMODE.NON_PERSISTENT };
    addRow((Object[])localObject);
    localObject = new String[] { "JMSType", "" };
    addRow((Object[])localObject);
    if (Gems.getGems().getShowExtendedProperties())
    {
      localObject = new String[] { "JMSExpiration", "0" };
      addRow((Object[])localObject);
      localObject = new String[] { "JMSPriority", "4" };
      addRow((Object[])localObject);
    }
  }
  
  public void emptyPropertyInfo(String paramString)
  {
    setRowCount(0);
    setColumnCount(0);
    addColumn("Property");
    addColumn("Value");
    TableColumn localTableColumn = this.m_table.getColumn("Value");
    localTableColumn.setCellEditor(new MultiEditor());
    localTableColumn.setCellRenderer(new MultiRenderer());
    Object localObject = { "JMSDeliveryMode", DELMODE.NON_PERSISTENT };
    addRow((Object[])localObject);
    localObject = new String[] { "JMSDestination", paramString };
    addRow((Object[])localObject);
    localObject = new String[] { "JMSCorrelationID", "" };
    addRow((Object[])localObject);
    localObject = new String[] { "JMSType", "" };
    addRow((Object[])localObject);
    if (Gems.getGems().getShowExtendedProperties())
    {
      localObject = new String[] { "JMSExpiration", "0" };
      addRow((Object[])localObject);
      localObject = new String[] { "JMSPriority", "4" };
      addRow((Object[])localObject);
    }
  }
  
  String getJMSCorrelationID()
  {
    for (int i = 0; i < getRowCount(); i++) {
      if (((String)getValueAt(i, 0)).equals("JMSCorrelationID")) {
        return (String)getValueAt(i, 1);
      }
    }
    return "";
  }
  
  int getJMSDeliveryMode()
  {
    for (int i = 0; i < getRowCount(); i++) {
      if (((String)getValueAt(i, 0)).equals("JMSDeliveryMode"))
      {
        Object localObject = getValueAt(i, 1);
        if ((localObject instanceof DELMODE))
        {
          if ((DELMODE)localObject == DELMODE.PERSISTENT) {
            return 2;
          }
          if ((DELMODE)localObject == DELMODE.RELIABLE) {
            return 22;
          }
        }
      }
    }
    return 1;
  }
  
  String getJMSDestination()
  {
    for (int i = 0; i < getRowCount(); i++) {
      if (((String)getValueAt(i, 0)).equals("JMSDestination")) {
        return (String)getValueAt(i, 1);
      }
    }
    return "";
  }
  
  int getJMSExpiration()
  {
    for (int i = 0; i < getRowCount(); i++) {
      if (((String)getValueAt(i, 0)).equals("JMSExpiration")) {
        return Integer.parseInt((String)getValueAt(i, 1));
      }
    }
    return 0;
  }
  
  int getJMSPriority()
  {
    for (int i = 0; i < getRowCount(); i++) {
      if (((String)getValueAt(i, 0)).equals("JMSPriority")) {
        return Integer.parseInt((String)getValueAt(i, 1));
      }
    }
    return 4;
  }
  
  GemsDestination getJMSReplyTo()
  {
    int i = 0;
    for (i = 0; i < this.m_table.getRowCount(); i++)
    {
      String str = (String)getValueAt(i, 0);
      if (str.equals("JMSReplyTo")) {
        return (GemsDestination)getValueAt(i, 1);
      }
      if (!str.startsWith("JMS")) {
        break;
      }
    }
    return null;
  }
  
  String getJMSType()
  {
    if (Gems.getGems().getShowExtendedProperties()) {
      return (String)getValueAt(3, 1);
    }
    return "";
  }
  
  public void addPropertyInfo(String paramString)
  {
    int i = paramString.indexOf('=');
    if (i > 0)
    {
      String str = paramString.substring(i + 1);
      int j = str.indexOf(':');
      try
      {
        Object localObject;
        if (j > 0)
        {
          switch (getTypeFromString(str.substring(0, j)))
          {
          case 9: 
            localObject = new Object[] { paramString.substring(0, i), str.substring(j + 1) };
            addRow((Object[])localObject);
            return;
          case 5: 
            localObject = new Object[] { paramString.substring(0, i), new Integer(str.substring(j + 1)) };
            addRow((Object[])localObject);
            return;
          case 6: 
            localObject = new Object[] { paramString.substring(0, i), new Long(str.substring(j + 1)) };
            addRow((Object[])localObject);
            return;
          case 1: 
            localObject = new Object[] { paramString.substring(0, i), new Boolean(str.substring(j + 1)) };
            addRow((Object[])localObject);
            return;
          case 4: 
            localObject = new Object[] { paramString.substring(0, i), new Short(str.substring(j + 1)) };
            addRow((Object[])localObject);
            return;
          case 2: 
            localObject = new Object[] { paramString.substring(0, i), new Byte(str.substring(j + 1)) };
            addRow((Object[])localObject);
            return;
          case 8: 
            localObject = new Object[] { paramString.substring(0, i), new Double(str.substring(j + 1)) };
            addRow((Object[])localObject);
            return;
          case 7: 
            localObject = new Object[] { paramString.substring(0, i), new Float(str.substring(j + 1)) };
            addRow((Object[])localObject);
            return;
          case 10: 
          case 11: 
          case 12: 
          case 13: 
          case 14: 
          case 15: 
          case 16: 
          case 18: 
          case 255: 
            localObject = new Object[] { paramString.substring(0, i), str };
            addRow((Object[])localObject);
            return;
          }
        }
        else
        {
          localObject = new String[] { paramString.substring(0, i), str };
          addRow((Object[])localObject);
        }
      }
      catch (Exception localException)
      {
        System.err.println("Exception: " + localException.getMessage());
      }
    }
  }
  
  public void addProperty()
  {
    String[] arrayOfString = { new String(), new String() };
    addRow(arrayOfString);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
    this.m_table.editCellAt(this.m_table.getRowCount() - 1, 0);
  }
  
  public void addJMSReplyToProperty(GemsDestination paramGemsDestination)
  {
    int i = 0;
    for (i = 0; i < this.m_table.getRowCount(); i++)
    {
      String str = (String)getValueAt(i, 0);
      if (str.equals("JMSReplyTo")) {
        return;
      }
      if ((!str.startsWith("JMS")) || (str.startsWith("JMS_"))) {
        break;
      }
    }
    Object[] arrayOfObject = { "JMSReplyTo", paramGemsDestination };
    insertRow(i, arrayOfObject);
  }
  
  public void addCompressProperty()
  {
    int i = 0;
    for (i = 0; i < this.m_table.getRowCount(); i++)
    {
      String str = (String)getValueAt(i, 0);
      if (str.equals("JMS_TIBCO_COMPRESS")) {
        return;
      }
      if (!str.startsWith("JMS")) {
        break;
      }
    }
    Object[] arrayOfObject = { "JMS_TIBCO_COMPRESS", new Boolean("true") };
    insertRow(i, arrayOfObject);
  }
  
  public void addPreserveProperty()
  {
    int i = 0;
    for (i = 0; i < this.m_table.getRowCount(); i++)
    {
      String str = (String)getValueAt(i, 0);
      if (str.equals("JMS_TIBCO_PRESERVE_UNDELIVERED")) {
        return;
      }
      if (!str.startsWith("JMS")) {
        break;
      }
    }
    Object[] arrayOfObject = { "JMS_TIBCO_PRESERVE_UNDELIVERED", new Boolean("true") };
    insertRow(i, arrayOfObject);
  }
  
  public void addEmptyPropertyInfo(int paramInt)
  {
    for (int i = 0; i < paramInt; i++)
    {
      String[] arrayOfString = { new String(), new String() };
      addRow(arrayOfString);
    }
  }
  
  public void addBooleanProperty()
  {
    Object[] arrayOfObject = { "boolean" + this.m_table.getColumnName(0), new Boolean("true") };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addByteProperty()
  {
    Object[] arrayOfObject = { "byte" + this.m_table.getColumnName(0), new Byte(0) };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addFloatProperty()
  {
    Object[] arrayOfObject = { "float" + this.m_table.getColumnName(0), new Float(0.0D) };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addDoubleProperty()
  {
    Object[] arrayOfObject = { "double" + this.m_table.getColumnName(0), new Double(0.0D) };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addStringProperty()
  {
    Object[] arrayOfObject = { "string" + this.m_table.getColumnName(0), new String() };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addShortProperty()
  {
    Object[] arrayOfObject = { "short" + this.m_table.getColumnName(0), new Short(0) };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addLongProperty()
  {
    Object[] arrayOfObject = { "long" + this.m_table.getColumnName(0), new Long(0L) };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addIntProperty()
  {
    Object[] arrayOfObject = { "int" + this.m_table.getColumnName(0), new Integer(0) };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  public void addIntegerProperty(String paramString, Integer paramInteger)
  {
    Object[] arrayOfObject = { paramString, paramInteger };
    addRow(arrayOfObject);
    this.m_table.changeSelection(this.m_table.getRowCount() - 1, 0, false, false);
  }
  
  private class MultiEditor
    implements TableCellEditor
  {
    private static final int DEFAULT = 0;
    private static final int COMBO_BOOL = 1;
    private static final int COMBO_DELMODE = 2;
    private static final int NOEDIT_DEST = 3;
    private DefaultCellEditor[] cellEditors = new DefaultCellEditor[4];
    private JComboBox delmodeComboBox = new JComboBox();
    private JComboBox boolComboBox;
    private JTextField noEditTextField = new JTextField();
    private int cellEditorID;
    private Object currObj = null;
    
    public MultiEditor()
    {
      for (GemsMsgPropTableModel.DELMODE localDELMODE : GemsMsgPropTableModel.DELMODE.values()) {
        this.delmodeComboBox.addItem(localDELMODE);
      }
      this.cellEditors[2] = new DefaultCellEditor(this.delmodeComboBox);
      this.boolComboBox = new JComboBox();
      this.boolComboBox.addItem("true");
      this.boolComboBox.addItem("false");
      this.cellEditors[1] = new DefaultCellEditor(this.boolComboBox);
      this.cellEditors[0] = new DefaultCellEditor(new JTextField());
      this.noEditTextField.setEditable(false);
      this.cellEditors[3] = new DefaultCellEditor(this.noEditTextField);
      this.cellEditorID = 0;
    }
    
    public Component getTableCellEditorComponent(JTable paramJTable, Object paramObject, boolean paramBoolean, int paramInt1, int paramInt2)
    {
      this.currObj = paramObject;
      if ((paramObject instanceof GemsMsgPropTableModel.DELMODE))
      {
        this.cellEditorID = 2;
      }
      else if ((paramObject instanceof Boolean))
      {
        this.cellEditorID = 1;
        this.boolComboBox.setSelectedItem(paramObject.toString());
      }
      else if ((paramObject instanceof GemsDestination))
      {
        for (Container localContainer = GemsMsgPropTableModel.this.m_table.getParent(); localContainer != null; localContainer = localContainer.getParent()) {
          if ((localContainer instanceof GemsMessageFrame))
          {
            GemsDestinationPicker localGemsDestinationPicker = new GemsDestinationPicker((JFrame)localContainer, ((GemsMessageFrame)localContainer).m_cn);
            if (localGemsDestinationPicker.m_retDest == null) {
              break;
            }
            this.currObj = localGemsDestinationPicker.m_retDest;
            paramObject = this.currObj;
            break;
          }
        }
        this.cellEditorID = 3;
      }
      else
      {
        this.cellEditorID = 0;
      }
      return this.cellEditors[this.cellEditorID].getTableCellEditorComponent(paramJTable, paramObject, paramBoolean, paramInt1, paramInt2);
    }
    
    public Object getCellEditorValue()
    {
      switch (this.cellEditorID)
      {
      case 2: 
        return this.delmodeComboBox.getSelectedItem();
      case 1: 
        return new Boolean((String)this.boolComboBox.getSelectedItem());
      case 3: 
        return this.currObj;
      }
      try
      {
        Object localObject = this.cellEditors[this.cellEditorID].getCellEditorValue();
        if ((this.currObj instanceof String)) {
          return localObject;
        }
        if ((this.currObj instanceof Integer)) {
          return new Integer((String)localObject);
        }
        if ((this.currObj instanceof Long)) {
          return new Long((String)localObject);
        }
        if ((this.currObj instanceof Short)) {
          return new Short((String)localObject);
        }
        if ((this.currObj instanceof Byte)) {
          return new Byte((String)localObject);
        }
        if ((this.currObj instanceof Float)) {
          return new Float((String)localObject);
        }
        if ((this.currObj instanceof Double)) {
          return new Double((String)localObject);
        }
        return localObject;
      }
      catch (Exception localException)
      {
        JOptionPane.showMessageDialog(null, localException.getMessage(), "Error", 1);
        System.err.println("Exception: " + localException.getMessage());
      }
      return this.currObj;
    }
    
    public Component getComponent()
    {
      return this.cellEditors[this.cellEditorID].getComponent();
    }
    
    public boolean stopCellEditing()
    {
      return this.cellEditors[this.cellEditorID].stopCellEditing();
    }
    
    public void cancelCellEditing()
    {
      this.cellEditors[this.cellEditorID].cancelCellEditing();
    }
    
    public boolean isCellEditable(EventObject paramEventObject)
    {
      return this.cellEditors[this.cellEditorID].isCellEditable(paramEventObject);
    }
    
    public boolean shouldSelectCell(EventObject paramEventObject)
    {
      return this.cellEditors[this.cellEditorID].shouldSelectCell(paramEventObject);
    }
    
    public void addCellEditorListener(CellEditorListener paramCellEditorListener)
    {
      this.cellEditors[this.cellEditorID].addCellEditorListener(paramCellEditorListener);
    }
    
    public void removeCellEditorListener(CellEditorListener paramCellEditorListener)
    {
      this.cellEditors[this.cellEditorID].removeCellEditorListener(paramCellEditorListener);
    }
    
    public void setClickCountToStart(int paramInt)
    {
      this.cellEditors[this.cellEditorID].setClickCountToStart(paramInt);
    }
    
    public int getClickCountToStart()
    {
      return this.cellEditors[this.cellEditorID].getClickCountToStart();
    }
  }
  
  class MultiRenderer
    extends DefaultTableCellRenderer
  {
    public MultiRenderer() {}
    
    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      Component localComponent = super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
      return super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
    }
  }
  
  private static enum DELMODE
  {
    NON_PERSISTENT,  PERSISTENT,  RELIABLE;
    
    private DELMODE() {}
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsMsgPropTableModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */