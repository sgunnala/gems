package com.tibco.gems;

import com.tibco.tibjms.admin.ServerInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import java.io.PrintStream;
import java.util.Enumeration;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.text.Position.Bias;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class GemsTreeModel
  extends DefaultTreeModel
  implements TreeSelectionListener
{
  DefaultMutableTreeNode m_root;
  JTree m_tree;
  Gems m_gems;
  
  public GemsTreeModel(DefaultMutableTreeNode paramDefaultMutableTreeNode)
  {
    super(paramDefaultMutableTreeNode);
    this.m_root = paramDefaultMutableTreeNode;
  }
  
  public void valueForPathChanged(TreePath paramTreePath, Object paramObject)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)paramTreePath.getLastPathComponent();
    nodeChanged(localDefaultMutableTreeNode);
  }
  
  public GemsConnectionNode newJMSConnection(DefaultMutableTreeNode paramDefaultMutableTreeNode, String paramString)
  {
    GemsConnectionNode localGemsConnectionNode = new GemsConnectionNode(paramString);
    paramDefaultMutableTreeNode.add(localGemsConnectionNode);
    return localGemsConnectionNode;
  }
  
  public void reloadTree()
  {
    reload();
    this.m_tree.expandPath(new TreePath(this.m_root.getPath()));
    this.m_tree.setSelectionPath(new TreePath(this.m_root.getPath()));
  }
  
  public GemsConnectionNode newJMSConnection(String paramString)
  {
    GemsConnectionNode localGemsConnectionNode = new GemsConnectionNode(paramString);
    this.m_root.add(localGemsConnectionNode);
    reload();
    this.m_tree.expandPath(new TreePath(localGemsConnectionNode.getPath()));
    this.m_tree.setSelectionPath(new TreePath(localGemsConnectionNode.getPath()));
    return localGemsConnectionNode;
  }
  
  public boolean connectCurrentNode(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    TreePath localTreePath = this.m_tree.getSelectionPath();
    if (localTreePath == null) {
      return false;
    }
    if (!(localTreePath.getLastPathComponent() instanceof GemsConnectionNode)) {
      return false;
    }
    GemsConnectionNode localGemsConnectionNode = (GemsConnectionNode)localTreePath.getLastPathComponent();
    if (localGemsConnectionNode == null) {
      return false;
    }
    localGemsConnectionNode.connect(paramString1, paramString2, paramString3, paramString4);
    reload();
    this.m_tree.expandPath(new TreePath(localGemsConnectionNode.getPath()));
    this.m_tree.setSelectionPath(new TreePath(localGemsConnectionNode.getPath()));
    return localGemsConnectionNode.isConnected();
  }
  
  public void disconnectCurrentNode()
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
        break;
      }
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      localGemsConnectionNode.disconnect();
      reload();
      this.m_tree.expandPath(new TreePath(localDefaultMutableTreeNode.getPath()));
      this.m_tree.setSelectionPath(new TreePath(localDefaultMutableTreeNode.getPath()));
    }
  }
  
  public void detailsPanelDoubleClick(String paramString)
  {
    if (paramString == null) {
      return;
    }
    DefaultMutableTreeNode localDefaultMutableTreeNode1 = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    if (localDefaultMutableTreeNode1 == null) {
      return;
    }
    this.m_tree.expandPath(new TreePath(localDefaultMutableTreeNode1.getPath()));
    String str1 = (String)localDefaultMutableTreeNode1.getUserObject();
    DefaultMutableTreeNode localDefaultMutableTreeNode2 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
    String str2 = null;
    if (localDefaultMutableTreeNode2 != null) {
      str2 = (String)localDefaultMutableTreeNode2.getUserObject();
    }
    TreePath localTreePath = this.m_tree.getNextMatch(paramString, this.m_tree.getRowForPath(new TreePath(localDefaultMutableTreeNode1.getPath())), Position.Bias.Forward);
    if (str1.startsWith("Topics"))
    {
      if (localTreePath == null) {
        createTopic(paramString, true);
      } else {
        this.m_tree.setSelectionPath(localTreePath);
      }
    }
    else if (str1.startsWith("Queues"))
    {
      if (localTreePath == null) {
        createQueue(paramString, true);
      } else {
        this.m_tree.setSelectionPath(localTreePath);
      }
    }
    else if ((!Gems.getGems().getViewOnlyMode()) && (localDefaultMutableTreeNode2 != null) && (str2.startsWith("Topics")))
    {
      ((GemsTopicNode)localDefaultMutableTreeNode1).setProperty((GemsConnectionNode)localDefaultMutableTreeNode2.getParent(), paramString);
    }
    else if ((!Gems.getGems().getViewOnlyMode()) && (localDefaultMutableTreeNode2 != null) && (str2.startsWith("Queues")))
    {
      ((GemsQueueNode)localDefaultMutableTreeNode1).setProperty((GemsConnectionNode)localDefaultMutableTreeNode2.getParent(), paramString);
    }
    else
    {
      Object localObject;
      if ((!Gems.getGems().getViewOnlyMode()) && (str1.equals("ACLs"))) {
        localObject = new GemsPermissionDialog(Gems.getGems().m_frame, (GemsConnectionNode)localDefaultMutableTreeNode1.getParent(), paramString, Gems.getGems().getDetailsPanel().getModel().getSelectedCol(2), Gems.getGems().getDetailsPanel().getModel().getSelectedCol(3), Gems.getGems().getDetailsPanel().getModel().getSelectedCol(4), Gems.getGems().getDetailsPanel().getModel().getSelectedCol(5));
      } else if ((!Gems.getGems().getViewOnlyMode()) && (str1.equals("AdminACLs"))) {
        localObject = new GemsAdminPermissionDialog(Gems.getGems().m_frame, (GemsConnectionNode)localDefaultMutableTreeNode1.getParent(), paramString, Gems.getGems().getDetailsPanel().getModel().getSelectedCol(2), Gems.getGems().getDetailsPanel().getModel().getSelectedCol(3));
      } else if (localTreePath != null) {
        this.m_tree.setSelectionPath(localTreePath);
      }
    }
  }
  
  public void setServerTrace()
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    if (localDefaultMutableTreeNode == null) {
      return;
    }
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
        break;
      }
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      GemsTraceDialog localGemsTraceDialog = new GemsTraceDialog(Gems.getGems().m_frame, localGemsConnectionNode);
    }
  }
  
  public void serverPanelDoubleClick(String paramString)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    if (localDefaultMutableTreeNode == null) {
      return;
    }
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
        break;
      }
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      localGemsConnectionNode.setServerProperty(paramString);
    }
  }
  
  public void serverMonitorDoubleClick(String paramString)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    if (localDefaultMutableTreeNode == null) {
      return;
    }
    this.m_tree.expandPath(new TreePath(localDefaultMutableTreeNode.getPath()));
    TreePath localTreePath = find2(this.m_tree, new TreePath(localDefaultMutableTreeNode.getPath()), paramString, localDefaultMutableTreeNode.getLevel(), true);
    if (localTreePath != null) {
      this.m_tree.setSelectionPath(localTreePath);
    }
  }
  
  public TreePath findByName(JTree paramJTree, String paramString)
  {
    TreeNode localTreeNode = (TreeNode)paramJTree.getModel().getRoot();
    return find2(paramJTree, new TreePath(localTreeNode), paramString, 0, true);
  }
  
  private TreePath find2(JTree paramJTree, TreePath paramTreePath, Object paramObject, int paramInt, boolean paramBoolean)
  {
    TreeNode localTreeNode1 = (TreeNode)paramTreePath.getLastPathComponent();
    Object localObject = localTreeNode1;
    if (paramBoolean) {
      localObject = localObject.toString();
    }
    if (localObject.equals(paramObject)) {
      return paramTreePath;
    }
    if (localTreeNode1.getChildCount() >= 0)
    {
      Enumeration localEnumeration = localTreeNode1.children();
      while (localEnumeration.hasMoreElements())
      {
        TreeNode localTreeNode2 = (TreeNode)localEnumeration.nextElement();
        TreePath localTreePath1 = paramTreePath.pathByAddingChild(localTreeNode2);
        TreePath localTreePath2 = find2(paramJTree, localTreePath1, paramObject, paramInt + 1, paramBoolean);
        if (localTreePath2 != null) {
          return localTreePath2;
        }
      }
    }
    return null;
  }
  
  public void createQueue(String paramString, boolean paramBoolean)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode1 = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode1.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode1 instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode1;
        break;
      }
      localDefaultMutableTreeNode1 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = localGemsConnectionNode.createQueue(paramString, paramBoolean);
      if (localDefaultMutableTreeNode2 == null) {
        return;
      }
      reload();
      this.m_tree.expandPath(new TreePath(((DefaultMutableTreeNode)localDefaultMutableTreeNode2.getParent()).getPath()));
      this.m_tree.setSelectionPath(new TreePath(localDefaultMutableTreeNode2.getPath()));
    }
  }
  
  public void removeQueue(String paramString)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    while (!(localDefaultMutableTreeNode instanceof GemsConnectionNode))
    {
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
      if (localDefaultMutableTreeNode == null) {
        return;
      }
    }
    if (!Gems.getGems().isStandbyOpsAllowed((GemsConnectionNode)localDefaultMutableTreeNode)) {
      return;
    }
    localDefaultMutableTreeNode = ((GemsConnectionNode)localDefaultMutableTreeNode).removeQueue(paramString);
    this.m_tree.updateUI();
    reload();
    this.m_tree.expandPath(new TreePath(localDefaultMutableTreeNode.getPath()));
    this.m_tree.setSelectionPath(new TreePath(localDefaultMutableTreeNode.getPath()));
  }
  
  public ServerInfo getSelectedJmsServerInfo()
  {
    TreePath localTreePath = this.m_tree.getSelectionPath();
    if (localTreePath != null)
    {
      DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localTreePath.getLastPathComponent();
      if (localDefaultMutableTreeNode == null) {
        return null;
      }
      if (localDefaultMutableTreeNode.getLevel() < 0) {
        return null;
      }
      GemsConnectionNode localGemsConnectionNode = null;
      while (localDefaultMutableTreeNode.getLevel() > 0)
      {
        if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
        {
          localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
          break;
        }
        localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
      }
      System.out.println("In getSelectedJmsServerInfo!");
      if (localGemsConnectionNode != null) {
        return localGemsConnectionNode.getJmsServerInfo(false);
      }
    }
    return null;
  }
  
  public TibjmsAdmin getSelectedJmsAdmin()
  {
    TreePath localTreePath = this.m_tree.getSelectionPath();
    if (localTreePath != null)
    {
      DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)localTreePath.getLastPathComponent();
      if (localDefaultMutableTreeNode == null) {
        return null;
      }
      if (localDefaultMutableTreeNode.getLevel() < 0) {
        return null;
      }
      GemsConnectionNode localGemsConnectionNode = null;
      while (localDefaultMutableTreeNode.getLevel() > 0)
      {
        if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
        {
          localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
          break;
        }
        localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
      }
      if (localGemsConnectionNode != null) {
        return localGemsConnectionNode.getJmsAdmin();
      }
    }
    return null;
  }
  
  public void valueChanged(TreeSelectionEvent paramTreeSelectionEvent)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getLastSelectedPathComponent();
    TreePath localTreePath = this.m_tree.getSelectionPath();
    if (localTreePath != null) {
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localTreePath.getLastPathComponent();
    }
    if (localDefaultMutableTreeNode == null) {
      return;
    }
    this.m_gems.treeSelectionChange(localDefaultMutableTreeNode, false);
  }
  
  public void createTopic(String paramString, boolean paramBoolean)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode1 = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode1.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode1 instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode1;
        break;
      }
      localDefaultMutableTreeNode1 = (DefaultMutableTreeNode)localDefaultMutableTreeNode1.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      DefaultMutableTreeNode localDefaultMutableTreeNode2 = localGemsConnectionNode.createTopic(paramString, paramBoolean);
      if (localDefaultMutableTreeNode2 == null) {
        return;
      }
      reload();
      this.m_tree.expandPath(new TreePath(((DefaultMutableTreeNode)localDefaultMutableTreeNode2.getParent()).getPath()));
      this.m_tree.setSelectionPath(new TreePath(localDefaultMutableTreeNode2.getPath()));
    }
  }
  
  public void removeTopic(String paramString)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
        break;
      }
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      localDefaultMutableTreeNode = localGemsConnectionNode.removeTopic(paramString);
      if (localDefaultMutableTreeNode == null) {
        return;
      }
      this.m_tree.updateUI();
      reload();
      this.m_tree.expandPath(new TreePath(localDefaultMutableTreeNode.getPath()));
      this.m_tree.setSelectionPath(new TreePath(localDefaultMutableTreeNode.getPath()));
    }
  }
  
  public void purgeTopic(String paramString)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
        break;
      }
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      localGemsConnectionNode.purgeTopic(paramString);
    }
  }
  
  public void purgeQueue(String paramString)
  {
    DefaultMutableTreeNode localDefaultMutableTreeNode = (DefaultMutableTreeNode)this.m_tree.getSelectionPath().getLastPathComponent();
    GemsConnectionNode localGemsConnectionNode = null;
    while (localDefaultMutableTreeNode.getLevel() > 0)
    {
      if ((localDefaultMutableTreeNode instanceof GemsConnectionNode))
      {
        localGemsConnectionNode = (GemsConnectionNode)localDefaultMutableTreeNode;
        break;
      }
      localDefaultMutableTreeNode = (DefaultMutableTreeNode)localDefaultMutableTreeNode.getParent();
    }
    if (localGemsConnectionNode != null)
    {
      if (!Gems.getGems().isStandbyOpsAllowed(localGemsConnectionNode)) {
        return;
      }
      localGemsConnectionNode.purgeQueue(paramString);
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsTreeModel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */