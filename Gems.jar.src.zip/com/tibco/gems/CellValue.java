package com.tibco.gems;

public class CellValue
  implements Comparable
{
  public String m_cellValue;
  public long m_value = -99L;
  public Long m_warnLimit = null;
  public Long m_errorLimit = null;
  
  public CellValue(String paramString, long paramLong, Long paramLong1, Long paramLong2)
  {
    this.m_cellValue = paramString;
    this.m_value = paramLong;
    this.m_warnLimit = paramLong1;
    this.m_errorLimit = paramLong2;
  }
  
  public CellValue(String paramString, int paramInt, Long paramLong1, Long paramLong2)
  {
    this.m_cellValue = paramString;
    this.m_value = paramInt;
    this.m_warnLimit = paramLong1;
    this.m_errorLimit = paramLong2;
  }
  
  public CellValue(char[] paramArrayOfChar)
  {
    this.m_cellValue = new String(paramArrayOfChar);
  }
  
  public CellValue(String paramString)
  {
    this.m_cellValue = paramString;
  }
  
  public CellValue(String paramString, int paramInt)
  {
    this.m_cellValue = paramString;
    this.m_value = paramInt;
  }
  
  public CellValue(String paramString, long paramLong)
  {
    this.m_cellValue = paramString;
    this.m_value = paramLong;
  }
  
  public String toString()
  {
    return this.m_cellValue;
  }
  
  public int compareTo(Object paramObject)
    throws ClassCastException
  {
    CellValue localCellValue = (CellValue)paramObject;
    if (this.m_value > localCellValue.m_value) {
      return 1;
    }
    if (this.m_value == localCellValue.m_value) {
      return 0;
    }
    return -1;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\CellValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */