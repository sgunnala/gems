package com.tibco.gems;

import java.text.MessageFormat;
import java.text.NumberFormat;

public abstract class StringUtilities
{
  public static String getHumanReadableSize(long paramLong)
  {
    long l1 = Math.pow(2.0D, 20.0D);
    long l2 = Math.pow(2.0D, 10.0D);
    long l3 = Math.pow(2.0D, 30.0D);
    NumberFormat localNumberFormat = NumberFormat.getNumberInstance();
    localNumberFormat.setMaximumFractionDigits(1);
    double d = 0.0D;
    long l4 = Math.abs(paramLong);
    String str = "";
    if (l4 / l3 >= 1L)
    {
      d = l4 / l3;
      str = "GB";
    }
    else if (l4 / l1 >= 1L)
    {
      d = l4 / l1;
      str = "MB";
    }
    else if (l4 / l2 >= 1L)
    {
      d = l4 / l2;
      str = "KB";
    }
    else
    {
      d = l4;
      str = "b";
    }
    return localNumberFormat.format((paramLong < 0L ? -1 : 1) * d) + str;
  }
  
  public static String dumpBytes(byte[] paramArrayOfByte)
  {
    StringBuffer localStringBuffer = new StringBuffer(paramArrayOfByte.length);
    for (int i = 0; i < paramArrayOfByte.length; i++)
    {
      String str = Integer.toHexString(256 + (paramArrayOfByte[i] & 0xFF)).substring(1);
      localStringBuffer.append((str.length() < 2 ? "0" : "") + str);
    }
    return localStringBuffer.toString();
  }
  
  public static String arrayToString(Object[] paramArrayOfObject)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; (paramArrayOfObject != null) && (i < paramArrayOfObject.length); i++)
    {
      localStringBuffer.append(paramArrayOfObject[i].toString());
      if (((paramArrayOfObject[i] instanceof String)) && (i + 1 < paramArrayOfObject.length)) {
        localStringBuffer.append(", ");
      }
    }
    return localStringBuffer.toString();
  }
  
  public static String getFullHumanReadableTime(long paramLong)
  {
    long l1 = 1000L;
    long l2 = 60L * l1;
    long l3 = 60L * l2;
    long l4 = 24L * l3;
    NumberFormat localNumberFormat = NumberFormat.getNumberInstance();
    localNumberFormat.setMaximumFractionDigits(0);
    StringBuffer localStringBuffer = new StringBuffer("");
    double d = 0.0D;
    int i = 1;
    int j = 0;
    long l5 = Math.abs(paramLong);
    String str = null;
    while (l5 >= 1L)
    {
      localStringBuffer.append(" ");
      if (l5 / l4 >= 1L)
      {
        j = 0;
        d = l5 / l4;
        l5 -= l4 * d;
        i = 0;
        str = "Days";
      }
      else if (l5 / l3 >= 1L)
      {
        j = 0;
        d = l5 / l3;
        str = "Hours";
        l5 -= l3 * d;
      }
      else if (l5 / l2 >= 1L)
      {
        j = 0;
        d = l5 / l2;
        str = "Minutes";
        l5 -= l2 * d;
      }
      else if (l5 / l1 >= 1L)
      {
        j = 0;
        d = l5 / l1;
        str = "Seconds";
        l5 -= l1 * d;
        if (i != 0) {}
      }
      else
      {
        if (j != 0)
        {
          d = l5;
          str = "Millisconds";
        }
        l5 -= l5;
        if (j == 0) {
          continue;
        }
      }
      Object[] arrayOfObject = { localNumberFormat.format(Math.floor(d)), str };
      localStringBuffer.append(MessageFormat.format("{0} {1}", arrayOfObject));
    }
    return localStringBuffer.toString().trim();
  }
  
  public static String stripSpaces(String paramString)
  {
    return paramString.replaceAll("\\s+", "");
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\StringUtilities.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */