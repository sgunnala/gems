package com.tibco.gems;

import com.tibco.tibjms.admin.TibjmsAdmin;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.jms.Message;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class GemsMessagePanel
  extends JPanel
{
  protected GemsMessageTableModel m_tableModel;
  JTable m_table;
  TibjmsAdmin m_admin = null;
  TableSorter m_sorter;
  
  public GemsMessagePanel()
  {
    super(true);
    setLayout(new BorderLayout());
    this.m_tableModel = new GemsMessageTableModel(false, false);
    this.m_sorter = new TableSorter(this.m_tableModel);
    this.m_table = new JTable(this.m_sorter);
    this.m_sorter.setTableHeader(this.m_table.getTableHeader());
    this.m_table.setSelectionMode(0);
    this.m_tableModel.m_table = this.m_table;
    addMouseListenerToTable(this.m_table);
    JScrollPane localJScrollPane = new JScrollPane(this.m_table);
    add(localJScrollPane, "Center");
  }
  
  public GemsMessageTableModel getModel()
  {
    return this.m_tableModel;
  }
  
  public void addMouseListenerToTable(JTable paramJTable)
  {
    MouseAdapter local1 = new MouseAdapter()
    {
      public void mouseClicked(MouseEvent paramAnonymousMouseEvent)
      {
        if (paramAnonymousMouseEvent.getClickCount() == 2)
        {
          Message localMessage = GemsMessagePanel.this.m_tableModel.getSelectedMessage();
          if (localMessage != null)
          {
            GemsMessageFrame localGemsMessageFrame = new GemsMessageFrame(null, false, null, false, null, true);
            localGemsMessageFrame.populate(localMessage);
          }
        }
      }
    };
    paramJTable.addMouseListener(local1);
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsMessagePanel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */