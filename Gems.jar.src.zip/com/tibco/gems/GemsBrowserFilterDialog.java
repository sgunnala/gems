package com.tibco.gems;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class GemsBrowserFilterDialog
  extends JDialog
{
  protected JTextField m_filter;
  protected boolean m_cancelled = false;
  protected Frame m_frame;
  protected Pattern m_pattern = null;
  
  public GemsBrowserFilterDialog(Frame paramFrame, String paramString)
  {
    super(paramFrame, paramString, true);
    this.m_frame = paramFrame;
  }
  
  public Pattern getFilter(Pattern paramPattern, String paramString)
  {
    Font localFont = new Font("Serif", 0, 14);
    JPanel localJPanel1 = new JPanel();
    localJPanel1.setLayout(new BoxLayout(localJPanel1, 1));
    JPanel localJPanel2 = new JPanel(new BorderLayout(10, 10));
    localJPanel1.add(localJPanel2);
    localJPanel2.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    JLabel localJLabel1 = new JLabel("Only show " + paramString + " that match this regex:");
    localJLabel1.setFont(localFont);
    this.m_filter = new JTextField(paramPattern != null ? paramPattern.pattern() : "");
    this.m_filter.setFont(localFont);
    localJPanel2.add(localJLabel1, "North");
    localJPanel2.add(this.m_filter, "Center");
    JLabel localJLabel2 = new JLabel("<html>Example: &nbsp;&nbsp;.*[Ee]rror.* &nbsp;&nbsp;matches " + paramString + " containing Error or error</html>");
    localJLabel2.setFont(localFont);
    localJLabel2.setEnabled(false);
    localJPanel2.add(localJLabel2, "South");
    JPanel localJPanel3 = new JPanel();
    localJPanel3.setLayout(new FlowLayout());
    JButton localJButton1 = new JButton("OK ");
    JButton localJButton2 = new JButton("Cancel ");
    localJPanel3.add(localJButton1);
    localJPanel3.add(localJButton2);
    localJButton1.addActionListener(new OkPressed());
    localJButton2.addActionListener(new CancelPressed());
    localJPanel1.add(localJPanel3);
    setContentPane(localJPanel1);
    setLocationRelativeTo(this.m_frame);
    pack();
    show();
    if (!this.m_cancelled) {
      return this.m_pattern;
    }
    return null;
  }
  
  class CancelPressed
    implements ActionListener
  {
    CancelPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsBrowserFilterDialog.this.m_cancelled = true;
      GemsBrowserFilterDialog.this.dispose();
    }
  }
  
  class OkPressed
    implements ActionListener
  {
    OkPressed() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      try
      {
        GemsBrowserFilterDialog.this.m_pattern = Pattern.compile(GemsBrowserFilterDialog.this.m_filter.getText());
      }
      catch (Exception localException)
      {
        JOptionPane.showMessageDialog(GemsBrowserFilterDialog.this.m_frame, localException.getMessage(), "Error", 1);
        System.err.println("Exception: " + localException.getMessage());
        return;
      }
      GemsBrowserFilterDialog.this.dispose();
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsBrowserFilterDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */