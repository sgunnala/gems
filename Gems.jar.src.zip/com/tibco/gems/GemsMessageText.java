package com.tibco.gems;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.StringReader;
import javax.jms.BytesMessage;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.swing.JTextArea;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class GemsMessageText
  extends JTextArea
{
  public static final int MODE_NONE = 0;
  public static final int MODE_HEXBYTES = 1;
  public static final int MODE_ASCIIBYTES = 2;
  public static final int MODE_TEXT = 3;
  public static final int MODE_XML = 4;
  protected int m_mode = 0;
  protected Message m_msg = null;
  protected JTextArea m_text = null;
  
  public int getMode()
  {
    return this.m_mode;
  }
  
  public void setMode(int paramInt)
  {
    if (this.m_msg == null) {
      return;
    }
    try
    {
      Object localObject1;
      Object localObject2;
      if ((this.m_msg instanceof BytesMessage))
      {
        long l;
        if (paramInt == 1)
        {
          localObject1 = (BytesMessage)this.m_msg;
          ((BytesMessage)localObject1).reset();
          l = ((BytesMessage)localObject1).getBodyLength();
          if (l > Gems.getGems().getMaxDisplayBytes())
          {
            System.err.println("Warning: Bytes message display limited to " + Gems.getGems().getMaxDisplayBytes() + " bytes (configurable in gems.props)");
            l = Gems.getGems().getMaxDisplayBytes();
          }
          localObject2 = new byte[(int)l];
          ((BytesMessage)localObject1).readBytes((byte[])localObject2, (int)l);
          setText(StringUtilities.dumpBytes((byte[])localObject2));
          this.m_mode = 1;
        }
        else if (paramInt == 2)
        {
          localObject1 = (BytesMessage)this.m_msg;
          ((BytesMessage)localObject1).reset();
          l = ((BytesMessage)localObject1).getBodyLength();
          if (l > Gems.getGems().getMaxDisplayBytes())
          {
            System.err.println("Warning: Bytes message display limited to " + Gems.getGems().getMaxDisplayBytes() + " bytes (configurable in gems.props)");
            l = Gems.getGems().getMaxDisplayBytes();
          }
          localObject2 = new byte[(int)l];
          ((BytesMessage)localObject1).readBytes((byte[])localObject2, (int)l);
          setText(new String((byte[])localObject2));
          this.m_mode = 2;
        }
      }
      else if ((this.m_msg instanceof TextMessage))
      {
        localObject1 = (TextMessage)this.m_msg;
        if (paramInt == 3)
        {
          setText(((TextMessage)localObject1).getText());
          this.m_mode = 3;
        }
        else if (paramInt == 4)
        {
          try
          {
            DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
            localObject2 = localDocumentBuilder.parse(new InputSource(new StringReader(((TextMessage)localObject1).getText())));
            TransformerFactory localTransformerFactory = TransformerFactory.newInstance();
            Transformer localTransformer = localTransformerFactory.newTransformer();
            localTransformer.setOutputProperty("indent", "yes");
            localTransformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
            ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
            localTransformer.transform(new DOMSource((Node)localObject2), new StreamResult(localByteArrayOutputStream));
            setText(localByteArrayOutputStream.toString());
            this.m_mode = 4;
          }
          catch (Exception localException2)
          {
            System.err.println("Exception: " + localException2.getMessage());
            setText(((TextMessage)localObject1).getText());
            this.m_mode = 3;
          }
        }
      }
    }
    catch (Exception localException1)
    {
      System.err.println("Exception: " + localException1.getMessage());
      return;
    }
  }
  
  public void setMessageText(Message paramMessage)
  {
    this.m_msg = paramMessage;
    this.m_mode = 0;
    try
    {
      Object localObject;
      if ((paramMessage instanceof TextMessage))
      {
        localObject = (TextMessage)paramMessage;
        setText(((TextMessage)localObject).getText());
        this.m_mode = 3;
      }
      else if ((paramMessage instanceof MapMessage))
      {
        localObject = (MapMessage)paramMessage;
        setText(localObject.toString());
      }
      else if ((paramMessage instanceof BytesMessage))
      {
        localObject = (BytesMessage)paramMessage;
        ((BytesMessage)localObject).reset();
        long l = ((BytesMessage)localObject).getBodyLength();
        if (l > Gems.getGems().getMaxDisplayBytes())
        {
          System.err.println("Warning: Bytes message display limited to " + Gems.getGems().getMaxDisplayBytes() + " bytes (configurable in gems.props)");
          l = Gems.getGems().getMaxDisplayBytes();
        }
        byte[] arrayOfByte = new byte[(int)l];
        ((BytesMessage)localObject).readBytes(arrayOfByte, (int)l);
        setText(StringUtilities.dumpBytes(arrayOfByte));
        this.m_mode = 1;
      }
      else if ((paramMessage instanceof StreamMessage))
      {
        localObject = (StreamMessage)paramMessage;
        setText(localObject.toString());
      }
      else if ((paramMessage instanceof ObjectMessage))
      {
        localObject = (ObjectMessage)paramMessage;
        setText(localObject.toString());
      }
    }
    catch (Exception localException)
    {
      System.err.println("Exception: " + localException.getMessage());
      return;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsMessageText.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */