package com.tibco.gems;

import com.tibco.tibjms.admin.ConnectionFactoryInfo;

public class GemsDummyConnectionFactoryInfo
  extends ConnectionFactoryInfo
{
  String m_factoryName = "";
  
  public GemsDummyConnectionFactoryInfo()
  {
    super("", null, 0, null);
  }
  
  public void setJndiName(String paramString)
  {
    this.m_factoryName = paramString;
  }
  
  public String getJndiName()
  {
    return this.m_factoryName;
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\GemsDummyConnectionFactoryInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */