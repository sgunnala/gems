package com.tibco.gems.chart;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Vector;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

public class GemsChartFieldList
  extends JPanel
  implements GemsTableListModelBase
{
  private static final int[] _columnSizes = { 10, 125 };
  private static final String[] _colunnHeaders = { " ", "Fields" };
  private GemsSubscriptionData _subscriptionData;
  private Vector _listElements;
  private GemsTableListPanel _tableListPanel;
  private GemsChartFrame m_chart;
  protected Timer m_timer = null;
  
  public void resetSelection()
  {
    this._tableListPanel.resetSelection();
  }
  
  public Vector getDataVector()
  {
    return this._listElements;
  }
  
  public int getColumnCount()
  {
    return 2;
  }
  
  public int[] getColumnSizes()
  {
    return _columnSizes;
  }
  
  public String[] getColumnHeadings()
  {
    return _colunnHeaders;
  }
  
  public void SelectChartableField()
  {
    int i = this._tableListPanel.getSelectedIndex();
    if (i == -1) {
      return;
    }
    ChartableField localChartableField = (ChartableField)this._listElements.elementAt(i);
    localChartableField.show = (!localChartableField.show);
    if (!localChartableField.show)
    {
      this.m_chart.removeChartableField(localChartableField.series);
      localChartableField.color = null;
    }
    else
    {
      if (localChartableField.series == -1) {
        if (this.m_timer == null)
        {
          this.m_timer = new Timer(500, new RefreshColorsTimerAction());
          this.m_timer.setInitialDelay(500);
          this.m_timer.start();
        }
        else
        {
          this.m_timer.restart();
        }
      }
      localChartableField.series = i;
      this.m_chart.showChartableField(localChartableField.series);
      localChartableField.color = this.m_chart.getSeriesColor(localChartableField.series);
    }
    this._tableListPanel.getTable().repaint();
  }
  
  public void refreshChartableFieldColors()
  {
    for (int i = 0; i < this._listElements.size(); i++)
    {
      ChartableField localChartableField = (ChartableField)this._listElements.elementAt(i);
      if ((localChartableField.show) && (localChartableField.color == null))
      {
        localChartableField.color = this.m_chart.getSeriesColor(localChartableField.series);
        if ((localChartableField.color == null) && (this.m_timer != null)) {}
        this.m_timer.restart();
      }
    }
    this._tableListPanel.resizeAndRepaint();
  }
  
  public void setListData(Vector paramVector)
  {
    this._listElements = paramVector;
    this._tableListPanel.setListElements(paramVector);
    resetSelection();
  }
  
  public Class getColumnClass(int paramInt)
  {
    if (paramInt == 0) {
      return Boolean.class;
    }
    return String.class;
  }
  
  public Object getValueAt(int paramInt1, int paramInt2)
  {
    ChartableField localChartableField = (ChartableField)this._listElements.elementAt(paramInt1);
    if (localChartableField != null)
    {
      if (paramInt2 == 0) {
        return new Boolean(localChartableField.show);
      }
      return localChartableField.name;
    }
    return "";
  }
  
  public int getRowCount()
  {
    if (this._listElements == null) {
      return 0;
    }
    return this._listElements.size();
  }
  
  public Vector createChartableFields(Vector paramVector)
  {
    Vector localVector = new Vector();
    for (int i = 0; i < paramVector.size(); i++) {
      localVector.addElement(new ChartableField((String)paramVector.elementAt(i), i));
    }
    return localVector;
  }
  
  public GemsChartFieldList(GemsChartFrame paramGemsChartFrame, String paramString, Vector paramVector, GemsSubscriptionData paramGemsSubscriptionData)
  {
    this.m_chart = paramGemsChartFrame;
    setLayout(new BorderLayout());
    setPreferredSize(new Dimension(180, 100));
    setBackground(Color.lightGray);
    this._subscriptionData = paramGemsSubscriptionData;
    this._listElements = createChartableFields(paramVector);
    this._tableListPanel = new GemsTableListPanel(this);
    this._tableListPanel.add(this._tableListPanel.constructListPanel(), "Center");
    JTable localJTable = this._tableListPanel.getTable();
    localJTable.setDefaultRenderer(String.class, new ChartableFieldRenderer(null));
    localJTable.setShowGrid(false);
    localJTable.getColumn("Fields").setPreferredWidth(140);
    JTableHeader localJTableHeader = localJTable.getTableHeader();
    localJTableHeader.setReorderingAllowed(false);
    _cls1 local_cls1 = new _cls1();
    localJTable.addMouseListener(local_cls1);
    add("Center", this._tableListPanel);
  }
  
  private class _cls1
    extends MouseAdapter
  {
    public void mouseClicked(MouseEvent paramMouseEvent)
    {
      GemsChartFieldList.this.SelectChartableField();
    }
    
    _cls1() {}
  }
  
  private class ChartableFieldRenderer
    extends DefaultTableCellRenderer
  {
    public Component getTableCellRendererComponent(JTable paramJTable, Object paramObject, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2)
    {
      GemsChartFieldList.ChartableField localChartableField = (GemsChartFieldList.ChartableField)GemsChartFieldList.this._listElements.elementAt(paramInt1);
      if (localChartableField.show) {
        setBackground(localChartableField.color);
      } else {
        setBackground(Color.white);
      }
      if (paramInt2 > 0)
      {
        paramBoolean1 = false;
        paramBoolean2 = false;
      }
      return super.getTableCellRendererComponent(paramJTable, paramObject, paramBoolean1, paramBoolean2, paramInt1, paramInt2);
    }
    
    ChartableFieldRenderer(GemsChartFieldList._cls1 param_cls1)
    {
      this();
    }
    
    private ChartableFieldRenderer() {}
  }
  
  class RefreshColorsTimerAction
    implements ActionListener
  {
    RefreshColorsTimerAction() {}
    
    public void actionPerformed(ActionEvent paramActionEvent)
    {
      GemsChartFieldList.this.m_timer.stop();
      GemsChartFieldList.this.refreshChartableFieldColors();
    }
  }
  
  private class ChartableField
  {
    boolean show;
    int series;
    String name;
    Color color = null;
    
    ChartableField(String paramString, int paramInt)
    {
      this.name = paramString;
      this.series = -1;
      this.show = false;
    }
  }
}


/* Location:              D:\tools\Gems\Gems.jar!\com\tibco\gems\chart\GemsChartFieldList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */